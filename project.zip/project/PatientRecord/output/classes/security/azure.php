<?php

require_once(getabspath("classes/security.php"));
require_once(getabspath("classes/security/openid.php"));


class SecurityPluginAzure extends SecurityPluginOpenId {
}
?>