<?php
$tdatamedicines_chart = array();
$tdatamedicines_chart[".searchableFields"] = array();
$tdatamedicines_chart[".ShortName"] = "medicines_chart";
$tdatamedicines_chart[".OwnerID"] = "";
$tdatamedicines_chart[".OriginalTable"] = "medicines";


$tdatamedicines_chart[".pagesByType"] = my_json_decode( "{\"chart\":[\"chart\"],\"masterchart\":[\"masterchart\"],\"search\":[\"search\"]}" );
$tdatamedicines_chart[".originalPagesByType"] = $tdatamedicines_chart[".pagesByType"];
$tdatamedicines_chart[".pages"] = types2pages( my_json_decode( "{\"chart\":[\"chart\"],\"masterchart\":[\"masterchart\"],\"search\":[\"search\"]}" ) );
$tdatamedicines_chart[".originalPages"] = $tdatamedicines_chart[".pages"];
$tdatamedicines_chart[".defaultPages"] = my_json_decode( "{\"chart\":\"chart\",\"masterchart\":\"masterchart\",\"search\":\"search\"}" );
$tdatamedicines_chart[".originalDefaultPages"] = $tdatamedicines_chart[".defaultPages"];

//	field labels
$fieldLabelsmedicines_chart = array();
$fieldToolTipsmedicines_chart = array();
$pageTitlesmedicines_chart = array();
$placeHoldersmedicines_chart = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsmedicines_chart["English"] = array();
	$fieldToolTipsmedicines_chart["English"] = array();
	$placeHoldersmedicines_chart["English"] = array();
	$pageTitlesmedicines_chart["English"] = array();
	$fieldLabelsmedicines_chart["English"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["English"]["id"] = "";
	$placeHoldersmedicines_chart["English"]["id"] = "";
	$fieldLabelsmedicines_chart["English"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["English"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["English"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["English"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["English"]["Description"] = "";
	$placeHoldersmedicines_chart["English"]["Description"] = "";
	$fieldLabelsmedicines_chart["English"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["English"]["Type"] = "";
	$placeHoldersmedicines_chart["English"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["English"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsmedicines_chart["Afrikaans"] = array();
	$fieldToolTipsmedicines_chart["Afrikaans"] = array();
	$placeHoldersmedicines_chart["Afrikaans"] = array();
	$pageTitlesmedicines_chart["Afrikaans"] = array();
	$fieldLabelsmedicines_chart["Afrikaans"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Afrikaans"]["id"] = "";
	$placeHoldersmedicines_chart["Afrikaans"]["id"] = "";
	$fieldLabelsmedicines_chart["Afrikaans"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Afrikaans"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Afrikaans"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Afrikaans"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Afrikaans"]["Description"] = "";
	$placeHoldersmedicines_chart["Afrikaans"]["Description"] = "";
	$fieldLabelsmedicines_chart["Afrikaans"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Afrikaans"]["Type"] = "";
	$placeHoldersmedicines_chart["Afrikaans"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Afrikaans"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsmedicines_chart["Arabic"] = array();
	$fieldToolTipsmedicines_chart["Arabic"] = array();
	$placeHoldersmedicines_chart["Arabic"] = array();
	$pageTitlesmedicines_chart["Arabic"] = array();
	$fieldLabelsmedicines_chart["Arabic"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Arabic"]["id"] = "";
	$placeHoldersmedicines_chart["Arabic"]["id"] = "";
	$fieldLabelsmedicines_chart["Arabic"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Arabic"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Arabic"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Arabic"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Arabic"]["Description"] = "";
	$placeHoldersmedicines_chart["Arabic"]["Description"] = "";
	$fieldLabelsmedicines_chart["Arabic"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Arabic"]["Type"] = "";
	$placeHoldersmedicines_chart["Arabic"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Arabic"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsmedicines_chart["Bosnian"] = array();
	$fieldToolTipsmedicines_chart["Bosnian"] = array();
	$placeHoldersmedicines_chart["Bosnian"] = array();
	$pageTitlesmedicines_chart["Bosnian"] = array();
	$fieldLabelsmedicines_chart["Bosnian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Bosnian"]["id"] = "";
	$placeHoldersmedicines_chart["Bosnian"]["id"] = "";
	$fieldLabelsmedicines_chart["Bosnian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Bosnian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Bosnian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Bosnian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Bosnian"]["Description"] = "";
	$placeHoldersmedicines_chart["Bosnian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Bosnian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Bosnian"]["Type"] = "";
	$placeHoldersmedicines_chart["Bosnian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Bosnian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsmedicines_chart["Bulgarian"] = array();
	$fieldToolTipsmedicines_chart["Bulgarian"] = array();
	$placeHoldersmedicines_chart["Bulgarian"] = array();
	$pageTitlesmedicines_chart["Bulgarian"] = array();
	$fieldLabelsmedicines_chart["Bulgarian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Bulgarian"]["id"] = "";
	$placeHoldersmedicines_chart["Bulgarian"]["id"] = "";
	$fieldLabelsmedicines_chart["Bulgarian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Bulgarian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Bulgarian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Bulgarian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Bulgarian"]["Description"] = "";
	$placeHoldersmedicines_chart["Bulgarian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Bulgarian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Bulgarian"]["Type"] = "";
	$placeHoldersmedicines_chart["Bulgarian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Bulgarian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsmedicines_chart["Catalan"] = array();
	$fieldToolTipsmedicines_chart["Catalan"] = array();
	$placeHoldersmedicines_chart["Catalan"] = array();
	$pageTitlesmedicines_chart["Catalan"] = array();
	$fieldLabelsmedicines_chart["Catalan"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Catalan"]["id"] = "";
	$placeHoldersmedicines_chart["Catalan"]["id"] = "";
	$fieldLabelsmedicines_chart["Catalan"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Catalan"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Catalan"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Catalan"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Catalan"]["Description"] = "";
	$placeHoldersmedicines_chart["Catalan"]["Description"] = "";
	$fieldLabelsmedicines_chart["Catalan"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Catalan"]["Type"] = "";
	$placeHoldersmedicines_chart["Catalan"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Catalan"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsmedicines_chart["Chinese"] = array();
	$fieldToolTipsmedicines_chart["Chinese"] = array();
	$placeHoldersmedicines_chart["Chinese"] = array();
	$pageTitlesmedicines_chart["Chinese"] = array();
	$fieldLabelsmedicines_chart["Chinese"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Chinese"]["id"] = "";
	$placeHoldersmedicines_chart["Chinese"]["id"] = "";
	$fieldLabelsmedicines_chart["Chinese"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Chinese"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Chinese"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Chinese"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Chinese"]["Description"] = "";
	$placeHoldersmedicines_chart["Chinese"]["Description"] = "";
	$fieldLabelsmedicines_chart["Chinese"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Chinese"]["Type"] = "";
	$placeHoldersmedicines_chart["Chinese"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Chinese"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsmedicines_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsmedicines_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersmedicines_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesmedicines_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersmedicines_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Chinese (Hong Kong S.A.R.)"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["Description"] = "";
	$placeHoldersmedicines_chart["Chinese (Hong Kong S.A.R.)"]["Description"] = "";
	$fieldLabelsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Chinese (Hong Kong S.A.R.)"]["Type"] = "";
	$placeHoldersmedicines_chart["Chinese (Hong Kong S.A.R.)"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Chinese (Hong Kong S.A.R.)"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsmedicines_chart["Chinese (Taiwan)"] = array();
	$fieldToolTipsmedicines_chart["Chinese (Taiwan)"] = array();
	$placeHoldersmedicines_chart["Chinese (Taiwan)"] = array();
	$pageTitlesmedicines_chart["Chinese (Taiwan)"] = array();
	$fieldLabelsmedicines_chart["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersmedicines_chart["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsmedicines_chart["Chinese (Taiwan)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Chinese (Taiwan)"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Chinese (Taiwan)"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Chinese (Taiwan)"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Chinese (Taiwan)"]["Description"] = "";
	$placeHoldersmedicines_chart["Chinese (Taiwan)"]["Description"] = "";
	$fieldLabelsmedicines_chart["Chinese (Taiwan)"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Chinese (Taiwan)"]["Type"] = "";
	$placeHoldersmedicines_chart["Chinese (Taiwan)"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Chinese (Taiwan)"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsmedicines_chart["Croatian"] = array();
	$fieldToolTipsmedicines_chart["Croatian"] = array();
	$placeHoldersmedicines_chart["Croatian"] = array();
	$pageTitlesmedicines_chart["Croatian"] = array();
	$fieldLabelsmedicines_chart["Croatian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Croatian"]["id"] = "";
	$placeHoldersmedicines_chart["Croatian"]["id"] = "";
	$fieldLabelsmedicines_chart["Croatian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Croatian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Croatian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Croatian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Croatian"]["Description"] = "";
	$placeHoldersmedicines_chart["Croatian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Croatian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Croatian"]["Type"] = "";
	$placeHoldersmedicines_chart["Croatian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Croatian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsmedicines_chart["Czech"] = array();
	$fieldToolTipsmedicines_chart["Czech"] = array();
	$placeHoldersmedicines_chart["Czech"] = array();
	$pageTitlesmedicines_chart["Czech"] = array();
	$fieldLabelsmedicines_chart["Czech"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Czech"]["id"] = "";
	$placeHoldersmedicines_chart["Czech"]["id"] = "";
	$fieldLabelsmedicines_chart["Czech"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Czech"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Czech"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Czech"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Czech"]["Description"] = "";
	$placeHoldersmedicines_chart["Czech"]["Description"] = "";
	$fieldLabelsmedicines_chart["Czech"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Czech"]["Type"] = "";
	$placeHoldersmedicines_chart["Czech"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Czech"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsmedicines_chart["Danish"] = array();
	$fieldToolTipsmedicines_chart["Danish"] = array();
	$placeHoldersmedicines_chart["Danish"] = array();
	$pageTitlesmedicines_chart["Danish"] = array();
	$fieldLabelsmedicines_chart["Danish"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Danish"]["id"] = "";
	$placeHoldersmedicines_chart["Danish"]["id"] = "";
	$fieldLabelsmedicines_chart["Danish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Danish"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Danish"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Danish"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Danish"]["Description"] = "";
	$placeHoldersmedicines_chart["Danish"]["Description"] = "";
	$fieldLabelsmedicines_chart["Danish"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Danish"]["Type"] = "";
	$placeHoldersmedicines_chart["Danish"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Danish"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsmedicines_chart["Dutch"] = array();
	$fieldToolTipsmedicines_chart["Dutch"] = array();
	$placeHoldersmedicines_chart["Dutch"] = array();
	$pageTitlesmedicines_chart["Dutch"] = array();
	$fieldLabelsmedicines_chart["Dutch"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Dutch"]["id"] = "";
	$placeHoldersmedicines_chart["Dutch"]["id"] = "";
	$fieldLabelsmedicines_chart["Dutch"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Dutch"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Dutch"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Dutch"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Dutch"]["Description"] = "";
	$placeHoldersmedicines_chart["Dutch"]["Description"] = "";
	$fieldLabelsmedicines_chart["Dutch"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Dutch"]["Type"] = "";
	$placeHoldersmedicines_chart["Dutch"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Dutch"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsmedicines_chart["Farsi"] = array();
	$fieldToolTipsmedicines_chart["Farsi"] = array();
	$placeHoldersmedicines_chart["Farsi"] = array();
	$pageTitlesmedicines_chart["Farsi"] = array();
	$fieldLabelsmedicines_chart["Farsi"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Farsi"]["id"] = "";
	$placeHoldersmedicines_chart["Farsi"]["id"] = "";
	$fieldLabelsmedicines_chart["Farsi"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Farsi"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Farsi"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Farsi"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Farsi"]["Description"] = "";
	$placeHoldersmedicines_chart["Farsi"]["Description"] = "";
	$fieldLabelsmedicines_chart["Farsi"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Farsi"]["Type"] = "";
	$placeHoldersmedicines_chart["Farsi"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Farsi"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsmedicines_chart["French"] = array();
	$fieldToolTipsmedicines_chart["French"] = array();
	$placeHoldersmedicines_chart["French"] = array();
	$pageTitlesmedicines_chart["French"] = array();
	$fieldLabelsmedicines_chart["French"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["French"]["id"] = "";
	$placeHoldersmedicines_chart["French"]["id"] = "";
	$fieldLabelsmedicines_chart["French"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["French"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["French"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["French"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["French"]["Description"] = "";
	$placeHoldersmedicines_chart["French"]["Description"] = "";
	$fieldLabelsmedicines_chart["French"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["French"]["Type"] = "";
	$placeHoldersmedicines_chart["French"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["French"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsmedicines_chart["Georgian"] = array();
	$fieldToolTipsmedicines_chart["Georgian"] = array();
	$placeHoldersmedicines_chart["Georgian"] = array();
	$pageTitlesmedicines_chart["Georgian"] = array();
	$fieldLabelsmedicines_chart["Georgian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Georgian"]["id"] = "";
	$placeHoldersmedicines_chart["Georgian"]["id"] = "";
	$fieldLabelsmedicines_chart["Georgian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Georgian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Georgian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Georgian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Georgian"]["Description"] = "";
	$placeHoldersmedicines_chart["Georgian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Georgian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Georgian"]["Type"] = "";
	$placeHoldersmedicines_chart["Georgian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Georgian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsmedicines_chart["German"] = array();
	$fieldToolTipsmedicines_chart["German"] = array();
	$placeHoldersmedicines_chart["German"] = array();
	$pageTitlesmedicines_chart["German"] = array();
	$fieldLabelsmedicines_chart["German"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["German"]["id"] = "";
	$placeHoldersmedicines_chart["German"]["id"] = "";
	$fieldLabelsmedicines_chart["German"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["German"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["German"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["German"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["German"]["Description"] = "";
	$placeHoldersmedicines_chart["German"]["Description"] = "";
	$fieldLabelsmedicines_chart["German"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["German"]["Type"] = "";
	$placeHoldersmedicines_chart["German"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["German"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsmedicines_chart["Greek"] = array();
	$fieldToolTipsmedicines_chart["Greek"] = array();
	$placeHoldersmedicines_chart["Greek"] = array();
	$pageTitlesmedicines_chart["Greek"] = array();
	$fieldLabelsmedicines_chart["Greek"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Greek"]["id"] = "";
	$placeHoldersmedicines_chart["Greek"]["id"] = "";
	$fieldLabelsmedicines_chart["Greek"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Greek"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Greek"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Greek"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Greek"]["Description"] = "";
	$placeHoldersmedicines_chart["Greek"]["Description"] = "";
	$fieldLabelsmedicines_chart["Greek"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Greek"]["Type"] = "";
	$placeHoldersmedicines_chart["Greek"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Greek"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsmedicines_chart["Hebrew"] = array();
	$fieldToolTipsmedicines_chart["Hebrew"] = array();
	$placeHoldersmedicines_chart["Hebrew"] = array();
	$pageTitlesmedicines_chart["Hebrew"] = array();
	$fieldLabelsmedicines_chart["Hebrew"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Hebrew"]["id"] = "";
	$placeHoldersmedicines_chart["Hebrew"]["id"] = "";
	$fieldLabelsmedicines_chart["Hebrew"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Hebrew"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Hebrew"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Hebrew"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Hebrew"]["Description"] = "";
	$placeHoldersmedicines_chart["Hebrew"]["Description"] = "";
	$fieldLabelsmedicines_chart["Hebrew"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Hebrew"]["Type"] = "";
	$placeHoldersmedicines_chart["Hebrew"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Hebrew"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsmedicines_chart["Hungarian"] = array();
	$fieldToolTipsmedicines_chart["Hungarian"] = array();
	$placeHoldersmedicines_chart["Hungarian"] = array();
	$pageTitlesmedicines_chart["Hungarian"] = array();
	$fieldLabelsmedicines_chart["Hungarian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Hungarian"]["id"] = "";
	$placeHoldersmedicines_chart["Hungarian"]["id"] = "";
	$fieldLabelsmedicines_chart["Hungarian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Hungarian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Hungarian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Hungarian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Hungarian"]["Description"] = "";
	$placeHoldersmedicines_chart["Hungarian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Hungarian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Hungarian"]["Type"] = "";
	$placeHoldersmedicines_chart["Hungarian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Hungarian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsmedicines_chart["Indonesian"] = array();
	$fieldToolTipsmedicines_chart["Indonesian"] = array();
	$placeHoldersmedicines_chart["Indonesian"] = array();
	$pageTitlesmedicines_chart["Indonesian"] = array();
	$fieldLabelsmedicines_chart["Indonesian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Indonesian"]["id"] = "";
	$placeHoldersmedicines_chart["Indonesian"]["id"] = "";
	$fieldLabelsmedicines_chart["Indonesian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Indonesian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Indonesian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Indonesian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Indonesian"]["Description"] = "";
	$placeHoldersmedicines_chart["Indonesian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Indonesian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Indonesian"]["Type"] = "";
	$placeHoldersmedicines_chart["Indonesian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Indonesian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsmedicines_chart["Italian"] = array();
	$fieldToolTipsmedicines_chart["Italian"] = array();
	$placeHoldersmedicines_chart["Italian"] = array();
	$pageTitlesmedicines_chart["Italian"] = array();
	$fieldLabelsmedicines_chart["Italian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Italian"]["id"] = "";
	$placeHoldersmedicines_chart["Italian"]["id"] = "";
	$fieldLabelsmedicines_chart["Italian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Italian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Italian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Italian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Italian"]["Description"] = "";
	$placeHoldersmedicines_chart["Italian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Italian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Italian"]["Type"] = "";
	$placeHoldersmedicines_chart["Italian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Italian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsmedicines_chart["Japanese"] = array();
	$fieldToolTipsmedicines_chart["Japanese"] = array();
	$placeHoldersmedicines_chart["Japanese"] = array();
	$pageTitlesmedicines_chart["Japanese"] = array();
	$fieldLabelsmedicines_chart["Japanese"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Japanese"]["id"] = "";
	$placeHoldersmedicines_chart["Japanese"]["id"] = "";
	$fieldLabelsmedicines_chart["Japanese"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Japanese"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Japanese"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Japanese"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Japanese"]["Description"] = "";
	$placeHoldersmedicines_chart["Japanese"]["Description"] = "";
	$fieldLabelsmedicines_chart["Japanese"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Japanese"]["Type"] = "";
	$placeHoldersmedicines_chart["Japanese"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Japanese"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsmedicines_chart["Malay"] = array();
	$fieldToolTipsmedicines_chart["Malay"] = array();
	$placeHoldersmedicines_chart["Malay"] = array();
	$pageTitlesmedicines_chart["Malay"] = array();
	$fieldLabelsmedicines_chart["Malay"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Malay"]["id"] = "";
	$placeHoldersmedicines_chart["Malay"]["id"] = "";
	$fieldLabelsmedicines_chart["Malay"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Malay"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Malay"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Malay"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Malay"]["Description"] = "";
	$placeHoldersmedicines_chart["Malay"]["Description"] = "";
	$fieldLabelsmedicines_chart["Malay"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Malay"]["Type"] = "";
	$placeHoldersmedicines_chart["Malay"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Malay"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsmedicines_chart["Norwegian(Bokmal)"] = array();
	$fieldToolTipsmedicines_chart["Norwegian(Bokmal)"] = array();
	$placeHoldersmedicines_chart["Norwegian(Bokmal)"] = array();
	$pageTitlesmedicines_chart["Norwegian(Bokmal)"] = array();
	$fieldLabelsmedicines_chart["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersmedicines_chart["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsmedicines_chart["Norwegian(Bokmal)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Norwegian(Bokmal)"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Norwegian(Bokmal)"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Norwegian(Bokmal)"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Norwegian(Bokmal)"]["Description"] = "";
	$placeHoldersmedicines_chart["Norwegian(Bokmal)"]["Description"] = "";
	$fieldLabelsmedicines_chart["Norwegian(Bokmal)"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Norwegian(Bokmal)"]["Type"] = "";
	$placeHoldersmedicines_chart["Norwegian(Bokmal)"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Norwegian(Bokmal)"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsmedicines_chart["Polish"] = array();
	$fieldToolTipsmedicines_chart["Polish"] = array();
	$placeHoldersmedicines_chart["Polish"] = array();
	$pageTitlesmedicines_chart["Polish"] = array();
	$fieldLabelsmedicines_chart["Polish"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Polish"]["id"] = "";
	$placeHoldersmedicines_chart["Polish"]["id"] = "";
	$fieldLabelsmedicines_chart["Polish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Polish"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Polish"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Polish"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Polish"]["Description"] = "";
	$placeHoldersmedicines_chart["Polish"]["Description"] = "";
	$fieldLabelsmedicines_chart["Polish"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Polish"]["Type"] = "";
	$placeHoldersmedicines_chart["Polish"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Polish"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsmedicines_chart["Portuguese(Brazil)"] = array();
	$fieldToolTipsmedicines_chart["Portuguese(Brazil)"] = array();
	$placeHoldersmedicines_chart["Portuguese(Brazil)"] = array();
	$pageTitlesmedicines_chart["Portuguese(Brazil)"] = array();
	$fieldLabelsmedicines_chart["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersmedicines_chart["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsmedicines_chart["Portuguese(Brazil)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Portuguese(Brazil)"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Portuguese(Brazil)"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Portuguese(Brazil)"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Portuguese(Brazil)"]["Description"] = "";
	$placeHoldersmedicines_chart["Portuguese(Brazil)"]["Description"] = "";
	$fieldLabelsmedicines_chart["Portuguese(Brazil)"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Portuguese(Brazil)"]["Type"] = "";
	$placeHoldersmedicines_chart["Portuguese(Brazil)"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Portuguese(Brazil)"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsmedicines_chart["Portuguese(Standard)"] = array();
	$fieldToolTipsmedicines_chart["Portuguese(Standard)"] = array();
	$placeHoldersmedicines_chart["Portuguese(Standard)"] = array();
	$pageTitlesmedicines_chart["Portuguese(Standard)"] = array();
	$fieldLabelsmedicines_chart["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Portuguese(Standard)"]["id"] = "";
	$placeHoldersmedicines_chart["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsmedicines_chart["Portuguese(Standard)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Portuguese(Standard)"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Portuguese(Standard)"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Portuguese(Standard)"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Portuguese(Standard)"]["Description"] = "";
	$placeHoldersmedicines_chart["Portuguese(Standard)"]["Description"] = "";
	$fieldLabelsmedicines_chart["Portuguese(Standard)"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Portuguese(Standard)"]["Type"] = "";
	$placeHoldersmedicines_chart["Portuguese(Standard)"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Portuguese(Standard)"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsmedicines_chart["Romanian"] = array();
	$fieldToolTipsmedicines_chart["Romanian"] = array();
	$placeHoldersmedicines_chart["Romanian"] = array();
	$pageTitlesmedicines_chart["Romanian"] = array();
	$fieldLabelsmedicines_chart["Romanian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Romanian"]["id"] = "";
	$placeHoldersmedicines_chart["Romanian"]["id"] = "";
	$fieldLabelsmedicines_chart["Romanian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Romanian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Romanian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Romanian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Romanian"]["Description"] = "";
	$placeHoldersmedicines_chart["Romanian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Romanian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Romanian"]["Type"] = "";
	$placeHoldersmedicines_chart["Romanian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Romanian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsmedicines_chart["Russian"] = array();
	$fieldToolTipsmedicines_chart["Russian"] = array();
	$placeHoldersmedicines_chart["Russian"] = array();
	$pageTitlesmedicines_chart["Russian"] = array();
	$fieldLabelsmedicines_chart["Russian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Russian"]["id"] = "";
	$placeHoldersmedicines_chart["Russian"]["id"] = "";
	$fieldLabelsmedicines_chart["Russian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Russian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Russian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Russian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Russian"]["Description"] = "";
	$placeHoldersmedicines_chart["Russian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Russian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Russian"]["Type"] = "";
	$placeHoldersmedicines_chart["Russian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Russian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsmedicines_chart["Serbian"] = array();
	$fieldToolTipsmedicines_chart["Serbian"] = array();
	$placeHoldersmedicines_chart["Serbian"] = array();
	$pageTitlesmedicines_chart["Serbian"] = array();
	$fieldLabelsmedicines_chart["Serbian"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Serbian"]["id"] = "";
	$placeHoldersmedicines_chart["Serbian"]["id"] = "";
	$fieldLabelsmedicines_chart["Serbian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Serbian"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Serbian"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Serbian"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Serbian"]["Description"] = "";
	$placeHoldersmedicines_chart["Serbian"]["Description"] = "";
	$fieldLabelsmedicines_chart["Serbian"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Serbian"]["Type"] = "";
	$placeHoldersmedicines_chart["Serbian"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Serbian"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsmedicines_chart["Slovak"] = array();
	$fieldToolTipsmedicines_chart["Slovak"] = array();
	$placeHoldersmedicines_chart["Slovak"] = array();
	$pageTitlesmedicines_chart["Slovak"] = array();
	$fieldLabelsmedicines_chart["Slovak"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Slovak"]["id"] = "";
	$placeHoldersmedicines_chart["Slovak"]["id"] = "";
	$fieldLabelsmedicines_chart["Slovak"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Slovak"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Slovak"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Slovak"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Slovak"]["Description"] = "";
	$placeHoldersmedicines_chart["Slovak"]["Description"] = "";
	$fieldLabelsmedicines_chart["Slovak"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Slovak"]["Type"] = "";
	$placeHoldersmedicines_chart["Slovak"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Slovak"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsmedicines_chart["Spanish"] = array();
	$fieldToolTipsmedicines_chart["Spanish"] = array();
	$placeHoldersmedicines_chart["Spanish"] = array();
	$pageTitlesmedicines_chart["Spanish"] = array();
	$fieldLabelsmedicines_chart["Spanish"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Spanish"]["id"] = "";
	$placeHoldersmedicines_chart["Spanish"]["id"] = "";
	$fieldLabelsmedicines_chart["Spanish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Spanish"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Spanish"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Spanish"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Spanish"]["Description"] = "";
	$placeHoldersmedicines_chart["Spanish"]["Description"] = "";
	$fieldLabelsmedicines_chart["Spanish"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Spanish"]["Type"] = "";
	$placeHoldersmedicines_chart["Spanish"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Spanish"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsmedicines_chart["Swedish"] = array();
	$fieldToolTipsmedicines_chart["Swedish"] = array();
	$placeHoldersmedicines_chart["Swedish"] = array();
	$pageTitlesmedicines_chart["Swedish"] = array();
	$fieldLabelsmedicines_chart["Swedish"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Swedish"]["id"] = "";
	$placeHoldersmedicines_chart["Swedish"]["id"] = "";
	$fieldLabelsmedicines_chart["Swedish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Swedish"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Swedish"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Swedish"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Swedish"]["Description"] = "";
	$placeHoldersmedicines_chart["Swedish"]["Description"] = "";
	$fieldLabelsmedicines_chart["Swedish"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Swedish"]["Type"] = "";
	$placeHoldersmedicines_chart["Swedish"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Swedish"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsmedicines_chart["Tagalog(Philippines)"] = array();
	$fieldToolTipsmedicines_chart["Tagalog(Philippines)"] = array();
	$placeHoldersmedicines_chart["Tagalog(Philippines)"] = array();
	$pageTitlesmedicines_chart["Tagalog(Philippines)"] = array();
	$fieldLabelsmedicines_chart["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersmedicines_chart["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsmedicines_chart["Tagalog(Philippines)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Tagalog(Philippines)"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Tagalog(Philippines)"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Tagalog(Philippines)"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Tagalog(Philippines)"]["Description"] = "";
	$placeHoldersmedicines_chart["Tagalog(Philippines)"]["Description"] = "";
	$fieldLabelsmedicines_chart["Tagalog(Philippines)"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Tagalog(Philippines)"]["Type"] = "";
	$placeHoldersmedicines_chart["Tagalog(Philippines)"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Tagalog(Philippines)"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsmedicines_chart["Thai"] = array();
	$fieldToolTipsmedicines_chart["Thai"] = array();
	$placeHoldersmedicines_chart["Thai"] = array();
	$pageTitlesmedicines_chart["Thai"] = array();
	$fieldLabelsmedicines_chart["Thai"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Thai"]["id"] = "";
	$placeHoldersmedicines_chart["Thai"]["id"] = "";
	$fieldLabelsmedicines_chart["Thai"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Thai"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Thai"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Thai"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Thai"]["Description"] = "";
	$placeHoldersmedicines_chart["Thai"]["Description"] = "";
	$fieldLabelsmedicines_chart["Thai"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Thai"]["Type"] = "";
	$placeHoldersmedicines_chart["Thai"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Thai"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsmedicines_chart["Turkish"] = array();
	$fieldToolTipsmedicines_chart["Turkish"] = array();
	$placeHoldersmedicines_chart["Turkish"] = array();
	$pageTitlesmedicines_chart["Turkish"] = array();
	$fieldLabelsmedicines_chart["Turkish"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Turkish"]["id"] = "";
	$placeHoldersmedicines_chart["Turkish"]["id"] = "";
	$fieldLabelsmedicines_chart["Turkish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Turkish"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Turkish"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Turkish"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Turkish"]["Description"] = "";
	$placeHoldersmedicines_chart["Turkish"]["Description"] = "";
	$fieldLabelsmedicines_chart["Turkish"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Turkish"]["Type"] = "";
	$placeHoldersmedicines_chart["Turkish"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Turkish"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsmedicines_chart["Urdu"] = array();
	$fieldToolTipsmedicines_chart["Urdu"] = array();
	$placeHoldersmedicines_chart["Urdu"] = array();
	$pageTitlesmedicines_chart["Urdu"] = array();
	$fieldLabelsmedicines_chart["Urdu"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Urdu"]["id"] = "";
	$placeHoldersmedicines_chart["Urdu"]["id"] = "";
	$fieldLabelsmedicines_chart["Urdu"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Urdu"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Urdu"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Urdu"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Urdu"]["Description"] = "";
	$placeHoldersmedicines_chart["Urdu"]["Description"] = "";
	$fieldLabelsmedicines_chart["Urdu"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Urdu"]["Type"] = "";
	$placeHoldersmedicines_chart["Urdu"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Urdu"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsmedicines_chart["Welsh"] = array();
	$fieldToolTipsmedicines_chart["Welsh"] = array();
	$placeHoldersmedicines_chart["Welsh"] = array();
	$pageTitlesmedicines_chart["Welsh"] = array();
	$fieldLabelsmedicines_chart["Welsh"]["id"] = "Id";
	$fieldToolTipsmedicines_chart["Welsh"]["id"] = "";
	$placeHoldersmedicines_chart["Welsh"]["id"] = "";
	$fieldLabelsmedicines_chart["Welsh"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines_chart["Welsh"]["MedicineName"] = "";
	$placeHoldersmedicines_chart["Welsh"]["MedicineName"] = "";
	$fieldLabelsmedicines_chart["Welsh"]["Description"] = "Description";
	$fieldToolTipsmedicines_chart["Welsh"]["Description"] = "";
	$placeHoldersmedicines_chart["Welsh"]["Description"] = "";
	$fieldLabelsmedicines_chart["Welsh"]["Type"] = "Type";
	$fieldToolTipsmedicines_chart["Welsh"]["Type"] = "";
	$placeHoldersmedicines_chart["Welsh"]["Type"] = "";
	if (count($fieldToolTipsmedicines_chart["Welsh"]))
		$tdatamedicines_chart[".isUseToolTips"] = true;
}


	$tdatamedicines_chart[".NCSearch"] = true;

	$tdatamedicines_chart[".ChartRefreshTime"] = 0;


$tdatamedicines_chart[".shortTableName"] = "medicines_chart";
$tdatamedicines_chart[".nSecOptions"] = 0;

$tdatamedicines_chart[".mainTableOwnerID"] = "";
$tdatamedicines_chart[".entityType"] = 3;
$tdatamedicines_chart[".connId"] = "testdb_at_localhost";


$tdatamedicines_chart[".strOriginalTableName"] = "medicines";

	



$tdatamedicines_chart[".showAddInPopup"] = false;

$tdatamedicines_chart[".showEditInPopup"] = false;

$tdatamedicines_chart[".showViewInPopup"] = false;

$tdatamedicines_chart[".listAjax"] = false;
//	temporary
//$tdatamedicines_chart[".listAjax"] = false;

	$tdatamedicines_chart[".audit"] = false;

	$tdatamedicines_chart[".locking"] = false;


$pages = $tdatamedicines_chart[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatamedicines_chart[".edit"] = true;
	$tdatamedicines_chart[".afterEditAction"] = 1;
	$tdatamedicines_chart[".closePopupAfterEdit"] = 1;
	$tdatamedicines_chart[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatamedicines_chart[".add"] = true;
$tdatamedicines_chart[".afterAddAction"] = 1;
$tdatamedicines_chart[".closePopupAfterAdd"] = 1;
$tdatamedicines_chart[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatamedicines_chart[".list"] = true;
}



$tdatamedicines_chart[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatamedicines_chart[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatamedicines_chart[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatamedicines_chart[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatamedicines_chart[".printFriendly"] = true;
}



$tdatamedicines_chart[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatamedicines_chart[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatamedicines_chart[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatamedicines_chart[".isUseAjaxSuggest"] = true;





$tdatamedicines_chart[".ajaxCodeSnippetAdded"] = false;

$tdatamedicines_chart[".buttonsAdded"] = false;

$tdatamedicines_chart[".addPageEvents"] = false;

// use timepicker for search panel
$tdatamedicines_chart[".isUseTimeForSearch"] = false;


$tdatamedicines_chart[".badgeColor"] = "9ACD32";


$tdatamedicines_chart[".allSearchFields"] = array();
$tdatamedicines_chart[".filterFields"] = array();
$tdatamedicines_chart[".requiredSearchFields"] = array();

$tdatamedicines_chart[".googleLikeFields"] = array();
$tdatamedicines_chart[".googleLikeFields"][] = "id";
$tdatamedicines_chart[".googleLikeFields"][] = "MedicineName";
$tdatamedicines_chart[".googleLikeFields"][] = "Description";
$tdatamedicines_chart[".googleLikeFields"][] = "Type";



$tdatamedicines_chart[".tableType"] = "chart";

$tdatamedicines_chart[".printerPageOrientation"] = 0;
$tdatamedicines_chart[".nPrinterPageScale"] = 100;

$tdatamedicines_chart[".nPrinterSplitRecords"] = 40;

$tdatamedicines_chart[".geocodingEnabled"] = false;



// chart settings
$tdatamedicines_chart[".chartType"] = "2DColumn";
// end of chart settings








$tstrOrderBy = "";
$tdatamedicines_chart[".strOrderBy"] = $tstrOrderBy;

$tdatamedicines_chart[".orderindexes"] = array();


$tdatamedicines_chart[".sqlHead"] = "SELECT id,  	MedicineName,  	Description,  	`Type`";
$tdatamedicines_chart[".sqlFrom"] = "FROM medicines";
$tdatamedicines_chart[".sqlWhereExpr"] = "";
$tdatamedicines_chart[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatamedicines_chart[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatamedicines_chart[".arrGroupsPerPage"] = $arrGPP;

$tdatamedicines_chart[".highlightSearchResults"] = true;

$tableKeysmedicines_chart = array();
$tableKeysmedicines_chart[] = "id";
$tdatamedicines_chart[".Keys"] = $tableKeysmedicines_chart;


$tdatamedicines_chart[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines_Chart","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines_chart["id"] = $fdata;
		$tdatamedicines_chart[".searchableFields"][] = "id";
//	MedicineName
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "MedicineName";
	$fdata["GoodName"] = "MedicineName";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines_Chart","MedicineName");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "MedicineName";

		$fdata["sourceSingle"] = "MedicineName";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "MedicineName";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines_chart["MedicineName"] = $fdata;
		$tdatamedicines_chart[".searchableFields"][] = "MedicineName";
//	Description
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Description";
	$fdata["GoodName"] = "Description";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines_Chart","Description");
	$fdata["FieldType"] = 201;


	
	
			

		$fdata["strField"] = "Description";

		$fdata["sourceSingle"] = "Description";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Description";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 0;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

		$edata["CreateThumbnail"] = true;
	$edata["StrThumbnail"] = "th";
			$edata["ThumbnailSize"] = 600;

	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines_chart["Description"] = $fdata;
		$tdatamedicines_chart[".searchableFields"][] = "Description";
//	Type
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Type";
	$fdata["GoodName"] = "Type";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines_Chart","Type");
	$fdata["FieldType"] = 129;


	
	
			

		$fdata["strField"] = "Type";

		$fdata["sourceSingle"] = "Type";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Type`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
		$edata["LookupType"] = 0;
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
	
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "Tablet";
	$edata["LookupValues"][] = "Capsule";
	$edata["LookupValues"][] = "Powder";
	$edata["LookupValues"][] = "Liquid";
	$edata["LookupValues"][] = "Ointments";

	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines_chart["Type"] = $fdata;
		$tdatamedicines_chart[".searchableFields"][] = "Type";

$tdatamedicines_chart[".groupChart"] = true;
$tdatamedicines_chart[".chartLabelInterval"] = 0;
$tdatamedicines_chart[".chartLabelField"] = "Type";
$tdatamedicines_chart[".chartSeries"] = array();
$tdatamedicines_chart[".chartSeries"][] = array(
	"field" => "id",
	"total" => "COUNT"
);
	$tdatamedicines_chart[".chartXml"] = '<chart>
		<attr value="tables">
			<attr value="0">medicines Chart</attr>
		</attr>
		<attr value="chart_type">
			<attr value="type">2d_column</attr>
		</attr>

		<attr value="parameters">';
	$tdatamedicines_chart[".chartXml"] .= '<attr value="0">
			<attr value="name">id</attr>';
	$tdatamedicines_chart[".chartXml"] .= '</attr>';
	$tdatamedicines_chart[".chartXml"] .= '<attr value="1">
		<attr value="name">Type</attr>
	</attr>';
	$tdatamedicines_chart[".chartXml"] .= '</attr>
			<attr value="appearance">';


	$tdatamedicines_chart[".chartXml"] .= '<attr value="head">'.xmlencode("Medicines Available Chart").'</attr>
<attr value="foot">'.xmlencode("Results").'</attr>
<attr value="y_axis_label">'.xmlencode("id").'</attr>


<attr value="slegend">true</attr>
<attr value="sgrid">true</attr>
<attr value="sname">true</attr>
<attr value="sval">true</attr>
<attr value="sanim">true</attr>
<attr value="sstacked">false</attr>
<attr value="slog">false</attr>
<attr value="aqua">0</attr>
<attr value="cview">0</attr>
<attr value="is3d">1</attr>
<attr value="isstacked">1</attr>
<attr value="linestyle">0</attr>
<attr value="autoupdate">0</attr>
<attr value="autoupmin">60</attr>';
$tdatamedicines_chart[".chartXml"] .= '</attr>

<attr value="fields">';
	$tdatamedicines_chart[".chartXml"] .= '<attr value="0">
		<attr value="name">id</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("medicines_Chart","id")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatamedicines_chart[".chartXml"] .= '<attr value="1">
		<attr value="name">MedicineName</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("medicines_Chart","MedicineName")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatamedicines_chart[".chartXml"] .= '<attr value="2">
		<attr value="name">Description</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("medicines_Chart","Description")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatamedicines_chart[".chartXml"] .= '<attr value="3">
		<attr value="name">Type</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("medicines_Chart","Type")).'</attr>
		<attr value="search"></attr>
	</attr>';
$tdatamedicines_chart[".chartXml"] .= '</attr>


<attr value="settings">
<attr value="name">medicines Chart</attr>
<attr value="short_table_name">medicines_chart</attr>
</attr>

</chart>';

$tables_data["medicines Chart"]=&$tdatamedicines_chart;
$field_labels["medicines_Chart"] = &$fieldLabelsmedicines_chart;
$fieldToolTips["medicines_Chart"] = &$fieldToolTipsmedicines_chart;
$placeHolders["medicines_Chart"] = &$placeHoldersmedicines_chart;
$page_titles["medicines_Chart"] = &$pageTitlesmedicines_chart;


changeTextControlsToDate( "medicines Chart" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["medicines Chart"] = array();
//	diagnoses
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="diagnoses";
		$detailsParam["dOriginalTable"] = "diagnoses";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "diagnoses";
	$detailsParam["dCaptionTable"] = GetTableCaption("diagnoses");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["medicines Chart"][$dIndex] = $detailsParam;

	
		$detailsTablesData["medicines Chart"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["medicines Chart"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["medicines Chart"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["medicines Chart"][$dIndex]["detailKeys"][]="medicine_id";
//endif

// tables which are master tables for current table (detail)
$masterTablesData["medicines Chart"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_medicines_chart()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	MedicineName,  	Description,  	`Type`";
$proto0["m_strFrom"] = "FROM medicines";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines Chart"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "medicines Chart";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "MedicineName",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines Chart"
));

$proto8["m_sql"] = "MedicineName";
$proto8["m_srcTableName"] = "medicines Chart";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Description",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines Chart"
));

$proto10["m_sql"] = "Description";
$proto10["m_srcTableName"] = "medicines Chart";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Type",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines Chart"
));

$proto12["m_sql"] = "`Type`";
$proto12["m_srcTableName"] = "medicines Chart";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto14=array();
$proto14["m_link"] = "SQLL_MAIN";
			$proto15=array();
$proto15["m_strName"] = "medicines";
$proto15["m_srcTableName"] = "medicines Chart";
$proto15["m_columns"] = array();
$proto15["m_columns"][] = "id";
$proto15["m_columns"][] = "MedicineName";
$proto15["m_columns"][] = "Description";
$proto15["m_columns"][] = "Type";
$obj = new SQLTable($proto15);

$proto14["m_table"] = $obj;
$proto14["m_sql"] = "medicines";
$proto14["m_alias"] = "";
$proto14["m_srcTableName"] = "medicines Chart";
$proto16=array();
$proto16["m_sql"] = "";
$proto16["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto16["m_column"]=$obj;
$proto16["m_contained"] = array();
$proto16["m_strCase"] = "";
$proto16["m_havingmode"] = false;
$proto16["m_inBrackets"] = false;
$proto16["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto16);

$proto14["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto14);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="medicines Chart";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_medicines_chart = createSqlQuery_medicines_chart();


	
		;

				

$tdatamedicines_chart[".sqlquery"] = $queryData_medicines_chart;



$tdatamedicines_chart[".hasEvents"] = false;

?>