<?php
$tdataadmin_rights = array();
$tdataadmin_rights[".searchableFields"] = array();
$tdataadmin_rights[".ShortName"] = "admin_rights";
$tdataadmin_rights[".OwnerID"] = "";
$tdataadmin_rights[".OriginalTable"] = "user_rightsugrights";


$tdataadmin_rights[".pagesByType"] = my_json_decode( "{}" );
$tdataadmin_rights[".originalPagesByType"] = $tdataadmin_rights[".pagesByType"];
$tdataadmin_rights[".pages"] = types2pages( my_json_decode( "{}" ) );
$tdataadmin_rights[".originalPages"] = $tdataadmin_rights[".pages"];
$tdataadmin_rights[".defaultPages"] = my_json_decode( "{}" );
$tdataadmin_rights[".originalDefaultPages"] = $tdataadmin_rights[".defaultPages"];

//	field labels
$fieldLabelsadmin_rights = array();
$fieldToolTipsadmin_rights = array();
$pageTitlesadmin_rights = array();
$placeHoldersadmin_rights = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsadmin_rights["English"] = array();
	$fieldToolTipsadmin_rights["English"] = array();
	$placeHoldersadmin_rights["English"] = array();
	$pageTitlesadmin_rights["English"] = array();
	$fieldLabelsadmin_rights["English"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["English"]["TableName"] = "";
	$placeHoldersadmin_rights["English"]["TableName"] = "";
	$fieldLabelsadmin_rights["English"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["English"]["GroupID"] = "";
	$placeHoldersadmin_rights["English"]["GroupID"] = "";
	$fieldLabelsadmin_rights["English"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["English"]["AccessMask"] = "";
	$placeHoldersadmin_rights["English"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["English"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["English"]["Page"] = "";
	$placeHoldersadmin_rights["English"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["English"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsadmin_rights["Afrikaans"] = array();
	$fieldToolTipsadmin_rights["Afrikaans"] = array();
	$placeHoldersadmin_rights["Afrikaans"] = array();
	$pageTitlesadmin_rights["Afrikaans"] = array();
	$fieldLabelsadmin_rights["Afrikaans"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Afrikaans"]["TableName"] = "";
	$placeHoldersadmin_rights["Afrikaans"]["TableName"] = "";
	$fieldLabelsadmin_rights["Afrikaans"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Afrikaans"]["GroupID"] = "";
	$placeHoldersadmin_rights["Afrikaans"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Afrikaans"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Afrikaans"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Afrikaans"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Afrikaans"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Afrikaans"]["Page"] = "";
	$placeHoldersadmin_rights["Afrikaans"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Afrikaans"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsadmin_rights["Arabic"] = array();
	$fieldToolTipsadmin_rights["Arabic"] = array();
	$placeHoldersadmin_rights["Arabic"] = array();
	$pageTitlesadmin_rights["Arabic"] = array();
	$fieldLabelsadmin_rights["Arabic"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Arabic"]["TableName"] = "";
	$placeHoldersadmin_rights["Arabic"]["TableName"] = "";
	$fieldLabelsadmin_rights["Arabic"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Arabic"]["GroupID"] = "";
	$placeHoldersadmin_rights["Arabic"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Arabic"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Arabic"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Arabic"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Arabic"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Arabic"]["Page"] = "";
	$placeHoldersadmin_rights["Arabic"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Arabic"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsadmin_rights["Bosnian"] = array();
	$fieldToolTipsadmin_rights["Bosnian"] = array();
	$placeHoldersadmin_rights["Bosnian"] = array();
	$pageTitlesadmin_rights["Bosnian"] = array();
	$fieldLabelsadmin_rights["Bosnian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Bosnian"]["TableName"] = "";
	$placeHoldersadmin_rights["Bosnian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Bosnian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Bosnian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Bosnian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Bosnian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Bosnian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Bosnian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Bosnian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Bosnian"]["Page"] = "";
	$placeHoldersadmin_rights["Bosnian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Bosnian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsadmin_rights["Bulgarian"] = array();
	$fieldToolTipsadmin_rights["Bulgarian"] = array();
	$placeHoldersadmin_rights["Bulgarian"] = array();
	$pageTitlesadmin_rights["Bulgarian"] = array();
	$fieldLabelsadmin_rights["Bulgarian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Bulgarian"]["TableName"] = "";
	$placeHoldersadmin_rights["Bulgarian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Bulgarian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Bulgarian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Bulgarian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Bulgarian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Bulgarian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Bulgarian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Bulgarian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Bulgarian"]["Page"] = "";
	$placeHoldersadmin_rights["Bulgarian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Bulgarian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsadmin_rights["Catalan"] = array();
	$fieldToolTipsadmin_rights["Catalan"] = array();
	$placeHoldersadmin_rights["Catalan"] = array();
	$pageTitlesadmin_rights["Catalan"] = array();
	$fieldLabelsadmin_rights["Catalan"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Catalan"]["TableName"] = "";
	$placeHoldersadmin_rights["Catalan"]["TableName"] = "";
	$fieldLabelsadmin_rights["Catalan"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Catalan"]["GroupID"] = "";
	$placeHoldersadmin_rights["Catalan"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Catalan"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Catalan"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Catalan"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Catalan"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Catalan"]["Page"] = "";
	$placeHoldersadmin_rights["Catalan"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Catalan"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsadmin_rights["Chinese"] = array();
	$fieldToolTipsadmin_rights["Chinese"] = array();
	$placeHoldersadmin_rights["Chinese"] = array();
	$pageTitlesadmin_rights["Chinese"] = array();
	$fieldLabelsadmin_rights["Chinese"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Chinese"]["TableName"] = "";
	$placeHoldersadmin_rights["Chinese"]["TableName"] = "";
	$fieldLabelsadmin_rights["Chinese"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Chinese"]["GroupID"] = "";
	$placeHoldersadmin_rights["Chinese"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Chinese"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Chinese"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Chinese"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Chinese"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Chinese"]["Page"] = "";
	$placeHoldersadmin_rights["Chinese"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Chinese"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsadmin_rights["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsadmin_rights["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersadmin_rights["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesadmin_rights["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsadmin_rights["Chinese (Hong Kong S.A.R.)"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Chinese (Hong Kong S.A.R.)"]["TableName"] = "";
	$placeHoldersadmin_rights["Chinese (Hong Kong S.A.R.)"]["TableName"] = "";
	$fieldLabelsadmin_rights["Chinese (Hong Kong S.A.R.)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Chinese (Hong Kong S.A.R.)"]["GroupID"] = "";
	$placeHoldersadmin_rights["Chinese (Hong Kong S.A.R.)"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Chinese (Hong Kong S.A.R.)"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Chinese (Hong Kong S.A.R.)"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Chinese (Hong Kong S.A.R.)"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Chinese (Hong Kong S.A.R.)"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Chinese (Hong Kong S.A.R.)"]["Page"] = "";
	$placeHoldersadmin_rights["Chinese (Hong Kong S.A.R.)"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Chinese (Hong Kong S.A.R.)"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsadmin_rights["Chinese (Taiwan)"] = array();
	$fieldToolTipsadmin_rights["Chinese (Taiwan)"] = array();
	$placeHoldersadmin_rights["Chinese (Taiwan)"] = array();
	$pageTitlesadmin_rights["Chinese (Taiwan)"] = array();
	$fieldLabelsadmin_rights["Chinese (Taiwan)"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Chinese (Taiwan)"]["TableName"] = "";
	$placeHoldersadmin_rights["Chinese (Taiwan)"]["TableName"] = "";
	$fieldLabelsadmin_rights["Chinese (Taiwan)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Chinese (Taiwan)"]["GroupID"] = "";
	$placeHoldersadmin_rights["Chinese (Taiwan)"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Chinese (Taiwan)"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Chinese (Taiwan)"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Chinese (Taiwan)"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Chinese (Taiwan)"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Chinese (Taiwan)"]["Page"] = "";
	$placeHoldersadmin_rights["Chinese (Taiwan)"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Chinese (Taiwan)"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsadmin_rights["Croatian"] = array();
	$fieldToolTipsadmin_rights["Croatian"] = array();
	$placeHoldersadmin_rights["Croatian"] = array();
	$pageTitlesadmin_rights["Croatian"] = array();
	$fieldLabelsadmin_rights["Croatian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Croatian"]["TableName"] = "";
	$placeHoldersadmin_rights["Croatian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Croatian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Croatian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Croatian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Croatian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Croatian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Croatian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Croatian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Croatian"]["Page"] = "";
	$placeHoldersadmin_rights["Croatian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Croatian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsadmin_rights["Czech"] = array();
	$fieldToolTipsadmin_rights["Czech"] = array();
	$placeHoldersadmin_rights["Czech"] = array();
	$pageTitlesadmin_rights["Czech"] = array();
	$fieldLabelsadmin_rights["Czech"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Czech"]["TableName"] = "";
	$placeHoldersadmin_rights["Czech"]["TableName"] = "";
	$fieldLabelsadmin_rights["Czech"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Czech"]["GroupID"] = "";
	$placeHoldersadmin_rights["Czech"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Czech"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Czech"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Czech"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Czech"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Czech"]["Page"] = "";
	$placeHoldersadmin_rights["Czech"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Czech"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsadmin_rights["Danish"] = array();
	$fieldToolTipsadmin_rights["Danish"] = array();
	$placeHoldersadmin_rights["Danish"] = array();
	$pageTitlesadmin_rights["Danish"] = array();
	$fieldLabelsadmin_rights["Danish"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Danish"]["TableName"] = "";
	$placeHoldersadmin_rights["Danish"]["TableName"] = "";
	$fieldLabelsadmin_rights["Danish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Danish"]["GroupID"] = "";
	$placeHoldersadmin_rights["Danish"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Danish"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Danish"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Danish"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Danish"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Danish"]["Page"] = "";
	$placeHoldersadmin_rights["Danish"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Danish"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsadmin_rights["Dutch"] = array();
	$fieldToolTipsadmin_rights["Dutch"] = array();
	$placeHoldersadmin_rights["Dutch"] = array();
	$pageTitlesadmin_rights["Dutch"] = array();
	$fieldLabelsadmin_rights["Dutch"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Dutch"]["TableName"] = "";
	$placeHoldersadmin_rights["Dutch"]["TableName"] = "";
	$fieldLabelsadmin_rights["Dutch"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Dutch"]["GroupID"] = "";
	$placeHoldersadmin_rights["Dutch"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Dutch"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Dutch"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Dutch"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Dutch"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Dutch"]["Page"] = "";
	$placeHoldersadmin_rights["Dutch"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Dutch"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsadmin_rights["Farsi"] = array();
	$fieldToolTipsadmin_rights["Farsi"] = array();
	$placeHoldersadmin_rights["Farsi"] = array();
	$pageTitlesadmin_rights["Farsi"] = array();
	$fieldLabelsadmin_rights["Farsi"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Farsi"]["TableName"] = "";
	$placeHoldersadmin_rights["Farsi"]["TableName"] = "";
	$fieldLabelsadmin_rights["Farsi"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Farsi"]["GroupID"] = "";
	$placeHoldersadmin_rights["Farsi"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Farsi"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Farsi"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Farsi"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Farsi"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Farsi"]["Page"] = "";
	$placeHoldersadmin_rights["Farsi"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Farsi"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsadmin_rights["French"] = array();
	$fieldToolTipsadmin_rights["French"] = array();
	$placeHoldersadmin_rights["French"] = array();
	$pageTitlesadmin_rights["French"] = array();
	$fieldLabelsadmin_rights["French"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["French"]["TableName"] = "";
	$placeHoldersadmin_rights["French"]["TableName"] = "";
	$fieldLabelsadmin_rights["French"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["French"]["GroupID"] = "";
	$placeHoldersadmin_rights["French"]["GroupID"] = "";
	$fieldLabelsadmin_rights["French"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["French"]["AccessMask"] = "";
	$placeHoldersadmin_rights["French"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["French"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["French"]["Page"] = "";
	$placeHoldersadmin_rights["French"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["French"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsadmin_rights["Georgian"] = array();
	$fieldToolTipsadmin_rights["Georgian"] = array();
	$placeHoldersadmin_rights["Georgian"] = array();
	$pageTitlesadmin_rights["Georgian"] = array();
	$fieldLabelsadmin_rights["Georgian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Georgian"]["TableName"] = "";
	$placeHoldersadmin_rights["Georgian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Georgian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Georgian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Georgian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Georgian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Georgian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Georgian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Georgian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Georgian"]["Page"] = "";
	$placeHoldersadmin_rights["Georgian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Georgian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsadmin_rights["German"] = array();
	$fieldToolTipsadmin_rights["German"] = array();
	$placeHoldersadmin_rights["German"] = array();
	$pageTitlesadmin_rights["German"] = array();
	$fieldLabelsadmin_rights["German"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["German"]["TableName"] = "";
	$placeHoldersadmin_rights["German"]["TableName"] = "";
	$fieldLabelsadmin_rights["German"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["German"]["GroupID"] = "";
	$placeHoldersadmin_rights["German"]["GroupID"] = "";
	$fieldLabelsadmin_rights["German"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["German"]["AccessMask"] = "";
	$placeHoldersadmin_rights["German"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["German"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["German"]["Page"] = "";
	$placeHoldersadmin_rights["German"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["German"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsadmin_rights["Greek"] = array();
	$fieldToolTipsadmin_rights["Greek"] = array();
	$placeHoldersadmin_rights["Greek"] = array();
	$pageTitlesadmin_rights["Greek"] = array();
	$fieldLabelsadmin_rights["Greek"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Greek"]["TableName"] = "";
	$placeHoldersadmin_rights["Greek"]["TableName"] = "";
	$fieldLabelsadmin_rights["Greek"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Greek"]["GroupID"] = "";
	$placeHoldersadmin_rights["Greek"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Greek"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Greek"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Greek"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Greek"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Greek"]["Page"] = "";
	$placeHoldersadmin_rights["Greek"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Greek"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsadmin_rights["Hebrew"] = array();
	$fieldToolTipsadmin_rights["Hebrew"] = array();
	$placeHoldersadmin_rights["Hebrew"] = array();
	$pageTitlesadmin_rights["Hebrew"] = array();
	$fieldLabelsadmin_rights["Hebrew"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Hebrew"]["TableName"] = "";
	$placeHoldersadmin_rights["Hebrew"]["TableName"] = "";
	$fieldLabelsadmin_rights["Hebrew"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Hebrew"]["GroupID"] = "";
	$placeHoldersadmin_rights["Hebrew"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Hebrew"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Hebrew"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Hebrew"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Hebrew"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Hebrew"]["Page"] = "";
	$placeHoldersadmin_rights["Hebrew"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Hebrew"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsadmin_rights["Hungarian"] = array();
	$fieldToolTipsadmin_rights["Hungarian"] = array();
	$placeHoldersadmin_rights["Hungarian"] = array();
	$pageTitlesadmin_rights["Hungarian"] = array();
	$fieldLabelsadmin_rights["Hungarian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Hungarian"]["TableName"] = "";
	$placeHoldersadmin_rights["Hungarian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Hungarian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Hungarian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Hungarian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Hungarian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Hungarian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Hungarian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Hungarian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Hungarian"]["Page"] = "";
	$placeHoldersadmin_rights["Hungarian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Hungarian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsadmin_rights["Indonesian"] = array();
	$fieldToolTipsadmin_rights["Indonesian"] = array();
	$placeHoldersadmin_rights["Indonesian"] = array();
	$pageTitlesadmin_rights["Indonesian"] = array();
	$fieldLabelsadmin_rights["Indonesian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Indonesian"]["TableName"] = "";
	$placeHoldersadmin_rights["Indonesian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Indonesian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Indonesian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Indonesian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Indonesian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Indonesian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Indonesian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Indonesian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Indonesian"]["Page"] = "";
	$placeHoldersadmin_rights["Indonesian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Indonesian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsadmin_rights["Italian"] = array();
	$fieldToolTipsadmin_rights["Italian"] = array();
	$placeHoldersadmin_rights["Italian"] = array();
	$pageTitlesadmin_rights["Italian"] = array();
	$fieldLabelsadmin_rights["Italian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Italian"]["TableName"] = "";
	$placeHoldersadmin_rights["Italian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Italian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Italian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Italian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Italian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Italian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Italian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Italian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Italian"]["Page"] = "";
	$placeHoldersadmin_rights["Italian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Italian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsadmin_rights["Japanese"] = array();
	$fieldToolTipsadmin_rights["Japanese"] = array();
	$placeHoldersadmin_rights["Japanese"] = array();
	$pageTitlesadmin_rights["Japanese"] = array();
	$fieldLabelsadmin_rights["Japanese"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Japanese"]["TableName"] = "";
	$placeHoldersadmin_rights["Japanese"]["TableName"] = "";
	$fieldLabelsadmin_rights["Japanese"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Japanese"]["GroupID"] = "";
	$placeHoldersadmin_rights["Japanese"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Japanese"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Japanese"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Japanese"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Japanese"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Japanese"]["Page"] = "";
	$placeHoldersadmin_rights["Japanese"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Japanese"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsadmin_rights["Malay"] = array();
	$fieldToolTipsadmin_rights["Malay"] = array();
	$placeHoldersadmin_rights["Malay"] = array();
	$pageTitlesadmin_rights["Malay"] = array();
	$fieldLabelsadmin_rights["Malay"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Malay"]["TableName"] = "";
	$placeHoldersadmin_rights["Malay"]["TableName"] = "";
	$fieldLabelsadmin_rights["Malay"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Malay"]["GroupID"] = "";
	$placeHoldersadmin_rights["Malay"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Malay"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Malay"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Malay"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Malay"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Malay"]["Page"] = "";
	$placeHoldersadmin_rights["Malay"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Malay"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsadmin_rights["Norwegian(Bokmal)"] = array();
	$fieldToolTipsadmin_rights["Norwegian(Bokmal)"] = array();
	$placeHoldersadmin_rights["Norwegian(Bokmal)"] = array();
	$pageTitlesadmin_rights["Norwegian(Bokmal)"] = array();
	$fieldLabelsadmin_rights["Norwegian(Bokmal)"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Norwegian(Bokmal)"]["TableName"] = "";
	$placeHoldersadmin_rights["Norwegian(Bokmal)"]["TableName"] = "";
	$fieldLabelsadmin_rights["Norwegian(Bokmal)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Norwegian(Bokmal)"]["GroupID"] = "";
	$placeHoldersadmin_rights["Norwegian(Bokmal)"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Norwegian(Bokmal)"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Norwegian(Bokmal)"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Norwegian(Bokmal)"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Norwegian(Bokmal)"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Norwegian(Bokmal)"]["Page"] = "";
	$placeHoldersadmin_rights["Norwegian(Bokmal)"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Norwegian(Bokmal)"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsadmin_rights["Polish"] = array();
	$fieldToolTipsadmin_rights["Polish"] = array();
	$placeHoldersadmin_rights["Polish"] = array();
	$pageTitlesadmin_rights["Polish"] = array();
	$fieldLabelsadmin_rights["Polish"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Polish"]["TableName"] = "";
	$placeHoldersadmin_rights["Polish"]["TableName"] = "";
	$fieldLabelsadmin_rights["Polish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Polish"]["GroupID"] = "";
	$placeHoldersadmin_rights["Polish"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Polish"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Polish"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Polish"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Polish"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Polish"]["Page"] = "";
	$placeHoldersadmin_rights["Polish"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Polish"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsadmin_rights["Portuguese(Brazil)"] = array();
	$fieldToolTipsadmin_rights["Portuguese(Brazil)"] = array();
	$placeHoldersadmin_rights["Portuguese(Brazil)"] = array();
	$pageTitlesadmin_rights["Portuguese(Brazil)"] = array();
	$fieldLabelsadmin_rights["Portuguese(Brazil)"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Portuguese(Brazil)"]["TableName"] = "";
	$placeHoldersadmin_rights["Portuguese(Brazil)"]["TableName"] = "";
	$fieldLabelsadmin_rights["Portuguese(Brazil)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Portuguese(Brazil)"]["GroupID"] = "";
	$placeHoldersadmin_rights["Portuguese(Brazil)"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Portuguese(Brazil)"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Portuguese(Brazil)"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Portuguese(Brazil)"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Portuguese(Brazil)"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Portuguese(Brazil)"]["Page"] = "";
	$placeHoldersadmin_rights["Portuguese(Brazil)"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Portuguese(Brazil)"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsadmin_rights["Portuguese(Standard)"] = array();
	$fieldToolTipsadmin_rights["Portuguese(Standard)"] = array();
	$placeHoldersadmin_rights["Portuguese(Standard)"] = array();
	$pageTitlesadmin_rights["Portuguese(Standard)"] = array();
	$fieldLabelsadmin_rights["Portuguese(Standard)"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Portuguese(Standard)"]["TableName"] = "";
	$placeHoldersadmin_rights["Portuguese(Standard)"]["TableName"] = "";
	$fieldLabelsadmin_rights["Portuguese(Standard)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Portuguese(Standard)"]["GroupID"] = "";
	$placeHoldersadmin_rights["Portuguese(Standard)"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Portuguese(Standard)"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Portuguese(Standard)"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Portuguese(Standard)"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Portuguese(Standard)"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Portuguese(Standard)"]["Page"] = "";
	$placeHoldersadmin_rights["Portuguese(Standard)"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Portuguese(Standard)"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsadmin_rights["Romanian"] = array();
	$fieldToolTipsadmin_rights["Romanian"] = array();
	$placeHoldersadmin_rights["Romanian"] = array();
	$pageTitlesadmin_rights["Romanian"] = array();
	$fieldLabelsadmin_rights["Romanian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Romanian"]["TableName"] = "";
	$placeHoldersadmin_rights["Romanian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Romanian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Romanian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Romanian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Romanian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Romanian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Romanian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Romanian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Romanian"]["Page"] = "";
	$placeHoldersadmin_rights["Romanian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Romanian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsadmin_rights["Russian"] = array();
	$fieldToolTipsadmin_rights["Russian"] = array();
	$placeHoldersadmin_rights["Russian"] = array();
	$pageTitlesadmin_rights["Russian"] = array();
	$fieldLabelsadmin_rights["Russian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Russian"]["TableName"] = "";
	$placeHoldersadmin_rights["Russian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Russian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Russian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Russian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Russian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Russian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Russian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Russian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Russian"]["Page"] = "";
	$placeHoldersadmin_rights["Russian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Russian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsadmin_rights["Serbian"] = array();
	$fieldToolTipsadmin_rights["Serbian"] = array();
	$placeHoldersadmin_rights["Serbian"] = array();
	$pageTitlesadmin_rights["Serbian"] = array();
	$fieldLabelsadmin_rights["Serbian"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Serbian"]["TableName"] = "";
	$placeHoldersadmin_rights["Serbian"]["TableName"] = "";
	$fieldLabelsadmin_rights["Serbian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Serbian"]["GroupID"] = "";
	$placeHoldersadmin_rights["Serbian"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Serbian"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Serbian"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Serbian"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Serbian"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Serbian"]["Page"] = "";
	$placeHoldersadmin_rights["Serbian"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Serbian"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsadmin_rights["Slovak"] = array();
	$fieldToolTipsadmin_rights["Slovak"] = array();
	$placeHoldersadmin_rights["Slovak"] = array();
	$pageTitlesadmin_rights["Slovak"] = array();
	$fieldLabelsadmin_rights["Slovak"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Slovak"]["TableName"] = "";
	$placeHoldersadmin_rights["Slovak"]["TableName"] = "";
	$fieldLabelsadmin_rights["Slovak"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Slovak"]["GroupID"] = "";
	$placeHoldersadmin_rights["Slovak"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Slovak"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Slovak"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Slovak"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Slovak"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Slovak"]["Page"] = "";
	$placeHoldersadmin_rights["Slovak"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Slovak"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsadmin_rights["Spanish"] = array();
	$fieldToolTipsadmin_rights["Spanish"] = array();
	$placeHoldersadmin_rights["Spanish"] = array();
	$pageTitlesadmin_rights["Spanish"] = array();
	$fieldLabelsadmin_rights["Spanish"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Spanish"]["TableName"] = "";
	$placeHoldersadmin_rights["Spanish"]["TableName"] = "";
	$fieldLabelsadmin_rights["Spanish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Spanish"]["GroupID"] = "";
	$placeHoldersadmin_rights["Spanish"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Spanish"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Spanish"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Spanish"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Spanish"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Spanish"]["Page"] = "";
	$placeHoldersadmin_rights["Spanish"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Spanish"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsadmin_rights["Swedish"] = array();
	$fieldToolTipsadmin_rights["Swedish"] = array();
	$placeHoldersadmin_rights["Swedish"] = array();
	$pageTitlesadmin_rights["Swedish"] = array();
	$fieldLabelsadmin_rights["Swedish"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Swedish"]["TableName"] = "";
	$placeHoldersadmin_rights["Swedish"]["TableName"] = "";
	$fieldLabelsadmin_rights["Swedish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Swedish"]["GroupID"] = "";
	$placeHoldersadmin_rights["Swedish"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Swedish"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Swedish"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Swedish"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Swedish"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Swedish"]["Page"] = "";
	$placeHoldersadmin_rights["Swedish"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Swedish"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsadmin_rights["Tagalog(Philippines)"] = array();
	$fieldToolTipsadmin_rights["Tagalog(Philippines)"] = array();
	$placeHoldersadmin_rights["Tagalog(Philippines)"] = array();
	$pageTitlesadmin_rights["Tagalog(Philippines)"] = array();
	$fieldLabelsadmin_rights["Tagalog(Philippines)"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Tagalog(Philippines)"]["TableName"] = "";
	$placeHoldersadmin_rights["Tagalog(Philippines)"]["TableName"] = "";
	$fieldLabelsadmin_rights["Tagalog(Philippines)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Tagalog(Philippines)"]["GroupID"] = "";
	$placeHoldersadmin_rights["Tagalog(Philippines)"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Tagalog(Philippines)"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Tagalog(Philippines)"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Tagalog(Philippines)"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Tagalog(Philippines)"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Tagalog(Philippines)"]["Page"] = "";
	$placeHoldersadmin_rights["Tagalog(Philippines)"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Tagalog(Philippines)"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsadmin_rights["Thai"] = array();
	$fieldToolTipsadmin_rights["Thai"] = array();
	$placeHoldersadmin_rights["Thai"] = array();
	$pageTitlesadmin_rights["Thai"] = array();
	$fieldLabelsadmin_rights["Thai"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Thai"]["TableName"] = "";
	$placeHoldersadmin_rights["Thai"]["TableName"] = "";
	$fieldLabelsadmin_rights["Thai"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Thai"]["GroupID"] = "";
	$placeHoldersadmin_rights["Thai"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Thai"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Thai"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Thai"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Thai"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Thai"]["Page"] = "";
	$placeHoldersadmin_rights["Thai"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Thai"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsadmin_rights["Turkish"] = array();
	$fieldToolTipsadmin_rights["Turkish"] = array();
	$placeHoldersadmin_rights["Turkish"] = array();
	$pageTitlesadmin_rights["Turkish"] = array();
	$fieldLabelsadmin_rights["Turkish"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Turkish"]["TableName"] = "";
	$placeHoldersadmin_rights["Turkish"]["TableName"] = "";
	$fieldLabelsadmin_rights["Turkish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Turkish"]["GroupID"] = "";
	$placeHoldersadmin_rights["Turkish"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Turkish"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Turkish"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Turkish"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Turkish"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Turkish"]["Page"] = "";
	$placeHoldersadmin_rights["Turkish"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Turkish"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsadmin_rights["Urdu"] = array();
	$fieldToolTipsadmin_rights["Urdu"] = array();
	$placeHoldersadmin_rights["Urdu"] = array();
	$pageTitlesadmin_rights["Urdu"] = array();
	$fieldLabelsadmin_rights["Urdu"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Urdu"]["TableName"] = "";
	$placeHoldersadmin_rights["Urdu"]["TableName"] = "";
	$fieldLabelsadmin_rights["Urdu"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Urdu"]["GroupID"] = "";
	$placeHoldersadmin_rights["Urdu"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Urdu"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Urdu"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Urdu"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Urdu"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Urdu"]["Page"] = "";
	$placeHoldersadmin_rights["Urdu"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Urdu"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsadmin_rights["Welsh"] = array();
	$fieldToolTipsadmin_rights["Welsh"] = array();
	$placeHoldersadmin_rights["Welsh"] = array();
	$pageTitlesadmin_rights["Welsh"] = array();
	$fieldLabelsadmin_rights["Welsh"]["TableName"] = "Table Name";
	$fieldToolTipsadmin_rights["Welsh"]["TableName"] = "";
	$placeHoldersadmin_rights["Welsh"]["TableName"] = "";
	$fieldLabelsadmin_rights["Welsh"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_rights["Welsh"]["GroupID"] = "";
	$placeHoldersadmin_rights["Welsh"]["GroupID"] = "";
	$fieldLabelsadmin_rights["Welsh"]["AccessMask"] = "Access Mask";
	$fieldToolTipsadmin_rights["Welsh"]["AccessMask"] = "";
	$placeHoldersadmin_rights["Welsh"]["AccessMask"] = "";
	$fieldLabelsadmin_rights["Welsh"]["Page"] = "Page";
	$fieldToolTipsadmin_rights["Welsh"]["Page"] = "";
	$placeHoldersadmin_rights["Welsh"]["Page"] = "";
	if (count($fieldToolTipsadmin_rights["Welsh"]))
		$tdataadmin_rights[".isUseToolTips"] = true;
}


	$tdataadmin_rights[".NCSearch"] = true;



$tdataadmin_rights[".shortTableName"] = "admin_rights";
$tdataadmin_rights[".nSecOptions"] = 0;

$tdataadmin_rights[".mainTableOwnerID"] = "";
$tdataadmin_rights[".entityType"] = 1;
$tdataadmin_rights[".connId"] = "testdb_at_localhost";


$tdataadmin_rights[".strOriginalTableName"] = "user_rightsugrights";

	



$tdataadmin_rights[".showAddInPopup"] = false;

$tdataadmin_rights[".showEditInPopup"] = false;

$tdataadmin_rights[".showViewInPopup"] = false;

$tdataadmin_rights[".listAjax"] = false;
//	temporary
//$tdataadmin_rights[".listAjax"] = false;

	$tdataadmin_rights[".audit"] = false;

	$tdataadmin_rights[".locking"] = false;


$pages = $tdataadmin_rights[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataadmin_rights[".edit"] = true;
	$tdataadmin_rights[".afterEditAction"] = 1;
	$tdataadmin_rights[".closePopupAfterEdit"] = 1;
	$tdataadmin_rights[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataadmin_rights[".add"] = true;
$tdataadmin_rights[".afterAddAction"] = 1;
$tdataadmin_rights[".closePopupAfterAdd"] = 1;
$tdataadmin_rights[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataadmin_rights[".list"] = true;
}



$tdataadmin_rights[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataadmin_rights[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataadmin_rights[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataadmin_rights[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataadmin_rights[".printFriendly"] = true;
}



$tdataadmin_rights[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataadmin_rights[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataadmin_rights[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataadmin_rights[".isUseAjaxSuggest"] = true;





$tdataadmin_rights[".ajaxCodeSnippetAdded"] = false;

$tdataadmin_rights[".buttonsAdded"] = false;

$tdataadmin_rights[".addPageEvents"] = false;

// use timepicker for search panel
$tdataadmin_rights[".isUseTimeForSearch"] = false;


$tdataadmin_rights[".badgeColor"] = "1E90FF";


$tdataadmin_rights[".allSearchFields"] = array();
$tdataadmin_rights[".filterFields"] = array();
$tdataadmin_rights[".requiredSearchFields"] = array();

$tdataadmin_rights[".googleLikeFields"] = array();
$tdataadmin_rights[".googleLikeFields"][] = "TableName";
$tdataadmin_rights[".googleLikeFields"][] = "GroupID";
$tdataadmin_rights[".googleLikeFields"][] = "AccessMask";
$tdataadmin_rights[".googleLikeFields"][] = "Page";



$tdataadmin_rights[".tableType"] = "list";

$tdataadmin_rights[".printerPageOrientation"] = 0;
$tdataadmin_rights[".nPrinterPageScale"] = 100;

$tdataadmin_rights[".nPrinterSplitRecords"] = 40;

$tdataadmin_rights[".geocodingEnabled"] = false;










$tdataadmin_rights[".pageSize"] = 20;

$tdataadmin_rights[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdataadmin_rights[".strOrderBy"] = $tstrOrderBy;

$tdataadmin_rights[".orderindexes"] = array();


$tdataadmin_rights[".sqlHead"] = "SELECT TableName,  	GroupID,  	AccessMask,  	Page";
$tdataadmin_rights[".sqlFrom"] = "FROM user_rightsugrights";
$tdataadmin_rights[".sqlWhereExpr"] = "";
$tdataadmin_rights[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataadmin_rights[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataadmin_rights[".arrGroupsPerPage"] = $arrGPP;

$tdataadmin_rights[".highlightSearchResults"] = true;

$tableKeysadmin_rights = array();
$tableKeysadmin_rights[] = "TableName";
$tableKeysadmin_rights[] = "GroupID";
$tdataadmin_rights[".Keys"] = $tableKeysadmin_rights;


$tdataadmin_rights[".hideMobileList"] = array();




//	TableName
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "TableName";
	$fdata["GoodName"] = "TableName";
	$fdata["ownerTable"] = "user_rightsugrights";
	$fdata["Label"] = GetFieldLabel("admin_rights","TableName");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "TableName";

		$fdata["sourceSingle"] = "TableName";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TableName";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_rights["TableName"] = $fdata;
		$tdataadmin_rights[".searchableFields"][] = "TableName";
//	GroupID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "GroupID";
	$fdata["GoodName"] = "GroupID";
	$fdata["ownerTable"] = "user_rightsugrights";
	$fdata["Label"] = GetFieldLabel("admin_rights","GroupID");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "GroupID";

		$fdata["sourceSingle"] = "GroupID";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "GroupID";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_rights["GroupID"] = $fdata;
		$tdataadmin_rights[".searchableFields"][] = "GroupID";
//	AccessMask
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "AccessMask";
	$fdata["GoodName"] = "AccessMask";
	$fdata["ownerTable"] = "user_rightsugrights";
	$fdata["Label"] = GetFieldLabel("admin_rights","AccessMask");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "AccessMask";

		$fdata["sourceSingle"] = "AccessMask";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "AccessMask";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=10";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_rights["AccessMask"] = $fdata;
		$tdataadmin_rights[".searchableFields"][] = "AccessMask";
//	Page
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Page";
	$fdata["GoodName"] = "Page";
	$fdata["ownerTable"] = "user_rightsugrights";
	$fdata["Label"] = GetFieldLabel("admin_rights","Page");
	$fdata["FieldType"] = 201;


	
	
			

		$fdata["strField"] = "Page";

		$fdata["sourceSingle"] = "Page";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Page";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 0;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

		$edata["CreateThumbnail"] = true;
	$edata["StrThumbnail"] = "th";
			$edata["ThumbnailSize"] = 600;

			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_rights["Page"] = $fdata;
		$tdataadmin_rights[".searchableFields"][] = "Page";


$tables_data["admin_rights"]=&$tdataadmin_rights;
$field_labels["admin_rights"] = &$fieldLabelsadmin_rights;
$fieldToolTips["admin_rights"] = &$fieldToolTipsadmin_rights;
$placeHolders["admin_rights"] = &$placeHoldersadmin_rights;
$page_titles["admin_rights"] = &$pageTitlesadmin_rights;


changeTextControlsToDate( "admin_rights" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["admin_rights"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["admin_rights"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_admin_rights()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "TableName,  	GroupID,  	AccessMask,  	Page";
$proto0["m_strFrom"] = "FROM user_rightsugrights";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "TableName",
	"m_strTable" => "user_rightsugrights",
	"m_srcTableName" => "admin_rights"
));

$proto6["m_sql"] = "TableName";
$proto6["m_srcTableName"] = "admin_rights";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "GroupID",
	"m_strTable" => "user_rightsugrights",
	"m_srcTableName" => "admin_rights"
));

$proto8["m_sql"] = "GroupID";
$proto8["m_srcTableName"] = "admin_rights";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "AccessMask",
	"m_strTable" => "user_rightsugrights",
	"m_srcTableName" => "admin_rights"
));

$proto10["m_sql"] = "AccessMask";
$proto10["m_srcTableName"] = "admin_rights";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Page",
	"m_strTable" => "user_rightsugrights",
	"m_srcTableName" => "admin_rights"
));

$proto12["m_sql"] = "Page";
$proto12["m_srcTableName"] = "admin_rights";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto14=array();
$proto14["m_link"] = "SQLL_MAIN";
			$proto15=array();
$proto15["m_strName"] = "user_rightsugrights";
$proto15["m_srcTableName"] = "admin_rights";
$proto15["m_columns"] = array();
$proto15["m_columns"][] = "TableName";
$proto15["m_columns"][] = "GroupID";
$proto15["m_columns"][] = "AccessMask";
$proto15["m_columns"][] = "Page";
$obj = new SQLTable($proto15);

$proto14["m_table"] = $obj;
$proto14["m_sql"] = "user_rightsugrights";
$proto14["m_alias"] = "";
$proto14["m_srcTableName"] = "admin_rights";
$proto16=array();
$proto16["m_sql"] = "";
$proto16["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto16["m_column"]=$obj;
$proto16["m_contained"] = array();
$proto16["m_strCase"] = "";
$proto16["m_havingmode"] = false;
$proto16["m_inBrackets"] = false;
$proto16["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto16);

$proto14["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto14);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="admin_rights";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_admin_rights = createSqlQuery_admin_rights();


	
		;

				

$tdataadmin_rights[".sqlquery"] = $queryData_admin_rights;



$tdataadmin_rights[".hasEvents"] = false;

?>