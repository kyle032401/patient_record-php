<?php
$tdatadoctors_chart = array();
$tdatadoctors_chart[".searchableFields"] = array();
$tdatadoctors_chart[".ShortName"] = "doctors_chart";
$tdatadoctors_chart[".OwnerID"] = "";
$tdatadoctors_chart[".OriginalTable"] = "doctors";


$tdatadoctors_chart[".pagesByType"] = my_json_decode( "{\"chart\":[\"chart\"],\"masterchart\":[\"masterchart\"],\"search\":[\"search\"]}" );
$tdatadoctors_chart[".originalPagesByType"] = $tdatadoctors_chart[".pagesByType"];
$tdatadoctors_chart[".pages"] = types2pages( my_json_decode( "{\"chart\":[\"chart\"],\"masterchart\":[\"masterchart\"],\"search\":[\"search\"]}" ) );
$tdatadoctors_chart[".originalPages"] = $tdatadoctors_chart[".pages"];
$tdatadoctors_chart[".defaultPages"] = my_json_decode( "{\"chart\":\"chart\",\"masterchart\":\"masterchart\",\"search\":\"search\"}" );
$tdatadoctors_chart[".originalDefaultPages"] = $tdatadoctors_chart[".defaultPages"];

//	field labels
$fieldLabelsdoctors_chart = array();
$fieldToolTipsdoctors_chart = array();
$pageTitlesdoctors_chart = array();
$placeHoldersdoctors_chart = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdoctors_chart["English"] = array();
	$fieldToolTipsdoctors_chart["English"] = array();
	$placeHoldersdoctors_chart["English"] = array();
	$pageTitlesdoctors_chart["English"] = array();
	$fieldLabelsdoctors_chart["English"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["English"]["id"] = "";
	$placeHoldersdoctors_chart["English"]["id"] = "";
	$fieldLabelsdoctors_chart["English"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["English"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["English"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["English"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["English"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["English"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["English"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["English"]["Email"] = "";
	$placeHoldersdoctors_chart["English"]["Email"] = "";
	$fieldLabelsdoctors_chart["English"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["English"]["Photo"] = "";
	$placeHoldersdoctors_chart["English"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["English"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsdoctors_chart["Afrikaans"] = array();
	$fieldToolTipsdoctors_chart["Afrikaans"] = array();
	$placeHoldersdoctors_chart["Afrikaans"] = array();
	$pageTitlesdoctors_chart["Afrikaans"] = array();
	$fieldLabelsdoctors_chart["Afrikaans"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Afrikaans"]["id"] = "";
	$placeHoldersdoctors_chart["Afrikaans"]["id"] = "";
	$fieldLabelsdoctors_chart["Afrikaans"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Afrikaans"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Afrikaans"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Afrikaans"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Afrikaans"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Afrikaans"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Afrikaans"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Afrikaans"]["Email"] = "";
	$placeHoldersdoctors_chart["Afrikaans"]["Email"] = "";
	$fieldLabelsdoctors_chart["Afrikaans"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Afrikaans"]["Photo"] = "";
	$placeHoldersdoctors_chart["Afrikaans"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Afrikaans"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsdoctors_chart["Arabic"] = array();
	$fieldToolTipsdoctors_chart["Arabic"] = array();
	$placeHoldersdoctors_chart["Arabic"] = array();
	$pageTitlesdoctors_chart["Arabic"] = array();
	$fieldLabelsdoctors_chart["Arabic"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Arabic"]["id"] = "";
	$placeHoldersdoctors_chart["Arabic"]["id"] = "";
	$fieldLabelsdoctors_chart["Arabic"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Arabic"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Arabic"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Arabic"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Arabic"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Arabic"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Arabic"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Arabic"]["Email"] = "";
	$placeHoldersdoctors_chart["Arabic"]["Email"] = "";
	$fieldLabelsdoctors_chart["Arabic"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Arabic"]["Photo"] = "";
	$placeHoldersdoctors_chart["Arabic"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Arabic"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsdoctors_chart["Bosnian"] = array();
	$fieldToolTipsdoctors_chart["Bosnian"] = array();
	$placeHoldersdoctors_chart["Bosnian"] = array();
	$pageTitlesdoctors_chart["Bosnian"] = array();
	$fieldLabelsdoctors_chart["Bosnian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Bosnian"]["id"] = "";
	$placeHoldersdoctors_chart["Bosnian"]["id"] = "";
	$fieldLabelsdoctors_chart["Bosnian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Bosnian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Bosnian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Bosnian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Bosnian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Bosnian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Bosnian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Bosnian"]["Email"] = "";
	$placeHoldersdoctors_chart["Bosnian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Bosnian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Bosnian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Bosnian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Bosnian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsdoctors_chart["Bulgarian"] = array();
	$fieldToolTipsdoctors_chart["Bulgarian"] = array();
	$placeHoldersdoctors_chart["Bulgarian"] = array();
	$pageTitlesdoctors_chart["Bulgarian"] = array();
	$fieldLabelsdoctors_chart["Bulgarian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Bulgarian"]["id"] = "";
	$placeHoldersdoctors_chart["Bulgarian"]["id"] = "";
	$fieldLabelsdoctors_chart["Bulgarian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Bulgarian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Bulgarian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Bulgarian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Bulgarian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Bulgarian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Bulgarian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Bulgarian"]["Email"] = "";
	$placeHoldersdoctors_chart["Bulgarian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Bulgarian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Bulgarian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Bulgarian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Bulgarian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsdoctors_chart["Catalan"] = array();
	$fieldToolTipsdoctors_chart["Catalan"] = array();
	$placeHoldersdoctors_chart["Catalan"] = array();
	$pageTitlesdoctors_chart["Catalan"] = array();
	$fieldLabelsdoctors_chart["Catalan"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Catalan"]["id"] = "";
	$placeHoldersdoctors_chart["Catalan"]["id"] = "";
	$fieldLabelsdoctors_chart["Catalan"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Catalan"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Catalan"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Catalan"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Catalan"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Catalan"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Catalan"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Catalan"]["Email"] = "";
	$placeHoldersdoctors_chart["Catalan"]["Email"] = "";
	$fieldLabelsdoctors_chart["Catalan"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Catalan"]["Photo"] = "";
	$placeHoldersdoctors_chart["Catalan"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Catalan"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsdoctors_chart["Chinese"] = array();
	$fieldToolTipsdoctors_chart["Chinese"] = array();
	$placeHoldersdoctors_chart["Chinese"] = array();
	$pageTitlesdoctors_chart["Chinese"] = array();
	$fieldLabelsdoctors_chart["Chinese"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Chinese"]["id"] = "";
	$placeHoldersdoctors_chart["Chinese"]["id"] = "";
	$fieldLabelsdoctors_chart["Chinese"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Chinese"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Chinese"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Chinese"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Chinese"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Chinese"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Chinese"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Chinese"]["Email"] = "";
	$placeHoldersdoctors_chart["Chinese"]["Email"] = "";
	$fieldLabelsdoctors_chart["Chinese"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Chinese"]["Photo"] = "";
	$placeHoldersdoctors_chart["Chinese"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Chinese"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsdoctors_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsdoctors_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersdoctors_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesdoctors_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersdoctors_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["Email"] = "";
	$placeHoldersdoctors_chart["Chinese (Hong Kong S.A.R.)"]["Email"] = "";
	$fieldLabelsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$placeHoldersdoctors_chart["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Chinese (Hong Kong S.A.R.)"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsdoctors_chart["Chinese (Taiwan)"] = array();
	$fieldToolTipsdoctors_chart["Chinese (Taiwan)"] = array();
	$placeHoldersdoctors_chart["Chinese (Taiwan)"] = array();
	$pageTitlesdoctors_chart["Chinese (Taiwan)"] = array();
	$fieldLabelsdoctors_chart["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersdoctors_chart["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsdoctors_chart["Chinese (Taiwan)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Chinese (Taiwan)"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Chinese (Taiwan)"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Chinese (Taiwan)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Chinese (Taiwan)"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Chinese (Taiwan)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Chinese (Taiwan)"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Chinese (Taiwan)"]["Email"] = "";
	$placeHoldersdoctors_chart["Chinese (Taiwan)"]["Email"] = "";
	$fieldLabelsdoctors_chart["Chinese (Taiwan)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Chinese (Taiwan)"]["Photo"] = "";
	$placeHoldersdoctors_chart["Chinese (Taiwan)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Chinese (Taiwan)"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsdoctors_chart["Croatian"] = array();
	$fieldToolTipsdoctors_chart["Croatian"] = array();
	$placeHoldersdoctors_chart["Croatian"] = array();
	$pageTitlesdoctors_chart["Croatian"] = array();
	$fieldLabelsdoctors_chart["Croatian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Croatian"]["id"] = "";
	$placeHoldersdoctors_chart["Croatian"]["id"] = "";
	$fieldLabelsdoctors_chart["Croatian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Croatian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Croatian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Croatian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Croatian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Croatian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Croatian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Croatian"]["Email"] = "";
	$placeHoldersdoctors_chart["Croatian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Croatian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Croatian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Croatian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Croatian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsdoctors_chart["Czech"] = array();
	$fieldToolTipsdoctors_chart["Czech"] = array();
	$placeHoldersdoctors_chart["Czech"] = array();
	$pageTitlesdoctors_chart["Czech"] = array();
	$fieldLabelsdoctors_chart["Czech"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Czech"]["id"] = "";
	$placeHoldersdoctors_chart["Czech"]["id"] = "";
	$fieldLabelsdoctors_chart["Czech"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Czech"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Czech"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Czech"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Czech"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Czech"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Czech"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Czech"]["Email"] = "";
	$placeHoldersdoctors_chart["Czech"]["Email"] = "";
	$fieldLabelsdoctors_chart["Czech"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Czech"]["Photo"] = "";
	$placeHoldersdoctors_chart["Czech"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Czech"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsdoctors_chart["Danish"] = array();
	$fieldToolTipsdoctors_chart["Danish"] = array();
	$placeHoldersdoctors_chart["Danish"] = array();
	$pageTitlesdoctors_chart["Danish"] = array();
	$fieldLabelsdoctors_chart["Danish"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Danish"]["id"] = "";
	$placeHoldersdoctors_chart["Danish"]["id"] = "";
	$fieldLabelsdoctors_chart["Danish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Danish"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Danish"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Danish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Danish"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Danish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Danish"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Danish"]["Email"] = "";
	$placeHoldersdoctors_chart["Danish"]["Email"] = "";
	$fieldLabelsdoctors_chart["Danish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Danish"]["Photo"] = "";
	$placeHoldersdoctors_chart["Danish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Danish"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsdoctors_chart["Dutch"] = array();
	$fieldToolTipsdoctors_chart["Dutch"] = array();
	$placeHoldersdoctors_chart["Dutch"] = array();
	$pageTitlesdoctors_chart["Dutch"] = array();
	$fieldLabelsdoctors_chart["Dutch"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Dutch"]["id"] = "";
	$placeHoldersdoctors_chart["Dutch"]["id"] = "";
	$fieldLabelsdoctors_chart["Dutch"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Dutch"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Dutch"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Dutch"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Dutch"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Dutch"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Dutch"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Dutch"]["Email"] = "";
	$placeHoldersdoctors_chart["Dutch"]["Email"] = "";
	$fieldLabelsdoctors_chart["Dutch"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Dutch"]["Photo"] = "";
	$placeHoldersdoctors_chart["Dutch"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Dutch"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsdoctors_chart["Farsi"] = array();
	$fieldToolTipsdoctors_chart["Farsi"] = array();
	$placeHoldersdoctors_chart["Farsi"] = array();
	$pageTitlesdoctors_chart["Farsi"] = array();
	$fieldLabelsdoctors_chart["Farsi"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Farsi"]["id"] = "";
	$placeHoldersdoctors_chart["Farsi"]["id"] = "";
	$fieldLabelsdoctors_chart["Farsi"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Farsi"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Farsi"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Farsi"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Farsi"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Farsi"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Farsi"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Farsi"]["Email"] = "";
	$placeHoldersdoctors_chart["Farsi"]["Email"] = "";
	$fieldLabelsdoctors_chart["Farsi"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Farsi"]["Photo"] = "";
	$placeHoldersdoctors_chart["Farsi"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Farsi"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsdoctors_chart["French"] = array();
	$fieldToolTipsdoctors_chart["French"] = array();
	$placeHoldersdoctors_chart["French"] = array();
	$pageTitlesdoctors_chart["French"] = array();
	$fieldLabelsdoctors_chart["French"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["French"]["id"] = "";
	$placeHoldersdoctors_chart["French"]["id"] = "";
	$fieldLabelsdoctors_chart["French"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["French"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["French"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["French"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["French"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["French"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["French"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["French"]["Email"] = "";
	$placeHoldersdoctors_chart["French"]["Email"] = "";
	$fieldLabelsdoctors_chart["French"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["French"]["Photo"] = "";
	$placeHoldersdoctors_chart["French"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["French"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsdoctors_chart["Georgian"] = array();
	$fieldToolTipsdoctors_chart["Georgian"] = array();
	$placeHoldersdoctors_chart["Georgian"] = array();
	$pageTitlesdoctors_chart["Georgian"] = array();
	$fieldLabelsdoctors_chart["Georgian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Georgian"]["id"] = "";
	$placeHoldersdoctors_chart["Georgian"]["id"] = "";
	$fieldLabelsdoctors_chart["Georgian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Georgian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Georgian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Georgian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Georgian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Georgian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Georgian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Georgian"]["Email"] = "";
	$placeHoldersdoctors_chart["Georgian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Georgian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Georgian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Georgian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Georgian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsdoctors_chart["German"] = array();
	$fieldToolTipsdoctors_chart["German"] = array();
	$placeHoldersdoctors_chart["German"] = array();
	$pageTitlesdoctors_chart["German"] = array();
	$fieldLabelsdoctors_chart["German"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["German"]["id"] = "";
	$placeHoldersdoctors_chart["German"]["id"] = "";
	$fieldLabelsdoctors_chart["German"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["German"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["German"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["German"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["German"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["German"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["German"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["German"]["Email"] = "";
	$placeHoldersdoctors_chart["German"]["Email"] = "";
	$fieldLabelsdoctors_chart["German"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["German"]["Photo"] = "";
	$placeHoldersdoctors_chart["German"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["German"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsdoctors_chart["Greek"] = array();
	$fieldToolTipsdoctors_chart["Greek"] = array();
	$placeHoldersdoctors_chart["Greek"] = array();
	$pageTitlesdoctors_chart["Greek"] = array();
	$fieldLabelsdoctors_chart["Greek"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Greek"]["id"] = "";
	$placeHoldersdoctors_chart["Greek"]["id"] = "";
	$fieldLabelsdoctors_chart["Greek"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Greek"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Greek"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Greek"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Greek"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Greek"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Greek"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Greek"]["Email"] = "";
	$placeHoldersdoctors_chart["Greek"]["Email"] = "";
	$fieldLabelsdoctors_chart["Greek"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Greek"]["Photo"] = "";
	$placeHoldersdoctors_chart["Greek"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Greek"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsdoctors_chart["Hebrew"] = array();
	$fieldToolTipsdoctors_chart["Hebrew"] = array();
	$placeHoldersdoctors_chart["Hebrew"] = array();
	$pageTitlesdoctors_chart["Hebrew"] = array();
	$fieldLabelsdoctors_chart["Hebrew"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Hebrew"]["id"] = "";
	$placeHoldersdoctors_chart["Hebrew"]["id"] = "";
	$fieldLabelsdoctors_chart["Hebrew"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Hebrew"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Hebrew"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Hebrew"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Hebrew"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Hebrew"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Hebrew"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Hebrew"]["Email"] = "";
	$placeHoldersdoctors_chart["Hebrew"]["Email"] = "";
	$fieldLabelsdoctors_chart["Hebrew"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Hebrew"]["Photo"] = "";
	$placeHoldersdoctors_chart["Hebrew"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Hebrew"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsdoctors_chart["Hungarian"] = array();
	$fieldToolTipsdoctors_chart["Hungarian"] = array();
	$placeHoldersdoctors_chart["Hungarian"] = array();
	$pageTitlesdoctors_chart["Hungarian"] = array();
	$fieldLabelsdoctors_chart["Hungarian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Hungarian"]["id"] = "";
	$placeHoldersdoctors_chart["Hungarian"]["id"] = "";
	$fieldLabelsdoctors_chart["Hungarian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Hungarian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Hungarian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Hungarian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Hungarian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Hungarian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Hungarian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Hungarian"]["Email"] = "";
	$placeHoldersdoctors_chart["Hungarian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Hungarian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Hungarian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Hungarian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Hungarian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsdoctors_chart["Indonesian"] = array();
	$fieldToolTipsdoctors_chart["Indonesian"] = array();
	$placeHoldersdoctors_chart["Indonesian"] = array();
	$pageTitlesdoctors_chart["Indonesian"] = array();
	$fieldLabelsdoctors_chart["Indonesian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Indonesian"]["id"] = "";
	$placeHoldersdoctors_chart["Indonesian"]["id"] = "";
	$fieldLabelsdoctors_chart["Indonesian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Indonesian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Indonesian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Indonesian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Indonesian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Indonesian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Indonesian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Indonesian"]["Email"] = "";
	$placeHoldersdoctors_chart["Indonesian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Indonesian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Indonesian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Indonesian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Indonesian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsdoctors_chart["Italian"] = array();
	$fieldToolTipsdoctors_chart["Italian"] = array();
	$placeHoldersdoctors_chart["Italian"] = array();
	$pageTitlesdoctors_chart["Italian"] = array();
	$fieldLabelsdoctors_chart["Italian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Italian"]["id"] = "";
	$placeHoldersdoctors_chart["Italian"]["id"] = "";
	$fieldLabelsdoctors_chart["Italian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Italian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Italian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Italian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Italian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Italian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Italian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Italian"]["Email"] = "";
	$placeHoldersdoctors_chart["Italian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Italian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Italian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Italian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Italian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsdoctors_chart["Japanese"] = array();
	$fieldToolTipsdoctors_chart["Japanese"] = array();
	$placeHoldersdoctors_chart["Japanese"] = array();
	$pageTitlesdoctors_chart["Japanese"] = array();
	$fieldLabelsdoctors_chart["Japanese"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Japanese"]["id"] = "";
	$placeHoldersdoctors_chart["Japanese"]["id"] = "";
	$fieldLabelsdoctors_chart["Japanese"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Japanese"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Japanese"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Japanese"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Japanese"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Japanese"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Japanese"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Japanese"]["Email"] = "";
	$placeHoldersdoctors_chart["Japanese"]["Email"] = "";
	$fieldLabelsdoctors_chart["Japanese"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Japanese"]["Photo"] = "";
	$placeHoldersdoctors_chart["Japanese"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Japanese"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsdoctors_chart["Malay"] = array();
	$fieldToolTipsdoctors_chart["Malay"] = array();
	$placeHoldersdoctors_chart["Malay"] = array();
	$pageTitlesdoctors_chart["Malay"] = array();
	$fieldLabelsdoctors_chart["Malay"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Malay"]["id"] = "";
	$placeHoldersdoctors_chart["Malay"]["id"] = "";
	$fieldLabelsdoctors_chart["Malay"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Malay"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Malay"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Malay"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Malay"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Malay"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Malay"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Malay"]["Email"] = "";
	$placeHoldersdoctors_chart["Malay"]["Email"] = "";
	$fieldLabelsdoctors_chart["Malay"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Malay"]["Photo"] = "";
	$placeHoldersdoctors_chart["Malay"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Malay"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsdoctors_chart["Norwegian(Bokmal)"] = array();
	$fieldToolTipsdoctors_chart["Norwegian(Bokmal)"] = array();
	$placeHoldersdoctors_chart["Norwegian(Bokmal)"] = array();
	$pageTitlesdoctors_chart["Norwegian(Bokmal)"] = array();
	$fieldLabelsdoctors_chart["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersdoctors_chart["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsdoctors_chart["Norwegian(Bokmal)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Norwegian(Bokmal)"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Norwegian(Bokmal)"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Norwegian(Bokmal)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Norwegian(Bokmal)"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Norwegian(Bokmal)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Norwegian(Bokmal)"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Norwegian(Bokmal)"]["Email"] = "";
	$placeHoldersdoctors_chart["Norwegian(Bokmal)"]["Email"] = "";
	$fieldLabelsdoctors_chart["Norwegian(Bokmal)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Norwegian(Bokmal)"]["Photo"] = "";
	$placeHoldersdoctors_chart["Norwegian(Bokmal)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Norwegian(Bokmal)"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsdoctors_chart["Polish"] = array();
	$fieldToolTipsdoctors_chart["Polish"] = array();
	$placeHoldersdoctors_chart["Polish"] = array();
	$pageTitlesdoctors_chart["Polish"] = array();
	$fieldLabelsdoctors_chart["Polish"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Polish"]["id"] = "";
	$placeHoldersdoctors_chart["Polish"]["id"] = "";
	$fieldLabelsdoctors_chart["Polish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Polish"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Polish"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Polish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Polish"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Polish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Polish"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Polish"]["Email"] = "";
	$placeHoldersdoctors_chart["Polish"]["Email"] = "";
	$fieldLabelsdoctors_chart["Polish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Polish"]["Photo"] = "";
	$placeHoldersdoctors_chart["Polish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Polish"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsdoctors_chart["Portuguese(Brazil)"] = array();
	$fieldToolTipsdoctors_chart["Portuguese(Brazil)"] = array();
	$placeHoldersdoctors_chart["Portuguese(Brazil)"] = array();
	$pageTitlesdoctors_chart["Portuguese(Brazil)"] = array();
	$fieldLabelsdoctors_chart["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersdoctors_chart["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Brazil)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Portuguese(Brazil)"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Portuguese(Brazil)"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Brazil)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Portuguese(Brazil)"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Portuguese(Brazil)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Brazil)"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Portuguese(Brazil)"]["Email"] = "";
	$placeHoldersdoctors_chart["Portuguese(Brazil)"]["Email"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Brazil)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Portuguese(Brazil)"]["Photo"] = "";
	$placeHoldersdoctors_chart["Portuguese(Brazil)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Portuguese(Brazil)"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsdoctors_chart["Portuguese(Standard)"] = array();
	$fieldToolTipsdoctors_chart["Portuguese(Standard)"] = array();
	$placeHoldersdoctors_chart["Portuguese(Standard)"] = array();
	$pageTitlesdoctors_chart["Portuguese(Standard)"] = array();
	$fieldLabelsdoctors_chart["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Portuguese(Standard)"]["id"] = "";
	$placeHoldersdoctors_chart["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Standard)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Portuguese(Standard)"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Portuguese(Standard)"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Standard)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Portuguese(Standard)"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Portuguese(Standard)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Standard)"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Portuguese(Standard)"]["Email"] = "";
	$placeHoldersdoctors_chart["Portuguese(Standard)"]["Email"] = "";
	$fieldLabelsdoctors_chart["Portuguese(Standard)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Portuguese(Standard)"]["Photo"] = "";
	$placeHoldersdoctors_chart["Portuguese(Standard)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Portuguese(Standard)"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsdoctors_chart["Romanian"] = array();
	$fieldToolTipsdoctors_chart["Romanian"] = array();
	$placeHoldersdoctors_chart["Romanian"] = array();
	$pageTitlesdoctors_chart["Romanian"] = array();
	$fieldLabelsdoctors_chart["Romanian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Romanian"]["id"] = "";
	$placeHoldersdoctors_chart["Romanian"]["id"] = "";
	$fieldLabelsdoctors_chart["Romanian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Romanian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Romanian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Romanian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Romanian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Romanian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Romanian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Romanian"]["Email"] = "";
	$placeHoldersdoctors_chart["Romanian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Romanian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Romanian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Romanian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Romanian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsdoctors_chart["Russian"] = array();
	$fieldToolTipsdoctors_chart["Russian"] = array();
	$placeHoldersdoctors_chart["Russian"] = array();
	$pageTitlesdoctors_chart["Russian"] = array();
	$fieldLabelsdoctors_chart["Russian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Russian"]["id"] = "";
	$placeHoldersdoctors_chart["Russian"]["id"] = "";
	$fieldLabelsdoctors_chart["Russian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Russian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Russian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Russian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Russian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Russian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Russian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Russian"]["Email"] = "";
	$placeHoldersdoctors_chart["Russian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Russian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Russian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Russian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Russian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsdoctors_chart["Serbian"] = array();
	$fieldToolTipsdoctors_chart["Serbian"] = array();
	$placeHoldersdoctors_chart["Serbian"] = array();
	$pageTitlesdoctors_chart["Serbian"] = array();
	$fieldLabelsdoctors_chart["Serbian"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Serbian"]["id"] = "";
	$placeHoldersdoctors_chart["Serbian"]["id"] = "";
	$fieldLabelsdoctors_chart["Serbian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Serbian"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Serbian"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Serbian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Serbian"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Serbian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Serbian"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Serbian"]["Email"] = "";
	$placeHoldersdoctors_chart["Serbian"]["Email"] = "";
	$fieldLabelsdoctors_chart["Serbian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Serbian"]["Photo"] = "";
	$placeHoldersdoctors_chart["Serbian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Serbian"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsdoctors_chart["Slovak"] = array();
	$fieldToolTipsdoctors_chart["Slovak"] = array();
	$placeHoldersdoctors_chart["Slovak"] = array();
	$pageTitlesdoctors_chart["Slovak"] = array();
	$fieldLabelsdoctors_chart["Slovak"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Slovak"]["id"] = "";
	$placeHoldersdoctors_chart["Slovak"]["id"] = "";
	$fieldLabelsdoctors_chart["Slovak"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Slovak"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Slovak"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Slovak"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Slovak"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Slovak"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Slovak"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Slovak"]["Email"] = "";
	$placeHoldersdoctors_chart["Slovak"]["Email"] = "";
	$fieldLabelsdoctors_chart["Slovak"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Slovak"]["Photo"] = "";
	$placeHoldersdoctors_chart["Slovak"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Slovak"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsdoctors_chart["Spanish"] = array();
	$fieldToolTipsdoctors_chart["Spanish"] = array();
	$placeHoldersdoctors_chart["Spanish"] = array();
	$pageTitlesdoctors_chart["Spanish"] = array();
	$fieldLabelsdoctors_chart["Spanish"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Spanish"]["id"] = "";
	$placeHoldersdoctors_chart["Spanish"]["id"] = "";
	$fieldLabelsdoctors_chart["Spanish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Spanish"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Spanish"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Spanish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Spanish"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Spanish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Spanish"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Spanish"]["Email"] = "";
	$placeHoldersdoctors_chart["Spanish"]["Email"] = "";
	$fieldLabelsdoctors_chart["Spanish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Spanish"]["Photo"] = "";
	$placeHoldersdoctors_chart["Spanish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Spanish"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsdoctors_chart["Swedish"] = array();
	$fieldToolTipsdoctors_chart["Swedish"] = array();
	$placeHoldersdoctors_chart["Swedish"] = array();
	$pageTitlesdoctors_chart["Swedish"] = array();
	$fieldLabelsdoctors_chart["Swedish"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Swedish"]["id"] = "";
	$placeHoldersdoctors_chart["Swedish"]["id"] = "";
	$fieldLabelsdoctors_chart["Swedish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Swedish"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Swedish"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Swedish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Swedish"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Swedish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Swedish"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Swedish"]["Email"] = "";
	$placeHoldersdoctors_chart["Swedish"]["Email"] = "";
	$fieldLabelsdoctors_chart["Swedish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Swedish"]["Photo"] = "";
	$placeHoldersdoctors_chart["Swedish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Swedish"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsdoctors_chart["Tagalog(Philippines)"] = array();
	$fieldToolTipsdoctors_chart["Tagalog(Philippines)"] = array();
	$placeHoldersdoctors_chart["Tagalog(Philippines)"] = array();
	$pageTitlesdoctors_chart["Tagalog(Philippines)"] = array();
	$fieldLabelsdoctors_chart["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersdoctors_chart["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsdoctors_chart["Tagalog(Philippines)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Tagalog(Philippines)"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Tagalog(Philippines)"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Tagalog(Philippines)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Tagalog(Philippines)"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Tagalog(Philippines)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Tagalog(Philippines)"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Tagalog(Philippines)"]["Email"] = "";
	$placeHoldersdoctors_chart["Tagalog(Philippines)"]["Email"] = "";
	$fieldLabelsdoctors_chart["Tagalog(Philippines)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Tagalog(Philippines)"]["Photo"] = "";
	$placeHoldersdoctors_chart["Tagalog(Philippines)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Tagalog(Philippines)"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsdoctors_chart["Thai"] = array();
	$fieldToolTipsdoctors_chart["Thai"] = array();
	$placeHoldersdoctors_chart["Thai"] = array();
	$pageTitlesdoctors_chart["Thai"] = array();
	$fieldLabelsdoctors_chart["Thai"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Thai"]["id"] = "";
	$placeHoldersdoctors_chart["Thai"]["id"] = "";
	$fieldLabelsdoctors_chart["Thai"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Thai"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Thai"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Thai"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Thai"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Thai"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Thai"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Thai"]["Email"] = "";
	$placeHoldersdoctors_chart["Thai"]["Email"] = "";
	$fieldLabelsdoctors_chart["Thai"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Thai"]["Photo"] = "";
	$placeHoldersdoctors_chart["Thai"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Thai"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsdoctors_chart["Turkish"] = array();
	$fieldToolTipsdoctors_chart["Turkish"] = array();
	$placeHoldersdoctors_chart["Turkish"] = array();
	$pageTitlesdoctors_chart["Turkish"] = array();
	$fieldLabelsdoctors_chart["Turkish"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Turkish"]["id"] = "";
	$placeHoldersdoctors_chart["Turkish"]["id"] = "";
	$fieldLabelsdoctors_chart["Turkish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Turkish"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Turkish"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Turkish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Turkish"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Turkish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Turkish"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Turkish"]["Email"] = "";
	$placeHoldersdoctors_chart["Turkish"]["Email"] = "";
	$fieldLabelsdoctors_chart["Turkish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Turkish"]["Photo"] = "";
	$placeHoldersdoctors_chart["Turkish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Turkish"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsdoctors_chart["Urdu"] = array();
	$fieldToolTipsdoctors_chart["Urdu"] = array();
	$placeHoldersdoctors_chart["Urdu"] = array();
	$pageTitlesdoctors_chart["Urdu"] = array();
	$fieldLabelsdoctors_chart["Urdu"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Urdu"]["id"] = "";
	$placeHoldersdoctors_chart["Urdu"]["id"] = "";
	$fieldLabelsdoctors_chart["Urdu"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Urdu"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Urdu"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Urdu"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Urdu"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Urdu"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Urdu"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Urdu"]["Email"] = "";
	$placeHoldersdoctors_chart["Urdu"]["Email"] = "";
	$fieldLabelsdoctors_chart["Urdu"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Urdu"]["Photo"] = "";
	$placeHoldersdoctors_chart["Urdu"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Urdu"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsdoctors_chart["Welsh"] = array();
	$fieldToolTipsdoctors_chart["Welsh"] = array();
	$placeHoldersdoctors_chart["Welsh"] = array();
	$pageTitlesdoctors_chart["Welsh"] = array();
	$fieldLabelsdoctors_chart["Welsh"]["id"] = "Id";
	$fieldToolTipsdoctors_chart["Welsh"]["id"] = "";
	$placeHoldersdoctors_chart["Welsh"]["id"] = "";
	$fieldLabelsdoctors_chart["Welsh"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_chart["Welsh"]["DoctorName"] = "";
	$placeHoldersdoctors_chart["Welsh"]["DoctorName"] = "";
	$fieldLabelsdoctors_chart["Welsh"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_chart["Welsh"]["ContactNumber"] = "";
	$placeHoldersdoctors_chart["Welsh"]["ContactNumber"] = "";
	$fieldLabelsdoctors_chart["Welsh"]["Email"] = "Email";
	$fieldToolTipsdoctors_chart["Welsh"]["Email"] = "";
	$placeHoldersdoctors_chart["Welsh"]["Email"] = "";
	$fieldLabelsdoctors_chart["Welsh"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_chart["Welsh"]["Photo"] = "";
	$placeHoldersdoctors_chart["Welsh"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_chart["Welsh"]))
		$tdatadoctors_chart[".isUseToolTips"] = true;
}


	$tdatadoctors_chart[".NCSearch"] = true;

	$tdatadoctors_chart[".ChartRefreshTime"] = 0;


$tdatadoctors_chart[".shortTableName"] = "doctors_chart";
$tdatadoctors_chart[".nSecOptions"] = 0;

$tdatadoctors_chart[".mainTableOwnerID"] = "";
$tdatadoctors_chart[".entityType"] = 3;
$tdatadoctors_chart[".connId"] = "testdb_at_localhost";


$tdatadoctors_chart[".strOriginalTableName"] = "doctors";

	



$tdatadoctors_chart[".showAddInPopup"] = false;

$tdatadoctors_chart[".showEditInPopup"] = false;

$tdatadoctors_chart[".showViewInPopup"] = false;

$tdatadoctors_chart[".listAjax"] = false;
//	temporary
//$tdatadoctors_chart[".listAjax"] = false;

	$tdatadoctors_chart[".audit"] = false;

	$tdatadoctors_chart[".locking"] = false;


$pages = $tdatadoctors_chart[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatadoctors_chart[".edit"] = true;
	$tdatadoctors_chart[".afterEditAction"] = 1;
	$tdatadoctors_chart[".closePopupAfterEdit"] = 1;
	$tdatadoctors_chart[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatadoctors_chart[".add"] = true;
$tdatadoctors_chart[".afterAddAction"] = 1;
$tdatadoctors_chart[".closePopupAfterAdd"] = 1;
$tdatadoctors_chart[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatadoctors_chart[".list"] = true;
}



$tdatadoctors_chart[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatadoctors_chart[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatadoctors_chart[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatadoctors_chart[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatadoctors_chart[".printFriendly"] = true;
}



$tdatadoctors_chart[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatadoctors_chart[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatadoctors_chart[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatadoctors_chart[".isUseAjaxSuggest"] = true;





$tdatadoctors_chart[".ajaxCodeSnippetAdded"] = false;

$tdatadoctors_chart[".buttonsAdded"] = false;

$tdatadoctors_chart[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadoctors_chart[".isUseTimeForSearch"] = false;


$tdatadoctors_chart[".badgeColor"] = "DC143C";


$tdatadoctors_chart[".allSearchFields"] = array();
$tdatadoctors_chart[".filterFields"] = array();
$tdatadoctors_chart[".requiredSearchFields"] = array();

$tdatadoctors_chart[".googleLikeFields"] = array();
$tdatadoctors_chart[".googleLikeFields"][] = "id";
$tdatadoctors_chart[".googleLikeFields"][] = "DoctorName";
$tdatadoctors_chart[".googleLikeFields"][] = "ContactNumber";
$tdatadoctors_chart[".googleLikeFields"][] = "Email";
$tdatadoctors_chart[".googleLikeFields"][] = "Photo";



$tdatadoctors_chart[".tableType"] = "chart";

$tdatadoctors_chart[".printerPageOrientation"] = 0;
$tdatadoctors_chart[".nPrinterPageScale"] = 100;

$tdatadoctors_chart[".nPrinterSplitRecords"] = 40;

$tdatadoctors_chart[".geocodingEnabled"] = false;



// chart settings
$tdatadoctors_chart[".chartType"] = "2DColumn";
// end of chart settings

$tdatadoctors_chart[".isDisplayLoading"] = true;







$tstrOrderBy = "";
$tdatadoctors_chart[".strOrderBy"] = $tstrOrderBy;

$tdatadoctors_chart[".orderindexes"] = array();


$tdatadoctors_chart[".sqlHead"] = "SELECT id,  	DoctorName,  	ContactNumber,  	Email,  	Photo";
$tdatadoctors_chart[".sqlFrom"] = "FROM doctors";
$tdatadoctors_chart[".sqlWhereExpr"] = "";
$tdatadoctors_chart[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadoctors_chart[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadoctors_chart[".arrGroupsPerPage"] = $arrGPP;

$tdatadoctors_chart[".highlightSearchResults"] = true;

$tableKeysdoctors_chart = array();
$tableKeysdoctors_chart[] = "id";
$tdatadoctors_chart[".Keys"] = $tableKeysdoctors_chart;


$tdatadoctors_chart[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Chart","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_chart["id"] = $fdata;
		$tdatadoctors_chart[".searchableFields"][] = "id";
//	DoctorName
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "DoctorName";
	$fdata["GoodName"] = "DoctorName";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Chart","DoctorName");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DoctorName";

		$fdata["sourceSingle"] = "DoctorName";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DoctorName";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_chart["DoctorName"] = $fdata;
		$tdatadoctors_chart[".searchableFields"][] = "DoctorName";
//	ContactNumber
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "ContactNumber";
	$fdata["GoodName"] = "ContactNumber";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Chart","ContactNumber");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "ContactNumber";

		$fdata["sourceSingle"] = "ContactNumber";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ContactNumber";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_chart["ContactNumber"] = $fdata;
		$tdatadoctors_chart[".searchableFields"][] = "ContactNumber";
//	Email
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Email";
	$fdata["GoodName"] = "Email";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Chart","Email");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Email";

		$fdata["sourceSingle"] = "Email";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Email";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_chart["Email"] = $fdata;
		$tdatadoctors_chart[".searchableFields"][] = "Email";
//	Photo
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Photo";
	$fdata["GoodName"] = "Photo";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Chart","Photo");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Photo";

		$fdata["sourceSingle"] = "Photo";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Photo";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "File-based Image");

	
	
				$vdata["ImageWidth"] = 600;
	$vdata["ImageHeight"] = 400;

			$vdata["multipleImgMode"] = 1;
	$vdata["maxImages"] = 0;

			$vdata["showGallery"] = true;
	$vdata["galleryMode"] = 2;
	$vdata["captionMode"] = 2;
	$vdata["captionField"] = "";

	$vdata["imageBorder"] = 1;
	$vdata["imageFullWidth"] = 1;


	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_chart["Photo"] = $fdata;
		$tdatadoctors_chart[".searchableFields"][] = "Photo";

$tdatadoctors_chart[".chartLabelField"] = "DoctorName";
$tdatadoctors_chart[".chartSeries"] = array();
$tdatadoctors_chart[".chartSeries"][] = array(
	"field" => "ContactNumber",
	"total" => ""
);
	$tdatadoctors_chart[".chartXml"] = '<chart>
		<attr value="tables">
			<attr value="0">doctors Chart</attr>
		</attr>
		<attr value="chart_type">
			<attr value="type">2d_column</attr>
		</attr>

		<attr value="parameters">';
	$tdatadoctors_chart[".chartXml"] .= '<attr value="0">
			<attr value="name">ContactNumber</attr>';
	$tdatadoctors_chart[".chartXml"] .= '</attr>';
	$tdatadoctors_chart[".chartXml"] .= '<attr value="1">
		<attr value="name">DoctorName</attr>
	</attr>';
	$tdatadoctors_chart[".chartXml"] .= '</attr>
			<attr value="appearance">';


	$tdatadoctors_chart[".chartXml"] .= '<attr value="head">'.xmlencode("Doctors Chart").'</attr>
<attr value="foot">'.xmlencode("Results").'</attr>
<attr value="y_axis_label">'.xmlencode("ContactNumber").'</attr>


<attr value="slegend">true</attr>
<attr value="sgrid">true</attr>
<attr value="sname">true</attr>
<attr value="sval">true</attr>
<attr value="sanim">true</attr>
<attr value="sstacked">false</attr>
<attr value="slog">false</attr>
<attr value="aqua">0</attr>
<attr value="cview">0</attr>
<attr value="is3d">1</attr>
<attr value="isstacked">0</attr>
<attr value="linestyle">0</attr>
<attr value="autoupdate">0</attr>
<attr value="autoupmin">60</attr>';
$tdatadoctors_chart[".chartXml"] .= '</attr>

<attr value="fields">';
	$tdatadoctors_chart[".chartXml"] .= '<attr value="0">
		<attr value="name">id</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("doctors_Chart","id")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadoctors_chart[".chartXml"] .= '<attr value="1">
		<attr value="name">DoctorName</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("doctors_Chart","DoctorName")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadoctors_chart[".chartXml"] .= '<attr value="2">
		<attr value="name">ContactNumber</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("doctors_Chart","ContactNumber")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadoctors_chart[".chartXml"] .= '<attr value="3">
		<attr value="name">Email</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("doctors_Chart","Email")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadoctors_chart[".chartXml"] .= '<attr value="4">
		<attr value="name">Photo</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("doctors_Chart","Photo")).'</attr>
		<attr value="search"></attr>
	</attr>';
$tdatadoctors_chart[".chartXml"] .= '</attr>


<attr value="settings">
<attr value="name">doctors Chart</attr>
<attr value="short_table_name">doctors_chart</attr>
</attr>

</chart>';

$tables_data["doctors Chart"]=&$tdatadoctors_chart;
$field_labels["doctors_Chart"] = &$fieldLabelsdoctors_chart;
$fieldToolTips["doctors_Chart"] = &$fieldToolTipsdoctors_chart;
$placeHolders["doctors_Chart"] = &$placeHoldersdoctors_chart;
$page_titles["doctors_Chart"] = &$pageTitlesdoctors_chart;


changeTextControlsToDate( "doctors Chart" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["doctors Chart"] = array();
//	treatments
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="treatments";
		$detailsParam["dOriginalTable"] = "treatments";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "treatments";
	$detailsParam["dCaptionTable"] = GetTableCaption("treatments");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["doctors Chart"][$dIndex] = $detailsParam;

	
		$detailsTablesData["doctors Chart"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["doctors Chart"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["doctors Chart"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["doctors Chart"][$dIndex]["detailKeys"][]="doctor_id";
//endif

// tables which are master tables for current table (detail)
$masterTablesData["doctors Chart"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_doctors_chart()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	DoctorName,  	ContactNumber,  	Email,  	Photo";
$proto0["m_strFrom"] = "FROM doctors";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Chart"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "doctors Chart";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "DoctorName",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Chart"
));

$proto8["m_sql"] = "DoctorName";
$proto8["m_srcTableName"] = "doctors Chart";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "ContactNumber",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Chart"
));

$proto10["m_sql"] = "ContactNumber";
$proto10["m_srcTableName"] = "doctors Chart";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Email",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Chart"
));

$proto12["m_sql"] = "Email";
$proto12["m_srcTableName"] = "doctors Chart";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Photo",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Chart"
));

$proto14["m_sql"] = "Photo";
$proto14["m_srcTableName"] = "doctors Chart";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "doctors";
$proto17["m_srcTableName"] = "doctors Chart";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "DoctorName";
$proto17["m_columns"][] = "ContactNumber";
$proto17["m_columns"][] = "Email";
$proto17["m_columns"][] = "Photo";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "doctors";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "doctors Chart";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="doctors Chart";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_doctors_chart = createSqlQuery_doctors_chart();


	
		;

					

$tdatadoctors_chart[".sqlquery"] = $queryData_doctors_chart;



$tdatadoctors_chart[".hasEvents"] = false;

?>