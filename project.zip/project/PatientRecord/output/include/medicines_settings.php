<?php
$tdatamedicines = array();
$tdatamedicines[".searchableFields"] = array();
$tdatamedicines[".ShortName"] = "medicines";
$tdatamedicines[".OwnerID"] = "";
$tdatamedicines[".OriginalTable"] = "medicines";


$tdatamedicines[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatamedicines[".originalPagesByType"] = $tdatamedicines[".pagesByType"];
$tdatamedicines[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatamedicines[".originalPages"] = $tdatamedicines[".pages"];
$tdatamedicines[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"masterlist\":\"masterlist\",\"masterprint\":\"masterprint\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatamedicines[".originalDefaultPages"] = $tdatamedicines[".defaultPages"];

//	field labels
$fieldLabelsmedicines = array();
$fieldToolTipsmedicines = array();
$pageTitlesmedicines = array();
$placeHoldersmedicines = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsmedicines["English"] = array();
	$fieldToolTipsmedicines["English"] = array();
	$placeHoldersmedicines["English"] = array();
	$pageTitlesmedicines["English"] = array();
	$fieldLabelsmedicines["English"]["id"] = "Id";
	$fieldToolTipsmedicines["English"]["id"] = "";
	$placeHoldersmedicines["English"]["id"] = "";
	$fieldLabelsmedicines["English"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["English"]["MedicineName"] = "";
	$placeHoldersmedicines["English"]["MedicineName"] = "";
	$fieldLabelsmedicines["English"]["Description"] = "Description";
	$fieldToolTipsmedicines["English"]["Description"] = "";
	$placeHoldersmedicines["English"]["Description"] = "";
	$fieldLabelsmedicines["English"]["Type"] = "Type";
	$fieldToolTipsmedicines["English"]["Type"] = "";
	$placeHoldersmedicines["English"]["Type"] = "";
	if (count($fieldToolTipsmedicines["English"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsmedicines["Afrikaans"] = array();
	$fieldToolTipsmedicines["Afrikaans"] = array();
	$placeHoldersmedicines["Afrikaans"] = array();
	$pageTitlesmedicines["Afrikaans"] = array();
	$fieldLabelsmedicines["Afrikaans"]["id"] = "Id";
	$fieldToolTipsmedicines["Afrikaans"]["id"] = "";
	$placeHoldersmedicines["Afrikaans"]["id"] = "";
	$fieldLabelsmedicines["Afrikaans"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Afrikaans"]["MedicineName"] = "";
	$placeHoldersmedicines["Afrikaans"]["MedicineName"] = "";
	$fieldLabelsmedicines["Afrikaans"]["Description"] = "Description";
	$fieldToolTipsmedicines["Afrikaans"]["Description"] = "";
	$placeHoldersmedicines["Afrikaans"]["Description"] = "";
	$fieldLabelsmedicines["Afrikaans"]["Type"] = "Type";
	$fieldToolTipsmedicines["Afrikaans"]["Type"] = "";
	$placeHoldersmedicines["Afrikaans"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Afrikaans"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsmedicines["Arabic"] = array();
	$fieldToolTipsmedicines["Arabic"] = array();
	$placeHoldersmedicines["Arabic"] = array();
	$pageTitlesmedicines["Arabic"] = array();
	$fieldLabelsmedicines["Arabic"]["id"] = "Id";
	$fieldToolTipsmedicines["Arabic"]["id"] = "";
	$placeHoldersmedicines["Arabic"]["id"] = "";
	$fieldLabelsmedicines["Arabic"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Arabic"]["MedicineName"] = "";
	$placeHoldersmedicines["Arabic"]["MedicineName"] = "";
	$fieldLabelsmedicines["Arabic"]["Description"] = "Description";
	$fieldToolTipsmedicines["Arabic"]["Description"] = "";
	$placeHoldersmedicines["Arabic"]["Description"] = "";
	$fieldLabelsmedicines["Arabic"]["Type"] = "Type";
	$fieldToolTipsmedicines["Arabic"]["Type"] = "";
	$placeHoldersmedicines["Arabic"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Arabic"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsmedicines["Bosnian"] = array();
	$fieldToolTipsmedicines["Bosnian"] = array();
	$placeHoldersmedicines["Bosnian"] = array();
	$pageTitlesmedicines["Bosnian"] = array();
	$fieldLabelsmedicines["Bosnian"]["id"] = "Id";
	$fieldToolTipsmedicines["Bosnian"]["id"] = "";
	$placeHoldersmedicines["Bosnian"]["id"] = "";
	$fieldLabelsmedicines["Bosnian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Bosnian"]["MedicineName"] = "";
	$placeHoldersmedicines["Bosnian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Bosnian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Bosnian"]["Description"] = "";
	$placeHoldersmedicines["Bosnian"]["Description"] = "";
	$fieldLabelsmedicines["Bosnian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Bosnian"]["Type"] = "";
	$placeHoldersmedicines["Bosnian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Bosnian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsmedicines["Bulgarian"] = array();
	$fieldToolTipsmedicines["Bulgarian"] = array();
	$placeHoldersmedicines["Bulgarian"] = array();
	$pageTitlesmedicines["Bulgarian"] = array();
	$fieldLabelsmedicines["Bulgarian"]["id"] = "Id";
	$fieldToolTipsmedicines["Bulgarian"]["id"] = "";
	$placeHoldersmedicines["Bulgarian"]["id"] = "";
	$fieldLabelsmedicines["Bulgarian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Bulgarian"]["MedicineName"] = "";
	$placeHoldersmedicines["Bulgarian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Bulgarian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Bulgarian"]["Description"] = "";
	$placeHoldersmedicines["Bulgarian"]["Description"] = "";
	$fieldLabelsmedicines["Bulgarian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Bulgarian"]["Type"] = "";
	$placeHoldersmedicines["Bulgarian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Bulgarian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsmedicines["Catalan"] = array();
	$fieldToolTipsmedicines["Catalan"] = array();
	$placeHoldersmedicines["Catalan"] = array();
	$pageTitlesmedicines["Catalan"] = array();
	$fieldLabelsmedicines["Catalan"]["id"] = "Id";
	$fieldToolTipsmedicines["Catalan"]["id"] = "";
	$placeHoldersmedicines["Catalan"]["id"] = "";
	$fieldLabelsmedicines["Catalan"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Catalan"]["MedicineName"] = "";
	$placeHoldersmedicines["Catalan"]["MedicineName"] = "";
	$fieldLabelsmedicines["Catalan"]["Description"] = "Description";
	$fieldToolTipsmedicines["Catalan"]["Description"] = "";
	$placeHoldersmedicines["Catalan"]["Description"] = "";
	$fieldLabelsmedicines["Catalan"]["Type"] = "Type";
	$fieldToolTipsmedicines["Catalan"]["Type"] = "";
	$placeHoldersmedicines["Catalan"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Catalan"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsmedicines["Chinese"] = array();
	$fieldToolTipsmedicines["Chinese"] = array();
	$placeHoldersmedicines["Chinese"] = array();
	$pageTitlesmedicines["Chinese"] = array();
	$fieldLabelsmedicines["Chinese"]["id"] = "Id";
	$fieldToolTipsmedicines["Chinese"]["id"] = "";
	$placeHoldersmedicines["Chinese"]["id"] = "";
	$fieldLabelsmedicines["Chinese"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Chinese"]["MedicineName"] = "";
	$placeHoldersmedicines["Chinese"]["MedicineName"] = "";
	$fieldLabelsmedicines["Chinese"]["Description"] = "Description";
	$fieldToolTipsmedicines["Chinese"]["Description"] = "";
	$placeHoldersmedicines["Chinese"]["Description"] = "";
	$fieldLabelsmedicines["Chinese"]["Type"] = "Type";
	$fieldToolTipsmedicines["Chinese"]["Type"] = "";
	$placeHoldersmedicines["Chinese"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Chinese"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsmedicines["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsmedicines["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersmedicines["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesmedicines["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsmedicines["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsmedicines["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersmedicines["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsmedicines["Chinese (Hong Kong S.A.R.)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Chinese (Hong Kong S.A.R.)"]["MedicineName"] = "";
	$placeHoldersmedicines["Chinese (Hong Kong S.A.R.)"]["MedicineName"] = "";
	$fieldLabelsmedicines["Chinese (Hong Kong S.A.R.)"]["Description"] = "Description";
	$fieldToolTipsmedicines["Chinese (Hong Kong S.A.R.)"]["Description"] = "";
	$placeHoldersmedicines["Chinese (Hong Kong S.A.R.)"]["Description"] = "";
	$fieldLabelsmedicines["Chinese (Hong Kong S.A.R.)"]["Type"] = "Type";
	$fieldToolTipsmedicines["Chinese (Hong Kong S.A.R.)"]["Type"] = "";
	$placeHoldersmedicines["Chinese (Hong Kong S.A.R.)"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Chinese (Hong Kong S.A.R.)"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsmedicines["Chinese (Taiwan)"] = array();
	$fieldToolTipsmedicines["Chinese (Taiwan)"] = array();
	$placeHoldersmedicines["Chinese (Taiwan)"] = array();
	$pageTitlesmedicines["Chinese (Taiwan)"] = array();
	$fieldLabelsmedicines["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsmedicines["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersmedicines["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsmedicines["Chinese (Taiwan)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Chinese (Taiwan)"]["MedicineName"] = "";
	$placeHoldersmedicines["Chinese (Taiwan)"]["MedicineName"] = "";
	$fieldLabelsmedicines["Chinese (Taiwan)"]["Description"] = "Description";
	$fieldToolTipsmedicines["Chinese (Taiwan)"]["Description"] = "";
	$placeHoldersmedicines["Chinese (Taiwan)"]["Description"] = "";
	$fieldLabelsmedicines["Chinese (Taiwan)"]["Type"] = "Type";
	$fieldToolTipsmedicines["Chinese (Taiwan)"]["Type"] = "";
	$placeHoldersmedicines["Chinese (Taiwan)"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Chinese (Taiwan)"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsmedicines["Croatian"] = array();
	$fieldToolTipsmedicines["Croatian"] = array();
	$placeHoldersmedicines["Croatian"] = array();
	$pageTitlesmedicines["Croatian"] = array();
	$fieldLabelsmedicines["Croatian"]["id"] = "Id";
	$fieldToolTipsmedicines["Croatian"]["id"] = "";
	$placeHoldersmedicines["Croatian"]["id"] = "";
	$fieldLabelsmedicines["Croatian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Croatian"]["MedicineName"] = "";
	$placeHoldersmedicines["Croatian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Croatian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Croatian"]["Description"] = "";
	$placeHoldersmedicines["Croatian"]["Description"] = "";
	$fieldLabelsmedicines["Croatian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Croatian"]["Type"] = "";
	$placeHoldersmedicines["Croatian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Croatian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsmedicines["Czech"] = array();
	$fieldToolTipsmedicines["Czech"] = array();
	$placeHoldersmedicines["Czech"] = array();
	$pageTitlesmedicines["Czech"] = array();
	$fieldLabelsmedicines["Czech"]["id"] = "Id";
	$fieldToolTipsmedicines["Czech"]["id"] = "";
	$placeHoldersmedicines["Czech"]["id"] = "";
	$fieldLabelsmedicines["Czech"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Czech"]["MedicineName"] = "";
	$placeHoldersmedicines["Czech"]["MedicineName"] = "";
	$fieldLabelsmedicines["Czech"]["Description"] = "Description";
	$fieldToolTipsmedicines["Czech"]["Description"] = "";
	$placeHoldersmedicines["Czech"]["Description"] = "";
	$fieldLabelsmedicines["Czech"]["Type"] = "Type";
	$fieldToolTipsmedicines["Czech"]["Type"] = "";
	$placeHoldersmedicines["Czech"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Czech"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsmedicines["Danish"] = array();
	$fieldToolTipsmedicines["Danish"] = array();
	$placeHoldersmedicines["Danish"] = array();
	$pageTitlesmedicines["Danish"] = array();
	$fieldLabelsmedicines["Danish"]["id"] = "Id";
	$fieldToolTipsmedicines["Danish"]["id"] = "";
	$placeHoldersmedicines["Danish"]["id"] = "";
	$fieldLabelsmedicines["Danish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Danish"]["MedicineName"] = "";
	$placeHoldersmedicines["Danish"]["MedicineName"] = "";
	$fieldLabelsmedicines["Danish"]["Description"] = "Description";
	$fieldToolTipsmedicines["Danish"]["Description"] = "";
	$placeHoldersmedicines["Danish"]["Description"] = "";
	$fieldLabelsmedicines["Danish"]["Type"] = "Type";
	$fieldToolTipsmedicines["Danish"]["Type"] = "";
	$placeHoldersmedicines["Danish"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Danish"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsmedicines["Dutch"] = array();
	$fieldToolTipsmedicines["Dutch"] = array();
	$placeHoldersmedicines["Dutch"] = array();
	$pageTitlesmedicines["Dutch"] = array();
	$fieldLabelsmedicines["Dutch"]["id"] = "Id";
	$fieldToolTipsmedicines["Dutch"]["id"] = "";
	$placeHoldersmedicines["Dutch"]["id"] = "";
	$fieldLabelsmedicines["Dutch"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Dutch"]["MedicineName"] = "";
	$placeHoldersmedicines["Dutch"]["MedicineName"] = "";
	$fieldLabelsmedicines["Dutch"]["Description"] = "Description";
	$fieldToolTipsmedicines["Dutch"]["Description"] = "";
	$placeHoldersmedicines["Dutch"]["Description"] = "";
	$fieldLabelsmedicines["Dutch"]["Type"] = "Type";
	$fieldToolTipsmedicines["Dutch"]["Type"] = "";
	$placeHoldersmedicines["Dutch"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Dutch"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsmedicines["Farsi"] = array();
	$fieldToolTipsmedicines["Farsi"] = array();
	$placeHoldersmedicines["Farsi"] = array();
	$pageTitlesmedicines["Farsi"] = array();
	$fieldLabelsmedicines["Farsi"]["id"] = "Id";
	$fieldToolTipsmedicines["Farsi"]["id"] = "";
	$placeHoldersmedicines["Farsi"]["id"] = "";
	$fieldLabelsmedicines["Farsi"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Farsi"]["MedicineName"] = "";
	$placeHoldersmedicines["Farsi"]["MedicineName"] = "";
	$fieldLabelsmedicines["Farsi"]["Description"] = "Description";
	$fieldToolTipsmedicines["Farsi"]["Description"] = "";
	$placeHoldersmedicines["Farsi"]["Description"] = "";
	$fieldLabelsmedicines["Farsi"]["Type"] = "Type";
	$fieldToolTipsmedicines["Farsi"]["Type"] = "";
	$placeHoldersmedicines["Farsi"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Farsi"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsmedicines["French"] = array();
	$fieldToolTipsmedicines["French"] = array();
	$placeHoldersmedicines["French"] = array();
	$pageTitlesmedicines["French"] = array();
	$fieldLabelsmedicines["French"]["id"] = "Id";
	$fieldToolTipsmedicines["French"]["id"] = "";
	$placeHoldersmedicines["French"]["id"] = "";
	$fieldLabelsmedicines["French"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["French"]["MedicineName"] = "";
	$placeHoldersmedicines["French"]["MedicineName"] = "";
	$fieldLabelsmedicines["French"]["Description"] = "Description";
	$fieldToolTipsmedicines["French"]["Description"] = "";
	$placeHoldersmedicines["French"]["Description"] = "";
	$fieldLabelsmedicines["French"]["Type"] = "Type";
	$fieldToolTipsmedicines["French"]["Type"] = "";
	$placeHoldersmedicines["French"]["Type"] = "";
	if (count($fieldToolTipsmedicines["French"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsmedicines["Georgian"] = array();
	$fieldToolTipsmedicines["Georgian"] = array();
	$placeHoldersmedicines["Georgian"] = array();
	$pageTitlesmedicines["Georgian"] = array();
	$fieldLabelsmedicines["Georgian"]["id"] = "Id";
	$fieldToolTipsmedicines["Georgian"]["id"] = "";
	$placeHoldersmedicines["Georgian"]["id"] = "";
	$fieldLabelsmedicines["Georgian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Georgian"]["MedicineName"] = "";
	$placeHoldersmedicines["Georgian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Georgian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Georgian"]["Description"] = "";
	$placeHoldersmedicines["Georgian"]["Description"] = "";
	$fieldLabelsmedicines["Georgian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Georgian"]["Type"] = "";
	$placeHoldersmedicines["Georgian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Georgian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsmedicines["German"] = array();
	$fieldToolTipsmedicines["German"] = array();
	$placeHoldersmedicines["German"] = array();
	$pageTitlesmedicines["German"] = array();
	$fieldLabelsmedicines["German"]["id"] = "Id";
	$fieldToolTipsmedicines["German"]["id"] = "";
	$placeHoldersmedicines["German"]["id"] = "";
	$fieldLabelsmedicines["German"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["German"]["MedicineName"] = "";
	$placeHoldersmedicines["German"]["MedicineName"] = "";
	$fieldLabelsmedicines["German"]["Description"] = "Description";
	$fieldToolTipsmedicines["German"]["Description"] = "";
	$placeHoldersmedicines["German"]["Description"] = "";
	$fieldLabelsmedicines["German"]["Type"] = "Type";
	$fieldToolTipsmedicines["German"]["Type"] = "";
	$placeHoldersmedicines["German"]["Type"] = "";
	if (count($fieldToolTipsmedicines["German"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsmedicines["Greek"] = array();
	$fieldToolTipsmedicines["Greek"] = array();
	$placeHoldersmedicines["Greek"] = array();
	$pageTitlesmedicines["Greek"] = array();
	$fieldLabelsmedicines["Greek"]["id"] = "Id";
	$fieldToolTipsmedicines["Greek"]["id"] = "";
	$placeHoldersmedicines["Greek"]["id"] = "";
	$fieldLabelsmedicines["Greek"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Greek"]["MedicineName"] = "";
	$placeHoldersmedicines["Greek"]["MedicineName"] = "";
	$fieldLabelsmedicines["Greek"]["Description"] = "Description";
	$fieldToolTipsmedicines["Greek"]["Description"] = "";
	$placeHoldersmedicines["Greek"]["Description"] = "";
	$fieldLabelsmedicines["Greek"]["Type"] = "Type";
	$fieldToolTipsmedicines["Greek"]["Type"] = "";
	$placeHoldersmedicines["Greek"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Greek"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsmedicines["Hebrew"] = array();
	$fieldToolTipsmedicines["Hebrew"] = array();
	$placeHoldersmedicines["Hebrew"] = array();
	$pageTitlesmedicines["Hebrew"] = array();
	$fieldLabelsmedicines["Hebrew"]["id"] = "Id";
	$fieldToolTipsmedicines["Hebrew"]["id"] = "";
	$placeHoldersmedicines["Hebrew"]["id"] = "";
	$fieldLabelsmedicines["Hebrew"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Hebrew"]["MedicineName"] = "";
	$placeHoldersmedicines["Hebrew"]["MedicineName"] = "";
	$fieldLabelsmedicines["Hebrew"]["Description"] = "Description";
	$fieldToolTipsmedicines["Hebrew"]["Description"] = "";
	$placeHoldersmedicines["Hebrew"]["Description"] = "";
	$fieldLabelsmedicines["Hebrew"]["Type"] = "Type";
	$fieldToolTipsmedicines["Hebrew"]["Type"] = "";
	$placeHoldersmedicines["Hebrew"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Hebrew"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsmedicines["Hungarian"] = array();
	$fieldToolTipsmedicines["Hungarian"] = array();
	$placeHoldersmedicines["Hungarian"] = array();
	$pageTitlesmedicines["Hungarian"] = array();
	$fieldLabelsmedicines["Hungarian"]["id"] = "Id";
	$fieldToolTipsmedicines["Hungarian"]["id"] = "";
	$placeHoldersmedicines["Hungarian"]["id"] = "";
	$fieldLabelsmedicines["Hungarian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Hungarian"]["MedicineName"] = "";
	$placeHoldersmedicines["Hungarian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Hungarian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Hungarian"]["Description"] = "";
	$placeHoldersmedicines["Hungarian"]["Description"] = "";
	$fieldLabelsmedicines["Hungarian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Hungarian"]["Type"] = "";
	$placeHoldersmedicines["Hungarian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Hungarian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsmedicines["Indonesian"] = array();
	$fieldToolTipsmedicines["Indonesian"] = array();
	$placeHoldersmedicines["Indonesian"] = array();
	$pageTitlesmedicines["Indonesian"] = array();
	$fieldLabelsmedicines["Indonesian"]["id"] = "Id";
	$fieldToolTipsmedicines["Indonesian"]["id"] = "";
	$placeHoldersmedicines["Indonesian"]["id"] = "";
	$fieldLabelsmedicines["Indonesian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Indonesian"]["MedicineName"] = "";
	$placeHoldersmedicines["Indonesian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Indonesian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Indonesian"]["Description"] = "";
	$placeHoldersmedicines["Indonesian"]["Description"] = "";
	$fieldLabelsmedicines["Indonesian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Indonesian"]["Type"] = "";
	$placeHoldersmedicines["Indonesian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Indonesian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsmedicines["Italian"] = array();
	$fieldToolTipsmedicines["Italian"] = array();
	$placeHoldersmedicines["Italian"] = array();
	$pageTitlesmedicines["Italian"] = array();
	$fieldLabelsmedicines["Italian"]["id"] = "Id";
	$fieldToolTipsmedicines["Italian"]["id"] = "";
	$placeHoldersmedicines["Italian"]["id"] = "";
	$fieldLabelsmedicines["Italian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Italian"]["MedicineName"] = "";
	$placeHoldersmedicines["Italian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Italian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Italian"]["Description"] = "";
	$placeHoldersmedicines["Italian"]["Description"] = "";
	$fieldLabelsmedicines["Italian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Italian"]["Type"] = "";
	$placeHoldersmedicines["Italian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Italian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsmedicines["Japanese"] = array();
	$fieldToolTipsmedicines["Japanese"] = array();
	$placeHoldersmedicines["Japanese"] = array();
	$pageTitlesmedicines["Japanese"] = array();
	$fieldLabelsmedicines["Japanese"]["id"] = "Id";
	$fieldToolTipsmedicines["Japanese"]["id"] = "";
	$placeHoldersmedicines["Japanese"]["id"] = "";
	$fieldLabelsmedicines["Japanese"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Japanese"]["MedicineName"] = "";
	$placeHoldersmedicines["Japanese"]["MedicineName"] = "";
	$fieldLabelsmedicines["Japanese"]["Description"] = "Description";
	$fieldToolTipsmedicines["Japanese"]["Description"] = "";
	$placeHoldersmedicines["Japanese"]["Description"] = "";
	$fieldLabelsmedicines["Japanese"]["Type"] = "Type";
	$fieldToolTipsmedicines["Japanese"]["Type"] = "";
	$placeHoldersmedicines["Japanese"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Japanese"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsmedicines["Malay"] = array();
	$fieldToolTipsmedicines["Malay"] = array();
	$placeHoldersmedicines["Malay"] = array();
	$pageTitlesmedicines["Malay"] = array();
	$fieldLabelsmedicines["Malay"]["id"] = "Id";
	$fieldToolTipsmedicines["Malay"]["id"] = "";
	$placeHoldersmedicines["Malay"]["id"] = "";
	$fieldLabelsmedicines["Malay"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Malay"]["MedicineName"] = "";
	$placeHoldersmedicines["Malay"]["MedicineName"] = "";
	$fieldLabelsmedicines["Malay"]["Description"] = "Description";
	$fieldToolTipsmedicines["Malay"]["Description"] = "";
	$placeHoldersmedicines["Malay"]["Description"] = "";
	$fieldLabelsmedicines["Malay"]["Type"] = "Type";
	$fieldToolTipsmedicines["Malay"]["Type"] = "";
	$placeHoldersmedicines["Malay"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Malay"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsmedicines["Norwegian(Bokmal)"] = array();
	$fieldToolTipsmedicines["Norwegian(Bokmal)"] = array();
	$placeHoldersmedicines["Norwegian(Bokmal)"] = array();
	$pageTitlesmedicines["Norwegian(Bokmal)"] = array();
	$fieldLabelsmedicines["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsmedicines["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersmedicines["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsmedicines["Norwegian(Bokmal)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Norwegian(Bokmal)"]["MedicineName"] = "";
	$placeHoldersmedicines["Norwegian(Bokmal)"]["MedicineName"] = "";
	$fieldLabelsmedicines["Norwegian(Bokmal)"]["Description"] = "Description";
	$fieldToolTipsmedicines["Norwegian(Bokmal)"]["Description"] = "";
	$placeHoldersmedicines["Norwegian(Bokmal)"]["Description"] = "";
	$fieldLabelsmedicines["Norwegian(Bokmal)"]["Type"] = "Type";
	$fieldToolTipsmedicines["Norwegian(Bokmal)"]["Type"] = "";
	$placeHoldersmedicines["Norwegian(Bokmal)"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Norwegian(Bokmal)"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsmedicines["Polish"] = array();
	$fieldToolTipsmedicines["Polish"] = array();
	$placeHoldersmedicines["Polish"] = array();
	$pageTitlesmedicines["Polish"] = array();
	$fieldLabelsmedicines["Polish"]["id"] = "Id";
	$fieldToolTipsmedicines["Polish"]["id"] = "";
	$placeHoldersmedicines["Polish"]["id"] = "";
	$fieldLabelsmedicines["Polish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Polish"]["MedicineName"] = "";
	$placeHoldersmedicines["Polish"]["MedicineName"] = "";
	$fieldLabelsmedicines["Polish"]["Description"] = "Description";
	$fieldToolTipsmedicines["Polish"]["Description"] = "";
	$placeHoldersmedicines["Polish"]["Description"] = "";
	$fieldLabelsmedicines["Polish"]["Type"] = "Type";
	$fieldToolTipsmedicines["Polish"]["Type"] = "";
	$placeHoldersmedicines["Polish"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Polish"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsmedicines["Portuguese(Brazil)"] = array();
	$fieldToolTipsmedicines["Portuguese(Brazil)"] = array();
	$placeHoldersmedicines["Portuguese(Brazil)"] = array();
	$pageTitlesmedicines["Portuguese(Brazil)"] = array();
	$fieldLabelsmedicines["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsmedicines["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersmedicines["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsmedicines["Portuguese(Brazil)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Portuguese(Brazil)"]["MedicineName"] = "";
	$placeHoldersmedicines["Portuguese(Brazil)"]["MedicineName"] = "";
	$fieldLabelsmedicines["Portuguese(Brazil)"]["Description"] = "Description";
	$fieldToolTipsmedicines["Portuguese(Brazil)"]["Description"] = "";
	$placeHoldersmedicines["Portuguese(Brazil)"]["Description"] = "";
	$fieldLabelsmedicines["Portuguese(Brazil)"]["Type"] = "Type";
	$fieldToolTipsmedicines["Portuguese(Brazil)"]["Type"] = "";
	$placeHoldersmedicines["Portuguese(Brazil)"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Portuguese(Brazil)"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsmedicines["Portuguese(Standard)"] = array();
	$fieldToolTipsmedicines["Portuguese(Standard)"] = array();
	$placeHoldersmedicines["Portuguese(Standard)"] = array();
	$pageTitlesmedicines["Portuguese(Standard)"] = array();
	$fieldLabelsmedicines["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsmedicines["Portuguese(Standard)"]["id"] = "";
	$placeHoldersmedicines["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsmedicines["Portuguese(Standard)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Portuguese(Standard)"]["MedicineName"] = "";
	$placeHoldersmedicines["Portuguese(Standard)"]["MedicineName"] = "";
	$fieldLabelsmedicines["Portuguese(Standard)"]["Description"] = "Description";
	$fieldToolTipsmedicines["Portuguese(Standard)"]["Description"] = "";
	$placeHoldersmedicines["Portuguese(Standard)"]["Description"] = "";
	$fieldLabelsmedicines["Portuguese(Standard)"]["Type"] = "Type";
	$fieldToolTipsmedicines["Portuguese(Standard)"]["Type"] = "";
	$placeHoldersmedicines["Portuguese(Standard)"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Portuguese(Standard)"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsmedicines["Romanian"] = array();
	$fieldToolTipsmedicines["Romanian"] = array();
	$placeHoldersmedicines["Romanian"] = array();
	$pageTitlesmedicines["Romanian"] = array();
	$fieldLabelsmedicines["Romanian"]["id"] = "Id";
	$fieldToolTipsmedicines["Romanian"]["id"] = "";
	$placeHoldersmedicines["Romanian"]["id"] = "";
	$fieldLabelsmedicines["Romanian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Romanian"]["MedicineName"] = "";
	$placeHoldersmedicines["Romanian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Romanian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Romanian"]["Description"] = "";
	$placeHoldersmedicines["Romanian"]["Description"] = "";
	$fieldLabelsmedicines["Romanian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Romanian"]["Type"] = "";
	$placeHoldersmedicines["Romanian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Romanian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsmedicines["Russian"] = array();
	$fieldToolTipsmedicines["Russian"] = array();
	$placeHoldersmedicines["Russian"] = array();
	$pageTitlesmedicines["Russian"] = array();
	$fieldLabelsmedicines["Russian"]["id"] = "Id";
	$fieldToolTipsmedicines["Russian"]["id"] = "";
	$placeHoldersmedicines["Russian"]["id"] = "";
	$fieldLabelsmedicines["Russian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Russian"]["MedicineName"] = "";
	$placeHoldersmedicines["Russian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Russian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Russian"]["Description"] = "";
	$placeHoldersmedicines["Russian"]["Description"] = "";
	$fieldLabelsmedicines["Russian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Russian"]["Type"] = "";
	$placeHoldersmedicines["Russian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Russian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsmedicines["Serbian"] = array();
	$fieldToolTipsmedicines["Serbian"] = array();
	$placeHoldersmedicines["Serbian"] = array();
	$pageTitlesmedicines["Serbian"] = array();
	$fieldLabelsmedicines["Serbian"]["id"] = "Id";
	$fieldToolTipsmedicines["Serbian"]["id"] = "";
	$placeHoldersmedicines["Serbian"]["id"] = "";
	$fieldLabelsmedicines["Serbian"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Serbian"]["MedicineName"] = "";
	$placeHoldersmedicines["Serbian"]["MedicineName"] = "";
	$fieldLabelsmedicines["Serbian"]["Description"] = "Description";
	$fieldToolTipsmedicines["Serbian"]["Description"] = "";
	$placeHoldersmedicines["Serbian"]["Description"] = "";
	$fieldLabelsmedicines["Serbian"]["Type"] = "Type";
	$fieldToolTipsmedicines["Serbian"]["Type"] = "";
	$placeHoldersmedicines["Serbian"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Serbian"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsmedicines["Slovak"] = array();
	$fieldToolTipsmedicines["Slovak"] = array();
	$placeHoldersmedicines["Slovak"] = array();
	$pageTitlesmedicines["Slovak"] = array();
	$fieldLabelsmedicines["Slovak"]["id"] = "Id";
	$fieldToolTipsmedicines["Slovak"]["id"] = "";
	$placeHoldersmedicines["Slovak"]["id"] = "";
	$fieldLabelsmedicines["Slovak"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Slovak"]["MedicineName"] = "";
	$placeHoldersmedicines["Slovak"]["MedicineName"] = "";
	$fieldLabelsmedicines["Slovak"]["Description"] = "Description";
	$fieldToolTipsmedicines["Slovak"]["Description"] = "";
	$placeHoldersmedicines["Slovak"]["Description"] = "";
	$fieldLabelsmedicines["Slovak"]["Type"] = "Type";
	$fieldToolTipsmedicines["Slovak"]["Type"] = "";
	$placeHoldersmedicines["Slovak"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Slovak"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsmedicines["Spanish"] = array();
	$fieldToolTipsmedicines["Spanish"] = array();
	$placeHoldersmedicines["Spanish"] = array();
	$pageTitlesmedicines["Spanish"] = array();
	$fieldLabelsmedicines["Spanish"]["id"] = "Id";
	$fieldToolTipsmedicines["Spanish"]["id"] = "";
	$placeHoldersmedicines["Spanish"]["id"] = "";
	$fieldLabelsmedicines["Spanish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Spanish"]["MedicineName"] = "";
	$placeHoldersmedicines["Spanish"]["MedicineName"] = "";
	$fieldLabelsmedicines["Spanish"]["Description"] = "Description";
	$fieldToolTipsmedicines["Spanish"]["Description"] = "";
	$placeHoldersmedicines["Spanish"]["Description"] = "";
	$fieldLabelsmedicines["Spanish"]["Type"] = "Type";
	$fieldToolTipsmedicines["Spanish"]["Type"] = "";
	$placeHoldersmedicines["Spanish"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Spanish"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsmedicines["Swedish"] = array();
	$fieldToolTipsmedicines["Swedish"] = array();
	$placeHoldersmedicines["Swedish"] = array();
	$pageTitlesmedicines["Swedish"] = array();
	$fieldLabelsmedicines["Swedish"]["id"] = "Id";
	$fieldToolTipsmedicines["Swedish"]["id"] = "";
	$placeHoldersmedicines["Swedish"]["id"] = "";
	$fieldLabelsmedicines["Swedish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Swedish"]["MedicineName"] = "";
	$placeHoldersmedicines["Swedish"]["MedicineName"] = "";
	$fieldLabelsmedicines["Swedish"]["Description"] = "Description";
	$fieldToolTipsmedicines["Swedish"]["Description"] = "";
	$placeHoldersmedicines["Swedish"]["Description"] = "";
	$fieldLabelsmedicines["Swedish"]["Type"] = "Type";
	$fieldToolTipsmedicines["Swedish"]["Type"] = "";
	$placeHoldersmedicines["Swedish"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Swedish"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsmedicines["Tagalog(Philippines)"] = array();
	$fieldToolTipsmedicines["Tagalog(Philippines)"] = array();
	$placeHoldersmedicines["Tagalog(Philippines)"] = array();
	$pageTitlesmedicines["Tagalog(Philippines)"] = array();
	$fieldLabelsmedicines["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsmedicines["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersmedicines["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsmedicines["Tagalog(Philippines)"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Tagalog(Philippines)"]["MedicineName"] = "";
	$placeHoldersmedicines["Tagalog(Philippines)"]["MedicineName"] = "";
	$fieldLabelsmedicines["Tagalog(Philippines)"]["Description"] = "Description";
	$fieldToolTipsmedicines["Tagalog(Philippines)"]["Description"] = "";
	$placeHoldersmedicines["Tagalog(Philippines)"]["Description"] = "";
	$fieldLabelsmedicines["Tagalog(Philippines)"]["Type"] = "Type";
	$fieldToolTipsmedicines["Tagalog(Philippines)"]["Type"] = "";
	$placeHoldersmedicines["Tagalog(Philippines)"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Tagalog(Philippines)"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsmedicines["Thai"] = array();
	$fieldToolTipsmedicines["Thai"] = array();
	$placeHoldersmedicines["Thai"] = array();
	$pageTitlesmedicines["Thai"] = array();
	$fieldLabelsmedicines["Thai"]["id"] = "Id";
	$fieldToolTipsmedicines["Thai"]["id"] = "";
	$placeHoldersmedicines["Thai"]["id"] = "";
	$fieldLabelsmedicines["Thai"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Thai"]["MedicineName"] = "";
	$placeHoldersmedicines["Thai"]["MedicineName"] = "";
	$fieldLabelsmedicines["Thai"]["Description"] = "Description";
	$fieldToolTipsmedicines["Thai"]["Description"] = "";
	$placeHoldersmedicines["Thai"]["Description"] = "";
	$fieldLabelsmedicines["Thai"]["Type"] = "Type";
	$fieldToolTipsmedicines["Thai"]["Type"] = "";
	$placeHoldersmedicines["Thai"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Thai"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsmedicines["Turkish"] = array();
	$fieldToolTipsmedicines["Turkish"] = array();
	$placeHoldersmedicines["Turkish"] = array();
	$pageTitlesmedicines["Turkish"] = array();
	$fieldLabelsmedicines["Turkish"]["id"] = "Id";
	$fieldToolTipsmedicines["Turkish"]["id"] = "";
	$placeHoldersmedicines["Turkish"]["id"] = "";
	$fieldLabelsmedicines["Turkish"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Turkish"]["MedicineName"] = "";
	$placeHoldersmedicines["Turkish"]["MedicineName"] = "";
	$fieldLabelsmedicines["Turkish"]["Description"] = "Description";
	$fieldToolTipsmedicines["Turkish"]["Description"] = "";
	$placeHoldersmedicines["Turkish"]["Description"] = "";
	$fieldLabelsmedicines["Turkish"]["Type"] = "Type";
	$fieldToolTipsmedicines["Turkish"]["Type"] = "";
	$placeHoldersmedicines["Turkish"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Turkish"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsmedicines["Urdu"] = array();
	$fieldToolTipsmedicines["Urdu"] = array();
	$placeHoldersmedicines["Urdu"] = array();
	$pageTitlesmedicines["Urdu"] = array();
	$fieldLabelsmedicines["Urdu"]["id"] = "Id";
	$fieldToolTipsmedicines["Urdu"]["id"] = "";
	$placeHoldersmedicines["Urdu"]["id"] = "";
	$fieldLabelsmedicines["Urdu"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Urdu"]["MedicineName"] = "";
	$placeHoldersmedicines["Urdu"]["MedicineName"] = "";
	$fieldLabelsmedicines["Urdu"]["Description"] = "Description";
	$fieldToolTipsmedicines["Urdu"]["Description"] = "";
	$placeHoldersmedicines["Urdu"]["Description"] = "";
	$fieldLabelsmedicines["Urdu"]["Type"] = "Type";
	$fieldToolTipsmedicines["Urdu"]["Type"] = "";
	$placeHoldersmedicines["Urdu"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Urdu"]))
		$tdatamedicines[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsmedicines["Welsh"] = array();
	$fieldToolTipsmedicines["Welsh"] = array();
	$placeHoldersmedicines["Welsh"] = array();
	$pageTitlesmedicines["Welsh"] = array();
	$fieldLabelsmedicines["Welsh"]["id"] = "Id";
	$fieldToolTipsmedicines["Welsh"]["id"] = "";
	$placeHoldersmedicines["Welsh"]["id"] = "";
	$fieldLabelsmedicines["Welsh"]["MedicineName"] = "Medicine Name";
	$fieldToolTipsmedicines["Welsh"]["MedicineName"] = "";
	$placeHoldersmedicines["Welsh"]["MedicineName"] = "";
	$fieldLabelsmedicines["Welsh"]["Description"] = "Description";
	$fieldToolTipsmedicines["Welsh"]["Description"] = "";
	$placeHoldersmedicines["Welsh"]["Description"] = "";
	$fieldLabelsmedicines["Welsh"]["Type"] = "Type";
	$fieldToolTipsmedicines["Welsh"]["Type"] = "";
	$placeHoldersmedicines["Welsh"]["Type"] = "";
	if (count($fieldToolTipsmedicines["Welsh"]))
		$tdatamedicines[".isUseToolTips"] = true;
}


	$tdatamedicines[".NCSearch"] = true;



$tdatamedicines[".shortTableName"] = "medicines";
$tdatamedicines[".nSecOptions"] = 0;

$tdatamedicines[".mainTableOwnerID"] = "";
$tdatamedicines[".entityType"] = 0;
$tdatamedicines[".connId"] = "testdb_at_localhost";


$tdatamedicines[".strOriginalTableName"] = "medicines";

	



$tdatamedicines[".showAddInPopup"] = false;

$tdatamedicines[".showEditInPopup"] = false;

$tdatamedicines[".showViewInPopup"] = false;

	$tdatamedicines[".listAjax"] = true;
//	temporary
//$tdatamedicines[".listAjax"] = false;

	$tdatamedicines[".audit"] = false;

	$tdatamedicines[".locking"] = false;


$pages = $tdatamedicines[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatamedicines[".edit"] = true;
	$tdatamedicines[".afterEditAction"] = 1;
	$tdatamedicines[".closePopupAfterEdit"] = 1;
	$tdatamedicines[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatamedicines[".add"] = true;
$tdatamedicines[".afterAddAction"] = 1;
$tdatamedicines[".closePopupAfterAdd"] = 1;
$tdatamedicines[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatamedicines[".list"] = true;
}



$tdatamedicines[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatamedicines[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatamedicines[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatamedicines[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatamedicines[".printFriendly"] = true;
}



$tdatamedicines[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatamedicines[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatamedicines[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatamedicines[".isUseAjaxSuggest"] = true;





$tdatamedicines[".ajaxCodeSnippetAdded"] = false;

$tdatamedicines[".buttonsAdded"] = false;

$tdatamedicines[".addPageEvents"] = false;

// use timepicker for search panel
$tdatamedicines[".isUseTimeForSearch"] = false;


$tdatamedicines[".badgeColor"] = "9ACD32";


$tdatamedicines[".allSearchFields"] = array();
$tdatamedicines[".filterFields"] = array();
$tdatamedicines[".requiredSearchFields"] = array();

$tdatamedicines[".googleLikeFields"] = array();
$tdatamedicines[".googleLikeFields"][] = "id";
$tdatamedicines[".googleLikeFields"][] = "MedicineName";
$tdatamedicines[".googleLikeFields"][] = "Description";
$tdatamedicines[".googleLikeFields"][] = "Type";



$tdatamedicines[".tableType"] = "list";

$tdatamedicines[".printerPageOrientation"] = 0;
$tdatamedicines[".nPrinterPageScale"] = 100;

$tdatamedicines[".nPrinterSplitRecords"] = 40;

$tdatamedicines[".geocodingEnabled"] = false;




$tdatamedicines[".isDisplayLoading"] = true;






$tdatamedicines[".pageSize"] = 20;

$tdatamedicines[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdatamedicines[".strOrderBy"] = $tstrOrderBy;

$tdatamedicines[".orderindexes"] = array();


$tdatamedicines[".sqlHead"] = "SELECT id,  	MedicineName,  	Description,  	`Type`";
$tdatamedicines[".sqlFrom"] = "FROM medicines";
$tdatamedicines[".sqlWhereExpr"] = "";
$tdatamedicines[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatamedicines[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatamedicines[".arrGroupsPerPage"] = $arrGPP;

$tdatamedicines[".highlightSearchResults"] = true;

$tableKeysmedicines = array();
$tableKeysmedicines[] = "id";
$tdatamedicines[".Keys"] = $tableKeysmedicines;


$tdatamedicines[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines["id"] = $fdata;
		$tdatamedicines[".searchableFields"][] = "id";
//	MedicineName
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "MedicineName";
	$fdata["GoodName"] = "MedicineName";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines","MedicineName");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "MedicineName";

		$fdata["sourceSingle"] = "MedicineName";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "MedicineName";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines["MedicineName"] = $fdata;
		$tdatamedicines[".searchableFields"][] = "MedicineName";
//	Description
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Description";
	$fdata["GoodName"] = "Description";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines","Description");
	$fdata["FieldType"] = 201;


	
	
			

		$fdata["strField"] = "Description";

		$fdata["sourceSingle"] = "Description";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Description";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 0;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

		$edata["CreateThumbnail"] = true;
	$edata["StrThumbnail"] = "th";
			$edata["ThumbnailSize"] = 600;

			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines["Description"] = $fdata;
		$tdatamedicines[".searchableFields"][] = "Description";
//	Type
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Type";
	$fdata["GoodName"] = "Type";
	$fdata["ownerTable"] = "medicines";
	$fdata["Label"] = GetFieldLabel("medicines","Type");
	$fdata["FieldType"] = 129;


	
	
			

		$fdata["strField"] = "Type";

		$fdata["sourceSingle"] = "Type";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Type`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
		$edata["LookupType"] = 0;
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
	
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "Tablet";
	$edata["LookupValues"][] = "Capsule";
	$edata["LookupValues"][] = "Powder";
	$edata["LookupValues"][] = "Liquid";
	$edata["LookupValues"][] = "Ointments";

	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
		$fdata["filterTotalFields"] = "id";
		$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatamedicines["Type"] = $fdata;
		$tdatamedicines[".searchableFields"][] = "Type";


$tables_data["medicines"]=&$tdatamedicines;
$field_labels["medicines"] = &$fieldLabelsmedicines;
$fieldToolTips["medicines"] = &$fieldToolTipsmedicines;
$placeHolders["medicines"] = &$placeHoldersmedicines;
$page_titles["medicines"] = &$pageTitlesmedicines;


changeTextControlsToDate( "medicines" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["medicines"] = array();
//	diagnoses
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="diagnoses";
		$detailsParam["dOriginalTable"] = "diagnoses";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "diagnoses";
	$detailsParam["dCaptionTable"] = GetTableCaption("diagnoses");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["medicines"][$dIndex] = $detailsParam;

	
		$detailsTablesData["medicines"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["medicines"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["medicines"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["medicines"][$dIndex]["detailKeys"][]="medicine_id";
//	diagnoses Chart
	
	

		$dIndex = 1;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="diagnoses Chart";
		$detailsParam["dOriginalTable"] = "diagnoses";



			$detailsParam["dType"]=PAGE_CHART;

		$detailsParam["dShortTable"] = "diagnoses_chart";
	$detailsParam["dCaptionTable"] = GetTableCaption("diagnoses_Chart");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["medicines"][$dIndex] = $detailsParam;

	
		$detailsTablesData["medicines"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["medicines"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["medicines"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["medicines"][$dIndex]["detailKeys"][]="medicine_id";
//endif

// tables which are master tables for current table (detail)
$masterTablesData["medicines"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_medicines()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	MedicineName,  	Description,  	`Type`";
$proto0["m_strFrom"] = "FROM medicines";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "medicines";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "MedicineName",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines"
));

$proto8["m_sql"] = "MedicineName";
$proto8["m_srcTableName"] = "medicines";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Description",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines"
));

$proto10["m_sql"] = "Description";
$proto10["m_srcTableName"] = "medicines";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Type",
	"m_strTable" => "medicines",
	"m_srcTableName" => "medicines"
));

$proto12["m_sql"] = "`Type`";
$proto12["m_srcTableName"] = "medicines";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto14=array();
$proto14["m_link"] = "SQLL_MAIN";
			$proto15=array();
$proto15["m_strName"] = "medicines";
$proto15["m_srcTableName"] = "medicines";
$proto15["m_columns"] = array();
$proto15["m_columns"][] = "id";
$proto15["m_columns"][] = "MedicineName";
$proto15["m_columns"][] = "Description";
$proto15["m_columns"][] = "Type";
$obj = new SQLTable($proto15);

$proto14["m_table"] = $obj;
$proto14["m_sql"] = "medicines";
$proto14["m_alias"] = "";
$proto14["m_srcTableName"] = "medicines";
$proto16=array();
$proto16["m_sql"] = "";
$proto16["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto16["m_column"]=$obj;
$proto16["m_contained"] = array();
$proto16["m_strCase"] = "";
$proto16["m_havingmode"] = false;
$proto16["m_inBrackets"] = false;
$proto16["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto16);

$proto14["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto14);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="medicines";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_medicines = createSqlQuery_medicines();


	
		;

				

$tdatamedicines[".sqlquery"] = $queryData_medicines;



include_once(getabspath("include/medicines_events.php"));
$tdatamedicines[".hasEvents"] = true;

?>