<?php
$dalTablepatients = array();
$dalTablepatients["id"] = array("type"=>20,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTablepatients["PatientName"] = array("type"=>200,"varname"=>"PatientName", "name" => "PatientName", "autoInc" => "0");
$dalTablepatients["Address"] = array("type"=>200,"varname"=>"Address", "name" => "Address", "autoInc" => "0");
$dalTablepatients["ContactNumber"] = array("type"=>3,"varname"=>"ContactNumber", "name" => "ContactNumber", "autoInc" => "0");
$dalTablepatients["Birthdate"] = array("type"=>7,"varname"=>"Birthdate", "name" => "Birthdate", "autoInc" => "0");
$dalTablepatients["Age"] = array("type"=>3,"varname"=>"Age", "name" => "Age", "autoInc" => "0");
$dalTablepatients["Gender"] = array("type"=>129,"varname"=>"Gender", "name" => "Gender", "autoInc" => "0");
$dalTablepatients["Email"] = array("type"=>200,"varname"=>"Email", "name" => "Email", "autoInc" => "0");
$dalTablepatients["Photo"] = array("type"=>200,"varname"=>"Photo", "name" => "Photo", "autoInc" => "0");
$dalTablepatients["id"]["key"]=true;

$dal_info["testdb_at_localhost__patients"] = &$dalTablepatients;
?>