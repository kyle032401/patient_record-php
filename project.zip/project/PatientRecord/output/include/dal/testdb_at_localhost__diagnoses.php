<?php
$dalTablediagnoses = array();
$dalTablediagnoses["id"] = array("type"=>20,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTablediagnoses["TakenTime"] = array("type"=>135,"varname"=>"TakenTime", "name" => "TakenTime", "autoInc" => "0");
$dalTablediagnoses["Quantity"] = array("type"=>3,"varname"=>"Quantity", "name" => "Quantity", "autoInc" => "0");
$dalTablediagnoses["treatment_id"] = array("type"=>20,"varname"=>"treatment_id", "name" => "treatment_id", "autoInc" => "0");
$dalTablediagnoses["medicine_id"] = array("type"=>20,"varname"=>"medicine_id", "name" => "medicine_id", "autoInc" => "0");
$dalTablediagnoses["Photo"] = array("type"=>200,"varname"=>"Photo", "name" => "Photo", "autoInc" => "0");
$dalTablediagnoses["Result"] = array("type"=>129,"varname"=>"Result", "name" => "Result", "autoInc" => "0");
$dalTablediagnoses["id"]["key"]=true;

$dal_info["testdb_at_localhost__diagnoses"] = &$dalTablediagnoses;
?>