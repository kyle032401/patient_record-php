<?php
$dalTabledoctors = array();
$dalTabledoctors["id"] = array("type"=>20,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTabledoctors["DoctorName"] = array("type"=>200,"varname"=>"DoctorName", "name" => "DoctorName", "autoInc" => "0");
$dalTabledoctors["ContactNumber"] = array("type"=>3,"varname"=>"ContactNumber", "name" => "ContactNumber", "autoInc" => "0");
$dalTabledoctors["Email"] = array("type"=>200,"varname"=>"Email", "name" => "Email", "autoInc" => "0");
$dalTabledoctors["Photo"] = array("type"=>200,"varname"=>"Photo", "name" => "Photo", "autoInc" => "0");
$dalTabledoctors["id"]["key"]=true;

$dal_info["testdb_at_localhost__doctors"] = &$dalTabledoctors;
?>