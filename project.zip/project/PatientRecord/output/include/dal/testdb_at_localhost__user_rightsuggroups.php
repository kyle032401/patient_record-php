<?php
$dalTableuser_rightsuggroups = array();
$dalTableuser_rightsuggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "1");
$dalTableuser_rightsuggroups["Label"] = array("type"=>200,"varname"=>"Label", "name" => "Label", "autoInc" => "0");
$dalTableuser_rightsuggroups["Provider"] = array("type"=>200,"varname"=>"Provider", "name" => "Provider", "autoInc" => "0");
$dalTableuser_rightsuggroups["Comment"] = array("type"=>201,"varname"=>"Comment", "name" => "Comment", "autoInc" => "0");
$dalTableuser_rightsuggroups["GroupID"]["key"]=true;

$dal_info["testdb_at_localhost__user_rightsuggroups"] = &$dalTableuser_rightsuggroups;
?>