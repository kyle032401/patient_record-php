<?php
$dalTablemedicines = array();
$dalTablemedicines["id"] = array("type"=>20,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTablemedicines["MedicineName"] = array("type"=>200,"varname"=>"MedicineName", "name" => "MedicineName", "autoInc" => "0");
$dalTablemedicines["Description"] = array("type"=>201,"varname"=>"Description", "name" => "Description", "autoInc" => "0");
$dalTablemedicines["Type"] = array("type"=>129,"varname"=>"Type", "name" => "Type", "autoInc" => "0");
$dalTablemedicines["id"]["key"]=true;

$dal_info["testdb_at_localhost__medicines"] = &$dalTablemedicines;
?>