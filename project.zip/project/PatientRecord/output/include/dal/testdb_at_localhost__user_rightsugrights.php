<?php
$dalTableuser_rightsugrights = array();
$dalTableuser_rightsugrights["TableName"] = array("type"=>200,"varname"=>"TableName", "name" => "TableName", "autoInc" => "0");
$dalTableuser_rightsugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "0");
$dalTableuser_rightsugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask", "name" => "AccessMask", "autoInc" => "0");
$dalTableuser_rightsugrights["Page"] = array("type"=>201,"varname"=>"Page", "name" => "Page", "autoInc" => "0");
$dalTableuser_rightsugrights["TableName"]["key"]=true;
$dalTableuser_rightsugrights["GroupID"]["key"]=true;

$dal_info["testdb_at_localhost__user_rightsugrights"] = &$dalTableuser_rightsugrights;
?>