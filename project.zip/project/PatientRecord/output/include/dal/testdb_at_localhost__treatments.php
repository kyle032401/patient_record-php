<?php
$dalTabletreatments = array();
$dalTabletreatments["id"] = array("type"=>20,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTabletreatments["TreatmentDate"] = array("type"=>7,"varname"=>"TreatmentDate", "name" => "TreatmentDate", "autoInc" => "0");
$dalTabletreatments["TreatmentTIme"] = array("type"=>134,"varname"=>"TreatmentTIme", "name" => "TreatmentTIme", "autoInc" => "0");
$dalTabletreatments["patient_id"] = array("type"=>20,"varname"=>"patient_id", "name" => "patient_id", "autoInc" => "0");
$dalTabletreatments["doctor_id"] = array("type"=>20,"varname"=>"doctor_id", "name" => "doctor_id", "autoInc" => "0");
$dalTabletreatments["id"]["key"]=true;

$dal_info["testdb_at_localhost__treatments"] = &$dalTabletreatments;
?>