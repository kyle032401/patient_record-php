<?php
$dalTableuser_rightsugmembers = array();
$dalTableuser_rightsugmembers["UserName"] = array("type"=>200,"varname"=>"UserName", "name" => "UserName", "autoInc" => "0");
$dalTableuser_rightsugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "0");
$dalTableuser_rightsugmembers["Provider"] = array("type"=>200,"varname"=>"Provider", "name" => "Provider", "autoInc" => "0");
$dalTableuser_rightsugmembers["UserName"]["key"]=true;
$dalTableuser_rightsugmembers["GroupID"]["key"]=true;
$dalTableuser_rightsugmembers["Provider"]["key"]=true;

$dal_info["testdb_at_localhost__user_rightsugmembers"] = &$dalTableuser_rightsugmembers;
?>