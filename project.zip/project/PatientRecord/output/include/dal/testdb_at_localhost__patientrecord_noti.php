<?php
$dalTablepatientrecord_noti = array();
$dalTablepatientrecord_noti["id"] = array("type"=>3,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTablepatientrecord_noti["message"] = array("type"=>201,"varname"=>"message", "name" => "message", "autoInc" => "0");
$dalTablepatientrecord_noti["user"] = array("type"=>200,"varname"=>"user", "name" => "user", "autoInc" => "0");
$dalTablepatientrecord_noti["provider"] = array("type"=>200,"varname"=>"provider", "name" => "provider", "autoInc" => "0");
$dalTablepatientrecord_noti["title"] = array("type"=>200,"varname"=>"title", "name" => "title", "autoInc" => "0");
$dalTablepatientrecord_noti["url"] = array("type"=>201,"varname"=>"url", "name" => "url", "autoInc" => "0");
$dalTablepatientrecord_noti["icon"] = array("type"=>200,"varname"=>"icon", "name" => "icon", "autoInc" => "0");
$dalTablepatientrecord_noti["created"] = array("type"=>135,"varname"=>"created", "name" => "created", "autoInc" => "0");
$dalTablepatientrecord_noti["expire"] = array("type"=>135,"varname"=>"expire", "name" => "expire", "autoInc" => "0");
$dalTablepatientrecord_noti["type"] = array("type"=>3,"varname"=>"type", "name" => "type", "autoInc" => "0");
$dalTablepatientrecord_noti["group"] = array("type"=>200,"varname"=>"group", "name" => "group", "autoInc" => "0");
$dalTablepatientrecord_noti["id"]["key"]=true;

$dal_info["testdb_at_localhost__patientrecord_noti"] = &$dalTablepatientrecord_noti;
?>