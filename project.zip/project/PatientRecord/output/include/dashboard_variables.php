<?php
$strTableName="Dashboard";


// alias for 'SQLQuery' object
$gSettings = new ProjectSettings("Dashboard");

?>