Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Portuguese(Standard)",

//	for list page
	TEXT_FIRST: 'Primeiro',
	TEXT_PREVIOUS: 'Anterior',
	TEXT_NEXT: 'Próximo',
	TEXT_LAST: 'Último',
	TEXT_PROCEED_TO: 'Ir para',
	TEXT_DETAIL_NOT_SAVED: 'Os registos %s não foram guardados',
	TEXT_NO_RECORDS: 'Nenhum Registo Encontrado',
	TEXT_DETAIL_GOTO: 'Ir para',
	TEXT_SHOW_ALL: 'Mostrar Todos',
	TEXT_SHOW_OPTIONS: 'Mostrar opções',
	TEXT_HIDE_OPTIONS: 'Esconder opções',
	TEXT_SEARCH_SHOW_OPTIONS:'Mostrar opções de pesquisa',
	TEXT_SEARCH_HIDE_OPTIONS:'Esconder opções de pesquisa',
	TEXT_SHOW_SEARCH_PANEL:'Show search panel',
	TEXT_HIDE_SEARCH_PANEL:'Hide search panel',


	TEXT_LOADING: 'a carregar',
	TEXT_DELETE_CONFIRM: 'Tem certeza que desejar eliminar estes registos?',
	TEXT_PAGE: 'Página',
	TEXT_PAGEMAX: 'de',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Código de segurança inválido.',
	TEXT_PLEASE_SELECT: 'Por Favor Selecione',
	TEXT_CTRL_CLICK: 'CTRL + click para mutliplas ordenações',
	TEXT_SAVE: 'Guardar',
	TEXT_CANCEL: 'Cancelar',
	TEXT_PREVIEW: 'previsualizar',
	TEXT_HIDE: 'esconder',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Do you want to navigate away from this page and lose unsaved changes?',

	TEXT_EDIT: 'Editar',
	TEXT_COPY: 'Copiar',
	TEXT_VIEW: 'Mostrar',
	TEXT_INLINE_EDIT: 'Editar',
	TEXT_INLINE_ADD: 'Adicionar Novo',
	TEXT_AA_P_ADD: 'Adicionar',

	TEXT_FIELDFILTER_HINT: 'Filtrar valores de campo',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Um e-mail com o código de segurança foi enviado para %email%.',
	USERINFO_ENTER_CODE: 'Digite o código abaixo.',
	USERINFO_SENT_TEXT: 'Uma mensagem de texto com o código de segurança foi enviado para %phone%.',
	USERINFO_INSTALL_APP1: 'Instalar um aplicativo de autenticação, como Google Authenticator, Authy, Microsoft Authenticator ou similar no seu telefone.',
	USERINFO_INSTALL_APP2: 'Em seguida, digitalizar o código QR abaixo com o aplicativo.',
	USERINFO_INSTALL_APP3: 'Ou criar um novo registro no aplicativo manualmente usando esta chave:',
	USERINFO_INSTALL_APP4: 'Em seguida, digite o código do aplicativo abaixo.',

//	for calendar
	TEXT_MONTH_JAN: 'Janeiro',
	TEXT_MONTH_FEB: 'Fevereiro',
	TEXT_MONTH_MAR: 'Março',
	TEXT_MONTH_APR: 'Abril',
	TEXT_MONTH_MAY: 'Maio',
	TEXT_MONTH_JUN: 'Junho',
	TEXT_MONTH_JUL: 'Julho',
	TEXT_MONTH_AUG: 'Agosto',
	TEXT_MONTH_SEP: 'Setembro',
	TEXT_MONTH_OCT: 'Outubro',
	TEXT_MONTH_NOV: 'Novembro',
	TEXT_MONTH_DEC: 'Dezembro',
	TEXT_DAY_SU: 'Domingo',
	TEXT_DAY_MO: 'Segunda',
	TEXT_DAY_TU: 'Terça',
	TEXT_DAY_WE: 'Quarta',
	TEXT_DAY_TH: 'Quinta',
	TEXT_DAY_FR: 'Sexta',
	TEXT_DAY_SA: 'Sábado',
	TEXT_TODAY: 'hoje',
	TEXT_SELECT_DATE: 'Selecionar Data',
	TEXT_TIME: 'Time',
	TEXT_TIME_HOUR: 'Hour',
	TEXT_TIME_MINUTE: 'Minute',
	TEXT_TIME_SECOND: 'Second',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Campo necessário',
	TEXT_INLINE_FIELD_ZIPCODE: 'O Campo deve ter um código postal válido',
	TEXT_INLINE_FIELD_EMAIL: 'O Campo deve ter um endereço de E-mail válido',
	TEXT_INLINE_FIELD_NUMBER: 'O Campo deve ser um número',
	TEXT_INLINE_FIELD_CURRENCY: 'O Campo deve ser moeda',
	TEXT_INLINE_FIELD_PHONE: 'O Campo deve ter um número de Telefone válido',
	TEXT_INLINE_FIELD_PASSWORD1: 'O Campo não pode ser do tipo',
	TEXT_INLINE_FIELD_PASSWORD2: 'O Campo deve ter pelo menos 4 caracteres',
	TEXT_INLINE_FIELD_STATE: 'O Campo deve ser um nome de País',
	TEXT_INLINE_FIELD_SSN: 'O Campo deve ser um número de',
	TEXT_INLINE_FIELD_DATE: 'O Campo deve ter uma data válida',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'O Campo deve ter horário no formato de 24 horas',
	TEXT_INLINE_FIELD_CC: 'O Campo deve conter um número de Cartão de Crédito válido',
	TEXT_INLINE_ERROR: 'Ocorreu um erro!',
	TEXT_INLINE_DENY_DUPLICATES: 'Field should not contain a duplicate value',
	TEXT_INLINE_USERNAME_EXISTS1: 'Nome do Utilizador',
	TEXT_INLINE_USERNAME_EXISTS2: 'já existe. Escolha outro nome',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email',
	TEXT_INLINE_EMAIL_ALREADY2: 'Já registrado. Se esqueceu o Nome de Utilizador ou Password, use o formulário ‘Esqueci a Minha Password’',

	//for RTE
	TEXT_VIEW_SOURCE: 'Visualizar Origem',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'Mostrar todos',
	TEXT_COLLAPSE_ALL: 'esconder todos',

	//for register page
	SEC_PWD_LEN: 'A password deve conter no mínimo %% caracteres de comprimento.',
	SEC_PWD_CASE: 'A password deve conter letras em Maiusculas e minusculas.',
	SEC_PWD_DIGIT: 'A password deve conter %% dígitos ou símbolos.',
	SEC_PWD_UNIQUE: 'A password deve conter %% caracteres únicos.',
	PASSWORDS_DONT_MATCH: 'Password não coincide',
	SUCCES_LOGGED_IN: 'You have successfully logged in.',

	//for pdf
	TEXT_PDF_BUILD1: 'A criar o PDF',
	TEXT_PDF_BUILD2: 'criado',
	TEXT_PDF_BUILD3: 'Could not create PDF',

	CLOSE_WINDOW: 'Fechar Janela',
	CLOSE: 'Close',
	RESET: 'Limpar',

	//for search options
	CONTAINS: 'Contém',
	EQUALS: 'Igual a',
	STARTS_WITH: 'Inicia por',
	MORE_THAN: 'Maior que',
	LESS_THAN: 'Menor que',
	BETWEEN: 'Entre',
	EMPTY: 'Vazio',

	NOT_CONTAINS: 'Não contêm',
	NOT_EQUALS: 'Não é igual a',
	NOT_STARTS_WITH: 'Não inicia por',
	NOT_MORE_THAN: 'Não é maior do que',
	NOT_LESS_THAN: 'Não é menor que',
	NOT_BETWEEN: 'Não está entre',
	NOT_EMPTY: 'Não está vazio',

	SEARCH_FOR: 'Procurar',

	ERROR_MISSING_FILE_NAME: 'File name was not provided',
	ERROR_ACCEPT_FILE_TYPES: 'File type is not acceptable',
	ERROR_MAX_FILE_SIZE: 'File size exceeds limit of %s kbytes',
	ERROR_MIN_FILE_SIZE: 'File size must not be less than %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Total files size exceeds limit of %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'You can upload only one file',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'You can upload no more than %s files',

	TEXT_SERVER_ERROR_OCCURRED: 'Server error occurred',
	TEXT_SEE_DETAILS: 'See details',

	ERROR_UPLOAD: 'Uploading failed',
	START_UPLOAD: 'Upload',
	CANCEL: 'Cancelar',
	DELETE: 'Eliminar',

	UPLOAD_DRAG: 'Drag files here',

	SELECT_ALL: 'Select all',
	UNSELECT_ALL: 'Unselect all',

	TEXT_WR_REPORT_SAVED: 'Relatório Gravado!',
	TEXT_WR_SOME_PROBLEM: 'Ocurreram erros durante a gravação',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_WR_HEADER: 'Header',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_COUNT: 'Contar',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Max',
	TEXT_SUM: 'Soma',
	TEXT_AVG: 'Média',
	TEXT_WR_TOTAL_DATA: 'Table Data',
	TEXT_PAGE_SUMMARY: 'Página de resumo',
	TEXT_GLOBAL_SUMMARY: 'Resumo Global',
	TEXT_WR_SUMMARY: 'Resumo',
	TEXT_FIELD: 'Campo',
	TEXT_WR_NO_COLOR: 'No color',

	TEXT_SEARCH_SAVING: 'Search saving',
	TEXT_SEARCH_NAME: 'Search name:',
	TEXT_DELETE_SEARCH_CAPTION: 'Delete saved search',
	TEXT_DELETE_SEARCH: 'Do you really want to delete this search?',
	TEXT_YES: 'Sim',
	TEXT_NO: 'Não',

	TEXT_FILTER_APPLY: 'Apply',
	TEXT_FILTER_CLEAR: 'Clear',
	TEXT_FILTER_MULTISELECT: 'Multiselect',

	// for rights page
	AA_ADD_NEW_GROUP: 'Adicionar novo groupo',
	AA_RENAMEGROUP: 'Renomear nome de Groupo',
	AA_GROUP_NEW: 'Novo Grupo',
	AA_DELETEGROUP: 'Quer mesmo apagar este groupo',
	AA_COPY_PERMISS_FROM: 'Choose the group to copy permissions from:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Choose columns to display',
	AA_SELECT_NONE: 'Select none',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Preparing page for printing',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processing records',
	IMPORT_FAILED: 'Import Failed',

	LOADING_FONTS: 'Carregando fontes',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Selecione o mês',
	DATEPICKER_NEXT_MONTH: 'Próximo mês',
	DATEPICKER_PREV_MONTH: 'Mês anterior',
	DATEPICKER_SELECT_YEAR: 'Selecione o ano',
	DATEPICKER_NEXT_YEAR: 'Próximo ano',
	DATEPICKER_PREV_YEAR: 'Próximo ano',

	TODAY: 'hoje',
	TIME: 'Time',
	TIME_HOUR: 'Hour',
	TIME_MINUTE: 'Minute',
	SELECT_DATE: 'Selecionar Data',

	SESSION_EXPIRED_COMMENT: 'Por motivos de segurança, sua sessão terá tempo em %seconds% segundos, a menos que você continue',

	NOW: 'agora',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'h',
	NOTI_DAY: 'd',

	
	EXPORT_TO_PDF: 'Export to PDF',
	EXPORT_TO_CSV: 'Exportar para CSV',
	SAVE_AS_PNG: 'Salve como PNG',
	PRINT: 'Print',

	TWOFACTOR_VERIFICATION: 'Verificação de dois fatores',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Endereço de e-mail', 
	TWO_FACTOR_PARAM_PHONE: 'Número de telefone', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};