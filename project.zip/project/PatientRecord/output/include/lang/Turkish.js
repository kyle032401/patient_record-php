Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Turkish",

//	for list page
	TEXT_FIRST: 'İlk',
	TEXT_PREVIOUS: 'Önceki',
	TEXT_NEXT: 'Sonraki',
	TEXT_LAST: 'Son',
	TEXT_PROCEED_TO: 'Baslama',
	TEXT_DETAIL_NOT_SAVED: 'Kayit %s süre içinde kaydedilemedi',
	TEXT_NO_RECORDS: 'Kayıt bulunamadı',
	TEXT_DETAIL_GOTO: 'git',
	TEXT_SHOW_ALL: 'Hepsini göster',
	TEXT_SHOW_OPTIONS: 'Seçenekleri göster',
	TEXT_HIDE_OPTIONS: 'Seçenekleri gizle',
	TEXT_SEARCH_SHOW_OPTIONS:'Arama seçenegini göster',
	TEXT_SEARCH_HIDE_OPTIONS:'Arama seçenegini gizle',
	TEXT_SHOW_SEARCH_PANEL:'Show search panel',
	TEXT_HIDE_SEARCH_PANEL:'Hide search panel',


	TEXT_LOADING: 'yükleniyor',
	TEXT_DELETE_CONFIRM: 'Bu kaydi silmek istediginizden eminmisiniz?',
	TEXT_PAGE: 'Sayfa',
	TEXT_PAGEMAX: '/',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Geçersiz güvenlik kodu',
	TEXT_PLEASE_SELECT: 'Lütfen Seçiniz',
	TEXT_CTRL_CLICK: 'Coklu sıralama için CTRK+  tıklayınız',
	TEXT_SAVE: 'Kaydet',
	TEXT_CANCEL: 'Vazgeç',
	TEXT_PREVIEW: 'önizleme',
	TEXT_HIDE: 'gizle',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Bu sayfanın dışında gezinmek ve kaydedilmemiş değişiklikleri kaybetmek istiyor musunuz?',

	TEXT_EDIT: 'Düzenle',
	TEXT_COPY: 'Kopyala',
	TEXT_VIEW: 'Göster',
	TEXT_INLINE_EDIT: 'Düzenle',
	TEXT_INLINE_ADD: 'Yeni Ekle',
	TEXT_AA_P_ADD: 'Ekle',

	TEXT_FIELDFILTER_HINT: 'Alan değerlerini filtreleyin',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'güvenlik kodu içeren bir eposta %email% gönderildi.',
	USERINFO_ENTER_CODE: 'Aşağıda bu kodu girin.',
	USERINFO_SENT_TEXT: 'güvenlik kodu içeren bir kısa mesaj %phone% gönderildi.',
	USERINFO_INSTALL_APP1: 'Google Authenticator\'da Authy Microsoft Authenticator\'la veya telefonunuzun benzer olarak bir kimlik doğrulama uygulamasını yükleyin.',
	USERINFO_INSTALL_APP2: 'Sonra app aşağıdaki QR kodunu tarayın.',
	USERINFO_INSTALL_APP3: 'Ya elle bu anahtarı kullanarak uygulamada yeni bir kayıt oluşturmak:',
	USERINFO_INSTALL_APP4: 'Ardından aşağıdaki uygulamadan kodunu girin.',

//	for calendar
	TEXT_MONTH_JAN: 'Ocak',
	TEXT_MONTH_FEB: 'Şubat',
	TEXT_MONTH_MAR: 'Mart',
	TEXT_MONTH_APR: 'Nisan',
	TEXT_MONTH_MAY: 'Mayıs',
	TEXT_MONTH_JUN: 'Haziran',
	TEXT_MONTH_JUL: 'Temmuz',
	TEXT_MONTH_AUG: 'Ağustos',
	TEXT_MONTH_SEP: 'Eylül',
	TEXT_MONTH_OCT: 'Ekim',
	TEXT_MONTH_NOV: 'Kasım',
	TEXT_MONTH_DEC: 'Aralık',
	TEXT_DAY_SU: 'Paz',
	TEXT_DAY_MO: 'Pzt',
	TEXT_DAY_TU: 'Sal',
	TEXT_DAY_WE: 'Çrş',
	TEXT_DAY_TH: 'Per',
	TEXT_DAY_FR: 'Cum',
	TEXT_DAY_SA: 'Cts',
	TEXT_TODAY: 'Bugün',
	TEXT_SELECT_DATE: 'Tarh Seç',
	TEXT_TIME: 'Zaman',
	TEXT_TIME_HOUR: 'Saat',
	TEXT_TIME_MINUTE: 'Dakika',
	TEXT_TIME_SECOND: 'Saniye',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Zorunlu alanlar',
	TEXT_INLINE_FIELD_ZIPCODE: 'Geçerli posta kodu girilmeli',
	TEXT_INLINE_FIELD_EMAIL: 'Geçerli email girilmeli',
	TEXT_INLINE_FIELD_NUMBER: 'Geçerli sayı girilmeli',
	TEXT_INLINE_FIELD_CURRENCY: 'Geçerli bir para birimi girilmeli',
	TEXT_INLINE_FIELD_PHONE: 'Geçerli telefon numarası girilmeli',
	TEXT_INLINE_FIELD_PASSWORD1: 'Alan "parola" olamaz',
	TEXT_INLINE_FIELD_PASSWORD2: 'Alana en az 4 karakter girilmeli',
	TEXT_INLINE_FIELD_STATE: 'Geçerli ABD Eyalet adı girilmeli',
	TEXT_INLINE_FIELD_SSN: 'Geçerli SSK numarası girilmeli',
	TEXT_INLINE_FIELD_DATE: 'Geçerli tarih girilmeli',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: '24 saat formatına uygun olmalı',
	TEXT_INLINE_FIELD_CC: 'Geçerli kredi kartı numarası girilmeli',
	TEXT_INLINE_ERROR: 'Hatalı',
	TEXT_INLINE_DENY_DUPLICATES: 'Alan tekrarlanan bir değer içermemelidir',
	TEXT_INLINE_USERNAME_EXISTS1: 'Kullanıcıadı',
	TEXT_INLINE_USERNAME_EXISTS2: 'zaten var. Lütfen başka bir ad seçiniz.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email',
	TEXT_INLINE_EMAIL_ALREADY2: 'zaten kayıtlı. Kullanıcıadınızı veya parolanızı unuttuysanız hatırlatma formunu doldurunuz.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Kaynağı göster',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'Altdizinleri Aç',
	TEXT_COLLAPSE_ALL: 'Altdizinleri Kapat',

	//for register page
	SEC_PWD_LEN: 'Parola enaz %%  karakter olmalı',
	SEC_PWD_CASE: 'Parola küçük ve büyük harf içermeli',
	SEC_PWD_DIGIT: 'Parola %%  sayı veya sembol içermeli',
	SEC_PWD_UNIQUE: 'Parola %%  benzersiz karakter içermeli',
	PASSWORDS_DONT_MATCH: 'Parola uyusmazligi',
	SUCCES_LOGGED_IN: 'You have successfully logged in.',

	//for pdf
	TEXT_PDF_BUILD1: 'PDF yap',
	TEXT_PDF_BUILD2: 'tamam',
	TEXT_PDF_BUILD3: 'Could not create PDF',

	CLOSE_WINDOW: 'Pencereyi Kapat',
	CLOSE: 'Close',
	RESET: 'Sıfırla',

	//for search options
	CONTAINS: 'içerir',
	EQUALS: 'eşit',
	STARTS_WITH: 'ile başlayan',
	MORE_THAN: 'Daha büyük',
	LESS_THAN: 'Daha küçük',
	BETWEEN: 'Arasinda',
	EMPTY: 'Bos',

	NOT_CONTAINS: 'içermez',
	NOT_EQUALS: 'esit/es olmayan',
	NOT_STARTS_WITH: 'ile baslamayan',
	NOT_MORE_THAN: 'büyük olmayan',
	NOT_LESS_THAN: 'küçük olmayan',
	NOT_BETWEEN: 'arasinda deger içermeyen / araliginda yeralmayan',
	NOT_EMPTY: 'bos degil',

	SEARCH_FOR: 'Aranacak Kelime',

	ERROR_MISSING_FILE_NAME: 'Dosya ady onaylanmady',
	ERROR_ACCEPT_FILE_TYPES: 'Dosya türü geçerli degil',
	ERROR_MAX_FILE_SIZE: 'Dosya boyutu %   kbytes sinirini asiyor',
	ERROR_MIN_FILE_SIZE: 'Dosya boyutu %   kbyte dan asagi olamaz',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Toplam Dosya boyutu %   kbytes sinirini asiyor',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Sadece bir dosya yükleyebilirsiniz',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'En fazla %   dosya  yükleyebilirsiniz',

	TEXT_SERVER_ERROR_OCCURRED: 'Server error occurred',
	TEXT_SEE_DETAILS: 'See details',

	ERROR_UPLOAD: 'Yükleme hatasi',
	START_UPLOAD: 'Yükle',
	CANCEL: 'Vazgeç',
	DELETE: 'Sil',

	UPLOAD_DRAG: 'Dosyaları buraya sürükleyin',

	SELECT_ALL: 'Hepsini seç',
	UNSELECT_ALL: 'Seçimi kaldır',

	TEXT_WR_REPORT_SAVED: 'Rapor kaydedildi',
	TEXT_WR_SOME_PROBLEM: 'Kayit sirasinda problem olustu',
	TEXT_WR_CROSS_GROUP: 'Grup',
	TEXT_WR_HEADER: 'Üst baslik',
	TEXT_WR_CROSS_GROUP: 'Grup',
	TEXT_COUNT: 'Say',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Max',
	TEXT_SUM: 'özet',
	TEXT_AVG: 'Ortalama',
	TEXT_WR_TOTAL_DATA: 'Veri Tablosu',
	TEXT_PAGE_SUMMARY: 'Sayfa özeti',
	TEXT_GLOBAL_SUMMARY: 'Genel özet',
	TEXT_WR_SUMMARY: 'Özet',
	TEXT_FIELD: 'Alan',
	TEXT_WR_NO_COLOR: 'Renk yok',

	TEXT_SEARCH_SAVING: 'Arama kaydediliyor',
	TEXT_SEARCH_NAME: 'Arama adı:',
	TEXT_DELETE_SEARCH_CAPTION: 'Kayıtlı arama silindi',
	TEXT_DELETE_SEARCH: 'Arama kaydını silmek istediğinizden eminmisiniz',
	TEXT_YES: 'Evet',
	TEXT_NO: 'Hayır',

	TEXT_FILTER_APPLY: 'Uygula',
	TEXT_FILTER_CLEAR: 'temizle',
	TEXT_FILTER_MULTISELECT: 'Çoklu seçim',

	// for rights page
	AA_ADD_NEW_GROUP: 'Yeni grup ekle',
	AA_RENAMEGROUP: 'Grup adı değiştir',
	AA_GROUP_NEW: 'yenigrup',
	AA_DELETEGROUP: 'Grubu silmek istediğinizden eminmisiniz?',
	AA_COPY_PERMISS_FROM: 'Choose the group to copy permissions from:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Choose columns to display',
	AA_SELECT_NONE: 'Select none',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Preparing page for printing',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processing records',
	IMPORT_FAILED: 'Import Failed',

	LOADING_FONTS: 'Yazı tipleri yükleniyor',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Ay seç',
	DATEPICKER_NEXT_MONTH: 'Gelecek ay',
	DATEPICKER_PREV_MONTH: 'Geçtiğimiz ay',
	DATEPICKER_SELECT_YEAR: 'seç Yıl',
	DATEPICKER_NEXT_YEAR: 'Gelecek Yıl',
	DATEPICKER_PREV_YEAR: 'Gelecek Yıl',

	TODAY: 'Bugün',
	TIME: 'Zaman',
	TIME_HOUR: 'Saat',
	TIME_MINUTE: 'Dakika',
	SELECT_DATE: 'Tarh Seç',

	SESSION_EXPIRED_COMMENT: 'Güvenlik nedeniyle, oturumunuz devam etmediğiniz sürece %seconds% saniyede zaman aşımına uğrayacak',

	NOW: 'şimdi',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'd',
	NOTI_HOUR: 'saat',
	NOTI_DAY: 'gün',

	
	EXPORT_TO_PDF: 'PDF yap',
	EXPORT_TO_CSV: 'CSV\'ye dışa aktarma',
	SAVE_AS_PNG: 'PNG olarak kaydedin',
	PRINT: 'Print',

	TWOFACTOR_VERIFICATION: 'İki faktörlü doğrulama',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'E', 
	TWO_FACTOR_PARAM_PHONE: 'Telefon numarası', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};