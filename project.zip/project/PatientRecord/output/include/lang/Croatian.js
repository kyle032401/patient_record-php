Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Croatian",

//	for list page
	TEXT_FIRST: 'Prvi',
	TEXT_PREVIOUS: 'Prethodni',
	TEXT_NEXT: 'Sljedeći',
	TEXT_LAST: 'Posljednji',
	TEXT_PROCEED_TO: 'Nastavi do',
	TEXT_DETAIL_NOT_SAVED: 'Zapisi u %s nisu spremljeni',
	TEXT_NO_RECORDS: 'Podatci nisu pronađeni',
	TEXT_DETAIL_GOTO: 'Idi na',
	TEXT_SHOW_ALL: 'Pokaži sve',
	TEXT_SHOW_OPTIONS: 'Prikaži mogućnosti',
	TEXT_HIDE_OPTIONS: 'Sakri mogućnosti',
	TEXT_SEARCH_SHOW_OPTIONS:'Prikaži mogućnosti za pretragu',
	TEXT_SEARCH_HIDE_OPTIONS:'Sakri mogućnosti za pretragu',
	TEXT_SHOW_SEARCH_PANEL:'Prikaži ploču za pretraživanje',
	TEXT_HIDE_SEARCH_PANEL:'Sakrij ploču za pretraživanje',


	TEXT_LOADING: 'učitavanje',
	TEXT_DELETE_CONFIRM: 'Da li zaista želite obrisati ove zapise?',
	TEXT_PAGE: 'Stranica',
	TEXT_PAGEMAX: 'od',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Neispravan sigurnosni kod.',
	TEXT_PLEASE_SELECT: 'Molim, izaberite',
	TEXT_CTRL_CLICK: 'CTRL + klik za višestruko sortiranje',
	TEXT_SAVE: 'Spremi',
	TEXT_CANCEL: 'Otkaži',
	TEXT_PREVIEW: 'prikaz',
	TEXT_HIDE: 'sakri',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Želite li otići s ove stranice i izgubiti nespremljene promjene?',

	TEXT_EDIT: 'Uredi',
	TEXT_COPY: 'Kopiraj',
	TEXT_VIEW: 'Pregledati',
	TEXT_INLINE_EDIT: 'Uredi',
	TEXT_INLINE_ADD: 'Dodaj novo',
	TEXT_AA_P_ADD: 'Dodaj',

	TEXT_FIELDFILTER_HINT: 'Filtrirati vrijednosti polja',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Email sa tajnim kodom poslan je na %email%.',
	USERINFO_ENTER_CODE: 'Ispod unesite kod.',
	USERINFO_SENT_TEXT: 'Tekstualna poruka sa tajnim kodom poslan je na %phone%.',
	USERINFO_INSTALL_APP1: 'Instalirajte autentifikacijsku aplikaciju kao npr. Google Authenticator, Authy, Microsoft Authenticator ili sličnu na Vaš mobitel.',
	USERINFO_INSTALL_APP2: 'Zatim skenirajte doljnji QR kod sa aplikacijom.',
	USERINFO_INSTALL_APP3: 'Ili napravite novi zapis u aplikaciji ručno koristeći ovaj kod:',
	USERINFO_INSTALL_APP4: 'Zatim unesite ispod kod prikazan u aplikaciji.',

//	for calendar
	TEXT_MONTH_JAN: 'Siječanj',
	TEXT_MONTH_FEB: 'Veljača',
	TEXT_MONTH_MAR: 'Ožujak',
	TEXT_MONTH_APR: 'Travanj',
	TEXT_MONTH_MAY: 'Svibanj',
	TEXT_MONTH_JUN: 'Lipanj',
	TEXT_MONTH_JUL: 'Srpanj',
	TEXT_MONTH_AUG: 'Kolovoz',
	TEXT_MONTH_SEP: 'Rujan',
	TEXT_MONTH_OCT: 'Listopad',
	TEXT_MONTH_NOV: 'Studeni',
	TEXT_MONTH_DEC: 'Prosinac',
	TEXT_DAY_SU: 'Ned',
	TEXT_DAY_MO: 'Pon',
	TEXT_DAY_TU: 'Uto',
	TEXT_DAY_WE: 'Sri',
	TEXT_DAY_TH: 'Čet',
	TEXT_DAY_FR: 'Pet',
	TEXT_DAY_SA: 'Sub',
	TEXT_TODAY: 'danas',
	TEXT_SELECT_DATE: 'Odaberi datum',
	TEXT_TIME: 'Vrijeme',
	TEXT_TIME_HOUR: 'Sat',
	TEXT_TIME_MINUTE: 'Minuta',
	TEXT_TIME_SECOND: 'Sekundi',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Obavezno polje',
	TEXT_INLINE_FIELD_ZIPCODE: 'Polje mora sadržavati ispravan poštanski broj',
	TEXT_INLINE_FIELD_EMAIL: 'Polje mora sadržavati ispravnu email adresu',
	TEXT_INLINE_FIELD_NUMBER: 'Polje mora sadržavati numeričku vrijednost',
	TEXT_INLINE_FIELD_CURRENCY: 'Polje mora sadržavati ispravan naziv države',
	TEXT_INLINE_FIELD_PHONE: 'Polje mora sadržavati ispravan broj telefona',
	TEXT_INLINE_FIELD_PASSWORD1: 'Polje ne može biti \'password\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Polje mora sadržavati najmanje 4 znaka',
	TEXT_INLINE_FIELD_STATE: 'Field should be a valid US state name',
	TEXT_INLINE_FIELD_SSN: 'Polje mora biti valjani socijani broj',
	TEXT_INLINE_FIELD_DATE: 'Polje mora sadržavati ispravan datum',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Polje mora sadržavati ispravno uneseno vrijeme',
	TEXT_INLINE_FIELD_CC: 'Polje mora sadržavati ispravan broj kreditne kartice',
	TEXT_INLINE_ERROR: 'Dogodila se pogreška',
	TEXT_INLINE_DENY_DUPLICATES: 'Polje ne smije sadržavati dvostruku vrijednost',
	TEXT_INLINE_USERNAME_EXISTS1: 'Korisničko ime ',
	TEXT_INLINE_USERNAME_EXISTS2: 'već postoji. Molim, promijenite.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email',
	TEXT_INLINE_EMAIL_ALREADY2: 'već postoji. Ako ste zaboravili Vaše korisničko ime ili lozinku koristite formu za podsjećanje.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Pogledaj izvor',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'proširi sve',
	TEXT_COLLAPSE_ALL: 'sažmi sve',

	//for register page
	SEC_PWD_LEN: 'Lozinka mora iti dužine od barem %% znaka.',
	SEC_PWD_CASE: 'Lozinka se mora sastojati od velikih i malih slova.',
	SEC_PWD_DIGIT: 'Lozinka se mora sastojati od barem %% broja ili simbola.',
	SEC_PWD_UNIQUE: 'Lozinka se mora sastojati od najmanje %% posebnih znakova.',
	PASSWORDS_DONT_MATCH: 'Lozinke nisu identične',
	SUCCES_LOGGED_IN: 'Uspješno ste se prijavili.',

	//for pdf
	TEXT_PDF_BUILD1: 'Kreiranje PDF datoteke',
	TEXT_PDF_BUILD2: 'završeno',
	TEXT_PDF_BUILD3: 'Nije moguće stvoriti PDF',

	CLOSE_WINDOW: 'Zatvori prozor',
	CLOSE: 'Zatvori',
	RESET: 'Poništi',

	//for search options
	CONTAINS: 'Sadrži',
	EQUALS: 'Jednak',
	STARTS_WITH: 'Počinje sa',
	MORE_THAN: 'Više od',
	LESS_THAN: 'Manje od',
	BETWEEN: 'Između',
	EMPTY: 'Prazan',

	NOT_CONTAINS: 'Ne sadrži',
	NOT_EQUALS: 'Nije jednako',
	NOT_STARTS_WITH: 'Ne počinje sa',
	NOT_MORE_THAN: 'Nije veće od',
	NOT_LESS_THAN: 'Nije manje od',
	NOT_BETWEEN: 'Nije između',
	NOT_EMPTY: 'Nije prazno',

	SEARCH_FOR: 'Potraži',

	ERROR_MISSING_FILE_NAME: 'Naziv datoteke nije navedena',
	ERROR_ACCEPT_FILE_TYPES: 'Vrsta datoteke nije prihvatljiva',
	ERROR_MAX_FILE_SIZE: 'Veličina datoteke premašuje ograničenje od %s KB',
	ERROR_MIN_FILE_SIZE: 'Veličina datoteke ne smije biti manja od %s KB',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Ukupna veličina datoteka premašuje ograničenje od %s KB',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Možete prenijeti samo jednu datoteku',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'Možete prenijeti najviše %s datoteka',

	TEXT_SERVER_ERROR_OCCURRED: 'Došlo je do pogreške poslužitelja',
	TEXT_SEE_DETAILS: 'Pogledaj detalje',

	ERROR_UPLOAD: 'Prijenos nije uspio',
	START_UPLOAD: 'Prenesi',
	CANCEL: 'Otkaži',
	DELETE: 'Obriši',

	UPLOAD_DRAG: 'Povucite datoteke ovdje',

	SELECT_ALL: 'Odaberi sve',
	UNSELECT_ALL: 'Poništi odabir svih',

	TEXT_WR_REPORT_SAVED: 'Izvještaj spremljen.',
	TEXT_WR_SOME_PROBLEM: 'Došlo je do problema prilikom spremanja',
	TEXT_WR_CROSS_GROUP: 'Grupa',
	TEXT_WR_HEADER: 'Zaglavlje',
	TEXT_WR_CROSS_GROUP: 'Grupa',
	TEXT_COUNT: 'Broj',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Max',
	TEXT_SUM: 'Sum',
	TEXT_AVG: 'Prosjek',
	TEXT_WR_TOTAL_DATA: 'Podaci tablice',
	TEXT_PAGE_SUMMARY: 'Ukupno za stranicu',
	TEXT_GLOBAL_SUMMARY: 'Sveukupno',
	TEXT_WR_SUMMARY: 'Sažetak',
	TEXT_FIELD: 'Polje',
	TEXT_WR_NO_COLOR: 'Bez boje',

	TEXT_SEARCH_SAVING: 'Spremanje pretraživanja',
	TEXT_SEARCH_NAME: 'Ime pretrage:',
	TEXT_DELETE_SEARCH_CAPTION: 'Obriši spremljene pretrage',
	TEXT_DELETE_SEARCH: 'Želite li zaista izbrisati ovo pretraživanje?',
	TEXT_YES: 'Da',
	TEXT_NO: 'Ne',

	TEXT_FILTER_APPLY: 'Primijeni',
	TEXT_FILTER_CLEAR: 'Očisti',
	TEXT_FILTER_MULTISELECT: 'Višestruki odabir',

	// for rights page
	AA_ADD_NEW_GROUP: 'Dodaj novu grupu',
	AA_RENAMEGROUP: 'Preimenuj grupu',
	AA_GROUP_NEW: 'newgroup-a',
	AA_DELETEGROUP: 'Da li stvarno želite obrisati grupu',
	AA_COPY_PERMISS_FROM: 'Odaberite grupu iz koje želite kopirati dozvole:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Odaberite stupce za prikaz',
	AA_SELECT_NONE: 'Poništite odabir',
	AA_OK: 'U redu',

	PREPARE_PAGE_FOR_PRINTING: 'Priprema stranice za ispis',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Obrada zapisa',
	IMPORT_FAILED: 'Uvoz nije uspio',

	LOADING_FONTS: 'Učitavanje fontova',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Odaberite mjesec',
	DATEPICKER_NEXT_MONTH: 'Sljedeći mjesec',
	DATEPICKER_PREV_MONTH: 'Prethodni mjesec',
	DATEPICKER_SELECT_YEAR: 'Odaberite godinu',
	DATEPICKER_NEXT_YEAR: 'Sljedeća godina',
	DATEPICKER_PREV_YEAR: 'Prethodna godina',

	TODAY: 'danas',
	TIME: 'Vrijeme',
	TIME_HOUR: 'Sat',
	TIME_MINUTE: 'Minuta',
	SELECT_DATE: 'Odaberi datum',

	SESSION_EXPIRED_COMMENT: 'Iz sigurnosnih razloga, Vaša će sesija biti prekinuta za %seconds% sekundi, osim ako ne nastavite',

	NOW: 'sada',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'sati',
	NOTI_DAY: 'd',

	
	EXPORT_TO_PDF: 'Izvezi u PDF',
	EXPORT_TO_CSV: 'Izvoz na CSV',
	SAVE_AS_PNG: 'Spremi kao PNG',
	PRINT: 'Ispis',

	TWOFACTOR_VERIFICATION: 'Provjera dvofaktora',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Email adresa', 
	TWO_FACTOR_PARAM_PHONE: 'Broj mobitela', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};