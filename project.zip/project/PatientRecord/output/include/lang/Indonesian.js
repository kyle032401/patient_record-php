Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Indonesian",

//	for list page
	TEXT_FIRST: 'Pertama',
	TEXT_PREVIOUS: 'Sebelumnya',
	TEXT_NEXT: 'Berikutnya',
	TEXT_LAST: 'Terakhir',
	TEXT_PROCEED_TO: 'Proceed to',
	TEXT_DETAIL_NOT_SAVED: 'Records in %s haven\'t been saved',
	TEXT_NO_RECORDS: 'Catatan tidak ditemukan',
	TEXT_DETAIL_GOTO: 'Go to',
	TEXT_SHOW_ALL: 'Perlihatkan semua',
	TEXT_SHOW_OPTIONS: 'Show options',
	TEXT_HIDE_OPTIONS: 'Hide options',
	TEXT_SEARCH_SHOW_OPTIONS:'Show search options',
	TEXT_SEARCH_HIDE_OPTIONS:'Hide search options',
	TEXT_SHOW_SEARCH_PANEL:'Show search panel',
	TEXT_HIDE_SEARCH_PANEL:'Hide search panel',


	TEXT_LOADING: 'loading',
	TEXT_DELETE_CONFIRM: 'Apa anda ingin menghapus record-record ini?',
	TEXT_PAGE: 'Halaman',
	TEXT_PAGEMAX: 'dari',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Invalid security code.',
	TEXT_PLEASE_SELECT: 'Silahkan pilih',
	TEXT_CTRL_CLICK: 'CTRL + click for multiple sorting',
	TEXT_SAVE: 'Simpan',
	TEXT_CANCEL: 'Batal',
	TEXT_PREVIEW: 'preview',
	TEXT_HIDE: 'hide',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Do you want to navigate away from this page and lose unsaved changes?',

	TEXT_EDIT: 'Edit',
	TEXT_COPY: 'Salin',
	TEXT_VIEW: 'Lihat',
	TEXT_INLINE_EDIT: 'Edit',
	TEXT_INLINE_ADD: 'Tambah baru',
	TEXT_AA_P_ADD: 'Add',

	TEXT_FIELDFILTER_HINT: 'Saring',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Email dengan kode keamanan dikirim ke %email%.',
	USERINFO_ENTER_CODE: 'Masukkan kode di bawah ini.',
	USERINFO_SENT_TEXT: 'Sebuah pesan teks dengan kode keamanan dikirim ke %phone%.',
	USERINFO_INSTALL_APP1: 'Install aplikasi otentikasi seperti Google Authenticator, Authy, Microsoft Authenticator atau serupa pada ponsel Anda.',
	USERINFO_INSTALL_APP2: 'Kemudian memindai kode QR di bawah dengan app.',
	USERINFO_INSTALL_APP3: 'Atau membuat rekor baru dalam aplikasi secara manual menggunakan kunci ini:',
	USERINFO_INSTALL_APP4: 'Lalu masukkan kode dari aplikasi di bawah ini.',

//	for calendar
	TEXT_MONTH_JAN: 'Januari',
	TEXT_MONTH_FEB: 'Februari',
	TEXT_MONTH_MAR: 'Maret',
	TEXT_MONTH_APR: 'April',
	TEXT_MONTH_MAY: 'Mei',
	TEXT_MONTH_JUN: 'Juni',
	TEXT_MONTH_JUL: 'Juli',
	TEXT_MONTH_AUG: 'Agustus',
	TEXT_MONTH_SEP: 'September',
	TEXT_MONTH_OCT: 'Oktober',
	TEXT_MONTH_NOV: 'Nopember',
	TEXT_MONTH_DEC: 'Desember',
	TEXT_DAY_SU: 'Mg',
	TEXT_DAY_MO: 'Sn',
	TEXT_DAY_TU: 'Sl',
	TEXT_DAY_WE: 'Rb',
	TEXT_DAY_TH: 'Km',
	TEXT_DAY_FR: 'Jm',
	TEXT_DAY_SA: 'Sb',
	TEXT_TODAY: 'today',
	TEXT_SELECT_DATE: 'Select Date',
	TEXT_TIME: 'Time',
	TEXT_TIME_HOUR: 'Hour',
	TEXT_TIME_MINUTE: 'Minute',
	TEXT_TIME_SECOND: 'Second',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Membutuhkan Kolom',
	TEXT_INLINE_FIELD_ZIPCODE: 'Kolom harus Kode Pos yang benar',
	TEXT_INLINE_FIELD_EMAIL: 'Kolom harus E-mail yang benar',
	TEXT_INLINE_FIELD_NUMBER: 'Kolom harus nomor',
	TEXT_INLINE_FIELD_CURRENCY: 'Kolom harus mata uang',
	TEXT_INLINE_FIELD_PHONE: 'Kolom harus Nomor Telepon',
	TEXT_INLINE_FIELD_PASSWORD1: 'Kolom tidak untuk "password"',
	TEXT_INLINE_FIELD_PASSWORD2: 'Kolom harus sepanjang dari 4 karakter',
	TEXT_INLINE_FIELD_STATE: 'Kolom harus Nama Negara',
	TEXT_INLINE_FIELD_SSN: 'Kolom harus Nomor Sosial Security',
	TEXT_INLINE_FIELD_DATE: 'Kolom harus tanggal yang benar',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Kolom harus waktu yang benar dalam format 24 jam',
	TEXT_INLINE_FIELD_CC: 'Kolom harus Nomor Kartu Kredit yang berlaku',
	TEXT_INLINE_ERROR: 'Terjadi kesalahan',
	TEXT_INLINE_DENY_DUPLICATES: 'Field should not contain a duplicate value',
	TEXT_INLINE_USERNAME_EXISTS1: 'Username',
	TEXT_INLINE_USERNAME_EXISTS2: 'sudah terpakai. Pilih username lainnya.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email',
	TEXT_INLINE_EMAIL_ALREADY2: 'telah terdaftar. Bila anda lupa username atau password anda, gunakan formulir pengingat password',

	//for RTE
	TEXT_VIEW_SOURCE: 'Lihat sumber',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'expand all',
	TEXT_COLLAPSE_ALL: 'collapse all',

	//for register page
	SEC_PWD_LEN: 'Password must be at least %% characters length.',
	SEC_PWD_CASE: 'Password must contain letters in upper and lower case.',
	SEC_PWD_DIGIT: 'Password must contain %% digits or symbols.',
	SEC_PWD_UNIQUE: 'Password must contain %% unique characters.',
	PASSWORDS_DONT_MATCH: 'Password tidak cocok',
	SUCCES_LOGGED_IN: 'You have successfully logged in.',

	//for pdf
	TEXT_PDF_BUILD1: 'Building PDF',
	TEXT_PDF_BUILD2: 'done',
	TEXT_PDF_BUILD3: 'Could not create PDF',

	CLOSE_WINDOW: 'Tutup jendela',
	CLOSE: 'Close',
	RESET: 'Tata ulang',

	//for search options
	CONTAINS: 'Berisi',
	EQUALS: 'Sama dengan',
	STARTS_WITH: 'Mulai dengan',
	MORE_THAN: 'Lebih dari',
	LESS_THAN: 'Kurang dari',
	BETWEEN: 'Antara',
	EMPTY: 'Kosong',

	NOT_CONTAINS: 'Doesn\'t contain',
	NOT_EQUALS: 'Doesn\'t equal',
	NOT_STARTS_WITH: 'Doesn\'t start with',
	NOT_MORE_THAN: 'Is not more than',
	NOT_LESS_THAN: 'Is not less than',
	NOT_BETWEEN: 'Is not between',
	NOT_EMPTY: 'Is not empty',

	SEARCH_FOR: 'Cari',

	ERROR_MISSING_FILE_NAME: 'File name was not provided',
	ERROR_ACCEPT_FILE_TYPES: 'File type is not acceptable',
	ERROR_MAX_FILE_SIZE: 'File size exceeds limit of %s kbytes',
	ERROR_MIN_FILE_SIZE: 'File size must not be less than %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Total files size exceeds limit of %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'You can upload only one file',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'You can upload no more than %s files',

	TEXT_SERVER_ERROR_OCCURRED: 'Server error occurred',
	TEXT_SEE_DETAILS: 'See details',

	ERROR_UPLOAD: 'Uploading failed',
	START_UPLOAD: 'Upload',
	CANCEL: 'Batal',
	DELETE: 'Hapus',

	UPLOAD_DRAG: 'Drag files here',

	SELECT_ALL: 'Select all',
	UNSELECT_ALL: 'Unselect all',

	TEXT_WR_REPORT_SAVED: 'Report Saved',
	TEXT_WR_SOME_PROBLEM: 'Some problems appear during saving',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_WR_HEADER: 'Header',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_COUNT: 'Hitung',
	TEXT_MIN: 'Min/Kurang',
	TEXT_MAX: 'Maksimum',
	TEXT_SUM: 'jumlah',
	TEXT_AVG: 'Avg',
	TEXT_WR_TOTAL_DATA: 'Table Data',
	TEXT_PAGE_SUMMARY: 'Halaman Ringkasan',
	TEXT_GLOBAL_SUMMARY: 'Ringkasan global',
	TEXT_WR_SUMMARY: 'Summary',
	TEXT_FIELD: 'Field',
	TEXT_WR_NO_COLOR: 'No color',

	TEXT_SEARCH_SAVING: 'Search saving',
	TEXT_SEARCH_NAME: 'Search name:',
	TEXT_DELETE_SEARCH_CAPTION: 'Delete saved search',
	TEXT_DELETE_SEARCH: 'Do you really want to delete this search?',
	TEXT_YES: 'Ya',
	TEXT_NO: 'Tidak',

	TEXT_FILTER_APPLY: 'Apply',
	TEXT_FILTER_CLEAR: 'Clear',
	TEXT_FILTER_MULTISELECT: 'Multiselect',

	// for rights page
	AA_ADD_NEW_GROUP: 'Add new group',
	AA_RENAMEGROUP: 'Rename group',
	AA_GROUP_NEW: 'newgroup',
	AA_DELETEGROUP: 'Do you really want to delete group',
	AA_COPY_PERMISS_FROM: 'Choose the group to copy permissions from:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Choose columns to display',
	AA_SELECT_NONE: 'Select none',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Preparing page for printing',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processing records',
	IMPORT_FAILED: 'Import Failed',

	LOADING_FONTS: 'Memuat font',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Pilih Bulan',
	DATEPICKER_NEXT_MONTH: 'Bulan depan',
	DATEPICKER_PREV_MONTH: 'Bulan sebelumnya',
	DATEPICKER_SELECT_YEAR: 'Pilih Tahun',
	DATEPICKER_NEXT_YEAR: 'Tahun depan',
	DATEPICKER_PREV_YEAR: 'Tahun depan',

	TODAY: 'today',
	TIME: 'Time',
	TIME_HOUR: 'Hour',
	TIME_MINUTE: 'Minute',
	SELECT_DATE: 'Select Date',

	SESSION_EXPIRED_COMMENT: 'Untuk alasan keamanan, sesi Anda akan habis dalam %seconds% detik kecuali Anda melanjutkan',

	NOW: 'sekarang',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'jam',
	NOTI_DAY: 'hari',

	
	EXPORT_TO_PDF: 'Export to PDF',
	EXPORT_TO_CSV: 'Ekspor ke CSV',
	SAVE_AS_PNG: 'Simpan sebagai PNG',
	PRINT: 'Print',

	TWOFACTOR_VERIFICATION: 'Verifikasi dua faktor',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Alamat email', 
	TWO_FACTOR_PARAM_PHONE: 'Nomor telepon', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};