Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Bulgarian",

//	for list page
	TEXT_FIRST: 'Първи',
	TEXT_PREVIOUS: 'Предишните',
	TEXT_NEXT: 'Нататък',
	TEXT_LAST: 'Последни',
	TEXT_PROCEED_TO: 'Премини към',
	TEXT_DETAIL_NOT_SAVED: 'Записите в %s не бяха запазени',
	TEXT_NO_RECORDS: 'Няма записи',
	TEXT_DETAIL_GOTO: 'Иди към',
	TEXT_SHOW_ALL: 'Покажи всички',
	TEXT_SHOW_OPTIONS: 'Покажи опции',
	TEXT_HIDE_OPTIONS: 'Скрий опций',
	TEXT_SEARCH_SHOW_OPTIONS:'Покажи опции търсене',
	TEXT_SEARCH_HIDE_OPTIONS:'Скрий опции търсене',
	TEXT_SHOW_SEARCH_PANEL:'покажи панела за търсене',
	TEXT_HIDE_SEARCH_PANEL:'скрий панела за търсене',


	TEXT_LOADING: 'Зареждане',
	TEXT_DELETE_CONFIRM: 'Действително ли искате да изтриете записа?',
	TEXT_PAGE: 'Страница',
	TEXT_PAGEMAX: 'от',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Неправилен код CAPTCHA.',
	TEXT_PLEASE_SELECT: 'Моля, изберете',
	TEXT_CTRL_CLICK: 'CTRL + click for multiple sorting',
	TEXT_SAVE: 'Запиши',
	TEXT_CANCEL: 'Откажи',
	TEXT_PREVIEW: 'предварителен преглед',
	TEXT_HIDE: 'скрий',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Вие наистина ли искате да напуснете страницата и да изгубите нещата, които не сте съхранили',

	TEXT_EDIT: 'Редактирай',
	TEXT_COPY: 'Копирай',
	TEXT_VIEW: 'Преглед',
	TEXT_INLINE_EDIT: 'Редактирай',
	TEXT_INLINE_ADD: 'Добави',
	TEXT_AA_P_ADD: 'Добави',

	TEXT_FIELDFILTER_HINT: 'Филтрирайте стойностите на полето',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Един имейл с кода за защита е изпратено до %email%.',
	USERINFO_ENTER_CODE: 'Въведете кода по-долу.',
	USERINFO_SENT_TEXT: 'Текстово съобщение с кода за защита е изпратено до %phone%.',
	USERINFO_INSTALL_APP1: 'Инсталиране на приложението за удостоверяване, като например Google Authenticator, Authy, Microsoft Authenticator или подобен на вашия телефон.',
	USERINFO_INSTALL_APP2: 'След сканирайте QR-кода с приложението.',
	USERINFO_INSTALL_APP3: 'Или да създадете нов запис в приложението ръчно с помощта на този бутон:',
	USERINFO_INSTALL_APP4: 'След това въведете кода от приложението по-долу.',

//	for calendar
	TEXT_MONTH_JAN: 'януари',
	TEXT_MONTH_FEB: 'февруари',
	TEXT_MONTH_MAR: 'март',
	TEXT_MONTH_APR: 'април',
	TEXT_MONTH_MAY: 'май',
	TEXT_MONTH_JUN: 'июни',
	TEXT_MONTH_JUL: 'июли',
	TEXT_MONTH_AUG: 'август',
	TEXT_MONTH_SEP: 'септември',
	TEXT_MONTH_OCT: 'октомври',
	TEXT_MONTH_NOV: 'ноември',
	TEXT_MONTH_DEC: 'декември',
	TEXT_DAY_SU: 'Нд',
	TEXT_DAY_MO: 'Пн',
	TEXT_DAY_TU: 'Вт',
	TEXT_DAY_WE: 'Ср',
	TEXT_DAY_TH: 'Чт',
	TEXT_DAY_FR: 'Пт',
	TEXT_DAY_SA: 'Сб',
	TEXT_TODAY: 'Днес',
	TEXT_SELECT_DATE: 'избор дата',
	TEXT_TIME: 'време',
	TEXT_TIME_HOUR: 'час',
	TEXT_TIME_MINUTE: 'минута',
	TEXT_TIME_SECOND: 'секунда',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Задължително поле',
	TEXT_INLINE_FIELD_ZIPCODE: 'Полето трябва да е пощенски код',
	TEXT_INLINE_FIELD_EMAIL: 'Полето трябва да е действителен имейл адрес',
	TEXT_INLINE_FIELD_NUMBER: 'Полето трябва да е действително число',
	TEXT_INLINE_FIELD_CURRENCY: 'Полето трябва да е действително за валутата',
	TEXT_INLINE_FIELD_PHONE: 'Поле должно быть действующим номером телефона',
	TEXT_INLINE_FIELD_PASSWORD1: 'Полето не може да е "парола"',
	TEXT_INLINE_FIELD_PASSWORD2: 'Полето трябва да е не помалко от 4 символа',
	TEXT_INLINE_FIELD_STATE: 'Полето трябва да е правилно име на област ',
	TEXT_INLINE_FIELD_SSN: 'Полето трябва да е действителен номер на социална осигуровка',
	TEXT_INLINE_FIELD_DATE: 'Полето трябва да е действителено на датата',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Полето трябва да е правилно време в 24-часов формат',
	TEXT_INLINE_FIELD_CC: 'Полето трябва да е действителен номер на кредитна карта',
	TEXT_INLINE_ERROR: 'възникна грешка',
	TEXT_INLINE_DENY_DUPLICATES: 'полето не трябва да съдържа дублираща стойност',
	TEXT_INLINE_USERNAME_EXISTS1: 'Потребител с такова име',
	TEXT_INLINE_USERNAME_EXISTS2: 'вече същества. изберете друго потрбителско име.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Имейл адреса',
	TEXT_INLINE_EMAIL_ALREADY2: 'вече е зарегистриран. Ако сте забравили потреб.име или парола, използвайте формата за напоминяне парола.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Преглед на източника',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'разгърни',
	TEXT_COLLAPSE_ALL: 'свий',

	//for register page
	SEC_PWD_LEN: 'Паролата трябва да е, поне%% символа дълга.',
	SEC_PWD_CASE: 'Паролата трябва да съдържа големи и малки букви.',
	SEC_PWD_DIGIT: 'Паролата трябва да съдържа%% цифри и символи.',
	SEC_PWD_UNIQUE: 'Паролата трябва да съдържа%% уникални символи.',
	PASSWORDS_DONT_MATCH: 'Паролите не съвпадат',
	SUCCES_LOGGED_IN: 'Вие успешно влезнахте.',

	//for pdf
	TEXT_PDF_BUILD1: 'Създаване PDF',
	TEXT_PDF_BUILD2: 'Завършено',
	TEXT_PDF_BUILD3: 'не можах да създам PDF',

	CLOSE_WINDOW: 'Затвори прозорец',
	CLOSE: 'затвори',
	RESET: 'Ресет',

	//for search options
	CONTAINS: 'Съдържа',
	EQUALS: 'Равно',
	STARTS_WITH: 'Започва с ...',
	MORE_THAN: 'Повече ...',
	LESS_THAN: 'Помалко ...',
	BETWEEN: 'Между',
	EMPTY: 'Празно',

	NOT_CONTAINS: 'Не съдържа',
	NOT_EQUALS: 'Не е равно на',
	NOT_STARTS_WITH: 'Не започва с',
	NOT_MORE_THAN: 'Не повече от',
	NOT_LESS_THAN: 'Не по-малко от',
	NOT_BETWEEN: 'Не е между',
	NOT_EMPTY: 'Не е празно',

	SEARCH_FOR: 'Търси',

	ERROR_MISSING_FILE_NAME: 'името на файла не е уточнено',
	ERROR_ACCEPT_FILE_TYPES: 'типът на файла не може да бъде приет',
	ERROR_MAX_FILE_SIZE: 'размерът на файла надхвърля %s kbytes ',
	ERROR_MIN_FILE_SIZE: 'размерът на файла не трябва да е повече от %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'размерът на общия брои файлове е %s kbytes ',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Вие може да качите само един файл',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'Вие не може да качите повече от %s файлове',

	TEXT_SERVER_ERROR_OCCURRED: 'възникна грешка на сървъра',
	TEXT_SEE_DETAILS: 'вижте детайлите',

	ERROR_UPLOAD: 'качването беше неуспешно',
	START_UPLOAD: 'качване',
	CANCEL: 'Откажи',
	DELETE: 'Изтрий',

	UPLOAD_DRAG: 'влачете файлове тук',

	SELECT_ALL: 'селектиране на всичко',
	UNSELECT_ALL: 'деселектиране на всичко',

	TEXT_WR_REPORT_SAVED: 'Отчетът е съхранен',
	TEXT_WR_SOME_PROBLEM: 'възникнаха някои проблеми при опит да се съхрани',
	TEXT_WR_CROSS_GROUP: 'групиране',
	TEXT_WR_HEADER: 'хедър',
	TEXT_WR_CROSS_GROUP: 'групиране',
	TEXT_COUNT: 'Количество записи',
	TEXT_MIN: 'Минимум',
	TEXT_MAX: 'Максимум',
	TEXT_SUM: 'Сума',
	TEXT_AVG: 'Avg',
	TEXT_WR_TOTAL_DATA: 'таблица с данни',
	TEXT_PAGE_SUMMARY: 'Страници подобобщено',
	TEXT_GLOBAL_SUMMARY: 'Общо',
	TEXT_WR_SUMMARY: 'Обобщение',
	TEXT_FIELD: 'Поле',
	TEXT_WR_NO_COLOR: 'без цвят',

	TEXT_SEARCH_SAVING: 'търсенето се съхранява',
	TEXT_SEARCH_NAME: 'търсене по име:',
	TEXT_DELETE_SEARCH_CAPTION: 'изтриване на съхраненото търсене',
	TEXT_DELETE_SEARCH: 'Наистина ли желаете да изтриете това търсене',
	TEXT_YES: 'Да',
	TEXT_NO: 'Нет',

	TEXT_FILTER_APPLY: 'Прилагане',
	TEXT_FILTER_CLEAR: 'изчистване',
	TEXT_FILTER_MULTISELECT: 'Няколко',

	// for rights page
	AA_ADD_NEW_GROUP: 'Добави нова група',
	AA_RENAMEGROUP: 'Преименувай групи',
	AA_GROUP_NEW: 'новагрупа',
	AA_DELETEGROUP: 'Действително ли искате да изтриете групата',
	AA_COPY_PERMISS_FROM: 'Изберете групата от която искате да копирате правата и разрешенията от:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'изберете колоните, които желаете да покажете',
	AA_SELECT_NONE: 'нищо не избирай',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'приготвям страницата за отпечатване',

	// import page
	IMPORT_PROCESSING_RECORDS: 'обработване на записите',
	IMPORT_FAILED: 'възникна грешка при импортирането',

	LOADING_FONTS: 'Шрифтовете се зареждат',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Изберете месец',
	DATEPICKER_NEXT_MONTH: 'Следващият месец',
	DATEPICKER_PREV_MONTH: 'Предходния месец',
	DATEPICKER_SELECT_YEAR: 'Изберете година',
	DATEPICKER_NEXT_YEAR: 'Следващата година',
	DATEPICKER_PREV_YEAR: 'Следващата година',

	TODAY: 'Днес',
	TIME: 'време',
	TIME_HOUR: 'час',
	TIME_MINUTE: 'минута',
	SELECT_DATE: 'избор дата',

	SESSION_EXPIRED_COMMENT: 'От съображения за сигурност, вашата сесия ще излезе в %seconds% секунди, освен ако не продължите',

	NOW: 'сега',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'м',
	NOTI_HOUR: 'ч',
	NOTI_DAY: 'д',

	
	EXPORT_TO_PDF: 'изнасяне в PDF',
	EXPORT_TO_CSV: 'Експорт в CSV',
	SAVE_AS_PNG: 'Запазете като PNG',
	PRINT: 'отпечатай',

	TWOFACTOR_VERIFICATION: 'Двуфакторна проверка',
	EMAIL: 'Имейл адрес',
	TWO_FACTOR_PARAM_EMAIL: 'Имейл адрес', 
	TWO_FACTOR_PARAM_PHONE: 'Телефонен номер', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};