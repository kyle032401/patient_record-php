Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Italian",

//	for list page
	TEXT_FIRST: 'Primo',
	TEXT_PREVIOUS: 'Precedente',
	TEXT_NEXT: 'Prossimo',
	TEXT_LAST: 'Ultimo',
	TEXT_PROCEED_TO: 'Procedi a',
	TEXT_DETAIL_NOT_SAVED: 'I record in %s non sono stati salvati',
	TEXT_NO_RECORDS: 'Non sono stati trovati Record',
	TEXT_DETAIL_GOTO: 'Vai a',
	TEXT_SHOW_ALL: 'Mostra tutto',
	TEXT_SHOW_OPTIONS: 'Mostra opzioni',
	TEXT_HIDE_OPTIONS: 'Nascondi opzioni',
	TEXT_SEARCH_SHOW_OPTIONS:'Mostra le opzioni di ricerca',
	TEXT_SEARCH_HIDE_OPTIONS:'Nascondi le opzioni di ricerca',
	TEXT_SHOW_SEARCH_PANEL:'Mostra il pannello di ricerca',
	TEXT_HIDE_SEARCH_PANEL:'Nascondi il pannello di ricerca',


	TEXT_LOADING: 'caricamento',
	TEXT_DELETE_CONFIRM: 'Vuoi veramente cancellare questi record?',
	TEXT_PAGE: 'Pagina',
	TEXT_PAGEMAX: 'di',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Codice di sicurezza non valido.',
	TEXT_PLEASE_SELECT: 'Prego seleziona',
	TEXT_CTRL_CLICK: 'CTRL + click per ordinamento multiplo',
	TEXT_SAVE: 'Salva',
	TEXT_CANCEL: 'Cancella',
	TEXT_PREVIEW: 'anteprima',
	TEXT_HIDE: 'nascondi',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Vuoi uscireo da questa pagina e perdere le modifiche non salvate?',

	TEXT_EDIT: 'Modifica',
	TEXT_COPY: 'Copia',
	TEXT_VIEW: 'Dettagli',
	TEXT_INLINE_EDIT: 'Modifica inline',
	TEXT_INLINE_ADD: 'Aggiungi nuovo inline',
	TEXT_AA_P_ADD: 'Aggiungi',

	TEXT_FIELDFILTER_HINT: 'Filtrare i valori del campo',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Una e-mail con il codice di sicurezza è stato inviato a %email%.',
	USERINFO_ENTER_CODE: 'Inserisci il codice di seguito.',
	USERINFO_SENT_TEXT: 'Un messaggio di testo con il codice di sicurezza è stato inviato a %phone%.',
	USERINFO_INSTALL_APP1: 'Installare un\'applicazione di autenticazione come Google Authenticator, Authy, Microsoft Authenticator o simili sul telefono.',
	USERINFO_INSTALL_APP2: 'Poi scansiona il codice QR in basso con l\'applicazione.',
	USERINFO_INSTALL_APP3: 'O crei un nuovo record nella applicazione manualmente utilizzando questa chiave:',
	USERINFO_INSTALL_APP4: 'Quindi inserisce il codice dall\'applicazione di seguito.',

//	for calendar
	TEXT_MONTH_JAN: 'Gennaio',
	TEXT_MONTH_FEB: 'Febbraio',
	TEXT_MONTH_MAR: 'Marzo',
	TEXT_MONTH_APR: 'Aprile',
	TEXT_MONTH_MAY: 'Maggio',
	TEXT_MONTH_JUN: 'Giugno',
	TEXT_MONTH_JUL: 'Luglio',
	TEXT_MONTH_AUG: 'Agosto',
	TEXT_MONTH_SEP: 'Settembre',
	TEXT_MONTH_OCT: 'Ottobre',
	TEXT_MONTH_NOV: 'Novembre',
	TEXT_MONTH_DEC: 'Dicembre',
	TEXT_DAY_SU: 'DO',
	TEXT_DAY_MO: 'LU',
	TEXT_DAY_TU: 'MA',
	TEXT_DAY_WE: 'ME',
	TEXT_DAY_TH: 'GI',
	TEXT_DAY_FR: 'VE',
	TEXT_DAY_SA: 'SA',
	TEXT_TODAY: 'oggi',
	TEXT_SELECT_DATE: 'Seleziona una data',
	TEXT_TIME: 'Tempo',
	TEXT_TIME_HOUR: 'Ora',
	TEXT_TIME_MINUTE: 'Minuto',
	TEXT_TIME_SECOND: 'Secondo',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Campo richiesto',
	TEXT_INLINE_FIELD_ZIPCODE: 'Il campo deve contenere un Codice di Avviamento Postale valido',
	TEXT_INLINE_FIELD_EMAIL: 'Il campo deve contenere un indirizzo di posta elettronica valido',
	TEXT_INLINE_FIELD_NUMBER: 'Il campo deve essere un Numero',
	TEXT_INLINE_FIELD_CURRENCY: 'Il campo deve essere in valuta',
	TEXT_INLINE_FIELD_PHONE: 'Il campo deve contenere un Numero di Telefono',
	TEXT_INLINE_FIELD_PASSWORD1: 'Il campo non può contenere la parola \'password\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Il campo deve essere lungo almeno 4 caratteri',
	TEXT_INLINE_FIELD_STATE: 'Il campo deve contenere un Nome di uno Stato',
	TEXT_INLINE_FIELD_SSN: 'Il campo deve contenere un Numero di Previdenza Sociale',
	TEXT_INLINE_FIELD_DATE: 'Il campo deve contenere una data valida',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Il campo deve contenere l\'ora nel formato h24',
	TEXT_INLINE_FIELD_CC: 'Il campo deve contenere un Numero di Carta di Credito valido',
	TEXT_INLINE_ERROR: 'Si é verificato un errore',
	TEXT_INLINE_DENY_DUPLICATES: 'Il campo non deve contenere valori duplicati',
	TEXT_INLINE_USERNAME_EXISTS1: 'Nome utente',
	TEXT_INLINE_USERNAME_EXISTS2: 'già esistente. Scegline un altro',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email',
	TEXT_INLINE_EMAIL_ALREADY2: 'già registrata. Se hai dimenticato il nome utente o la password, usa il modulo per ricordare la password',

	//for RTE
	TEXT_VIEW_SOURCE: 'Guarda sorgente',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'espandi tutto',
	TEXT_COLLAPSE_ALL: 'chiudi tutto',

	//for register page
	SEC_PWD_LEN: 'La password deve essere lunga almeno %% caratteri.',
	SEC_PWD_CASE: 'La password deve contenere caratteri in maiuscolo e in minuscolo.',
	SEC_PWD_DIGIT: 'La password deve contenere %% numeri o simboli.',
	SEC_PWD_UNIQUE: 'La password deve contenere %% caratteri diversi.',
	PASSWORDS_DONT_MATCH: 'La password non combina',
	SUCCES_LOGGED_IN: 'Sei entrato con successo',

	//for pdf
	TEXT_PDF_BUILD1: 'Creazione PDF',
	TEXT_PDF_BUILD2: 'fatto',
	TEXT_PDF_BUILD3: 'Non è possibile creare il PDF',

	CLOSE_WINDOW: 'Chiudi finestra',
	CLOSE: 'Chiudi',
	RESET: 'Annulla',

	//for search options
	CONTAINS: 'Contiene',
	EQUALS: 'Uguale',
	STARTS_WITH: 'Incomincia per',
	MORE_THAN: 'Più di',
	LESS_THAN: 'Meno di',
	BETWEEN: 'Tra',
	EMPTY: 'Vuoto',

	NOT_CONTAINS: 'Non contiene',
	NOT_EQUALS: 'Non è uguale a',
	NOT_STARTS_WITH: 'Non inizia per',
	NOT_MORE_THAN: 'Non è maggiore di',
	NOT_LESS_THAN: 'Non è minore di',
	NOT_BETWEEN: 'Non è compreso',
	NOT_EMPTY: 'Non è vuoto',

	SEARCH_FOR: 'Cerca per',

	ERROR_MISSING_FILE_NAME: 'Il file non è stato fornito',
	ERROR_ACCEPT_FILE_TYPES: 'Il tipo di file non è accettabile',
	ERROR_MAX_FILE_SIZE: 'La dimensione del file supera il limite di %s kbytes',
	ERROR_MIN_FILE_SIZE: 'La dimensione del file non dev\'essere inferiore a %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'La dimensione totale dei file supera il limite di %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Puoi fare l\'upload di un solo file',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'Puoi fare l\'upload di max %s file',

	TEXT_SERVER_ERROR_OCCURRED: 'E\' avvenuto un errore sul server',
	TEXT_SEE_DETAILS: 'Vedi i dettagli',

	ERROR_UPLOAD: 'Upload fallito',
	START_UPLOAD: 'Upload',
	CANCEL: 'Cancella',
	DELETE: 'Cancella',

	UPLOAD_DRAG: 'Trascinare i file qui',

	SELECT_ALL: 'Seleziona tutti',
	UNSELECT_ALL: 'Deseleziona tutti',

	TEXT_WR_REPORT_SAVED: 'Report salvato',
	TEXT_WR_SOME_PROBLEM: 'Sono emersi problemi durante il salvataggio',
	TEXT_WR_CROSS_GROUP: 'Gruppo',
	TEXT_WR_HEADER: 'Testata',
	TEXT_WR_CROSS_GROUP: 'Gruppo',
	TEXT_COUNT: 'Conta',
	TEXT_MIN: 'Minimo',
	TEXT_MAX: 'Massimo',
	TEXT_SUM: 'Somma',
	TEXT_AVG: 'Media',
	TEXT_WR_TOTAL_DATA: 'Tabella dati',
	TEXT_PAGE_SUMMARY: 'Sommario della pagina',
	TEXT_GLOBAL_SUMMARY: 'Sommario globale',
	TEXT_WR_SUMMARY: 'Sommario',
	TEXT_FIELD: 'Campo',
	TEXT_WR_NO_COLOR: 'Nessun colore',

	TEXT_SEARCH_SAVING: 'Salvataggio ricerche',
	TEXT_SEARCH_NAME: 'Nome da ricercare',
	TEXT_DELETE_SEARCH_CAPTION: 'Cancella le ricerche salvate',
	TEXT_DELETE_SEARCH: 'Vuoi veramente cancellare questa ricerca ?',
	TEXT_YES: 'Si',
	TEXT_NO: 'No',

	TEXT_FILTER_APPLY: 'Applicare',
	TEXT_FILTER_CLEAR: 'Rimuovi Filtro',
	TEXT_FILTER_MULTISELECT: 'Multiselezione',

	// for rights page
	AA_ADD_NEW_GROUP: 'Aggiungi gruppo',
	AA_RENAMEGROUP: 'Rinomina gruppo',
	AA_GROUP_NEW: 'Nuovo gruppo',
	AA_DELETEGROUP: 'Vuoi veramente cancellare il gruppo',
	AA_COPY_PERMISS_FROM: 'Scegliere il gruppo da cui copiare i permessi :',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Schegli le colonne da visionare',
	AA_SELECT_NONE: 'Nessuna selezione',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Preparazione della pagina per la stampa',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Records processati',
	IMPORT_FAILED: 'Importazione Fallita',

	LOADING_FONTS: 'Caricamento dei font',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Selezionare il mese',
	DATEPICKER_NEXT_MONTH: 'Il prossimo mese',
	DATEPICKER_PREV_MONTH: 'Il mese scorso',
	DATEPICKER_SELECT_YEAR: 'Seleziona Anno',
	DATEPICKER_NEXT_YEAR: 'L\'anno prossimo',
	DATEPICKER_PREV_YEAR: 'L\'anno prossimo',

	TODAY: 'oggi',
	TIME: 'Tempo',
	TIME_HOUR: 'Ora',
	TIME_MINUTE: 'Minuto',
	SELECT_DATE: 'Seleziona una data',

	SESSION_EXPIRED_COMMENT: 'Per motivi di sicurezza, la tua sessione sarà scaduta in %seconds% secondi a meno che non continui',

	NOW: 'Ora',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'ore',
	NOTI_DAY: 'giorni',

	
	EXPORT_TO_PDF: 'Esporta in PDF',
	EXPORT_TO_CSV: 'Esporta in CSV',
	SAVE_AS_PNG: 'Salva come PNG',
	PRINT: 'Stampa',

	TWOFACTOR_VERIFICATION: 'Verifica a due fattori',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Indirizzo email', 
	TWO_FACTOR_PARAM_PHONE: 'Numero di telefono', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};