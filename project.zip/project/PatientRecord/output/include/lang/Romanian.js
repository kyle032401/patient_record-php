Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Romanian",

//	for list page
	TEXT_FIRST: 'Primul',
	TEXT_PREVIOUS: 'Anterior',
	TEXT_NEXT: 'Urmator',
	TEXT_LAST: 'Ultimul',
	TEXT_PROCEED_TO: 'Mergi la',
	TEXT_DETAIL_NOT_SAVED: 'Inregistrarile in %s nu au fost salvate',
	TEXT_NO_RECORDS: 'Nu s-au gasit inregistrari',
	TEXT_DETAIL_GOTO: 'Mergi la',
	TEXT_SHOW_ALL: 'Afiseaza tot',
	TEXT_SHOW_OPTIONS: 'Arata optiuni',
	TEXT_HIDE_OPTIONS: 'Ascunde optiuni',
	TEXT_SEARCH_SHOW_OPTIONS:'Arata optiunile cautarii',
	TEXT_SEARCH_HIDE_OPTIONS:'Ascunde optiunile cautarii',
	TEXT_SHOW_SEARCH_PANEL:'Afiseaza panoul de cautare',
	TEXT_HIDE_SEARCH_PANEL:'Ascunde panoul de cautare',


	TEXT_LOADING: 'incarc',
	TEXT_DELETE_CONFIRM: 'Chiar doriti sa stergeti aceste inregistrari?',
	TEXT_PAGE: 'Pagina',
	TEXT_PAGEMAX: 'din',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Cod de securitate invalid.',
	TEXT_PLEASE_SELECT: 'Va rog selectati',
	TEXT_CTRL_CLICK: 'CTRL + click pentru sortare multipla',
	TEXT_SAVE: 'Salveaza',
	TEXT_CANCEL: 'Anuleaza',
	TEXT_PREVIEW: 'previzualizare',
	TEXT_HIDE: 'ascunde',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Doresti sa parasesti aceasta pagina si sa pierzi modificarile nesalvate?',

	TEXT_EDIT: 'Editeaza',
	TEXT_COPY: 'Copiaza',
	TEXT_VIEW: 'Vezi',
	TEXT_INLINE_EDIT: 'Editeaza aici',
	TEXT_INLINE_ADD: 'Adauga aici',
	TEXT_AA_P_ADD: 'Adauga',

	TEXT_FIELDFILTER_HINT: 'Filtra valorile câmpului',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Un e-mail cu codul de securitate a fost trimis la %email%.',
	USERINFO_ENTER_CODE: 'Introduceti codul de mai jos.',
	USERINFO_SENT_TEXT: 'Un mesaj text cu codul de securitate a fost trimis la %phone%.',
	USERINFO_INSTALL_APP1: 'Instalați o aplicație de autentificare, cum ar fi Google Authenticator, Authy, Microsoft Authenticator sau similare pe telefon.',
	USERINFO_INSTALL_APP2: 'Apoi, scanați codul QR de mai jos cu aplicația.',
	USERINFO_INSTALL_APP3: 'Sau de a crea un nou record în aplicația manual utilizând această cheie:',
	USERINFO_INSTALL_APP4: 'Apoi introduceți codul din aplicația de mai jos.',

//	for calendar
	TEXT_MONTH_JAN: 'Ianuarie',
	TEXT_MONTH_FEB: 'Februarie',
	TEXT_MONTH_MAR: 'Martie',
	TEXT_MONTH_APR: 'Aprilie',
	TEXT_MONTH_MAY: 'Mai',
	TEXT_MONTH_JUN: 'Iunie',
	TEXT_MONTH_JUL: 'Iulie',
	TEXT_MONTH_AUG: 'August',
	TEXT_MONTH_SEP: 'Septembrie',
	TEXT_MONTH_OCT: 'Octombrie',
	TEXT_MONTH_NOV: 'Noiembrie',
	TEXT_MONTH_DEC: 'Decembrie',
	TEXT_DAY_SU: 'Du',
	TEXT_DAY_MO: 'Lu',
	TEXT_DAY_TU: 'Ma',
	TEXT_DAY_WE: 'Mi',
	TEXT_DAY_TH: 'Joi',
	TEXT_DAY_FR: 'Vi',
	TEXT_DAY_SA: 'Sa',
	TEXT_TODAY: 'azi',
	TEXT_SELECT_DATE: 'Selecteaza data',
	TEXT_TIME: 'Timp',
	TEXT_TIME_HOUR: 'Ora',
	TEXT_TIME_MINUTE: 'Minut',
	TEXT_TIME_SECOND: 'Secunda',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Camp obligatoriu',
	TEXT_INLINE_FIELD_ZIPCODE: 'Campurile trebuie sa fie coduri postale valide',
	TEXT_INLINE_FIELD_EMAIL: 'Campul trebuie sa fie un E-mail valid',
	TEXT_INLINE_FIELD_NUMBER: 'Campul trebuie sa fie un Numar',
	TEXT_INLINE_FIELD_CURRENCY: 'Campul trebuie sa fie de tip Moneda',
	TEXT_INLINE_FIELD_PHONE: 'Campul trebuie sa fie un Numar de telefon',
	TEXT_INLINE_FIELD_PASSWORD1: 'Campul nu poate avea valoarea \'password\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Campul trebuie sa aiba minim 4 caractere lungime',
	TEXT_INLINE_FIELD_STATE: 'Campul trebuie sa fie un nume de Stat',
	TEXT_INLINE_FIELD_SSN: 'Campul trebuie sa fie CNP',
	TEXT_INLINE_FIELD_DATE: 'Campul trebuie sa fie o data valida',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Campul trebuie sa fie o ora valida in formatul 24-ore',
	TEXT_INLINE_FIELD_CC: 'Campul trebuie sa sa fie un numar valid de Credit Card',
	TEXT_INLINE_ERROR: 'Eroare detectata',
	TEXT_INLINE_DENY_DUPLICATES: 'Campul nu trebuie sa contina o valoare duplicat',
	TEXT_INLINE_USERNAME_EXISTS1: 'Utilizatorul',
	TEXT_INLINE_USERNAME_EXISTS2: 'deja exista. Alegeti un alt utilizator.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email',
	TEXT_INLINE_EMAIL_ALREADY2: 'deja inregistrat. Daca ati uitat utilizatorul sau parola folositi pagina de amintire a parolei.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Vezi sursa',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'extinde',
	TEXT_COLLAPSE_ALL: 'restrange',

	//for register page
	SEC_PWD_LEN: 'Parola trebuie sa fie de minim %% caractere.',
	SEC_PWD_CASE: 'Parola trebuie sa contina caractere mari si mici.',
	SEC_PWD_DIGIT: 'Parola trebuie sa contina %% numere sau simboluri.',
	SEC_PWD_UNIQUE: 'Parola trebuie sa contina %% caractere unice.',
	PASSWORDS_DONT_MATCH: 'Parola nu se potriveste',
	SUCCES_LOGGED_IN: 'Te-ai autentificat cu succes.',

	//for pdf
	TEXT_PDF_BUILD1: 'Construiesc PDF',
	TEXT_PDF_BUILD2: 'gata',
	TEXT_PDF_BUILD3: 'Fisierul PDf nu a putut fi creat',

	CLOSE_WINDOW: 'Inchide fereastra',
	CLOSE: 'Inchide',
	RESET: 'Reseteaza',

	//for search options
	CONTAINS: 'Contine',
	EQUALS: 'Egal',
	STARTS_WITH: 'Incepe cu ...',
	MORE_THAN: 'Mai mult ca ...',
	LESS_THAN: 'Mai mic ca ...',
	BETWEEN: 'Intre',
	EMPTY: 'Gol',

	NOT_CONTAINS: 'Nu contine',
	NOT_EQUALS: 'Nu este egal cu',
	NOT_STARTS_WITH: 'Nu incepe cu',
	NOT_MORE_THAN: 'Nu este mai mult ca',
	NOT_LESS_THAN: 'Nu este mai mic ca',
	NOT_BETWEEN: 'Nu este intre',
	NOT_EMPTY: 'Nu este gol',

	SEARCH_FOR: 'Cauta dupa',

	ERROR_MISSING_FILE_NAME: 'Numele fisierului nu a fost furnizat',
	ERROR_ACCEPT_FILE_TYPES: 'Tipul fisierului nu este admis',
	ERROR_MAX_FILE_SIZE: 'Dimensiunea fisierului depaseste limita de %s kB',
	ERROR_MIN_FILE_SIZE: 'Dimensiunea fisierului trebuie sa fie de minim %s kB',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Dimensiunea totala a fisierelor depaseste limita de %s kB',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Poti incarca doar un singur fisier',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'Nu poti incarca mai mult de %s fisiere',

	TEXT_SERVER_ERROR_OCCURRED: 'A aparut o eroare de server',
	TEXT_SEE_DETAILS: 'Vezi detalii',

	ERROR_UPLOAD: 'Incarcarea a esuat',
	START_UPLOAD: 'Incarca',
	CANCEL: 'Anuleaza',
	DELETE: 'Sterge',

	UPLOAD_DRAG: 'Trage fisierele aici',

	SELECT_ALL: 'Selecteaza tot',
	UNSELECT_ALL: 'Deselecteaza tot',

	TEXT_WR_REPORT_SAVED: 'Raport Salvat',
	TEXT_WR_SOME_PROBLEM: 'Apar unele probleme in timpul procesului de salvare',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_WR_HEADER: 'Header',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_COUNT: 'Pozitii',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Max',
	TEXT_SUM: 'Suma',
	TEXT_AVG: 'Medie',
	TEXT_WR_TOTAL_DATA: 'Date tabel',
	TEXT_PAGE_SUMMARY: 'Sumar pagina',
	TEXT_GLOBAL_SUMMARY: 'Sumar global',
	TEXT_WR_SUMMARY: 'Rezumat',
	TEXT_FIELD: 'Camp',
	TEXT_WR_NO_COLOR: 'Nicio culoare',

	TEXT_SEARCH_SAVING: 'Se salveaza cautarea',
	TEXT_SEARCH_NAME: 'Nume cautare:',
	TEXT_DELETE_SEARCH_CAPTION: 'Sterge cautarea salvata',
	TEXT_DELETE_SEARCH: 'Sigur doresti sa stergi aceasta cautare?',
	TEXT_YES: 'Da',
	TEXT_NO: 'Nu',

	TEXT_FILTER_APPLY: 'Aplica',
	TEXT_FILTER_CLEAR: 'Sterge',
	TEXT_FILTER_MULTISELECT: 'Selectie multipla',

	// for rights page
	AA_ADD_NEW_GROUP: 'Adauga grup nou',
	AA_RENAMEGROUP: 'Redenumeste grup',
	AA_GROUP_NEW: 'grupnou',
	AA_DELETEGROUP: 'Confirmati stergerea grupului?',
	AA_COPY_PERMISS_FROM: 'Selecteaza grupul de unde sa copiezi permisiunile:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Alege coloanele de afisat',
	AA_SELECT_NONE: 'Selecteaza nimic',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Pregatire pagina pentru printare',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Procesare inregistrari',
	IMPORT_FAILED: 'Import nereusit',

	LOADING_FONTS: 'Se încarcă fonturi',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Alege luna',
	DATEPICKER_NEXT_MONTH: 'Luna viitoare',
	DATEPICKER_PREV_MONTH: 'Luna trecută',
	DATEPICKER_SELECT_YEAR: 'Selectați Anul',
	DATEPICKER_NEXT_YEAR: 'Anul urmator',
	DATEPICKER_PREV_YEAR: 'Anul urmator',

	TODAY: 'azi',
	TIME: 'Timp',
	TIME_HOUR: 'Ora',
	TIME_MINUTE: 'Minut',
	SELECT_DATE: 'Selecteaza data',

	SESSION_EXPIRED_COMMENT: 'Din motive de securitate, sesiunea dvs. va dura în %seconds% de secunde dacă nu continuați',

	NOW: 'acum',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'ore',
	NOTI_DAY: 'zile',

	
	EXPORT_TO_PDF: 'Export ca PDF',
	EXPORT_TO_CSV: 'Exportați la CSV',
	SAVE_AS_PNG: 'Salvați ca PNG',
	PRINT: 'Tipareste',

	TWOFACTOR_VERIFICATION: 'Verificare cu doi factori',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Adresa de email', 
	TWO_FACTOR_PARAM_PHONE: 'Numar de telefon', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};