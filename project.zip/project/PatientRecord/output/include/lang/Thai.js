Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Thai",

//	for list page
	TEXT_FIRST: 'รายการแรก',
	TEXT_PREVIOUS: 'ก่อนหน้า',
	TEXT_NEXT: 'ถัดไป',
	TEXT_LAST: 'รายการสุดท้าย',
	TEXT_PROCEED_TO: 'Proceed to',
	TEXT_DETAIL_NOT_SAVED: 'Records in %s haven\'t been saved',
	TEXT_NO_RECORDS: 'ไม่พบรายการ',
	TEXT_DETAIL_GOTO: 'Go to',
	TEXT_SHOW_ALL: 'แสดงทั้งหมด',
	TEXT_SHOW_OPTIONS: 'Show options',
	TEXT_HIDE_OPTIONS: 'Hide options',
	TEXT_SEARCH_SHOW_OPTIONS:'Show search options',
	TEXT_SEARCH_HIDE_OPTIONS:'Hide search options',
	TEXT_SHOW_SEARCH_PANEL:'Show search panel',
	TEXT_HIDE_SEARCH_PANEL:'Hide search panel',


	TEXT_LOADING: 'loading',
	TEXT_DELETE_CONFIRM: 'คุณต้องการลบรายการนี้จริงๆ หรือไม่',
	TEXT_PAGE: 'หน้า',
	TEXT_PAGEMAX: 'ของ',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'รหัสความปลอดภัยไม่ถูกต้อง',
	TEXT_PLEASE_SELECT: 'กรุณาเลือก',
	TEXT_CTRL_CLICK: 'CTRL + click for multiple sorting',
	TEXT_SAVE: 'บันทึก',
	TEXT_CANCEL: 'ยกเลิก',
	TEXT_PREVIEW: 'preview',
	TEXT_HIDE: 'hide',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Do you want to navigate away from this page and lose unsaved changes?',

	TEXT_EDIT: 'แก้ไข',
	TEXT_COPY: 'คัดลอก',
	TEXT_VIEW: 'ดู',
	TEXT_INLINE_EDIT: 'แก้ไข',
	TEXT_INLINE_ADD: 'เพิ่มใหม่',
	TEXT_AA_P_ADD: 'เพิ่ม',

	TEXT_FIELDFILTER_HINT: 'กรอง',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'ส่งอีเมลพร้อมรหัสรักษาความปลอดภัยที่ถูกส่งไป %email%',
	USERINFO_ENTER_CODE: 'ใส่รหัสที่ด้านล่าง',
	USERINFO_SENT_TEXT: 'ข้อความข้อความที่มีรหัสรักษาความปลอดภัยที่ถูกส่งไป %phone%',
	USERINFO_INSTALL_APP1: 'ติดตั้งแอปการตรวจสอบเช่น Google Authenticator ให้ Authy ไมโครซอฟท์ Authenticator หรือคล้ายกันในโทรศัพท์ของคุณ',
	USERINFO_INSTALL_APP2: 'แล้วสแกนรหัส QR ด้านล่างกับ app',
	USERINFO_INSTALL_APP3: 'หรือสร้างสถิติใหม่ในการตรวจสอบด้วยตนเองโดยใช้คีย์นี้:',
	USERINFO_INSTALL_APP4: 'จากนั้นใส่รหัสจากการตรวจสอบดังต่อไปนี้',

//	for calendar
	TEXT_MONTH_JAN: 'มกราคม',
	TEXT_MONTH_FEB: 'กุมภาพันธ์',
	TEXT_MONTH_MAR: 'มีนาคม',
	TEXT_MONTH_APR: 'เมษายน',
	TEXT_MONTH_MAY: 'พฤษภาคม',
	TEXT_MONTH_JUN: 'มิถุนายน',
	TEXT_MONTH_JUL: 'กรกฎาคม',
	TEXT_MONTH_AUG: 'สิงหาคม',
	TEXT_MONTH_SEP: 'กันยายน',
	TEXT_MONTH_OCT: 'ตุลาคม',
	TEXT_MONTH_NOV: 'พฤศจิกายน',
	TEXT_MONTH_DEC: 'ธันวาคม',
	TEXT_DAY_SU: 'อ',
	TEXT_DAY_MO: 'จ',
	TEXT_DAY_TU: 'อัง',
	TEXT_DAY_WE: 'พ',
	TEXT_DAY_TH: 'พฤ',
	TEXT_DAY_FR: 'ศ',
	TEXT_DAY_SA: 'ส',
	TEXT_TODAY: 'today',
	TEXT_SELECT_DATE: 'Select Date',
	TEXT_TIME: 'Time',
	TEXT_TIME_HOUR: 'Hour',
	TEXT_TIME_MINUTE: 'Minute',
	TEXT_TIME_SECOND: 'Second',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'ฟิลด์ที่ต้องกรอก',
	TEXT_INLINE_FIELD_ZIPCODE: 'ฟิลด์ต้องเป็นรหัสไปรษณีย์',
	TEXT_INLINE_FIELD_EMAIL: 'ฟิลด์ต้องเป็นอีเมลที่ถูกต้อง',
	TEXT_INLINE_FIELD_NUMBER: 'ฟิลด์ต้องเป็นหมายเลข',
	TEXT_INLINE_FIELD_CURRENCY: 'ฟิลด์ต้องเป็นเงินตรา',
	TEXT_INLINE_FIELD_PHONE: 'ฟิลด์ต้องเป็นหมายเลขโทรศัพท์',
	TEXT_INLINE_FIELD_PASSWORD1: 'ฟิลด์ไม่สามารถเป็น \'รหัสผ่าน\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'ฟิลด์ต้องมีความยาวอย่างน้อย 4 อักษร',
	TEXT_INLINE_FIELD_STATE: 'ฟิลด์ต้องเป็นชื่อรัฐ',
	TEXT_INLINE_FIELD_SSN: 'ฟิลด์ต้องเป็นหมายเลขประกันสังคม',
	TEXT_INLINE_FIELD_DATE: 'ฟิลด์ต้องเป็นวันที่ที่ถูกต้อง',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'ฟิลด์ต้องเป็นรูปแบบเวลา 24 ชั่วโมง',
	TEXT_INLINE_FIELD_CC: 'ฟิลด์ต้องมีหมายเลขบัตรเครดิตที่ถูกต้อง',
	TEXT_INLINE_ERROR: 'ข้อผิดพลาดที่เกิดขึ้น',
	TEXT_INLINE_DENY_DUPLICATES: 'Field should not contain a duplicate value',
	TEXT_INLINE_USERNAME_EXISTS1: 'ชื่อผู้ใช้',
	TEXT_INLINE_USERNAME_EXISTS2: 'มีอยู่แล้ว เลือกชื่อผู้ใช้อื่น',
	TEXT_INLINE_EMAIL_ALREADY1: 'อีเมล',
	TEXT_INLINE_EMAIL_ALREADY2: 'ได้ลงทะเบียนแล้ว หากท่านลืมชื่อผู้ใช้หรือรหัสผ่านของท่าน ให้ใช้แบบฟอร์มเตือนความจำรหัสผ่าน',

	//for RTE
	TEXT_VIEW_SOURCE: 'ดูแหล่ง',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'expand all',
	TEXT_COLLAPSE_ALL: 'collapse all',

	//for register page
	SEC_PWD_LEN: 'รหัสผ่านต้องมีความยาวอย่างน้อย%%ตัวอักษร',
	SEC_PWD_CASE: 'รหัสผ่านต้องประกอบด้วยตัวพิมพ์ใหญ่และตัวพิมพ์เล็ก',
	SEC_PWD_DIGIT: 'รหัสผ่านต้องประกอบด้วยหมายเลขหรือสัญลักษณ์%%ตัว',
	SEC_PWD_UNIQUE: 'รหัสผ่านต้องประกอบด้วยอักขระพิเศษ%%ตัว',
	PASSWORDS_DONT_MATCH: 'รหัสผ่านไม่สัมพันธ์กัน',
	SUCCES_LOGGED_IN: 'You have successfully logged in.',

	//for pdf
	TEXT_PDF_BUILD1: 'Building PDF',
	TEXT_PDF_BUILD2: 'done',
	TEXT_PDF_BUILD3: 'Could not create PDF',

	CLOSE_WINDOW: 'ปิดหน้าต่าง',
	CLOSE: 'Close',
	RESET: 'ตั้งค่าใหม่',

	//for search options
	CONTAINS: 'ประกอบด้วย',
	EQUALS: 'เท่ากับ',
	STARTS_WITH: 'เริ่มด้วย',
	MORE_THAN: 'มากกว่า',
	LESS_THAN: 'น้อยกว่า',
	BETWEEN: 'ระหว่าง',
	EMPTY: 'ว่าง',

	NOT_CONTAINS: 'Doesn\'t contain',
	NOT_EQUALS: 'Doesn\'t equal',
	NOT_STARTS_WITH: 'Doesn\'t start with',
	NOT_MORE_THAN: 'Is not more than',
	NOT_LESS_THAN: 'Is not less than',
	NOT_BETWEEN: 'Is not between',
	NOT_EMPTY: 'Is not empty',

	SEARCH_FOR: 'ค้นหา',

	ERROR_MISSING_FILE_NAME: 'File name was not provided',
	ERROR_ACCEPT_FILE_TYPES: 'File type is not acceptable',
	ERROR_MAX_FILE_SIZE: 'File size exceeds limit of %s kbytes',
	ERROR_MIN_FILE_SIZE: 'File size must not be less than %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Total files size exceeds limit of %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'You can upload only one file',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'You can upload no more than %s files',

	TEXT_SERVER_ERROR_OCCURRED: 'Server error occurred',
	TEXT_SEE_DETAILS: 'See details',

	ERROR_UPLOAD: 'Uploading failed',
	START_UPLOAD: 'Upload',
	CANCEL: 'ยกเลิก',
	DELETE: 'ลบ',

	UPLOAD_DRAG: 'Drag files here',

	SELECT_ALL: 'Select all',
	UNSELECT_ALL: 'Unselect all',

	TEXT_WR_REPORT_SAVED: 'Report Saved',
	TEXT_WR_SOME_PROBLEM: 'Some problems appear during saving',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_WR_HEADER: 'Header',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_COUNT: 'นับ',
	TEXT_MIN: 'น้อยที่สุด',
	TEXT_MAX: 'มากที่สุด',
	TEXT_SUM: 'ยอด',
	TEXT_AVG: 'Avg',
	TEXT_WR_TOTAL_DATA: 'Table Data',
	TEXT_PAGE_SUMMARY: 'สรุปหน้า',
	TEXT_GLOBAL_SUMMARY: 'สรุปทั้งหมด',
	TEXT_WR_SUMMARY: 'Summary',
	TEXT_FIELD: 'Field',
	TEXT_WR_NO_COLOR: 'No color',

	TEXT_SEARCH_SAVING: 'Search saving',
	TEXT_SEARCH_NAME: 'Search name:',
	TEXT_DELETE_SEARCH_CAPTION: 'Delete saved search',
	TEXT_DELETE_SEARCH: 'Do you really want to delete this search?',
	TEXT_YES: 'ใช่',
	TEXT_NO: 'ไม่',

	TEXT_FILTER_APPLY: 'Apply',
	TEXT_FILTER_CLEAR: 'Clear',
	TEXT_FILTER_MULTISELECT: 'Multiselect',

	// for rights page
	AA_ADD_NEW_GROUP: 'เพิ่มกลุ่มใหม่',
	AA_RENAMEGROUP: 'เปลี่ยนชื่อกลุ่มใหม่',
	AA_GROUP_NEW: 'newgroup',
	AA_DELETEGROUP: 'Do you really want to delete group',
	AA_COPY_PERMISS_FROM: 'Choose the group to copy permissions from:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Choose columns to display',
	AA_SELECT_NONE: 'Select none',
	AA_OK: 'ตกลง',

	PREPARE_PAGE_FOR_PRINTING: 'Preparing page for printing',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processing records',
	IMPORT_FAILED: 'Import Failed',

	LOADING_FONTS: 'แบบอักษรกำลังโหลด',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'เลือกเดือน',
	DATEPICKER_NEXT_MONTH: 'เดือนหน้า',
	DATEPICKER_PREV_MONTH: 'เดือนที่แล้ว',
	DATEPICKER_SELECT_YEAR: 'เลือกปี',
	DATEPICKER_NEXT_YEAR: 'ปีหน้า',
	DATEPICKER_PREV_YEAR: 'ปีหน้า',

	TODAY: 'today',
	TIME: 'Time',
	TIME_HOUR: 'Hour',
	TIME_MINUTE: 'Minute',
	SELECT_DATE: 'Select Date',

	SESSION_EXPIRED_COMMENT: 'เพื่อเหตุผลด้านความปลอดภัยเซสชั่นของคุณจะหมดเวลาใน %seconds% วินาทีเว้นแต่คุณจะดำเนินการต่อ',

	NOW: 'ตอนนี้',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'นาที',
	NOTI_HOUR: 'ชั่วโมง',
	NOTI_DAY: 'วัน',

	
	EXPORT_TO_PDF: 'Export to PDF',
	EXPORT_TO_CSV: 'ส่งออกไปยัง CSV',
	SAVE_AS_PNG: 'บันทึกเป็น PNG',
	PRINT: 'Print',

	TWOFACTOR_VERIFICATION: 'การตรวจสอบสองปัจจัย',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'ที่อยู่อีเมล', 
	TWO_FACTOR_PARAM_PHONE: 'หมายเลขโทรศัพท์', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};