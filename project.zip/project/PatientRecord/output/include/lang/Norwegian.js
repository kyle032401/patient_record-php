Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Norwegian(Bokmal)",

//	for list page
	TEXT_FIRST: 'Første',
	TEXT_PREVIOUS: 'Forrige',
	TEXT_NEXT: 'Neste',
	TEXT_LAST: 'Siste',
	TEXT_PROCEED_TO: 'Fortsett til',
	TEXT_DETAIL_NOT_SAVED: 'Poster i %s er ikke lagret',
	TEXT_NO_RECORDS: 'Fant ingen poster',
	TEXT_DETAIL_GOTO: 'Gå til',
	TEXT_SHOW_ALL: 'Vis alle',
	TEXT_SHOW_OPTIONS: 'Vis valg',
	TEXT_HIDE_OPTIONS: 'Skjul valg',
	TEXT_SEARCH_SHOW_OPTIONS:'Vis søke valg',
	TEXT_SEARCH_HIDE_OPTIONS:'Skjul søke valg',
	TEXT_SHOW_SEARCH_PANEL:'Vis søkepanelet',
	TEXT_HIDE_SEARCH_PANEL:'Skjul søkepanelet',


	TEXT_LOADING: 'laster',
	TEXT_DELETE_CONFIRM: 'Bekreft at du vil slette disse postene',
	TEXT_PAGE: 'Side',
	TEXT_PAGEMAX: 'av',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Ugyldig sikkerhetskode.',
	TEXT_PLEASE_SELECT: 'Venligst velg',
	TEXT_CTRL_CLICK: 'CTRL + klikk for å sortere med flere kolonner',
	TEXT_SAVE: 'Lagre',
	TEXT_CANCEL: 'Avbryt',
	TEXT_PREVIEW: 'forhåndsvisning',
	TEXT_HIDE: 'skjul',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Ønsker du å forlate denne siden uten å lagre endringer?',

	TEXT_EDIT: 'Rediger',
	TEXT_COPY: 'Kopi',
	TEXT_VIEW: 'Vis',
	TEXT_INLINE_EDIT: 'Rediger linje',
	TEXT_INLINE_ADD: 'Ny linje',
	TEXT_AA_P_ADD: 'Legg til',

	TEXT_FIELDFILTER_HINT: 'Filtrere feltverdier',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'En e-post med sikkerhetskoden ble sendt til %email%.',
	USERINFO_ENTER_CODE: 'Tast inn koden under.',
	USERINFO_SENT_TEXT: 'En tekstmelding med sikkerhetskoden ble sendt til %phone%.',
	USERINFO_INSTALL_APP1: 'Installer en godkjenningsapp som Google Authenticator, Authy, Microsoft Autentisering eller lignende på telefonen.',
	USERINFO_INSTALL_APP2: 'Deretter skanne QR-koden nedenfor med programmet.',
	USERINFO_INSTALL_APP3: 'Eller opprette en ny data i app manuelt med denne nøkkelen:',
	USERINFO_INSTALL_APP4: 'Deretter skriver du inn koden fra app nedenfor.',

//	for calendar
	TEXT_MONTH_JAN: 'Januar',
	TEXT_MONTH_FEB: 'Februar',
	TEXT_MONTH_MAR: 'Mars',
	TEXT_MONTH_APR: 'April',
	TEXT_MONTH_MAY: 'Mai',
	TEXT_MONTH_JUN: 'Juni',
	TEXT_MONTH_JUL: 'Juli',
	TEXT_MONTH_AUG: 'August',
	TEXT_MONTH_SEP: 'September',
	TEXT_MONTH_OCT: 'Oktober',
	TEXT_MONTH_NOV: 'November',
	TEXT_MONTH_DEC: 'Desember',
	TEXT_DAY_SU: 'Sø',
	TEXT_DAY_MO: 'Ma',
	TEXT_DAY_TU: 'Ti',
	TEXT_DAY_WE: 'On',
	TEXT_DAY_TH: 'To',
	TEXT_DAY_FR: 'Fr',
	TEXT_DAY_SA: 'Lø',
	TEXT_TODAY: 'i dag',
	TEXT_SELECT_DATE: 'Velg dato',
	TEXT_TIME: 'Tid',
	TEXT_TIME_HOUR: 'Time',
	TEXT_TIME_MINUTE: 'Minutt',
	TEXT_TIME_SECOND: 'Sekund',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Påkrevd felt',
	TEXT_INLINE_FIELD_ZIPCODE: 'Feltet må inneholde et gyldig postnummer',
	TEXT_INLINE_FIELD_EMAIL: 'Feltet må inneholde en gyldig e-post adresse',
	TEXT_INLINE_FIELD_NUMBER: 'Feltet må inneholde et gyldig nummer',
	TEXT_INLINE_FIELD_CURRENCY: 'Feltet må inneholde gyldig valuta format',
	TEXT_INLINE_FIELD_PHONE: 'Feltet må inneholde et gyldig telefonnummer',
	TEXT_INLINE_FIELD_PASSWORD1: 'Feltet kan ikke være \'passord\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Feltet må være minst 4 tegn langt',
	TEXT_INLINE_FIELD_STATE: 'Feltet må inneholde navn på en stat i USA',
	TEXT_INLINE_FIELD_SSN: 'Feltet må inneholde gyldig personnummer',
	TEXT_INLINE_FIELD_DATE: 'Feltet må inneholde gyldig dato format',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Feltet må inneholde tid i 24-timersformatet',
	TEXT_INLINE_FIELD_CC: 'Feltet må inneholde et gyldig kredittkortnummer',
	TEXT_INLINE_ERROR: 'En feil oppstod',
	TEXT_INLINE_DENY_DUPLICATES: 'Feltet bør ikke inneholde duplikate verdier',
	TEXT_INLINE_USERNAME_EXISTS1: 'Brukernavnet',
	TEXT_INLINE_USERNAME_EXISTS2: 'finnes fra før. Vennligst velg et annet brukernavn.',
	TEXT_INLINE_EMAIL_ALREADY1: 'E-post',
	TEXT_INLINE_EMAIL_ALREADY2: 'er allerede registert. Dersom du har glemt brukernavn og passord, gå til vinduet for å få tilsendt passordet.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Vis kilde',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'utvid alle',
	TEXT_COLLAPSE_ALL: 'skjul alle',

	//for register page
	SEC_PWD_LEN: 'Passordet må minst inneholde %% tegn.',
	SEC_PWD_CASE: 'Passordet må inneholde både store og små bokstaver.',
	SEC_PWD_DIGIT: 'Passordet må inneholde %% tall eller bokstaver/tegn.',
	SEC_PWD_UNIQUE: 'Passordet må inneholde minst %% unike tegn.',
	PASSWORDS_DONT_MATCH: 'Passordene du oppga var ikke like',
	SUCCES_LOGGED_IN: 'Du har logget deg på.',

	//for pdf
	TEXT_PDF_BUILD1: 'Bygger PDF-fil',
	TEXT_PDF_BUILD2: 'ferdig',
	TEXT_PDF_BUILD3: 'Kunne ikke opprette PDF',

	CLOSE_WINDOW: 'Lukk vindu',
	CLOSE: 'Lukk',
	RESET: 'Tilbakestill',

	//for search options
	CONTAINS: 'Inneholder',
	EQUALS: 'Er lik',
	STARTS_WITH: 'Begynner med',
	MORE_THAN: 'Større enn …',
	LESS_THAN: 'Mindre enn',
	BETWEEN: 'Mellom',
	EMPTY: 'Tom',

	NOT_CONTAINS: 'Inneholder ikke',
	NOT_EQUALS: 'Er ikke lik',
	NOT_STARTS_WITH: 'Begynner ikke med',
	NOT_MORE_THAN: 'Er ikke større enn',
	NOT_LESS_THAN: 'Er ikke mindre enn',
	NOT_BETWEEN: 'Er ikke mellom',
	NOT_EMPTY: 'Er ikke tom',

	SEARCH_FOR: 'Søk etter',

	ERROR_MISSING_FILE_NAME: 'Filnavnet ble ikke lagt inn',
	ERROR_ACCEPT_FILE_TYPES: 'Filtypen er ikke godkjent',
	ERROR_MAX_FILE_SIZE: 'Filstørrelsen overstiger grensen på %s kbytes',
	ERROR_MIN_FILE_SIZE: 'Filstørrelsen må ikke være mindre enn %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Total filstørrelse overstiger totalt grense på %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Du kan kun laste opp kun én fil',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'Du kan ikke laste opp mer enn %s filer',

	TEXT_SERVER_ERROR_OCCURRED: 'Serverfeil oppstod',
	TEXT_SEE_DETAILS: 'Se detaljer',

	ERROR_UPLOAD: 'Opplastning feilet',
	START_UPLOAD: 'Last opp',
	CANCEL: 'Avbryt',
	DELETE: 'Slett',

	UPLOAD_DRAG: 'Dra filer hit',

	SELECT_ALL: 'Velg alle',
	UNSELECT_ALL: 'Velg bort alle',

	TEXT_WR_REPORT_SAVED: 'Rapport lagret',
	TEXT_WR_SOME_PROBLEM: 'Noen problemer oppstod under lagring',
	TEXT_WR_CROSS_GROUP: 'Gruppe',
	TEXT_WR_HEADER: 'Overskrift',
	TEXT_WR_CROSS_GROUP: 'Gruppe',
	TEXT_COUNT: 'Antall',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Maks',
	TEXT_SUM: 'Sum',
	TEXT_AVG: 'Snitt',
	TEXT_WR_TOTAL_DATA: 'Tabelldata',
	TEXT_PAGE_SUMMARY: 'Oppsummeringsside',
	TEXT_GLOBAL_SUMMARY: 'Global oppsummering',
	TEXT_WR_SUMMARY: 'Sammendrag',
	TEXT_FIELD: 'Felt',
	TEXT_WR_NO_COLOR: 'Ingen farge',

	TEXT_SEARCH_SAVING: 'Lagre søk',
	TEXT_SEARCH_NAME: 'Søk navn:',
	TEXT_DELETE_SEARCH_CAPTION: 'Slett lagrede søk',
	TEXT_DELETE_SEARCH: 'Ønsker du å slette dette søket?',
	TEXT_YES: 'Ja',
	TEXT_NO: 'Nei',

	TEXT_FILTER_APPLY: 'Søk',
	TEXT_FILTER_CLEAR: 'Rens',
	TEXT_FILTER_MULTISELECT: 'Flervalg',

	// for rights page
	AA_ADD_NEW_GROUP: 'Legg til ny gruppe',
	AA_RENAMEGROUP: 'Endre gruppenavn',
	AA_GROUP_NEW: 'ny gruppe',
	AA_DELETEGROUP: 'Vil du virkelig slette gruppen ',
	AA_COPY_PERMISS_FROM: 'Velg gruppe å kopiere rettigheter fra:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Velg kolonner til visning',
	AA_SELECT_NONE: 'Velg ingen',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Forbered side for utskrift',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Behandler poster',
	IMPORT_FAILED: 'Import feilet',

	LOADING_FONTS: 'Laste inn skrifter',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Velg måned',
	DATEPICKER_NEXT_MONTH: 'Neste måned',
	DATEPICKER_PREV_MONTH: 'Forrige måned',
	DATEPICKER_SELECT_YEAR: 'Velg år',
	DATEPICKER_NEXT_YEAR: 'Neste år',
	DATEPICKER_PREV_YEAR: 'Neste år',

	TODAY: 'i dag',
	TIME: 'Tid',
	TIME_HOUR: 'Time',
	TIME_MINUTE: 'Minutt',
	SELECT_DATE: 'Velg dato',

	SESSION_EXPIRED_COMMENT: 'Av sikkerhetsgrunner vil økten din utløpe om %seconds% sekunder, med mindre du fortsetter',

	NOW: 'nå',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'timer',
	NOTI_DAY: 'd',

	
	EXPORT_TO_PDF: 'Eksporter til PDF',
	EXPORT_TO_CSV: 'Ekporter data som CSV',
	SAVE_AS_PNG: 'Lagre som PNG',
	PRINT: 'Skriv ut',

	TWOFACTOR_VERIFICATION: 'To-faktorverifisering',
	EMAIL: 'E-post',
	TWO_FACTOR_PARAM_EMAIL: 'E-postadresse', 
	TWO_FACTOR_PARAM_PHONE: 'Telefonnummer', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};