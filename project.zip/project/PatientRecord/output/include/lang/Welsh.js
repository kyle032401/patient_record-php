Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Welsh",

//	for list page
	TEXT_FIRST: 'Cyntaf',
	TEXT_PREVIOUS: 'Blaenorol',
	TEXT_NEXT: 'Nesaf',
	TEXT_LAST: 'Olaf',
	TEXT_PROCEED_TO: 'Ymlaen i',
	TEXT_DETAIL_NOT_SAVED: 'Ni arbedwyd y cofnodion',
	TEXT_NO_RECORDS: 'Ni ddaethpwyd o hyd i unrhyw gofnod',
	TEXT_DETAIL_GOTO: 'Mynd i',
	TEXT_SHOW_ALL: 'Dangos pob un',
	TEXT_SHOW_OPTIONS: 'Dangos dewisiadau',
	TEXT_HIDE_OPTIONS: 'Cuddio dewisiadau',
	TEXT_SEARCH_SHOW_OPTIONS:'Dangos dewisiadau chwilio',
	TEXT_SEARCH_HIDE_OPTIONS:'Cuddio dewisiadau chwilio',
	TEXT_SHOW_SEARCH_PANEL:'Show search panel',
	TEXT_HIDE_SEARCH_PANEL:'Hide search panel',


	TEXT_LOADING: 'llwytho',
	TEXT_DELETE_CONFIRM: 'Ydych chi eisiau dileu\'r cofnodion hyn?',
	TEXT_PAGE: 'Tudalen',
	TEXT_PAGEMAX: 'o',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Cod diogelwch annilys.',
	TEXT_PLEASE_SELECT: 'Dewiswch',
	TEXT_CTRL_CLICK: 'CTRL + clic i sortio amryw',
	TEXT_SAVE: 'Arbed',
	TEXT_CANCEL: 'Canslo',
	TEXT_PREVIEW: 'cipolwg',
	TEXT_HIDE: 'cuddio',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Do you want to navigate away from this page and lose unsaved changes?',

	TEXT_EDIT: 'Golygu',
	TEXT_COPY: 'Copi',
	TEXT_VIEW: 'Gweld',
	TEXT_INLINE_EDIT: 'Golygu sylw',
	TEXT_INLINE_ADD: 'Ychwanegu sylw',
	TEXT_AA_P_ADD: 'Ychwanegu',

	TEXT_FIELDFILTER_HINT: 'Hidlech',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'E-bost gyda y cod diogelwch ei anfon i %email%.',
	USERINFO_ENTER_CODE: 'Rhowch y cod isod.',
	USERINFO_SENT_TEXT: 'Neges testun gyda y cod diogelwch ei anfon i %phone%.',
	USERINFO_INSTALL_APP1: 'Gosod app dilysu fel Google Authenticator, Authy, Microsoft Authenticator neu debyg ar eich ffôn.',
	USERINFO_INSTALL_APP2: 'Yna sganiwch y cod QR isod gyda\'r app.',
	USERINFO_INSTALL_APP3: 'Neu greu record newydd yn y app llaw gan ddefnyddio\'r allwedd hon:',
	USERINFO_INSTALL_APP4: 'Yna nodwch y cod o\'r app isod.',

//	for calendar
	TEXT_MONTH_JAN: 'Ionawr',
	TEXT_MONTH_FEB: 'Chwefror',
	TEXT_MONTH_MAR: 'Mawrth',
	TEXT_MONTH_APR: 'Ebrill',
	TEXT_MONTH_MAY: 'Mai',
	TEXT_MONTH_JUN: 'Mehefin',
	TEXT_MONTH_JUL: 'Gorffennaf',
	TEXT_MONTH_AUG: 'Awst',
	TEXT_MONTH_SEP: 'Medi',
	TEXT_MONTH_OCT: 'Hydref',
	TEXT_MONTH_NOV: 'Tachwedd',
	TEXT_MONTH_DEC: 'Rhagfyr',
	TEXT_DAY_SU: 'Su',
	TEXT_DAY_MO: 'Ll',
	TEXT_DAY_TU: 'Maw',
	TEXT_DAY_WE: 'Me',
	TEXT_DAY_TH: 'Iau',
	TEXT_DAY_FR: 'Gw',
	TEXT_DAY_SA: 'Sa',
	TEXT_TODAY: 'heddiw',
	TEXT_SELECT_DATE: 'Dewiswch ddyddiad',
	TEXT_TIME: 'Time',
	TEXT_TIME_HOUR: 'Hour',
	TEXT_TIME_MINUTE: 'Minute',
	TEXT_TIME_SECOND: 'Second',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Maes gofynnol',
	TEXT_INLINE_FIELD_ZIPCODE: 'Dylai\'r maes fod yn god post dilys',
	TEXT_INLINE_FIELD_EMAIL: 'Dylai\'r maes fod yn gyfeiriad e-bost dilys',
	TEXT_INLINE_FIELD_NUMBER: 'Dylai\'r maes fod yn rif dilys',
	TEXT_INLINE_FIELD_CURRENCY: 'Dylai\'r maes fod yn arian dilys',
	TEXT_INLINE_FIELD_PHONE: 'Dylai\'r maes fod yn rif ffôn dilys',
	TEXT_INLINE_FIELD_PASSWORD1: 'Nid \'cyfrinair\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Dylai\'r maes fod yn o leiaf 4 llythyren o hyd',
	TEXT_INLINE_FIELD_STATE: 'Dylai\'r maes fod yn enw talaith dilys',
	TEXT_INLINE_FIELD_SSN: 'Dylai\'r maes fod yn rif nawdd cymdeithasol dilys',
	TEXT_INLINE_FIELD_DATE: 'Dylai\'r maes fod yn ddyddiad dilys',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Dylai\'r maes fod yn amser dilys mewn fformat 24 awr',
	TEXT_INLINE_FIELD_CC: 'Dylai\'r maes fod yn rif cerdyn credyd dilys',
	TEXT_INLINE_ERROR: 'Gwall',
	TEXT_INLINE_DENY_DUPLICATES: 'Field should not contain a duplicate value',
	TEXT_INLINE_USERNAME_EXISTS1: 'Enw defnyddiwr',
	TEXT_INLINE_USERNAME_EXISTS2: 'eisoes yn bodoli. Defnyddiwr enw defnyddiwr arall.',
	TEXT_INLINE_EMAIL_ALREADY1: 'E-bost',
	TEXT_INLINE_EMAIL_ALREADY2: 'eisoes wedi cofrestru. Os ydych wedi anghofio eich enw defnyddiwr neu gyfrinair, defnyddiwr y ffurflen atgoffa cyfrinair.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Gweld ffynhonnell',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'ehangu',
	TEXT_COLLAPSE_ALL: 'lleihau',

	//for register page
	SEC_PWD_LEN: 'Mae\'n rhaid i\'r cyfrinair fod yn o leiaf %% llythyren o hyd.',
	SEC_PWD_CASE: 'Mae\'n rhaid i\'r cyfrinair gynnwys llythrennau bychain a llythrennau bras.',
	SEC_PWD_DIGIT: 'Mae\'n rhaid i\'r cyfrinair gynnwys %% digid neu symbol.',
	SEC_PWD_UNIQUE: 'Mae\'n rhaid i\'r cyfrinair gynnwys %% llythyren unigryw.',
	PASSWORDS_DONT_MATCH: 'Nid yw\'r cyfrineiriau yn cyfateb',
	SUCCES_LOGGED_IN: 'You have successfully logged in.',

	//for pdf
	TEXT_PDF_BUILD1: 'Adeiladu PDF',
	TEXT_PDF_BUILD2: 'wedi gorffen',
	TEXT_PDF_BUILD3: 'Could not create PDF',

	CLOSE_WINDOW: 'Cau ffenestr',
	CLOSE: 'Close',
	RESET: 'Ailosod',

	//for search options
	CONTAINS: 'Yn cynnwys',
	EQUALS: 'Yn hafal i',
	STARTS_WITH: 'Yn dechrau gyda',
	MORE_THAN: 'Mwy na',
	LESS_THAN: 'Llai na',
	BETWEEN: 'rhwng',
	EMPTY: 'Gwag',

	NOT_CONTAINS: 'Ddim yn cynnwys',
	NOT_EQUALS: 'Ddim yn hafal i',
	NOT_STARTS_WITH: 'Ddim yn dechrau gyda',
	NOT_MORE_THAN: 'ddim yn fwy na',
	NOT_LESS_THAN: 'ddim yn llai na',
	NOT_BETWEEN: 'ddim rhwng',
	NOT_EMPTY: 'ddim yn wag',

	SEARCH_FOR: 'Chwilio am',

	ERROR_MISSING_FILE_NAME: 'File name was not provided',
	ERROR_ACCEPT_FILE_TYPES: 'File type is not acceptable',
	ERROR_MAX_FILE_SIZE: 'File size exceeds limit of %s kbytes',
	ERROR_MIN_FILE_SIZE: 'File size must not be less than %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Total files size exceeds limit of %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'You can upload only one file',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'You can upload no more than %s files',

	TEXT_SERVER_ERROR_OCCURRED: 'Server error occurred',
	TEXT_SEE_DETAILS: 'See details',

	ERROR_UPLOAD: 'Uploading failed',
	START_UPLOAD: 'Upload',
	CANCEL: 'Canslo',
	DELETE: 'Dileu',

	UPLOAD_DRAG: 'Drag files here',

	SELECT_ALL: 'Select all',
	UNSELECT_ALL: 'Unselect all',

	TEXT_WR_REPORT_SAVED: 'Report Saved',
	TEXT_WR_SOME_PROBLEM: 'Some problems appear during saving',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_WR_HEADER: 'Header',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_COUNT: 'Cyfrif',
	TEXT_MIN: 'Isafswm',
	TEXT_MAX: 'Uchafswm',
	TEXT_SUM: 'Swm',
	TEXT_AVG: 'Avg',
	TEXT_WR_TOTAL_DATA: 'Table Data',
	TEXT_PAGE_SUMMARY: 'Crynodeb tudalen',
	TEXT_GLOBAL_SUMMARY: 'Crynodeb eang',
	TEXT_WR_SUMMARY: 'Summary',
	TEXT_FIELD: 'maes',
	TEXT_WR_NO_COLOR: 'No color',

	TEXT_SEARCH_SAVING: 'Search saving',
	TEXT_SEARCH_NAME: 'Search name:',
	TEXT_DELETE_SEARCH_CAPTION: 'Delete saved search',
	TEXT_DELETE_SEARCH: 'Do you really want to delete this search?',
	TEXT_YES: 'Parhau',
	TEXT_NO: 'Canslo',

	TEXT_FILTER_APPLY: 'Apply',
	TEXT_FILTER_CLEAR: 'Clear',
	TEXT_FILTER_MULTISELECT: 'Multiselect',

	// for rights page
	AA_ADD_NEW_GROUP: 'Ychwanegu grŵp newydd',
	AA_RENAMEGROUP: 'Ailenwi grŵp',
	AA_GROUP_NEW: 'grŵp newydd',
	AA_DELETEGROUP: 'Ydych chi eisiau dileu\'r grŵp',
	AA_COPY_PERMISS_FROM: 'Choose the group to copy permissions from:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Choose columns to display',
	AA_SELECT_NONE: 'Select none',
	AA_OK: 'Iawn',

	PREPARE_PAGE_FOR_PRINTING: 'Preparing page for printing',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processing records',
	IMPORT_FAILED: 'Import Failed',

	LOADING_FONTS: 'ffontiau Llwytho',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Dewiswch Mis',
	DATEPICKER_NEXT_MONTH: 'Mis nesaf',
	DATEPICKER_PREV_MONTH: 'Mis blaenorol',
	DATEPICKER_SELECT_YEAR: 'Dewiswch Flwyddyn',
	DATEPICKER_NEXT_YEAR: 'Blwyddyn nesaf',
	DATEPICKER_PREV_YEAR: 'Blwyddyn nesaf',

	TODAY: 'heddiw',
	TIME: 'Time',
	TIME_HOUR: 'Hour',
	TIME_MINUTE: 'Minute',
	SELECT_DATE: 'Dewiswch ddyddiad',

	SESSION_EXPIRED_COMMENT: 'Am resymau diogelwch, bydd eich sesiwn yn amser allan yn %seconds% eiliad oni bai eich bod yn parhau',

	NOW: 'amod',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'awr',
	NOTI_DAY: 'diwrnod',

	
	EXPORT_TO_PDF: 'Export to PDF',
	EXPORT_TO_CSV: 'Allforio i CSV',
	SAVE_AS_PNG: 'Arbed fel PNG',
	PRINT: 'Print',

	TWOFACTOR_VERIFICATION: 'Gwirio dau ffactor',
	EMAIL: 'E-bost',
	TWO_FACTOR_PARAM_EMAIL: 'Cyfeiriad ebost', 
	TWO_FACTOR_PARAM_PHONE: 'Rhif ffôn', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};