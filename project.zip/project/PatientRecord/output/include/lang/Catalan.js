Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Catalan",

//	for list page
	TEXT_FIRST: 'Primer',
	TEXT_PREVIOUS: 'Previ',
	TEXT_NEXT: 'Següent',
	TEXT_LAST: 'Ultim',
	TEXT_PROCEED_TO: 'Anar a',
	TEXT_DETAIL_NOT_SAVED: 'Registres %s no s\'han guardat',
	TEXT_NO_RECORDS: 'No s\'han trobat registres',
	TEXT_DETAIL_GOTO: 'Anar a',
	TEXT_SHOW_ALL: 'Mostrar-los tots',
	TEXT_SHOW_OPTIONS: 'Mostrar opcions',
	TEXT_HIDE_OPTIONS: 'Amagar opcions',
	TEXT_SEARCH_SHOW_OPTIONS:'Mostrar opcions de cerca',
	TEXT_SEARCH_HIDE_OPTIONS:'Amagar opcions de cerca',
	TEXT_SHOW_SEARCH_PANEL:'Mostrar panell de cerca',
	TEXT_HIDE_SEARCH_PANEL:'Amagar panell de cerca',


	TEXT_LOADING: 'carregant',
	TEXT_DELETE_CONFIRM: 'Realment vols esborrar aquests registres?',
	TEXT_PAGE: 'Pagina',
	TEXT_PAGEMAX: 'de',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Codi de seguretat no valid',
	TEXT_PLEASE_SELECT: 'Siusplau seleccioneu',
	TEXT_CTRL_CLICK: 'CTRL + click per a ordenar per multiples camps',
	TEXT_SAVE: 'Guardar',
	TEXT_CANCEL: 'Cancelar',
	TEXT_PREVIEW: 'previsualitzar',
	TEXT_HIDE: 'amagar',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Desitja sortir i perdre els canvis?',

	TEXT_EDIT: 'Editar',
	TEXT_COPY: 'Copiar',
	TEXT_VIEW: 'Veure',
	TEXT_INLINE_EDIT: 'Editar en linia',
	TEXT_INLINE_ADD: 'Afegir en linia',
	TEXT_AA_P_ADD: 'Afegir',

	TEXT_FIELDFILTER_HINT: 'Filtra els valors del camp',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Un correu electrònic amb el codi de seguretat va ser enviat a %email%.',
	USERINFO_ENTER_CODE: 'Introduir aquest codi a continuació.',
	USERINFO_SENT_TEXT: 'Un missatge de text amb el codi de seguretat va ser enviat a %phone%.',
	USERINFO_INSTALL_APP1: 'Instal·lar una aplicació d\'autenticació com Google Authenticator, Authy, Microsoft autenticador o similars al seu telèfon.',
	USERINFO_INSTALL_APP2: 'A continuació, escanejar el codi QR a continuació amb l\'aplicació.',
	USERINFO_INSTALL_APP3: 'O crear un nou registre a l\'aplicació manualment utilitzant aquesta clau:',
	USERINFO_INSTALL_APP4: 'A continuació, introdueixi el codi de l\'aplicació a continuació.',

//	for calendar
	TEXT_MONTH_JAN: 'Gener',
	TEXT_MONTH_FEB: 'Febrer',
	TEXT_MONTH_MAR: 'Març',
	TEXT_MONTH_APR: 'Abril',
	TEXT_MONTH_MAY: 'Maig',
	TEXT_MONTH_JUN: 'Juny',
	TEXT_MONTH_JUL: 'Juliol',
	TEXT_MONTH_AUG: 'Agost',
	TEXT_MONTH_SEP: 'Setembre',
	TEXT_MONTH_OCT: 'Octubre',
	TEXT_MONTH_NOV: 'Novembre',
	TEXT_MONTH_DEC: 'Desembre',
	TEXT_DAY_SU: 'Diu',
	TEXT_DAY_MO: 'Dill',
	TEXT_DAY_TU: 'Dima',
	TEXT_DAY_WE: 'Dime',
	TEXT_DAY_TH: 'Dij',
	TEXT_DAY_FR: 'Div',
	TEXT_DAY_SA: 'Diss',
	TEXT_TODAY: 'Avui',
	TEXT_SELECT_DATE: 'Seleccioneu una data',
	TEXT_TIME: 'Temps',
	TEXT_TIME_HOUR: 'Hora',
	TEXT_TIME_MINUTE: 'Minut',
	TEXT_TIME_SECOND: 'Segon',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Camp requerit',
	TEXT_INLINE_FIELD_ZIPCODE: 'El camp ha de ser un codi postal valid',
	TEXT_INLINE_FIELD_EMAIL: 'El camp ha de ser una adreça de email válida',
	TEXT_INLINE_FIELD_NUMBER: 'El camp ha de ser un numero valid',
	TEXT_INLINE_FIELD_CURRENCY: 'El camp ha de ser un numero valid de moneda',
	TEXT_INLINE_FIELD_PHONE: 'El camp ha de ser un numero de telèfon valid',
	TEXT_INLINE_FIELD_PASSWORD1: 'El camp no pot la contrassenya',
	TEXT_INLINE_FIELD_PASSWORD2: 'El camp pot ser com a máxim de 4 caracters',
	TEXT_INLINE_FIELD_STATE: 'El camp ha de ser un estat valid',
	TEXT_INLINE_FIELD_SSN: 'El camp ha de ser un numero de seguretat social valid',
	TEXT_INLINE_FIELD_DATE: 'El camp ha de ser una data valida',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'El camp ha de ser en format de 24 hores',
	TEXT_INLINE_FIELD_CC: 'El camp ha de ser un numero valid de targeta',
	TEXT_INLINE_ERROR: 'S\'ha produit un error',
	TEXT_INLINE_DENY_DUPLICATES: 'Camp no pot contenir valors duplicats',
	TEXT_INLINE_USERNAME_EXISTS1: 'Usuari',
	TEXT_INLINE_USERNAME_EXISTS2: 'ja existeix. Tria un altre usuari.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email',
	TEXT_INLINE_EMAIL_ALREADY2: 'Ja estas registrat. Si has oblidat el teu nom d\'usuari o contrasenya utilitza el formulari per recordar la contrasenya.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Veure el Codi',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'Expandiu-los tots',
	TEXT_COLLAPSE_ALL: 'Plegueu-los tots',

	//for register page
	SEC_PWD_LEN: 'La contrasenya ha de contenir almenys %% caràcters ',
	SEC_PWD_CASE: 'La contrasenya ha de contenir lletres en majúscules i minúscules',
	SEC_PWD_DIGIT: 'La contrasenya ha de contenir almenys %% dígits o simbols',
	SEC_PWD_UNIQUE: 'La contrasenya ha de contenir %% caràcters únics',
	PASSWORDS_DONT_MATCH: 'Les contrasenyes no coincideixen',
	SUCCES_LOGGED_IN: 'Ha iniciat la sesió correctament a.',

	//for pdf
	TEXT_PDF_BUILD1: 'Construint PDF',
	TEXT_PDF_BUILD2: 'creat',
	TEXT_PDF_BUILD3: 'No s\'ha pogut crear el PDF',

	CLOSE_WINDOW: 'Tancar la finestra',
	CLOSE: 'Tancar',
	RESET: 'Reset',

	//for search options
	CONTAINS: 'Conté',
	EQUALS: 'Iguals',
	STARTS_WITH: 'Comença amb...',
	MORE_THAN: 'Major que',
	LESS_THAN: 'Menor que...',
	BETWEEN: 'Entre',
	EMPTY: 'Buit',

	NOT_CONTAINS: 'No conté',
	NOT_EQUALS: 'No és igual',
	NOT_STARTS_WITH: 'No comença amb',
	NOT_MORE_THAN: 'No és major que',
	NOT_LESS_THAN: 'No és menor que',
	NOT_BETWEEN: 'No esta entre',
	NOT_EMPTY: 'No esta buit',

	SEARCH_FOR: 'Buscar per',

	ERROR_MISSING_FILE_NAME: 'No s\'ha definit nom d\'arxiu',
	ERROR_ACCEPT_FILE_TYPES: 'Tipus de fitxer no vàlid',
	ERROR_MAX_FILE_SIZE: 'Tamany d\'arxiu superior a %s kbytes',
	ERROR_MIN_FILE_SIZE: 'El tamany d\'arxiu no pot ser inferior a %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'El tamany total d\'arxius excedeix %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Sols pot pujar un arxiu',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'No put pujar més de %s arxius',

	TEXT_SERVER_ERROR_OCCURRED: 'Hi ha hagut un error',
	TEXT_SEE_DETAILS: 'Mostrar detalls',

	ERROR_UPLOAD: 'Pujada fallida',
	START_UPLOAD: 'Pujar',
	CANCEL: 'Cancelar',
	DELETE: 'Eliminar',

	UPLOAD_DRAG: 'Arrossegui arxius aquí',

	SELECT_ALL: 'Seleccioni tot',
	UNSELECT_ALL: 'De-seleccioni tot',

	TEXT_WR_REPORT_SAVED: 'Informe guardat',
	TEXT_WR_SOME_PROBLEM: 'Han aparegut problemes en el guardat',
	TEXT_WR_CROSS_GROUP: 'Grup',
	TEXT_WR_HEADER: 'Capçalera',
	TEXT_WR_CROSS_GROUP: 'Grup',
	TEXT_COUNT: 'Compta',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Max',
	TEXT_SUM: 'Sum',
	TEXT_AVG: 'Mitjana',
	TEXT_WR_TOTAL_DATA: 'Data de taula',
	TEXT_PAGE_SUMMARY: 'Pagina de resum',
	TEXT_GLOBAL_SUMMARY: 'Resum global',
	TEXT_WR_SUMMARY: 'Resum',
	TEXT_FIELD: 'Camp',
	TEXT_WR_NO_COLOR: 'Sense color',

	TEXT_SEARCH_SAVING: 'Guardar cerca',
	TEXT_SEARCH_NAME: 'Cerca nom:',
	TEXT_DELETE_SEARCH_CAPTION: 'Eliminar cerques guardades',
	TEXT_DELETE_SEARCH: 'Desitja eliminar aquesta cerca?',
	TEXT_YES: 'Si',
	TEXT_NO: 'No',

	TEXT_FILTER_APPLY: 'Aplicar',
	TEXT_FILTER_CLEAR: 'Netejar',
	TEXT_FILTER_MULTISELECT: 'Selecció múltiple',

	// for rights page
	AA_ADD_NEW_GROUP: 'Afegir nou grup',
	AA_RENAMEGROUP: 'Renombrar grup',
	AA_GROUP_NEW: 'Grup nou',
	AA_DELETEGROUP: 'Realment vols esborrar el grup',
	AA_COPY_PERMISS_FROM: 'Esculli el grup d\'origen de permisos:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Esculli columnes a mostrar',
	AA_SELECT_NONE: 'Sense selecció',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Preparant pàgines per a imprimir',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processant registres',
	IMPORT_FAILED: 'Importació fallida',

	LOADING_FONTS: 'Càrrega de fonts',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Seleccioneu Mes',
	DATEPICKER_NEXT_MONTH: 'El mes que ve',
	DATEPICKER_PREV_MONTH: 'Mes anterior',
	DATEPICKER_SELECT_YEAR: 'Seleccioneu l\'any',
	DATEPICKER_NEXT_YEAR: 'L\'any que vé',
	DATEPICKER_PREV_YEAR: 'L\'any que vé',

	TODAY: 'Avui',
	TIME: 'Temps',
	TIME_HOUR: 'Hora',
	TIME_MINUTE: 'Minut',
	SELECT_DATE: 'Seleccioneu una data',

	SESSION_EXPIRED_COMMENT: 'Per motius de seguretat, la vostra sessió es retirarà en %seconds% segons tret que continuï',

	NOW: 'ara',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'hores',
	NOTI_DAY: 'd',

	
	EXPORT_TO_PDF: 'Exportar a PDF',
	EXPORT_TO_CSV: 'Exporta a CSV',
	SAVE_AS_PNG: 'Desa com a PNG',
	PRINT: 'Imprimir',

	TWOFACTOR_VERIFICATION: 'Verificació de dos factors',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Correu electrònic', 
	TWO_FACTOR_PARAM_PHONE: 'Número de telèfon', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};