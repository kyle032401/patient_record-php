Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Serbian",

//	for list page
	TEXT_FIRST: 'Prvi',
	TEXT_PREVIOUS: 'Prethodno',
	TEXT_NEXT: 'Sledeće',
	TEXT_LAST: 'Poslednji',
	TEXT_PROCEED_TO: 'Nastavi do',
	TEXT_DETAIL_NOT_SAVED: 'Stavke %s nisu snimljene',
	TEXT_NO_RECORDS: 'Podaci nisu pronađeni',
	TEXT_DETAIL_GOTO: 'Idi na',
	TEXT_SHOW_ALL: 'Prikaži sve',
	TEXT_SHOW_OPTIONS: 'Prikaži opcije',
	TEXT_HIDE_OPTIONS: 'Sakri opcije',
	TEXT_SEARCH_SHOW_OPTIONS:'Prikaži opcije pretrage',
	TEXT_SEARCH_HIDE_OPTIONS:'Sakri opcije pretrage',
	TEXT_SHOW_SEARCH_PANEL:'Prikaži panel pretrage',
	TEXT_HIDE_SEARCH_PANEL:'Sakri panel pretrage',


	TEXT_LOADING: 'učitavanje',
	TEXT_DELETE_CONFIRM: 'Da li zaista želite da obrišete ove podatke?',
	TEXT_PAGE: 'Stranica',
	TEXT_PAGEMAX: 'od',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Neispravan sigurnosni kod.',
	TEXT_PLEASE_SELECT: 'Molim, izaberite',
	TEXT_CTRL_CLICK: 'CTRL + klik za višestruko sortiranje',
	TEXT_SAVE: 'Sačuvaj',
	TEXT_CANCEL: 'Otkaži',
	TEXT_PREVIEW: 'prikaži',
	TEXT_HIDE: 'sakri',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Da li želite da napustite stranu bez snimanja izmena podataka ?',

	TEXT_EDIT: 'Obraditi',
	TEXT_COPY: 'Kopiraj',
	TEXT_VIEW: 'Detalji',
	TEXT_INLINE_EDIT: 'Izmeniti',
	TEXT_INLINE_ADD: 'Dodaj (inline)',
	TEXT_AA_P_ADD: 'Dodaj',

	TEXT_FIELDFILTER_HINT: 'Филтрирати вредности поља',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'e-mail sa sigurnosnim kodom je poslat na %email% .',
	USERINFO_ENTER_CODE: 'Unesite kod ispod.',
	USERINFO_SENT_TEXT: 'Tekstualna poruka sa sigurnosnim kodom je poslata na telefonski broj %phone%.',
	USERINFO_INSTALL_APP1: 'Instalacija aplikacije za autentifikaciju kao što su Google autentifikator, Microsoft Autentifikatoru ili slično na telefonu',
	USERINFO_INSTALL_APP2: 'Zatim skenirajte QR kod sa aplikacijom.',
	USERINFO_INSTALL_APP3: 'Ili napravite novi unos ručno koristeći ovaj ključ:',
	USERINFO_INSTALL_APP4: 'Zatim unesite kod uz pomoć aplikacije ispod.',

//	for calendar
	TEXT_MONTH_JAN: 'Januar',
	TEXT_MONTH_FEB: 'Februar',
	TEXT_MONTH_MAR: 'Mart',
	TEXT_MONTH_APR: 'April',
	TEXT_MONTH_MAY: 'Maj',
	TEXT_MONTH_JUN: 'Juni',
	TEXT_MONTH_JUL: 'Juli',
	TEXT_MONTH_AUG: 'Avgust',
	TEXT_MONTH_SEP: 'Septembar',
	TEXT_MONTH_OCT: 'Oktobar',
	TEXT_MONTH_NOV: 'Novembar',
	TEXT_MONTH_DEC: 'Decembar',
	TEXT_DAY_SU: 'Ned',
	TEXT_DAY_MO: 'Pon',
	TEXT_DAY_TU: 'Uto',
	TEXT_DAY_WE: 'Sre',
	TEXT_DAY_TH: 'Čet',
	TEXT_DAY_FR: 'Pet',
	TEXT_DAY_SA: 'Sub',
	TEXT_TODAY: 'danas',
	TEXT_SELECT_DATE: 'Izaberi datum',
	TEXT_TIME: 'Vreme',
	TEXT_TIME_HOUR: 'Sat',
	TEXT_TIME_MINUTE: 'Minut',
	TEXT_TIME_SECOND: 'Sekunde',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Obavezno polje',
	TEXT_INLINE_FIELD_ZIPCODE: 'Field should be a valid zipcode',
	TEXT_INLINE_FIELD_EMAIL: 'Polje mora biti ispravna email adresa',
	TEXT_INLINE_FIELD_NUMBER: 'Field should be a valid number',
	TEXT_INLINE_FIELD_CURRENCY: 'Polje mora biti ispravna valuta',
	TEXT_INLINE_FIELD_PHONE: 'Field should be a valid phone number',
	TEXT_INLINE_FIELD_PASSWORD1: 'Polje ne može biti \'password\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Field should be at least 4 characters long',
	TEXT_INLINE_FIELD_STATE: 'Field should be a valid US state name',
	TEXT_INLINE_FIELD_SSN: 'Field should be a valid Social Security Number',
	TEXT_INLINE_FIELD_DATE: 'Field should be a valid date',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Field should be a valid time in 24-hour format',
	TEXT_INLINE_FIELD_CC: 'Polje mora sadržati ispravan broj kreditne kartice',
	TEXT_INLINE_ERROR: 'Dogodila se greška',
	TEXT_INLINE_DENY_DUPLICATES: 'Polje ne može sadržati duplirane vrednosti',
	TEXT_INLINE_USERNAME_EXISTS1: 'Ovo korisničko ime',
	TEXT_INLINE_USERNAME_EXISTS2: ' već postoji. Molim, promenite korisničko ime.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Email ',
	TEXT_INLINE_EMAIL_ALREADY2: 'postoji od ranije.Ako ste zaboravili korisničko ime ili šifru koristite opciju za obnovu.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Pogledaj izvor',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'Proširi',
	TEXT_COLLAPSE_ALL: 'Skupi',

	//for register page
	SEC_PWD_LEN: 'Šifra mora biti dužine od barem %% karaktera.',
	SEC_PWD_CASE: 'Šifra se mora sastojati od velikih i malih slova.',
	SEC_PWD_DIGIT: 'Šifra se mora sastojati od barem %% broja ili simbola.',
	SEC_PWD_UNIQUE: 'Šifra se mora sastojati od najmanje %% posebnih znakova.',
	PASSWORDS_DONT_MATCH: 'Šifre nisu identične',
	SUCCES_LOGGED_IN: 'Uspešno ste se prijavili.',

	//for pdf
	TEXT_PDF_BUILD1: 'Kreiranje PDF datoteke',
	TEXT_PDF_BUILD2: 'završeno',
	TEXT_PDF_BUILD3: 'Nije moguće kreirati PDF !',

	CLOSE_WINDOW: 'Zatvori prozor',
	CLOSE: 'Close',
	RESET: 'Poništi',

	//for search options
	CONTAINS: 'Sadrži',
	EQUALS: 'Jednak',
	STARTS_WITH: 'Počinje sa',
	MORE_THAN: 'Više od',
	LESS_THAN: 'Manje od',
	BETWEEN: 'Između',
	EMPTY: 'Prazno',

	NOT_CONTAINS: 'Ne sadrži',
	NOT_EQUALS: 'Nije jednako',
	NOT_STARTS_WITH: 'Ne počinje sa',
	NOT_MORE_THAN: 'Nije veće od',
	NOT_LESS_THAN: 'Nije manje od',
	NOT_BETWEEN: 'Nije između',
	NOT_EMPTY: 'Nije prazno',

	SEARCH_FOR: 'Traži za',

	ERROR_MISSING_FILE_NAME: 'File name was not provided',
	ERROR_ACCEPT_FILE_TYPES: 'File type is not acceptable',
	ERROR_MAX_FILE_SIZE: 'File size exceeds limit of %s kbytes',
	ERROR_MIN_FILE_SIZE: 'File size must not be less than %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Ukupna veličina fajla prelazi limit od %s kbytes',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Možete da uploadujete samo jedan fajl',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'You can upload no more than %s files',

	TEXT_SERVER_ERROR_OCCURRED: 'Serverska greška',
	TEXT_SEE_DETAILS: 'Vidi detalje',

	ERROR_UPLOAD: 'Neuspešan upload',
	START_UPLOAD: 'Upload',
	CANCEL: 'Otkaži',
	DELETE: 'Obriši',

	UPLOAD_DRAG: 'Prevuci fajlove ovde',

	SELECT_ALL: 'Obeleži sve',
	UNSELECT_ALL: 'Unselect all',

	TEXT_WR_REPORT_SAVED: 'Report Saved',
	TEXT_WR_SOME_PROBLEM: 'Some problems appear during saving',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_WR_HEADER: 'Header',
	TEXT_WR_CROSS_GROUP: 'Group',
	TEXT_COUNT: 'Broj',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Max',
	TEXT_SUM: 'Sum',
	TEXT_AVG: 'Prosek',
	TEXT_WR_TOTAL_DATA: 'Table Data',
	TEXT_PAGE_SUMMARY: 'Ukupno po strani',
	TEXT_GLOBAL_SUMMARY: 'Ukupno za sve',
	TEXT_WR_SUMMARY: 'Summary',
	TEXT_FIELD: 'Polje',
	TEXT_WR_NO_COLOR: 'No color',

	TEXT_SEARCH_SAVING: 'Snimi pretragu',
	TEXT_SEARCH_NAME: 'Ime pretrage:',
	TEXT_DELETE_SEARCH_CAPTION: 'Obriši snimljenu pretragu',
	TEXT_DELETE_SEARCH: 'Da li zaista želite da obrišete pretragu?',
	TEXT_YES: 'DA',
	TEXT_NO: 'NE',

	TEXT_FILTER_APPLY: 'Primeni',
	TEXT_FILTER_CLEAR: 'Očisti',
	TEXT_FILTER_MULTISELECT: 'Izaberi više',

	// for rights page
	AA_ADD_NEW_GROUP: 'Dodaj novu grupu',
	AA_RENAMEGROUP: 'Preimenuj grupu',
	AA_GROUP_NEW: 'nova grupa',
	AA_DELETEGROUP: 'Da li zaista želite da obrišete grupu',
	AA_COPY_PERMISS_FROM: 'Izaberite grupu da kopirate privilegije:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Izaberite kolone za prikaz',
	AA_SELECT_NONE: 'Select none',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Priprema strane za štampanje',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processing records',
	IMPORT_FAILED: 'Import je neuspešan !',

	LOADING_FONTS: 'Učitavanje fontova',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Izaberite mesec',
	DATEPICKER_NEXT_MONTH: 'Sledećeg meseca',
	DATEPICKER_PREV_MONTH: 'Prethodni mesec',
	DATEPICKER_SELECT_YEAR: 'Izaberite godinu',
	DATEPICKER_NEXT_YEAR: 'Sledeće godine',
	DATEPICKER_PREV_YEAR: 'Prethodne godine',

	TODAY: 'danas',
	TIME: 'Vreme',
	TIME_HOUR: 'Sat',
	TIME_MINUTE: 'Minut',
	SELECT_DATE: 'Izaberi datum',

	SESSION_EXPIRED_COMMENT: 'Iz bezbednosnih razloga, Vaša sesija ističe za %seconds% sekundi.',

	NOW: 'Сада',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'м',
	NOTI_HOUR: 'сати',
	NOTI_DAY: 'д',

	
	EXPORT_TO_PDF: 'Izvezi u PDF',
	EXPORT_TO_CSV: 'Извоз у ЦСВ',
	SAVE_AS_PNG: 'Сачувај као ПДФ',
	PRINT: 'Štampaj',

	TWOFACTOR_VERIFICATION: 'Верификација две фактора',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Adresa e-pošte', 
	TWO_FACTOR_PARAM_PHONE: 'Broj telefona', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};