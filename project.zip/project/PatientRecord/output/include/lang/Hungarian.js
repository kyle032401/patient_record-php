Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Hungarian",

//	for list page
	TEXT_FIRST: 'Első',
	TEXT_PREVIOUS: 'Előző',
	TEXT_NEXT: 'Következő',
	TEXT_LAST: 'Utolsó',
	TEXT_PROCEED_TO: 'Továbblépés',
	TEXT_DETAIL_NOT_SAVED: 'Rekordok %s nem lettek elmentve',
	TEXT_NO_RECORDS: 'Nincsennek rekordok',
	TEXT_DETAIL_GOTO: 'Ugrás',
	TEXT_SHOW_ALL: 'Összeset mutat',
	TEXT_SHOW_OPTIONS: 'Beállítások megjelenítése',
	TEXT_HIDE_OPTIONS: 'Beállítások elrejtése',
	TEXT_SEARCH_SHOW_OPTIONS:'Keresési beállítások megjelenítése',
	TEXT_SEARCH_HIDE_OPTIONS:'Keresési beállítások elrejtése',
	TEXT_SHOW_SEARCH_PANEL:'Kereső panel megjelenítése',
	TEXT_HIDE_SEARCH_PANEL:'Kereső panel elrejtése',


	TEXT_LOADING: 'Betöltés....',
	TEXT_DELETE_CONFIRM: 'Valóban törölni kívánja a rekordokat?',
	TEXT_PAGE: 'Oldal',
	TEXT_PAGEMAX: '',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Rossz biztonsági kód.',
	TEXT_PLEASE_SELECT: 'Kérem válasszon',
	TEXT_CTRL_CLICK: 'CTRL + kattintás a többszörös rendezéshez',
	TEXT_SAVE: 'Mentés',
	TEXT_CANCEL: 'Mégsem',
	TEXT_PREVIEW: 'Előnézet',
	TEXT_HIDE: 'Elrejt',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Elhagyja az oldalt mentés nélkül?',

	TEXT_EDIT: 'Szerkesztés',
	TEXT_COPY: 'Másolás',
	TEXT_VIEW: 'Nézet',
	TEXT_INLINE_EDIT: 'Módosítás',
	TEXT_INLINE_ADD: 'Új hozzáadás',
	TEXT_AA_P_ADD: 'Hozzáadás',

	TEXT_FIELDFILTER_HINT: 'Szűrő',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'Egy e-mail biztonsági kódot küldtünk %email%.',
	USERINFO_ENTER_CODE: 'Írja be a kódot az alábbi.',
	USERINFO_SENT_TEXT: 'A szöveges üzenetet a biztonsági kódot küldték %phone%.',
	USERINFO_INSTALL_APP1: 'Telepítse hitelesítési alkalmazást, mint a Google Hitelesítő Authy Microsoft Hitelesítő vagy hasonló telefonján.',
	USERINFO_INSTALL_APP2: 'Ezután olvassa be a QR-kód alatt a kb.',
	USERINFO_INSTALL_APP3: 'Vagy hozzon létre egy új rekordot az alkalmazásban manuálisan ezt a kulcsot:',
	USERINFO_INSTALL_APP4: 'Ezután írja be a kódot az alkalmazás alatti.',

//	for calendar
	TEXT_MONTH_JAN: 'Január',
	TEXT_MONTH_FEB: 'Február',
	TEXT_MONTH_MAR: 'Március',
	TEXT_MONTH_APR: 'Április',
	TEXT_MONTH_MAY: 'Május',
	TEXT_MONTH_JUN: 'Június',
	TEXT_MONTH_JUL: 'Július',
	TEXT_MONTH_AUG: 'Augusztus',
	TEXT_MONTH_SEP: 'Szeptember',
	TEXT_MONTH_OCT: 'Októbert',
	TEXT_MONTH_NOV: 'November',
	TEXT_MONTH_DEC: 'December',
	TEXT_DAY_SU: 'Va',
	TEXT_DAY_MO: 'Hé',
	TEXT_DAY_TU: 'Ke',
	TEXT_DAY_WE: 'Sze',
	TEXT_DAY_TH: 'Cs',
	TEXT_DAY_FR: 'Pé',
	TEXT_DAY_SA: 'Szo',
	TEXT_TODAY: 'ma',
	TEXT_SELECT_DATE: 'Válassz dátumot',
	TEXT_TIME: 'Idő',
	TEXT_TIME_HOUR: 'Óra',
	TEXT_TIME_MINUTE: 'Perc',
	TEXT_TIME_SECOND: 'Másodperc',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Kötelező mező',
	TEXT_INLINE_FIELD_ZIPCODE: 'Mezőben érvényes ZIP kódot kell megadni',
	TEXT_INLINE_FIELD_EMAIL: 'Mezőben érvényes email címet kell megadni',
	TEXT_INLINE_FIELD_NUMBER: 'Mezőben érvényes számot kell megadni',
	TEXT_INLINE_FIELD_CURRENCY: 'Mezőben pénznemet kell megadni',
	TEXT_INLINE_FIELD_PHONE: 'Mezőben érvényes telefonszámot kell megadni',
	TEXT_INLINE_FIELD_PASSWORD1: 'A jelszó nem lehet \'jelszó\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Jelszónak legalább 4 karakternek kell lennie',
	TEXT_INLINE_FIELD_STATE: 'Mezőben érvényes USA államot kell megadni',
	TEXT_INLINE_FIELD_SSN: 'Mezőben érvényes TB számot kell megadni',
	TEXT_INLINE_FIELD_DATE: 'Mezőben érvényes dátumot kell megadni',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Mezőben érvényes 24-órás időt kell megadni',
	TEXT_INLINE_FIELD_CC: 'Mezőben érvényes hitelkártya számot kell megadni',
	TEXT_INLINE_ERROR: 'Hiba történt',
	TEXT_INLINE_DENY_DUPLICATES: 'Mező nem tartalmazhat duplikált értéket',
	TEXT_INLINE_USERNAME_EXISTS1: 'Felhasználónév',
	TEXT_INLINE_USERNAME_EXISTS2: 'már létezik, kérjük válasszon másikat.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Emailcím',
	TEXT_INLINE_EMAIL_ALREADY2: 'már létezik. Ha elfelejtette felhasználónevét vagy jelszavát, használja a jelszó emlékeztetőt.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Forrás nézet',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'Mind kibontása',
	TEXT_COLLAPSE_ALL: 'Mind összecsukás',

	//for register page
	SEC_PWD_LEN: 'A jelszónak legalább %% karakternek kell lennie.',
	SEC_PWD_CASE: 'A jelszónak kis és nagybetűket kell tartalmaznia.',
	SEC_PWD_DIGIT: 'A jelszónak %% számot és szimbólumot kell tartalmaznia.',
	SEC_PWD_UNIQUE: 'A jelszónak %% egyedi karaktert kell tartalmaznia.',
	PASSWORDS_DONT_MATCH: 'Jelszavak nem egyeznek',
	SUCCES_LOGGED_IN: 'Sikeresen bejelentkezett.',

	//for pdf
	TEXT_PDF_BUILD1: 'PDF Létrehozása',
	TEXT_PDF_BUILD2: 'kész',
	TEXT_PDF_BUILD3: 'A PDF létrehozása sikertelen',

	CLOSE_WINDOW: 'Ablak bezárása',
	CLOSE: 'Bezár',
	RESET: 'Alaphelyzet',

	//for search options
	CONTAINS: 'Tartalmaz',
	EQUALS: 'Egyenlő',
	STARTS_WITH: 'Kezdés ezzel',
	MORE_THAN: 'Több mint',
	LESS_THAN: 'Kevesebb mint',
	BETWEEN: 'Között',
	EMPTY: 'Üres',

	NOT_CONTAINS: 'Nem tartalmaz',
	NOT_EQUALS: 'Nem egyenlő',
	NOT_STARTS_WITH: 'Nem kezdődik',
	NOT_MORE_THAN: 'Nem több mint',
	NOT_LESS_THAN: 'Nem kevesebb mint',
	NOT_BETWEEN: 'Nincs e között',
	NOT_EMPTY: 'Nem üres',

	SEARCH_FOR: 'Keresés',

	ERROR_MISSING_FILE_NAME: 'Nincs megadva fájlnév',
	ERROR_ACCEPT_FILE_TYPES: 'Érvénytelen fájltípus',
	ERROR_MAX_FILE_SIZE: 'Fájl mérete meghaladja a %s kbyte-ot',
	ERROR_MIN_FILE_SIZE: 'Fájl méretének %s kbyte-nál kisebbnek kell lenni',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Totál fájlméret meghaladja a %s kbyte-ot',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Csak egy fájlt tölthet fel',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'Maximum %s fájlt tölthet fel',

	TEXT_SERVER_ERROR_OCCURRED: 'Szerver hiba történt',
	TEXT_SEE_DETAILS: 'Részletek',

	ERROR_UPLOAD: 'Feltöltés hiba',
	START_UPLOAD: 'Feltöltés',
	CANCEL: 'Mégsem',
	DELETE: 'Törlés',

	UPLOAD_DRAG: 'Húzza a fájlokat ide',

	SELECT_ALL: 'Mindet kiválaszt',
	UNSELECT_ALL: 'Mindet visszavon',

	TEXT_WR_REPORT_SAVED: 'Riport Elmentve',
	TEXT_WR_SOME_PROBLEM: 'Néhány hiba történt mentéskor',
	TEXT_WR_CROSS_GROUP: 'Csoport',
	TEXT_WR_HEADER: 'Fejléc',
	TEXT_WR_CROSS_GROUP: 'Csoport',
	TEXT_COUNT: 'Összegzés',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Max',
	TEXT_SUM: 'Sum',
	TEXT_AVG: 'Átl.',
	TEXT_WR_TOTAL_DATA: 'Tábla Adatok',
	TEXT_PAGE_SUMMARY: 'Oldal összegzés',
	TEXT_GLOBAL_SUMMARY: 'Globális összegzés',
	TEXT_WR_SUMMARY: 'Összegzés',
	TEXT_FIELD: 'Mező',
	TEXT_WR_NO_COLOR: 'Nincs szín',

	TEXT_SEARCH_SAVING: 'Keresés mentése',
	TEXT_SEARCH_NAME: 'Leresés neve:',
	TEXT_DELETE_SEARCH_CAPTION: 'Mentett keresés törlése',
	TEXT_DELETE_SEARCH: 'Biztosan törölni akarja ezt a keresést?',
	TEXT_YES: 'Igen',
	TEXT_NO: 'Nem',

	TEXT_FILTER_APPLY: 'Alkalmaz',
	TEXT_FILTER_CLEAR: 'Töröl',
	TEXT_FILTER_MULTISELECT: 'Többszörös kijelölés',

	// for rights page
	AA_ADD_NEW_GROUP: 'Új csoport',
	AA_RENAMEGROUP: 'Csoport átnevezés',
	AA_GROUP_NEW: 'újcsoport',
	AA_DELETEGROUP: 'Valóban töröljem a következő csoportot',
	AA_COPY_PERMISS_FROM: 'Válasszon csoportot a jogosultság másoláshoz:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Válassza ki a megjelenítendő oszlopokat',
	AA_SELECT_NONE: 'Semmi választás',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Oldal előkészítése nyomtatáshoz',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Rekordok feldolgozása',
	IMPORT_FAILED: 'Import Hiba',

	LOADING_FONTS: 'Loading betűtípusok',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Válassz hónapot',
	DATEPICKER_NEXT_MONTH: 'Következő hónap',
	DATEPICKER_PREV_MONTH: 'Előző hónap',
	DATEPICKER_SELECT_YEAR: 'Select éve',
	DATEPICKER_NEXT_YEAR: 'Következő év',
	DATEPICKER_PREV_YEAR: 'Következő év',

	TODAY: 'ma',
	TIME: 'Idő',
	TIME_HOUR: 'Óra',
	TIME_MINUTE: 'Perc',
	SELECT_DATE: 'Válassz dátumot',

	SESSION_EXPIRED_COMMENT: 'Biztonsági okokból a munkamenet %seconds% másodperc alatt időt tölt be, hacsak nem folytatódik',

	NOW: 'Most',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'p',
	NOTI_HOUR: 'óra',
	NOTI_DAY: 'nap',

	
	EXPORT_TO_PDF: 'Export PDF-be',
	EXPORT_TO_CSV: 'Export a CSV -be',
	SAVE_AS_PNG: 'Mentés PNG -ként',
	PRINT: 'Nyomtatás',

	TWOFACTOR_VERIFICATION: 'Kéttényezős ellenőrzés',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'Email cím', 
	TWO_FACTOR_PARAM_PHONE: 'Telefonszám', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};