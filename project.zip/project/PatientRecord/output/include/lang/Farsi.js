Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Farsi",

//	for list page
	TEXT_FIRST: 'اول',
	TEXT_PREVIOUS: 'گذشته',
	TEXT_NEXT: 'بعدی',
	TEXT_LAST: 'بعد',
	TEXT_PROCEED_TO: 'رفتن به',
	TEXT_DETAIL_NOT_SAVED: 'ركوردها در %s ذخيره نشده است.',
	TEXT_NO_RECORDS: 'موردی پیدا نشد',
	TEXT_DETAIL_GOTO: 'رفتن به',
	TEXT_SHOW_ALL: 'همه را نشان بده',
	TEXT_SHOW_OPTIONS: 'نمايش گزينه ها',
	TEXT_HIDE_OPTIONS: 'مخفي كردن گزينه ها',
	TEXT_SEARCH_SHOW_OPTIONS:'نمايش گزينه هاي جستجو',
	TEXT_SEARCH_HIDE_OPTIONS:'مخفي كردن گزينه هاي جستجو',
	TEXT_SHOW_SEARCH_PANEL:'Show search panel',
	TEXT_HIDE_SEARCH_PANEL:'Hide search panel',


	TEXT_LOADING: 'درحاب بارگذاري',
	TEXT_DELETE_CONFIRM: 'آیا شما واقعا می خواهید این پرونده را حذف کنید؟',
	TEXT_PAGE: 'صفحه',
	TEXT_PAGEMAX: 'از',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'كد امنيتي نامعتبر است',
	TEXT_PLEASE_SELECT: 'لطفا  انتخاب کنید',
	TEXT_CTRL_CLICK: 'CTRL + كليك براي مرتب سازي چندگانه',
	TEXT_SAVE: 'ذخیره',
	TEXT_CANCEL: 'لغو',
	TEXT_PREVIEW: 'پيش نمايش',
	TEXT_HIDE: 'پنهان',
	TEXT_QUESTION_UNSAVED_CHANGES: 'آیا شما می خواهید تغییراتتان را از دست بدهید؟ ',

	TEXT_EDIT: 'ویرایش',
	TEXT_COPY: 'کپی',
	TEXT_VIEW: 'نمایش',
	TEXT_INLINE_EDIT: 'ویرایش',
	TEXT_INLINE_ADD: 'وارد کردن اطلاعات جدید در این پنجره',
	TEXT_AA_P_ADD: 'وارد کردن اطلاعات جدید',

	TEXT_FIELDFILTER_HINT: 'فیلتر کردن',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'یک ایمیل با کد امنیتی را به %email% فرستاده شد.',
	USERINFO_ENTER_CODE: 'که کد زیر را وارد کنید.',
	USERINFO_SENT_TEXT: 'یک پیام نوشتاری با کد امنیتی را به %phone% فرستاده شد.',
	USERINFO_INSTALL_APP1: 'نصب برنامه احراز هویت مانند Google Authenticator، Authy، مایکروسافت Authenticator را یا مشابه بر روی تلفن خود را.',
	USERINFO_INSTALL_APP2: 'سپس کد QR زیر با نرم افزار اسکن.',
	USERINFO_INSTALL_APP3: 'یا ایجاد یک رکورد جدید در نرم افزار به صورت دستی با استفاده از این کلید:',
	USERINFO_INSTALL_APP4: 'سپس کد از برنامه زیر وارد کنید.',

//	for calendar
	TEXT_MONTH_JAN: 'ژانویه',
	TEXT_MONTH_FEB: 'فوریه',
	TEXT_MONTH_MAR: 'مارچ',
	TEXT_MONTH_APR: 'آوریل',
	TEXT_MONTH_MAY: 'مه',
	TEXT_MONTH_JUN: 'ژوئن',
	TEXT_MONTH_JUL: 'ژوئیه',
	TEXT_MONTH_AUG: 'اوت',
	TEXT_MONTH_SEP: 'سپتامبر',
	TEXT_MONTH_OCT: 'اکتبر',
	TEXT_MONTH_NOV: 'نوامبر',
	TEXT_MONTH_DEC: 'دسامبر',
	TEXT_DAY_SU: 'یکشنبه',
	TEXT_DAY_MO: 'دوشنبه',
	TEXT_DAY_TU: 'سه شنبه',
	TEXT_DAY_WE: 'چهارشنبه',
	TEXT_DAY_TH: 'پنجشنبه',
	TEXT_DAY_FR: 'جمعه',
	TEXT_DAY_SA: 'شنبه',
	TEXT_TODAY: 'امروز',
	TEXT_SELECT_DATE: 'انتخاب تاريخ',
	TEXT_TIME: 'زمان',
	TEXT_TIME_HOUR: 'ساعت',
	TEXT_TIME_MINUTE: 'دقیقه',
	TEXT_TIME_SECOND: 'ثانیه',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'فيلد مورد نياز است',
	TEXT_INLINE_FIELD_ZIPCODE: 'فيلد بايد كد پستي معتبر باشد',
	TEXT_INLINE_FIELD_EMAIL: 'فيلد بايد آدرس پست الكترونيك معتبر باشد',
	TEXT_INLINE_FIELD_NUMBER: 'فيلد بايد عدد معتبر باشد',
	TEXT_INLINE_FIELD_CURRENCY: 'فيلد بايد مبلغ عددي معتبر باشد',
	TEXT_INLINE_FIELD_PHONE: 'فيلد بايد شماره تلفن معتبر باشد',
	TEXT_INLINE_FIELD_PASSWORD1: 'فيلد نمي تواند \'password\' باشد',
	TEXT_INLINE_FIELD_PASSWORD2: 'فيلد حداقل بايد 4 حرف باشد',
	TEXT_INLINE_FIELD_STATE: 'فيلد بايد نام ايالت معتبر ايالات متحده باشد',
	TEXT_INLINE_FIELD_SSN: 'فيلد بايد كدملي معتبر باشد',
	TEXT_INLINE_FIELD_DATE: 'فيلد بايد تاريخ معتبر باشد',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'فيلد بايد زمان عددي براساس 24 ساعته باشد',
	TEXT_INLINE_FIELD_CC: 'فيلد بايد شماره كارت اعتباري معتبر باشد',
	TEXT_INLINE_ERROR: 'خطايي رخ داده',
	TEXT_INLINE_DENY_DUPLICATES: 'فیلد باید یک مقدار تکراری را شامل نشود',
	TEXT_INLINE_USERNAME_EXISTS1: 'نام کاربری',
	TEXT_INLINE_USERNAME_EXISTS2: 'قبلا ثبت شده است. انتخاب نام یک کاربر دیگر',
	TEXT_INLINE_EMAIL_ALREADY1: 'فرستادن به ایمیل',
	TEXT_INLINE_EMAIL_ALREADY2: 'قبلا ثبت نام کرده اید.اگر شما رمز عبورتان و نام کاربریتان را فراموش کرده اید با ادمین تماس بگیرید',

	//for RTE
	TEXT_VIEW_SOURCE: 'مشاهده منبع',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'گشايش همه',
	TEXT_COLLAPSE_ALL: 'بستن همه',

	//for register page
	SEC_PWD_LEN: 'رمز عبور حداقل بايد %% حرف باشد',
	SEC_PWD_CASE: 'رمز عبور بايد شامل حروف بزرگ و كوچك باشد',
	SEC_PWD_DIGIT: 'رمز عبور بايد شامل %% عدد يا نماد باشد.',
	SEC_PWD_UNIQUE: 'رمز عبور بايد شامل %% حرف بدون تكرار باشد',
	PASSWORDS_DONT_MATCH: 'کلمه عبور مطابقت ندارد',
	SUCCES_LOGGED_IN: 'شما با موفقیت وارد سایت شدید',

	//for pdf
	TEXT_PDF_BUILD1: 'ساخت پي دي اف',
	TEXT_PDF_BUILD2: 'انجام شد',
	TEXT_PDF_BUILD3: 'Could not create PDF',

	CLOSE_WINDOW: 'بستن پنجره',
	CLOSE: 'Close',
	RESET: 'رشته های کمپرسی',

	//for search options
	CONTAINS: 'محتوا',
	EQUALS: 'مساوی',
	STARTS_WITH: 'آغاز می شود با ...',
	MORE_THAN: 'بیشتر از...',
	LESS_THAN: 'کمتر از ...',
	BETWEEN: 'بين',
	EMPTY: 'خالی',

	NOT_CONTAINS: 'شامل نمي باشد',
	NOT_EQUALS: 'مساوي نيست با',
	NOT_STARTS_WITH: 'شروع نمي شود با',
	NOT_MORE_THAN: 'بيشتر نيست از',
	NOT_LESS_THAN: 'كمتر نيست از',
	NOT_BETWEEN: 'نيست بين',
	NOT_EMPTY: 'خالي نمي باشد',

	SEARCH_FOR: 'جستجو از',

	ERROR_MISSING_FILE_NAME: 'نام فایل ارائه نشده است',
	ERROR_ACCEPT_FILE_TYPES: 'نوع فایل قابل قبول نیست',
	ERROR_MAX_FILE_SIZE: 'حجم فایل بیش از حد %s kbytes',
	ERROR_MIN_FILE_SIZE: 'اندازه فایل نباید کمتر از %s kbytes',
	ERROR_MAX_TOTAL_FILE_SIZE: 'حجم فایل بیش از حد است',
	ERROR_MAX_NUMBER_OF_FILES_ONE: '٪s شما فقط یک فایل می توانید آپلود کنید',
	ERROR_MAX_NUMBER_OF_FILES_MANY: '  شما می توانید بیش از٪ s فایل های آپلود',

	TEXT_SERVER_ERROR_OCCURRED: 'Server error occurred',
	TEXT_SEE_DETAILS: 'See details',

	ERROR_UPLOAD: 'آپلود فایل',
	START_UPLOAD: 'آپلود',
	CANCEL: 'لغو',
	DELETE: 'بررسی',

	UPLOAD_DRAG: 'کشیدن و انداخت فایل به اینجا',

	SELECT_ALL: 'انتخاب همه',
	UNSELECT_ALL: 'لغو انتخاب همه',

	TEXT_WR_REPORT_SAVED: 'ذخیره گزارش',
	TEXT_WR_SOME_PROBLEM: 'برخی از مشکلات در طول ذخیره سازی',
	TEXT_WR_CROSS_GROUP: 'گروه',
	TEXT_WR_HEADER: 'بالا نویس برگه ',
	TEXT_WR_CROSS_GROUP: 'گروه',
	TEXT_COUNT: 'تعداد',
	TEXT_MIN: 'کمترین',
	TEXT_MAX: 'بیشترین',
	TEXT_SUM: 'مجموع',
	TEXT_AVG: 'میانگین',
	TEXT_WR_TOTAL_DATA: 'تاریخ جدول',
	TEXT_PAGE_SUMMARY: 'خلاصه صفحه',
	TEXT_GLOBAL_SUMMARY: 'خلاصه عمومی',
	TEXT_WR_SUMMARY: 'خلاصه',
	TEXT_FIELD: 'Field',
	TEXT_WR_NO_COLOR: 'رنگ نه',

	TEXT_SEARCH_SAVING: 'ذخیره جستجو',
	TEXT_SEARCH_NAME: 'نام جستجو:',
	TEXT_DELETE_SEARCH_CAPTION: 'حذف ذخیره جستجو',
	TEXT_DELETE_SEARCH: 'آیا شما واقعا میخواهید جستجو را حذف کنید؟',
	TEXT_YES: 'بله',
	TEXT_NO: 'نه',

	TEXT_FILTER_APPLY: 'اعمال',
	TEXT_FILTER_CLEAR: 'پاک کردن',
	TEXT_FILTER_MULTISELECT: 'انتخاب چندگانه',

	// for rights page
	AA_ADD_NEW_GROUP: 'افزودن گروه جديد',
	AA_RENAMEGROUP: 'تغيير نام گروه',
	AA_GROUP_NEW: 'گروه جديد',
	AA_DELETEGROUP: 'آيا از حذف گروه مطمئن هستيد؟',
	AA_COPY_PERMISS_FROM: 'انتخاب گروه برای کپی کردن مجوز از:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Choose columns to display',
	AA_SELECT_NONE: 'Select none',
	AA_OK: 'موافق',

	PREPARE_PAGE_FOR_PRINTING: 'Preparing page for printing',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Processing records',
	IMPORT_FAILED: 'Import Failed',

	LOADING_FONTS: 'در حال بارگذاری فونت',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'انتخاب ماه',
	DATEPICKER_NEXT_MONTH: 'ماه بعد',
	DATEPICKER_PREV_MONTH: 'ماه گذشته',
	DATEPICKER_SELECT_YEAR: 'انتخاب سال',
	DATEPICKER_NEXT_YEAR: 'سال آینده',
	DATEPICKER_PREV_YEAR: 'سال آینده',

	TODAY: 'امروز',
	TIME: 'زمان',
	TIME_HOUR: 'ساعت',
	TIME_MINUTE: 'دقیقه',
	SELECT_DATE: 'انتخاب تاريخ',

	SESSION_EXPIRED_COMMENT: 'به دلایل امنیتی، جلسه شما در %seconds% ثانیه طول خواهد کشید، مگر اینکه ادامه دهید',

	NOW: 'اکنون',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'دقیقه',
	NOTI_HOUR: 'ساعت',
	NOTI_DAY: 'روز',

	
	EXPORT_TO_PDF: 'ذخیره با فرمت پی دی اف PDF',
	EXPORT_TO_CSV: 'صادرات به CSV',
	SAVE_AS_PNG: 'به عنوان PNG ذخیره کنید',
	PRINT: 'Print',

	TWOFACTOR_VERIFICATION: 'تأیید دو عاملی',
	EMAIL: 'ایمیل',
	TWO_FACTOR_PARAM_EMAIL: 'آدرس ایمیل', 
	TWO_FACTOR_PARAM_PHONE: 'شماره تلفن', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};