Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Afrikaans",

//	for list page
	TEXT_FIRST: 'Eerste',
	TEXT_PREVIOUS: 'Vorige',
	TEXT_NEXT: 'Volgende',
	TEXT_LAST: 'Laaste',
	TEXT_PROCEED_TO: 'Gaan na',
	TEXT_DETAIL_NOT_SAVED: 'rekords in %s is nie gestoor nie',
	TEXT_NO_RECORDS: 'Geen rekords gevind nie',
	TEXT_DETAIL_GOTO: 'Gaan na',
	TEXT_SHOW_ALL: 'Wys alles',
	TEXT_SHOW_OPTIONS: 'Wys opsies',
	TEXT_HIDE_OPTIONS: 'Versteek opsies',
	TEXT_SEARCH_SHOW_OPTIONS:'Wys soek opsies',
	TEXT_SEARCH_HIDE_OPTIONS:'Versteek soek opsies',
	TEXT_SHOW_SEARCH_PANEL:'Show search panel',
	TEXT_HIDE_SEARCH_PANEL:'Hide search panel',


	TEXT_LOADING: 'laai',
	TEXT_DELETE_CONFIRM: 'Wil jy regtig hierdie rekord verwyder?',
	TEXT_PAGE: 'Bladsy',
	TEXT_PAGEMAX: 'van',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Ongeldige sekuriteitskode',
	TEXT_PLEASE_SELECT: 'Kies asb.',
	TEXT_CTRL_CLICK: 'CTRL + kliek vir verskeie kollom sortering',
	TEXT_SAVE: 'Stoor',
	TEXT_CANCEL: 'Kanselleer',
	TEXT_PREVIEW: 'wys',
	TEXT_HIDE: 'verwyder',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Wil jy die bladsy verlaat? Ongestoorde data sal verloor word.',

	TEXT_EDIT: 'Verander',
	TEXT_COPY: 'Kopieër',
	TEXT_VIEW: 'Sien',
	TEXT_INLINE_EDIT: 'Verander inlyn',
	TEXT_INLINE_ADD: 'Voeg nuwe inlyn rekord by',
	TEXT_AA_P_ADD: 'Voeg by',

	TEXT_FIELDFILTER_HINT: 'Filter veldwaardes',

//	for userinfo page
	USERINFO_SENT_EMAIL: '\'N e-pos met die sekuriteit\'s kode gestuur om %email%.',
	USERINFO_ENTER_CODE: 'Voer daardie kode hieronder.',
	USERINFO_SENT_TEXT: '\'N SMS met die sekuriteit\'s kode gestuur om %phone%.',
	USERINFO_INSTALL_APP1: 'Installeer \'n verifikasie inligting soos Google Authenticator Authy, Microsoft Authenticator- of soortgelyke op jou selfoon.',
	USERINFO_INSTALL_APP2: 'Dan scan die QR-kode hieronder met die app.',
	USERINFO_INSTALL_APP3: 'Of \'n nuwe rekord in die jeug met die hand gebruik van hierdie sleutel:',
	USERINFO_INSTALL_APP4: 'en dan die kode van die jeug hieronder.',

//	for calendar
	TEXT_MONTH_JAN: 'Januarie',
	TEXT_MONTH_FEB: 'Februarie',
	TEXT_MONTH_MAR: 'Maart',
	TEXT_MONTH_APR: 'April',
	TEXT_MONTH_MAY: 'Mei',
	TEXT_MONTH_JUN: 'Junie',
	TEXT_MONTH_JUL: 'Julie',
	TEXT_MONTH_AUG: 'Augustus',
	TEXT_MONTH_SEP: 'September',
	TEXT_MONTH_OCT: 'Oktober',
	TEXT_MONTH_NOV: 'November',
	TEXT_MONTH_DEC: 'Desember',
	TEXT_DAY_SU: 'So',
	TEXT_DAY_MO: 'Ma',
	TEXT_DAY_TU: 'Di',
	TEXT_DAY_WE: 'Wo',
	TEXT_DAY_TH: 'Do',
	TEXT_DAY_FR: 'Vry',
	TEXT_DAY_SA: 'Sa',
	TEXT_TODAY: 'vandag',
	TEXT_SELECT_DATE: 'Kies Datum',
	TEXT_TIME: 'Tyd',
	TEXT_TIME_HOUR: 'Uur',
	TEXT_TIME_MINUTE: 'Minuut',
	TEXT_TIME_SECOND: 'Tweede',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Veld is verpligtend',
	TEXT_INLINE_FIELD_ZIPCODE: 'Veld moet \'n wettige poskode wees',
	TEXT_INLINE_FIELD_EMAIL: 'Veld moet \'n wettige e-pos adres wees',
	TEXT_INLINE_FIELD_NUMBER: 'Veld moet \'n numeriese waarde wees',
	TEXT_INLINE_FIELD_CURRENCY: 'Veld moet \'n wettige geldeenheid wees',
	TEXT_INLINE_FIELD_PHONE: 'Veld moet \'n wettige Tel. No. wees',
	TEXT_INLINE_FIELD_PASSWORD1: 'Veld kan nie \'password\' wees nie',
	TEXT_INLINE_FIELD_PASSWORD2: 'Veld moet minstens 4 karakters wees',
	TEXT_INLINE_FIELD_STATE: 'Veld moet \'n wettige Amerikaanse staat wees',
	TEXT_INLINE_FIELD_SSN: 'Veld moet \'n wettige Sosiale Sekuriteitsno. wees',
	TEXT_INLINE_FIELD_DATE: 'Veld moet \'n wettige datum wees',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Veld moet \'n wettige tyd in 24-uur formaat wees',
	TEXT_INLINE_FIELD_CC: 'Veld moet \'n wettige kredietkaart nommer wees',
	TEXT_INLINE_ERROR: 'Fout',
	TEXT_INLINE_DENY_DUPLICATES: 'Veld kan nie \'n dupliserende waarde hê nie.',
	TEXT_INLINE_USERNAME_EXISTS1: 'Verbruikersnaam',
	TEXT_INLINE_USERNAME_EXISTS2: 'bestaan alreeds. Kies \'n ander gebruikersnaam.',
	TEXT_INLINE_EMAIL_ALREADY1: 'E-pos',
	TEXT_INLINE_EMAIL_ALREADY2: 'Alreeds geregistreer. As jy jou info vergeet het, gebruik die wagwoord herinneringsvorm.',

	//for RTE
	TEXT_VIEW_SOURCE: 'Sien ',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'brei almal uit',
	TEXT_COLLAPSE_ALL: 'krimp almal',

	//for register page
	SEC_PWD_LEN: 'Wagwoord moet ten minste %% karakters lank wees',
	SEC_PWD_CASE: 'Wagwoord moet kleinletters en hoofletters bevat',
	SEC_PWD_DIGIT: 'Wagwoord moet %% syfers en simbole insluit',
	SEC_PWD_UNIQUE: 'Wagwoord moet %% unieke karakters insluit',
	PASSWORDS_DONT_MATCH: 'Wagwoorde stem nie ooreen nie',
	SUCCES_LOGGED_IN: 'U het suksesvol aangelog',

	//for pdf
	TEXT_PDF_BUILD1: 'Skep PDF',
	TEXT_PDF_BUILD2: 'voltooi',
	TEXT_PDF_BUILD3: 'Could not create PDF',

	CLOSE_WINDOW: 'Maak venster toe',
	CLOSE: 'Close',
	RESET: 'Herstel',

	//for search options
	CONTAINS: 'Bevat',
	EQUALS: 'Gelyk aan',
	STARTS_WITH: 'Begin met...',
	MORE_THAN: 'Meer as...',
	LESS_THAN: 'Minder as...',
	BETWEEN: 'Tussen',
	EMPTY: 'Leeg',

	NOT_CONTAINS: 'Sluit nie in nie',
	NOT_EQUALS: 'Is nie gelyk aan',
	NOT_STARTS_WITH: 'Begin nie met',
	NOT_MORE_THAN: 'Is nie meer as',
	NOT_LESS_THAN: 'Is nie minder as',
	NOT_BETWEEN: 'Is nie tussen',
	NOT_EMPTY: 'Is nie leeg',

	SEARCH_FOR: 'Soek vir',

	ERROR_MISSING_FILE_NAME: 'Leêr naam was nie voorsien nie',
	ERROR_ACCEPT_FILE_TYPES: 'Leêr tipe is nie aanvaarbaar nie',
	ERROR_MAX_FILE_SIZE: 'Leêr naam is groter as ,imiet van %s',
	ERROR_MIN_FILE_SIZE: 'Leêr grootte mag nie minder as %s kilo grepe wees nie',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Totale leêr grootte is groter as limiet van %s',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'U kan net een leêr oplaai',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'U kan nie meer as %s leêrs oplaai nie',

	TEXT_SERVER_ERROR_OCCURRED: 'Server error occurred',
	TEXT_SEE_DETAILS: 'See details',

	ERROR_UPLOAD: 'Oplaai het misluk',
	START_UPLOAD: 'Laai op',
	CANCEL: 'Kanselleer',
	DELETE: 'Verwyder',

	UPLOAD_DRAG: 'Trek leêrs hier',

	SELECT_ALL: 'Kies alles',
	UNSELECT_ALL: 'Verwyder alles',

	TEXT_WR_REPORT_SAVED: 'Verslag gestoor',
	TEXT_WR_SOME_PROBLEM: 'Sommige probleme gedurende die stoor proses',
	TEXT_WR_CROSS_GROUP: 'Groep',
	TEXT_WR_HEADER: 'Hoof',
	TEXT_WR_CROSS_GROUP: 'Groep',
	TEXT_COUNT: 'Tel totaal',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Maks',
	TEXT_SUM: 'Som',
	TEXT_AVG: 'Gem',
	TEXT_WR_TOTAL_DATA: 'Tabel Data',
	TEXT_PAGE_SUMMARY: 'Bladsy opsomming',
	TEXT_GLOBAL_SUMMARY: 'Globale opsomming',
	TEXT_WR_SUMMARY: 'Opsomming',
	TEXT_FIELD: 'Veld',
	TEXT_WR_NO_COLOR: 'Geen kleur',

	TEXT_SEARCH_SAVING: 'Soek resultaat stoor',
	TEXT_SEARCH_NAME: 'Soek resultaat naam',
	TEXT_DELETE_SEARCH_CAPTION: 'Verwyder gestoorder stoor resultate',
	TEXT_DELETE_SEARCH: 'Wil jy regtig die soek resultate verwyder?',
	TEXT_YES: 'Ja',
	TEXT_NO: 'Nee',

	TEXT_FILTER_APPLY: 'Toepas',
	TEXT_FILTER_CLEAR: 'maak skoon',
	TEXT_FILTER_MULTISELECT: 'Multikeuse',

	// for rights page
	AA_ADD_NEW_GROUP: 'Voeg nuwe groep by',
	AA_RENAMEGROUP: 'Verander groep naam',
	AA_GROUP_NEW: 'nuwegroep',
	AA_DELETEGROUP: 'Wil jy die hele volgende groep verwyder',
	AA_COPY_PERMISS_FROM: 'Kies die groep waarvan toestemmings gekopieër moet word. ',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Kies kolomme om te wys',
	AA_SELECT_NONE: 'Kies een',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Druk van bladsy word voorberei',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Rekords word geprosesseer',
	IMPORT_FAILED: 'Import Failed',

	LOADING_FONTS: 'Laai fonts',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Kies Maand',
	DATEPICKER_NEXT_MONTH: 'Volgende maand',
	DATEPICKER_PREV_MONTH: 'vorige Maand',
	DATEPICKER_SELECT_YEAR: 'Kies Jaar',
	DATEPICKER_NEXT_YEAR: 'Volgende jaar',
	DATEPICKER_PREV_YEAR: 'Volgende jaar',

	TODAY: 'vandag',
	TIME: 'Tyd',
	TIME_HOUR: 'Uur',
	TIME_MINUTE: 'Minuut',
	SELECT_DATE: 'Kies Datum',

	SESSION_EXPIRED_COMMENT: 'Om sekuriteitsredes sal u sessie in %seconds% sekondes uitstort, tensy u voortgaan',

	NOW: 'nou',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'uur',
	NOTI_DAY: 'd',

	
	EXPORT_TO_PDF: 'Voer uit na PDF',
	EXPORT_TO_CSV: 'Uitvoer na CSV',
	SAVE_AS_PNG: 'Stoor as PNG',
	PRINT: 'Print',

	TWOFACTOR_VERIFICATION: 'Two-faktor verifikasie',
	EMAIL: 'E-pos',
	TWO_FACTOR_PARAM_EMAIL: 'E-pos adres', 
	TWO_FACTOR_PARAM_PHONE: 'Telefoon nommer', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};