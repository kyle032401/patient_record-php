Runner.namespace('Runner.lang');

Runner.lang.constants = {

	current_language: "Polish",

//	for list page
	TEXT_FIRST: 'Pierwszy',
	TEXT_PREVIOUS: 'Poprzedni',
	TEXT_NEXT: 'Następny',
	TEXT_LAST: 'Ostatni',
	TEXT_PROCEED_TO: 'Przejdź do',
	TEXT_DETAIL_NOT_SAVED: 'Rekordy w %s nie zostały zapisane',
	TEXT_NO_RECORDS: 'Nie znaleziono rekordów',
	TEXT_DETAIL_GOTO: 'Idź do',
	TEXT_SHOW_ALL: 'Wszystkie',
	TEXT_SHOW_OPTIONS: 'Pokaż opcje',
	TEXT_HIDE_OPTIONS: 'Ukryj opcje',
	TEXT_SEARCH_SHOW_OPTIONS:'Pokaż opcje wyszukiwania',
	TEXT_SEARCH_HIDE_OPTIONS:'Ukryj opcje wyszukiwania',
	TEXT_SHOW_SEARCH_PANEL:'Pokaż panel wyszukiwania',
	TEXT_HIDE_SEARCH_PANEL:'Ukryj panel wyszukiwania',


	TEXT_LOADING: 'ładowanie',
	TEXT_DELETE_CONFIRM: 'Czy na pewno chcesz usunąć te rekordy?',
	TEXT_PAGE: 'Strona',
	TEXT_PAGEMAX: 'z',

//	for editing pages
	TEXT_INVALID_CAPTCHA_CODE: 'Błedny kod bezpieczeństwa.',
	TEXT_PLEASE_SELECT: 'Wybierz proszę',
	TEXT_CTRL_CLICK: 'CTRL + klik sortowanie złożone',
	TEXT_SAVE: 'Zachowaj',
	TEXT_CANCEL: 'Zrezygnuj',
	TEXT_PREVIEW: 'podgląd',
	TEXT_HIDE: 'ukryj',
	TEXT_QUESTION_UNSAVED_CHANGES: 'Czy chcesz opuścić tę stronę i stracić niezapamiętane zmiany?',

	TEXT_EDIT: 'Edytuj',
	TEXT_COPY: 'Kopia',
	TEXT_VIEW: 'Podgląd',
	TEXT_INLINE_EDIT: 'Edytuj wiersz',
	TEXT_INLINE_ADD: 'Dodaj wiersz',
	TEXT_AA_P_ADD: 'Dodaj',

	TEXT_FIELDFILTER_HINT: 'Filtruj wartości pola',

//	for userinfo page
	USERINFO_SENT_EMAIL: 'E-mail z kodem bezpieczeństwa została wysłana do %email%.',
	USERINFO_ENTER_CODE: 'Wpisz ten kod poniżej.',
	USERINFO_SENT_TEXT: 'Wiadomość tekstowa z kodem bezpieczeństwa została wysłana do %phone%.',
	USERINFO_INSTALL_APP1: 'Zainstalować aplikację uwierzytelniania, takich jak Google Authenticator Authy, Microsoft Authenticator lub podobny w telefonie.',
	USERINFO_INSTALL_APP2: 'Następnie zeskanować kod QR poniżej z aplikacji.',
	USERINFO_INSTALL_APP3: 'Lub utworzyć nowy rekord w aplikacji ręcznie za pomocą tego przycisku:',
	USERINFO_INSTALL_APP4: 'Następnie wprowadź kod z aplikacji poniżej.',

//	for calendar
	TEXT_MONTH_JAN: 'Styczeń',
	TEXT_MONTH_FEB: 'Luty',
	TEXT_MONTH_MAR: 'Marzec',
	TEXT_MONTH_APR: 'Kwiecień',
	TEXT_MONTH_MAY: 'Maj',
	TEXT_MONTH_JUN: 'Czerwiec',
	TEXT_MONTH_JUL: 'Lipiec',
	TEXT_MONTH_AUG: 'Sierpień',
	TEXT_MONTH_SEP: 'Wrzesień',
	TEXT_MONTH_OCT: 'Październik',
	TEXT_MONTH_NOV: 'Listopad',
	TEXT_MONTH_DEC: 'Grudzień',
	TEXT_DAY_SU: 'Nd',
	TEXT_DAY_MO: 'Pn',
	TEXT_DAY_TU: 'Wt',
	TEXT_DAY_WE: 'śr',
	TEXT_DAY_TH: 'Czw',
	TEXT_DAY_FR: 'Pt',
	TEXT_DAY_SA: 'So',
	TEXT_TODAY: 'dzisiaj',
	TEXT_SELECT_DATE: 'Wybierz Datę',
	TEXT_TIME: 'Czas',
	TEXT_TIME_HOUR: 'Godzina',
	TEXT_TIME_MINUTE: 'Minuta',
	TEXT_TIME_SECOND: 'Sekunda',

//	for inline message
	TEXT_INLINE_FIELD_REQUIRED: 'Pole wymagane',
	TEXT_INLINE_FIELD_ZIPCODE: 'Pole powinno zawierać ważny kod pocztowy',
	TEXT_INLINE_FIELD_EMAIL: 'Pole powinno zawierać ważny adres email',
	TEXT_INLINE_FIELD_NUMBER: 'Pole powinno zawierać numer',
	TEXT_INLINE_FIELD_CURRENCY: 'Pole powinno zawierać walutę',
	TEXT_INLINE_FIELD_PHONE: 'Pole powinno zawierać numer telefonu',
	TEXT_INLINE_FIELD_PASSWORD1: 'Pole nie może zawierać \'hasła\'',
	TEXT_INLINE_FIELD_PASSWORD2: 'Pole powinno mieć co najmniej 4 znaki ',
	TEXT_INLINE_FIELD_STATE: 'Pole powinno zawierać nazwę stanu',
	TEXT_INLINE_FIELD_SSN: 'Pole powinno zawierać numer Social Security',
	TEXT_INLINE_FIELD_DATE: 'Pole powinno zawierać datę',
	TEXT_INLINE_FIELD_DATE_NOT_ALLOWED_DAY: '',
	TEXT_INLINE_FIELD_DATE_NOT_IN_INTERVAL: '',
	TEXT_INLINE_FIELD_DATE_EARLIER_THAN_START: '',
	TEXT_INLINE_FIELD_DATE_LATER_THAN_END: '',
	TEXT_INLINE_FIELD_TIME: 'Pole powinno zawierać ważny czas w formacie 24 godzinnym',
	TEXT_INLINE_FIELD_CC: 'Pole powinno zawierać ważny numer karty kredytowej',
	TEXT_INLINE_ERROR: 'Wystąpił błąd',
	TEXT_INLINE_DENY_DUPLICATES: 'Pole nie powinno zawierać powtarzających się wartości',
	TEXT_INLINE_USERNAME_EXISTS1: 'Nazw użytkownika',
	TEXT_INLINE_USERNAME_EXISTS2: 'już istnieje. Wybierz inną nazwę.',
	TEXT_INLINE_EMAIL_ALREADY1: 'Adres e-mail',
	TEXT_INLINE_EMAIL_ALREADY2: 'już istnieje. Jeśli zapomniałeś swoją nazwe użytkownika lub hasło użyj formularza odzyskiwania hasła',

	//for RTE
	TEXT_VIEW_SOURCE: 'Podgląd źródła',
	//for tree-like menu
	TEXT_EXPAND_ALL: 'rozwiń wszystkie',
	TEXT_COLLAPSE_ALL: 'zwiń wszystkie',

	//for register page
	SEC_PWD_LEN: 'Hasło musi mieć conajmniej %% znaków długości.',
	SEC_PWD_CASE: 'Hasło musi zawierać małe i duże litery. ',
	SEC_PWD_DIGIT: 'Hasło musi mieć conajmniej %% cyfr lub symboli.',
	SEC_PWD_UNIQUE: 'Hasło musi zawierać %% unikalnych znaków.',
	PASSWORDS_DONT_MATCH: 'Hasło nie pasuje',
	SUCCES_LOGGED_IN: 'Pomyślnie zalogowany.',

	//for pdf
	TEXT_PDF_BUILD1: 'Tworzenie pliku PDF',
	TEXT_PDF_BUILD2: 'wykonane',
	TEXT_PDF_BUILD3: 'Nie można utworzyć PDF',

	CLOSE_WINDOW: 'Zamknij okno',
	CLOSE: 'Zamknij',
	RESET: 'Zresetuj',

	//for search options
	CONTAINS: 'Zawiera',
	EQUALS: 'Równa się',
	STARTS_WITH: 'Rozpoczyna się od',
	MORE_THAN: 'Większe niż',
	LESS_THAN: 'Mniejsze niż',
	BETWEEN: 'Pomiędzy',
	EMPTY: 'Pusty',

	NOT_CONTAINS: 'Nie zawiera',
	NOT_EQUALS: 'Nie jest równe',
	NOT_STARTS_WITH: 'Nie rozpoczyna się od',
	NOT_MORE_THAN: 'Nie jest wieksze niż',
	NOT_LESS_THAN: 'Nie jest mniejsze niż',
	NOT_BETWEEN: 'Nie jest pomiędzy',
	NOT_EMPTY: 'Nie jest puste',

	SEARCH_FOR: 'Szukaj',

	ERROR_MISSING_FILE_NAME: 'Nie podano nazwy pliku',
	ERROR_ACCEPT_FILE_TYPES: 'Typ pliku nie jest akceptowalny',
	ERROR_MAX_FILE_SIZE: 'Rozmiar pliku przekracza limit %s kbajtów',
	ERROR_MIN_FILE_SIZE: 'Rozmiar pliku nie może być mniejszy niż %s kbajtów',
	ERROR_MAX_TOTAL_FILE_SIZE: 'Całkowity rozmiar plików przekracza limit %s kbajtów',
	ERROR_MAX_NUMBER_OF_FILES_ONE: 'Możesz załadować tylko jeden plik',
	ERROR_MAX_NUMBER_OF_FILES_MANY: 'Możesz załadować nie więcej niż %s plików',

	TEXT_SERVER_ERROR_OCCURRED: 'Wystąpił błąd serwera',
	TEXT_SEE_DETAILS: 'Zobacz szczegóły',

	ERROR_UPLOAD: 'Ładowanie nie powiodło się',
	START_UPLOAD: 'Załaduj',
	CANCEL: 'Zrezygnuj',
	DELETE: 'Usuń',

	UPLOAD_DRAG: 'Przeciągnij pliki tutaj',

	SELECT_ALL: 'Zaznacz wszystkie',
	UNSELECT_ALL: 'Odznacz wszystkie',

	TEXT_WR_REPORT_SAVED: 'Raport Zapisany',
	TEXT_WR_SOME_PROBLEM: 'Wystąpiły jakieś problemy podczas zapisu',
	TEXT_WR_CROSS_GROUP: 'Grupa',
	TEXT_WR_HEADER: 'Nagłówek',
	TEXT_WR_CROSS_GROUP: 'Grupa',
	TEXT_COUNT: 'Zliczanie',
	TEXT_MIN: 'Min',
	TEXT_MAX: 'Maks',
	TEXT_SUM: 'Suma',
	TEXT_AVG: 'Śred',
	TEXT_WR_TOTAL_DATA: 'Tabela Danych',
	TEXT_PAGE_SUMMARY: 'Podsumowanie strony',
	TEXT_GLOBAL_SUMMARY: 'Podsumowanie całkowite',
	TEXT_WR_SUMMARY: 'Podsumowanie',
	TEXT_FIELD: 'Pole',
	TEXT_WR_NO_COLOR: 'Brak koloru',

	TEXT_SEARCH_SAVING: 'Zapamiętywanie wyszukiwania',
	TEXT_SEARCH_NAME: 'Nazwa wyszukiwania:',
	TEXT_DELETE_SEARCH_CAPTION: 'Usuń zapamiętane wyszukiwanie',
	TEXT_DELETE_SEARCH: 'Czy naprawdę chcesz usunąć to wyszukiwanie?',
	TEXT_YES: 'Tak',
	TEXT_NO: 'Nie',

	TEXT_FILTER_APPLY: 'Zastosuj',
	TEXT_FILTER_CLEAR: 'Wyczyść',
	TEXT_FILTER_MULTISELECT: 'Wielokrotny wybór',

	// for rights page
	AA_ADD_NEW_GROUP: 'Dodaj nową grupę',
	AA_RENAMEGROUP: 'Zmień nazwę grupy',
	AA_GROUP_NEW: 'nowa grupa',
	AA_DELETEGROUP: 'Czy naprawdę chcesz usunąć grupę',
	AA_COPY_PERMISS_FROM: 'Wybierz grupę, z której kopiować uprawnienia:',
	AA_CHOOSE_COLUMNS_TO_DIPLAY: 'Wybierz kolumny do wyświetlania',
	AA_SELECT_NONE: 'Wybierz jeden',
	AA_OK: 'OK',

	PREPARE_PAGE_FOR_PRINTING: 'Przygotowywanie strony do wydruku',

	// import page
	IMPORT_PROCESSING_RECORDS: 'Przetwarzanie rekordów',
	IMPORT_FAILED: 'Import nieudany',

	LOADING_FONTS: 'Ładowanie czcionek',

	DATEPICKER_CLOSE: '',
	DATEPICKER_SELECT_MONTH: 'Wybierz miesiąc',
	DATEPICKER_NEXT_MONTH: 'W następnym miesiącu',
	DATEPICKER_PREV_MONTH: 'Poprzedni miesiac',
	DATEPICKER_SELECT_YEAR: 'Wybierz rok',
	DATEPICKER_NEXT_YEAR: 'Następny rok',
	DATEPICKER_PREV_YEAR: 'Następny rok',

	TODAY: 'dzisiaj',
	TIME: 'Czas',
	TIME_HOUR: 'Godzina',
	TIME_MINUTE: 'Minuta',
	SELECT_DATE: 'Wybierz Datę',

	SESSION_EXPIRED_COMMENT: 'Ze względów bezpieczeństwa twoja sesja będzie czasowa w %seconds% sekund, chyba że będziesz kontynuować',

	NOW: 'Teraz',
	NOTI_SECOND: '',
	NOTI_MINUTE: 'm',
	NOTI_HOUR: 'godzin',
	NOTI_DAY: 'd',

	
	EXPORT_TO_PDF: 'Eksport do PDF',
	EXPORT_TO_CSV: 'Eksportuj do CSV',
	SAVE_AS_PNG: 'Zapisz jako PNG',
	PRINT: 'Drukuj',

	TWOFACTOR_VERIFICATION: 'Weryfikacja dwuskładnikowa',
	EMAIL: 'Email',
	TWO_FACTOR_PARAM_EMAIL: 'adres e-mail', 
	TWO_FACTOR_PARAM_PHONE: 'Numer telefonu', 
};

Runner.lang.customlabels = {

	prefix: 'CUSTOM_LABEL_',

	// custom labels
	CUSTOM_LABEL_CUSTOM: ''
};