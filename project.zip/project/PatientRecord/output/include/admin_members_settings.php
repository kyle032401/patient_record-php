<?php
$tdataadmin_members = array();
$tdataadmin_members[".searchableFields"] = array();
$tdataadmin_members[".ShortName"] = "admin_members";
$tdataadmin_members[".OwnerID"] = "";
$tdataadmin_members[".OriginalTable"] = "user_rightsugmembers";


$tdataadmin_members[".pagesByType"] = my_json_decode( "{\"search\":[\"search\"]}" );
$tdataadmin_members[".originalPagesByType"] = $tdataadmin_members[".pagesByType"];
$tdataadmin_members[".pages"] = types2pages( my_json_decode( "{\"search\":[\"search\"]}" ) );
$tdataadmin_members[".originalPages"] = $tdataadmin_members[".pages"];
$tdataadmin_members[".defaultPages"] = my_json_decode( "{\"search\":\"search\"}" );
$tdataadmin_members[".originalDefaultPages"] = $tdataadmin_members[".defaultPages"];

//	field labels
$fieldLabelsadmin_members = array();
$fieldToolTipsadmin_members = array();
$pageTitlesadmin_members = array();
$placeHoldersadmin_members = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsadmin_members["English"] = array();
	$fieldToolTipsadmin_members["English"] = array();
	$placeHoldersadmin_members["English"] = array();
	$pageTitlesadmin_members["English"] = array();
	$fieldLabelsadmin_members["English"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["English"]["UserName"] = "";
	$placeHoldersadmin_members["English"]["UserName"] = "";
	$fieldLabelsadmin_members["English"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["English"]["GroupID"] = "";
	$placeHoldersadmin_members["English"]["GroupID"] = "";
	$fieldLabelsadmin_members["English"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["English"]["Provider"] = "";
	$placeHoldersadmin_members["English"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["English"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsadmin_members["Afrikaans"] = array();
	$fieldToolTipsadmin_members["Afrikaans"] = array();
	$placeHoldersadmin_members["Afrikaans"] = array();
	$pageTitlesadmin_members["Afrikaans"] = array();
	$fieldLabelsadmin_members["Afrikaans"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Afrikaans"]["UserName"] = "";
	$placeHoldersadmin_members["Afrikaans"]["UserName"] = "";
	$fieldLabelsadmin_members["Afrikaans"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Afrikaans"]["GroupID"] = "";
	$placeHoldersadmin_members["Afrikaans"]["GroupID"] = "";
	$fieldLabelsadmin_members["Afrikaans"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Afrikaans"]["Provider"] = "";
	$placeHoldersadmin_members["Afrikaans"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Afrikaans"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsadmin_members["Arabic"] = array();
	$fieldToolTipsadmin_members["Arabic"] = array();
	$placeHoldersadmin_members["Arabic"] = array();
	$pageTitlesadmin_members["Arabic"] = array();
	$fieldLabelsadmin_members["Arabic"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Arabic"]["UserName"] = "";
	$placeHoldersadmin_members["Arabic"]["UserName"] = "";
	$fieldLabelsadmin_members["Arabic"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Arabic"]["GroupID"] = "";
	$placeHoldersadmin_members["Arabic"]["GroupID"] = "";
	$fieldLabelsadmin_members["Arabic"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Arabic"]["Provider"] = "";
	$placeHoldersadmin_members["Arabic"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Arabic"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsadmin_members["Bosnian"] = array();
	$fieldToolTipsadmin_members["Bosnian"] = array();
	$placeHoldersadmin_members["Bosnian"] = array();
	$pageTitlesadmin_members["Bosnian"] = array();
	$fieldLabelsadmin_members["Bosnian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Bosnian"]["UserName"] = "";
	$placeHoldersadmin_members["Bosnian"]["UserName"] = "";
	$fieldLabelsadmin_members["Bosnian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Bosnian"]["GroupID"] = "";
	$placeHoldersadmin_members["Bosnian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Bosnian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Bosnian"]["Provider"] = "";
	$placeHoldersadmin_members["Bosnian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Bosnian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsadmin_members["Bulgarian"] = array();
	$fieldToolTipsadmin_members["Bulgarian"] = array();
	$placeHoldersadmin_members["Bulgarian"] = array();
	$pageTitlesadmin_members["Bulgarian"] = array();
	$fieldLabelsadmin_members["Bulgarian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Bulgarian"]["UserName"] = "";
	$placeHoldersadmin_members["Bulgarian"]["UserName"] = "";
	$fieldLabelsadmin_members["Bulgarian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Bulgarian"]["GroupID"] = "";
	$placeHoldersadmin_members["Bulgarian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Bulgarian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Bulgarian"]["Provider"] = "";
	$placeHoldersadmin_members["Bulgarian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Bulgarian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsadmin_members["Catalan"] = array();
	$fieldToolTipsadmin_members["Catalan"] = array();
	$placeHoldersadmin_members["Catalan"] = array();
	$pageTitlesadmin_members["Catalan"] = array();
	$fieldLabelsadmin_members["Catalan"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Catalan"]["UserName"] = "";
	$placeHoldersadmin_members["Catalan"]["UserName"] = "";
	$fieldLabelsadmin_members["Catalan"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Catalan"]["GroupID"] = "";
	$placeHoldersadmin_members["Catalan"]["GroupID"] = "";
	$fieldLabelsadmin_members["Catalan"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Catalan"]["Provider"] = "";
	$placeHoldersadmin_members["Catalan"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Catalan"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsadmin_members["Chinese"] = array();
	$fieldToolTipsadmin_members["Chinese"] = array();
	$placeHoldersadmin_members["Chinese"] = array();
	$pageTitlesadmin_members["Chinese"] = array();
	$fieldLabelsadmin_members["Chinese"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Chinese"]["UserName"] = "";
	$placeHoldersadmin_members["Chinese"]["UserName"] = "";
	$fieldLabelsadmin_members["Chinese"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Chinese"]["GroupID"] = "";
	$placeHoldersadmin_members["Chinese"]["GroupID"] = "";
	$fieldLabelsadmin_members["Chinese"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Chinese"]["Provider"] = "";
	$placeHoldersadmin_members["Chinese"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Chinese"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsadmin_members["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsadmin_members["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersadmin_members["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesadmin_members["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsadmin_members["Chinese (Hong Kong S.A.R.)"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Chinese (Hong Kong S.A.R.)"]["UserName"] = "";
	$placeHoldersadmin_members["Chinese (Hong Kong S.A.R.)"]["UserName"] = "";
	$fieldLabelsadmin_members["Chinese (Hong Kong S.A.R.)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Chinese (Hong Kong S.A.R.)"]["GroupID"] = "";
	$placeHoldersadmin_members["Chinese (Hong Kong S.A.R.)"]["GroupID"] = "";
	$fieldLabelsadmin_members["Chinese (Hong Kong S.A.R.)"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Chinese (Hong Kong S.A.R.)"]["Provider"] = "";
	$placeHoldersadmin_members["Chinese (Hong Kong S.A.R.)"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Chinese (Hong Kong S.A.R.)"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsadmin_members["Chinese (Taiwan)"] = array();
	$fieldToolTipsadmin_members["Chinese (Taiwan)"] = array();
	$placeHoldersadmin_members["Chinese (Taiwan)"] = array();
	$pageTitlesadmin_members["Chinese (Taiwan)"] = array();
	$fieldLabelsadmin_members["Chinese (Taiwan)"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Chinese (Taiwan)"]["UserName"] = "";
	$placeHoldersadmin_members["Chinese (Taiwan)"]["UserName"] = "";
	$fieldLabelsadmin_members["Chinese (Taiwan)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Chinese (Taiwan)"]["GroupID"] = "";
	$placeHoldersadmin_members["Chinese (Taiwan)"]["GroupID"] = "";
	$fieldLabelsadmin_members["Chinese (Taiwan)"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Chinese (Taiwan)"]["Provider"] = "";
	$placeHoldersadmin_members["Chinese (Taiwan)"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Chinese (Taiwan)"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsadmin_members["Croatian"] = array();
	$fieldToolTipsadmin_members["Croatian"] = array();
	$placeHoldersadmin_members["Croatian"] = array();
	$pageTitlesadmin_members["Croatian"] = array();
	$fieldLabelsadmin_members["Croatian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Croatian"]["UserName"] = "";
	$placeHoldersadmin_members["Croatian"]["UserName"] = "";
	$fieldLabelsadmin_members["Croatian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Croatian"]["GroupID"] = "";
	$placeHoldersadmin_members["Croatian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Croatian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Croatian"]["Provider"] = "";
	$placeHoldersadmin_members["Croatian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Croatian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsadmin_members["Czech"] = array();
	$fieldToolTipsadmin_members["Czech"] = array();
	$placeHoldersadmin_members["Czech"] = array();
	$pageTitlesadmin_members["Czech"] = array();
	$fieldLabelsadmin_members["Czech"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Czech"]["UserName"] = "";
	$placeHoldersadmin_members["Czech"]["UserName"] = "";
	$fieldLabelsadmin_members["Czech"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Czech"]["GroupID"] = "";
	$placeHoldersadmin_members["Czech"]["GroupID"] = "";
	$fieldLabelsadmin_members["Czech"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Czech"]["Provider"] = "";
	$placeHoldersadmin_members["Czech"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Czech"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsadmin_members["Danish"] = array();
	$fieldToolTipsadmin_members["Danish"] = array();
	$placeHoldersadmin_members["Danish"] = array();
	$pageTitlesadmin_members["Danish"] = array();
	$fieldLabelsadmin_members["Danish"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Danish"]["UserName"] = "";
	$placeHoldersadmin_members["Danish"]["UserName"] = "";
	$fieldLabelsadmin_members["Danish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Danish"]["GroupID"] = "";
	$placeHoldersadmin_members["Danish"]["GroupID"] = "";
	$fieldLabelsadmin_members["Danish"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Danish"]["Provider"] = "";
	$placeHoldersadmin_members["Danish"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Danish"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsadmin_members["Dutch"] = array();
	$fieldToolTipsadmin_members["Dutch"] = array();
	$placeHoldersadmin_members["Dutch"] = array();
	$pageTitlesadmin_members["Dutch"] = array();
	$fieldLabelsadmin_members["Dutch"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Dutch"]["UserName"] = "";
	$placeHoldersadmin_members["Dutch"]["UserName"] = "";
	$fieldLabelsadmin_members["Dutch"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Dutch"]["GroupID"] = "";
	$placeHoldersadmin_members["Dutch"]["GroupID"] = "";
	$fieldLabelsadmin_members["Dutch"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Dutch"]["Provider"] = "";
	$placeHoldersadmin_members["Dutch"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Dutch"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsadmin_members["Farsi"] = array();
	$fieldToolTipsadmin_members["Farsi"] = array();
	$placeHoldersadmin_members["Farsi"] = array();
	$pageTitlesadmin_members["Farsi"] = array();
	$fieldLabelsadmin_members["Farsi"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Farsi"]["UserName"] = "";
	$placeHoldersadmin_members["Farsi"]["UserName"] = "";
	$fieldLabelsadmin_members["Farsi"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Farsi"]["GroupID"] = "";
	$placeHoldersadmin_members["Farsi"]["GroupID"] = "";
	$fieldLabelsadmin_members["Farsi"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Farsi"]["Provider"] = "";
	$placeHoldersadmin_members["Farsi"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Farsi"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsadmin_members["French"] = array();
	$fieldToolTipsadmin_members["French"] = array();
	$placeHoldersadmin_members["French"] = array();
	$pageTitlesadmin_members["French"] = array();
	$fieldLabelsadmin_members["French"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["French"]["UserName"] = "";
	$placeHoldersadmin_members["French"]["UserName"] = "";
	$fieldLabelsadmin_members["French"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["French"]["GroupID"] = "";
	$placeHoldersadmin_members["French"]["GroupID"] = "";
	$fieldLabelsadmin_members["French"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["French"]["Provider"] = "";
	$placeHoldersadmin_members["French"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["French"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsadmin_members["Georgian"] = array();
	$fieldToolTipsadmin_members["Georgian"] = array();
	$placeHoldersadmin_members["Georgian"] = array();
	$pageTitlesadmin_members["Georgian"] = array();
	$fieldLabelsadmin_members["Georgian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Georgian"]["UserName"] = "";
	$placeHoldersadmin_members["Georgian"]["UserName"] = "";
	$fieldLabelsadmin_members["Georgian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Georgian"]["GroupID"] = "";
	$placeHoldersadmin_members["Georgian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Georgian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Georgian"]["Provider"] = "";
	$placeHoldersadmin_members["Georgian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Georgian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsadmin_members["German"] = array();
	$fieldToolTipsadmin_members["German"] = array();
	$placeHoldersadmin_members["German"] = array();
	$pageTitlesadmin_members["German"] = array();
	$fieldLabelsadmin_members["German"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["German"]["UserName"] = "";
	$placeHoldersadmin_members["German"]["UserName"] = "";
	$fieldLabelsadmin_members["German"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["German"]["GroupID"] = "";
	$placeHoldersadmin_members["German"]["GroupID"] = "";
	$fieldLabelsadmin_members["German"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["German"]["Provider"] = "";
	$placeHoldersadmin_members["German"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["German"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsadmin_members["Greek"] = array();
	$fieldToolTipsadmin_members["Greek"] = array();
	$placeHoldersadmin_members["Greek"] = array();
	$pageTitlesadmin_members["Greek"] = array();
	$fieldLabelsadmin_members["Greek"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Greek"]["UserName"] = "";
	$placeHoldersadmin_members["Greek"]["UserName"] = "";
	$fieldLabelsadmin_members["Greek"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Greek"]["GroupID"] = "";
	$placeHoldersadmin_members["Greek"]["GroupID"] = "";
	$fieldLabelsadmin_members["Greek"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Greek"]["Provider"] = "";
	$placeHoldersadmin_members["Greek"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Greek"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsadmin_members["Hebrew"] = array();
	$fieldToolTipsadmin_members["Hebrew"] = array();
	$placeHoldersadmin_members["Hebrew"] = array();
	$pageTitlesadmin_members["Hebrew"] = array();
	$fieldLabelsadmin_members["Hebrew"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Hebrew"]["UserName"] = "";
	$placeHoldersadmin_members["Hebrew"]["UserName"] = "";
	$fieldLabelsadmin_members["Hebrew"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Hebrew"]["GroupID"] = "";
	$placeHoldersadmin_members["Hebrew"]["GroupID"] = "";
	$fieldLabelsadmin_members["Hebrew"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Hebrew"]["Provider"] = "";
	$placeHoldersadmin_members["Hebrew"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Hebrew"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsadmin_members["Hungarian"] = array();
	$fieldToolTipsadmin_members["Hungarian"] = array();
	$placeHoldersadmin_members["Hungarian"] = array();
	$pageTitlesadmin_members["Hungarian"] = array();
	$fieldLabelsadmin_members["Hungarian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Hungarian"]["UserName"] = "";
	$placeHoldersadmin_members["Hungarian"]["UserName"] = "";
	$fieldLabelsadmin_members["Hungarian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Hungarian"]["GroupID"] = "";
	$placeHoldersadmin_members["Hungarian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Hungarian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Hungarian"]["Provider"] = "";
	$placeHoldersadmin_members["Hungarian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Hungarian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsadmin_members["Indonesian"] = array();
	$fieldToolTipsadmin_members["Indonesian"] = array();
	$placeHoldersadmin_members["Indonesian"] = array();
	$pageTitlesadmin_members["Indonesian"] = array();
	$fieldLabelsadmin_members["Indonesian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Indonesian"]["UserName"] = "";
	$placeHoldersadmin_members["Indonesian"]["UserName"] = "";
	$fieldLabelsadmin_members["Indonesian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Indonesian"]["GroupID"] = "";
	$placeHoldersadmin_members["Indonesian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Indonesian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Indonesian"]["Provider"] = "";
	$placeHoldersadmin_members["Indonesian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Indonesian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsadmin_members["Italian"] = array();
	$fieldToolTipsadmin_members["Italian"] = array();
	$placeHoldersadmin_members["Italian"] = array();
	$pageTitlesadmin_members["Italian"] = array();
	$fieldLabelsadmin_members["Italian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Italian"]["UserName"] = "";
	$placeHoldersadmin_members["Italian"]["UserName"] = "";
	$fieldLabelsadmin_members["Italian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Italian"]["GroupID"] = "";
	$placeHoldersadmin_members["Italian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Italian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Italian"]["Provider"] = "";
	$placeHoldersadmin_members["Italian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Italian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsadmin_members["Japanese"] = array();
	$fieldToolTipsadmin_members["Japanese"] = array();
	$placeHoldersadmin_members["Japanese"] = array();
	$pageTitlesadmin_members["Japanese"] = array();
	$fieldLabelsadmin_members["Japanese"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Japanese"]["UserName"] = "";
	$placeHoldersadmin_members["Japanese"]["UserName"] = "";
	$fieldLabelsadmin_members["Japanese"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Japanese"]["GroupID"] = "";
	$placeHoldersadmin_members["Japanese"]["GroupID"] = "";
	$fieldLabelsadmin_members["Japanese"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Japanese"]["Provider"] = "";
	$placeHoldersadmin_members["Japanese"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Japanese"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsadmin_members["Malay"] = array();
	$fieldToolTipsadmin_members["Malay"] = array();
	$placeHoldersadmin_members["Malay"] = array();
	$pageTitlesadmin_members["Malay"] = array();
	$fieldLabelsadmin_members["Malay"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Malay"]["UserName"] = "";
	$placeHoldersadmin_members["Malay"]["UserName"] = "";
	$fieldLabelsadmin_members["Malay"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Malay"]["GroupID"] = "";
	$placeHoldersadmin_members["Malay"]["GroupID"] = "";
	$fieldLabelsadmin_members["Malay"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Malay"]["Provider"] = "";
	$placeHoldersadmin_members["Malay"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Malay"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsadmin_members["Norwegian(Bokmal)"] = array();
	$fieldToolTipsadmin_members["Norwegian(Bokmal)"] = array();
	$placeHoldersadmin_members["Norwegian(Bokmal)"] = array();
	$pageTitlesadmin_members["Norwegian(Bokmal)"] = array();
	$fieldLabelsadmin_members["Norwegian(Bokmal)"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Norwegian(Bokmal)"]["UserName"] = "";
	$placeHoldersadmin_members["Norwegian(Bokmal)"]["UserName"] = "";
	$fieldLabelsadmin_members["Norwegian(Bokmal)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Norwegian(Bokmal)"]["GroupID"] = "";
	$placeHoldersadmin_members["Norwegian(Bokmal)"]["GroupID"] = "";
	$fieldLabelsadmin_members["Norwegian(Bokmal)"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Norwegian(Bokmal)"]["Provider"] = "";
	$placeHoldersadmin_members["Norwegian(Bokmal)"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Norwegian(Bokmal)"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsadmin_members["Polish"] = array();
	$fieldToolTipsadmin_members["Polish"] = array();
	$placeHoldersadmin_members["Polish"] = array();
	$pageTitlesadmin_members["Polish"] = array();
	$fieldLabelsadmin_members["Polish"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Polish"]["UserName"] = "";
	$placeHoldersadmin_members["Polish"]["UserName"] = "";
	$fieldLabelsadmin_members["Polish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Polish"]["GroupID"] = "";
	$placeHoldersadmin_members["Polish"]["GroupID"] = "";
	$fieldLabelsadmin_members["Polish"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Polish"]["Provider"] = "";
	$placeHoldersadmin_members["Polish"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Polish"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsadmin_members["Portuguese(Brazil)"] = array();
	$fieldToolTipsadmin_members["Portuguese(Brazil)"] = array();
	$placeHoldersadmin_members["Portuguese(Brazil)"] = array();
	$pageTitlesadmin_members["Portuguese(Brazil)"] = array();
	$fieldLabelsadmin_members["Portuguese(Brazil)"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Portuguese(Brazil)"]["UserName"] = "";
	$placeHoldersadmin_members["Portuguese(Brazil)"]["UserName"] = "";
	$fieldLabelsadmin_members["Portuguese(Brazil)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Portuguese(Brazil)"]["GroupID"] = "";
	$placeHoldersadmin_members["Portuguese(Brazil)"]["GroupID"] = "";
	$fieldLabelsadmin_members["Portuguese(Brazil)"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Portuguese(Brazil)"]["Provider"] = "";
	$placeHoldersadmin_members["Portuguese(Brazil)"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Portuguese(Brazil)"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsadmin_members["Portuguese(Standard)"] = array();
	$fieldToolTipsadmin_members["Portuguese(Standard)"] = array();
	$placeHoldersadmin_members["Portuguese(Standard)"] = array();
	$pageTitlesadmin_members["Portuguese(Standard)"] = array();
	$fieldLabelsadmin_members["Portuguese(Standard)"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Portuguese(Standard)"]["UserName"] = "";
	$placeHoldersadmin_members["Portuguese(Standard)"]["UserName"] = "";
	$fieldLabelsadmin_members["Portuguese(Standard)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Portuguese(Standard)"]["GroupID"] = "";
	$placeHoldersadmin_members["Portuguese(Standard)"]["GroupID"] = "";
	$fieldLabelsadmin_members["Portuguese(Standard)"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Portuguese(Standard)"]["Provider"] = "";
	$placeHoldersadmin_members["Portuguese(Standard)"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Portuguese(Standard)"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsadmin_members["Romanian"] = array();
	$fieldToolTipsadmin_members["Romanian"] = array();
	$placeHoldersadmin_members["Romanian"] = array();
	$pageTitlesadmin_members["Romanian"] = array();
	$fieldLabelsadmin_members["Romanian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Romanian"]["UserName"] = "";
	$placeHoldersadmin_members["Romanian"]["UserName"] = "";
	$fieldLabelsadmin_members["Romanian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Romanian"]["GroupID"] = "";
	$placeHoldersadmin_members["Romanian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Romanian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Romanian"]["Provider"] = "";
	$placeHoldersadmin_members["Romanian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Romanian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsadmin_members["Russian"] = array();
	$fieldToolTipsadmin_members["Russian"] = array();
	$placeHoldersadmin_members["Russian"] = array();
	$pageTitlesadmin_members["Russian"] = array();
	$fieldLabelsadmin_members["Russian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Russian"]["UserName"] = "";
	$placeHoldersadmin_members["Russian"]["UserName"] = "";
	$fieldLabelsadmin_members["Russian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Russian"]["GroupID"] = "";
	$placeHoldersadmin_members["Russian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Russian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Russian"]["Provider"] = "";
	$placeHoldersadmin_members["Russian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Russian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsadmin_members["Serbian"] = array();
	$fieldToolTipsadmin_members["Serbian"] = array();
	$placeHoldersadmin_members["Serbian"] = array();
	$pageTitlesadmin_members["Serbian"] = array();
	$fieldLabelsadmin_members["Serbian"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Serbian"]["UserName"] = "";
	$placeHoldersadmin_members["Serbian"]["UserName"] = "";
	$fieldLabelsadmin_members["Serbian"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Serbian"]["GroupID"] = "";
	$placeHoldersadmin_members["Serbian"]["GroupID"] = "";
	$fieldLabelsadmin_members["Serbian"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Serbian"]["Provider"] = "";
	$placeHoldersadmin_members["Serbian"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Serbian"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsadmin_members["Slovak"] = array();
	$fieldToolTipsadmin_members["Slovak"] = array();
	$placeHoldersadmin_members["Slovak"] = array();
	$pageTitlesadmin_members["Slovak"] = array();
	$fieldLabelsadmin_members["Slovak"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Slovak"]["UserName"] = "";
	$placeHoldersadmin_members["Slovak"]["UserName"] = "";
	$fieldLabelsadmin_members["Slovak"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Slovak"]["GroupID"] = "";
	$placeHoldersadmin_members["Slovak"]["GroupID"] = "";
	$fieldLabelsadmin_members["Slovak"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Slovak"]["Provider"] = "";
	$placeHoldersadmin_members["Slovak"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Slovak"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsadmin_members["Spanish"] = array();
	$fieldToolTipsadmin_members["Spanish"] = array();
	$placeHoldersadmin_members["Spanish"] = array();
	$pageTitlesadmin_members["Spanish"] = array();
	$fieldLabelsadmin_members["Spanish"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Spanish"]["UserName"] = "";
	$placeHoldersadmin_members["Spanish"]["UserName"] = "";
	$fieldLabelsadmin_members["Spanish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Spanish"]["GroupID"] = "";
	$placeHoldersadmin_members["Spanish"]["GroupID"] = "";
	$fieldLabelsadmin_members["Spanish"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Spanish"]["Provider"] = "";
	$placeHoldersadmin_members["Spanish"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Spanish"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsadmin_members["Swedish"] = array();
	$fieldToolTipsadmin_members["Swedish"] = array();
	$placeHoldersadmin_members["Swedish"] = array();
	$pageTitlesadmin_members["Swedish"] = array();
	$fieldLabelsadmin_members["Swedish"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Swedish"]["UserName"] = "";
	$placeHoldersadmin_members["Swedish"]["UserName"] = "";
	$fieldLabelsadmin_members["Swedish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Swedish"]["GroupID"] = "";
	$placeHoldersadmin_members["Swedish"]["GroupID"] = "";
	$fieldLabelsadmin_members["Swedish"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Swedish"]["Provider"] = "";
	$placeHoldersadmin_members["Swedish"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Swedish"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsadmin_members["Tagalog(Philippines)"] = array();
	$fieldToolTipsadmin_members["Tagalog(Philippines)"] = array();
	$placeHoldersadmin_members["Tagalog(Philippines)"] = array();
	$pageTitlesadmin_members["Tagalog(Philippines)"] = array();
	$fieldLabelsadmin_members["Tagalog(Philippines)"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Tagalog(Philippines)"]["UserName"] = "";
	$placeHoldersadmin_members["Tagalog(Philippines)"]["UserName"] = "";
	$fieldLabelsadmin_members["Tagalog(Philippines)"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Tagalog(Philippines)"]["GroupID"] = "";
	$placeHoldersadmin_members["Tagalog(Philippines)"]["GroupID"] = "";
	$fieldLabelsadmin_members["Tagalog(Philippines)"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Tagalog(Philippines)"]["Provider"] = "";
	$placeHoldersadmin_members["Tagalog(Philippines)"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Tagalog(Philippines)"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsadmin_members["Thai"] = array();
	$fieldToolTipsadmin_members["Thai"] = array();
	$placeHoldersadmin_members["Thai"] = array();
	$pageTitlesadmin_members["Thai"] = array();
	$fieldLabelsadmin_members["Thai"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Thai"]["UserName"] = "";
	$placeHoldersadmin_members["Thai"]["UserName"] = "";
	$fieldLabelsadmin_members["Thai"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Thai"]["GroupID"] = "";
	$placeHoldersadmin_members["Thai"]["GroupID"] = "";
	$fieldLabelsadmin_members["Thai"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Thai"]["Provider"] = "";
	$placeHoldersadmin_members["Thai"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Thai"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsadmin_members["Turkish"] = array();
	$fieldToolTipsadmin_members["Turkish"] = array();
	$placeHoldersadmin_members["Turkish"] = array();
	$pageTitlesadmin_members["Turkish"] = array();
	$fieldLabelsadmin_members["Turkish"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Turkish"]["UserName"] = "";
	$placeHoldersadmin_members["Turkish"]["UserName"] = "";
	$fieldLabelsadmin_members["Turkish"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Turkish"]["GroupID"] = "";
	$placeHoldersadmin_members["Turkish"]["GroupID"] = "";
	$fieldLabelsadmin_members["Turkish"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Turkish"]["Provider"] = "";
	$placeHoldersadmin_members["Turkish"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Turkish"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsadmin_members["Urdu"] = array();
	$fieldToolTipsadmin_members["Urdu"] = array();
	$placeHoldersadmin_members["Urdu"] = array();
	$pageTitlesadmin_members["Urdu"] = array();
	$fieldLabelsadmin_members["Urdu"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Urdu"]["UserName"] = "";
	$placeHoldersadmin_members["Urdu"]["UserName"] = "";
	$fieldLabelsadmin_members["Urdu"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Urdu"]["GroupID"] = "";
	$placeHoldersadmin_members["Urdu"]["GroupID"] = "";
	$fieldLabelsadmin_members["Urdu"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Urdu"]["Provider"] = "";
	$placeHoldersadmin_members["Urdu"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Urdu"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsadmin_members["Welsh"] = array();
	$fieldToolTipsadmin_members["Welsh"] = array();
	$placeHoldersadmin_members["Welsh"] = array();
	$pageTitlesadmin_members["Welsh"] = array();
	$fieldLabelsadmin_members["Welsh"]["UserName"] = "User Name";
	$fieldToolTipsadmin_members["Welsh"]["UserName"] = "";
	$placeHoldersadmin_members["Welsh"]["UserName"] = "";
	$fieldLabelsadmin_members["Welsh"]["GroupID"] = "Group ID";
	$fieldToolTipsadmin_members["Welsh"]["GroupID"] = "";
	$placeHoldersadmin_members["Welsh"]["GroupID"] = "";
	$fieldLabelsadmin_members["Welsh"]["Provider"] = "Provider";
	$fieldToolTipsadmin_members["Welsh"]["Provider"] = "";
	$placeHoldersadmin_members["Welsh"]["Provider"] = "";
	if (count($fieldToolTipsadmin_members["Welsh"]))
		$tdataadmin_members[".isUseToolTips"] = true;
}


	$tdataadmin_members[".NCSearch"] = true;



$tdataadmin_members[".shortTableName"] = "admin_members";
$tdataadmin_members[".nSecOptions"] = 0;

$tdataadmin_members[".mainTableOwnerID"] = "";
$tdataadmin_members[".entityType"] = 1;
$tdataadmin_members[".connId"] = "testdb_at_localhost";


$tdataadmin_members[".strOriginalTableName"] = "user_rightsugmembers";

	



$tdataadmin_members[".showAddInPopup"] = false;

$tdataadmin_members[".showEditInPopup"] = false;

$tdataadmin_members[".showViewInPopup"] = false;

$tdataadmin_members[".listAjax"] = false;
//	temporary
//$tdataadmin_members[".listAjax"] = false;

	$tdataadmin_members[".audit"] = false;

	$tdataadmin_members[".locking"] = false;


$pages = $tdataadmin_members[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataadmin_members[".edit"] = true;
	$tdataadmin_members[".afterEditAction"] = 1;
	$tdataadmin_members[".closePopupAfterEdit"] = 1;
	$tdataadmin_members[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataadmin_members[".add"] = true;
$tdataadmin_members[".afterAddAction"] = 1;
$tdataadmin_members[".closePopupAfterAdd"] = 1;
$tdataadmin_members[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataadmin_members[".list"] = true;
}



$tdataadmin_members[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataadmin_members[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataadmin_members[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataadmin_members[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataadmin_members[".printFriendly"] = true;
}



$tdataadmin_members[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataadmin_members[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataadmin_members[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataadmin_members[".isUseAjaxSuggest"] = true;





$tdataadmin_members[".ajaxCodeSnippetAdded"] = false;

$tdataadmin_members[".buttonsAdded"] = false;

$tdataadmin_members[".addPageEvents"] = false;

// use timepicker for search panel
$tdataadmin_members[".isUseTimeForSearch"] = false;


$tdataadmin_members[".badgeColor"] = "EDCA00";


$tdataadmin_members[".allSearchFields"] = array();
$tdataadmin_members[".filterFields"] = array();
$tdataadmin_members[".requiredSearchFields"] = array();

$tdataadmin_members[".googleLikeFields"] = array();
$tdataadmin_members[".googleLikeFields"][] = "UserName";
$tdataadmin_members[".googleLikeFields"][] = "GroupID";
$tdataadmin_members[".googleLikeFields"][] = "Provider";



$tdataadmin_members[".tableType"] = "list";

$tdataadmin_members[".printerPageOrientation"] = 0;
$tdataadmin_members[".nPrinterPageScale"] = 100;

$tdataadmin_members[".nPrinterSplitRecords"] = 40;

$tdataadmin_members[".geocodingEnabled"] = false;










$tdataadmin_members[".pageSize"] = 20;

$tdataadmin_members[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdataadmin_members[".strOrderBy"] = $tstrOrderBy;

$tdataadmin_members[".orderindexes"] = array();


$tdataadmin_members[".sqlHead"] = "SELECT UserName,  	GroupID,  	Provider";
$tdataadmin_members[".sqlFrom"] = "FROM user_rightsugmembers";
$tdataadmin_members[".sqlWhereExpr"] = "";
$tdataadmin_members[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataadmin_members[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataadmin_members[".arrGroupsPerPage"] = $arrGPP;

$tdataadmin_members[".highlightSearchResults"] = true;

$tableKeysadmin_members = array();
$tableKeysadmin_members[] = "UserName";
$tableKeysadmin_members[] = "GroupID";
$tableKeysadmin_members[] = "Provider";
$tdataadmin_members[".Keys"] = $tableKeysadmin_members;


$tdataadmin_members[".hideMobileList"] = array();




//	UserName
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "UserName";
	$fdata["GoodName"] = "UserName";
	$fdata["ownerTable"] = "user_rightsugmembers";
	$fdata["Label"] = GetFieldLabel("admin_members","UserName");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "UserName";

		$fdata["sourceSingle"] = "UserName";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "UserName";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_members["UserName"] = $fdata;
		$tdataadmin_members[".searchableFields"][] = "UserName";
//	GroupID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "GroupID";
	$fdata["GoodName"] = "GroupID";
	$fdata["ownerTable"] = "user_rightsugmembers";
	$fdata["Label"] = GetFieldLabel("admin_members","GroupID");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "GroupID";

		$fdata["sourceSingle"] = "GroupID";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "GroupID";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_members["GroupID"] = $fdata;
		$tdataadmin_members[".searchableFields"][] = "GroupID";
//	Provider
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Provider";
	$fdata["GoodName"] = "Provider";
	$fdata["ownerTable"] = "user_rightsugmembers";
	$fdata["Label"] = GetFieldLabel("admin_members","Provider");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Provider";

		$fdata["sourceSingle"] = "Provider";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Provider";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=10";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_members["Provider"] = $fdata;
		$tdataadmin_members[".searchableFields"][] = "Provider";


$tables_data["admin_members"]=&$tdataadmin_members;
$field_labels["admin_members"] = &$fieldLabelsadmin_members;
$fieldToolTips["admin_members"] = &$fieldToolTipsadmin_members;
$placeHolders["admin_members"] = &$placeHoldersadmin_members;
$page_titles["admin_members"] = &$pageTitlesadmin_members;


changeTextControlsToDate( "admin_members" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["admin_members"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["admin_members"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_admin_members()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "UserName,  	GroupID,  	Provider";
$proto0["m_strFrom"] = "FROM user_rightsugmembers";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "UserName",
	"m_strTable" => "user_rightsugmembers",
	"m_srcTableName" => "admin_members"
));

$proto6["m_sql"] = "UserName";
$proto6["m_srcTableName"] = "admin_members";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "GroupID",
	"m_strTable" => "user_rightsugmembers",
	"m_srcTableName" => "admin_members"
));

$proto8["m_sql"] = "GroupID";
$proto8["m_srcTableName"] = "admin_members";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Provider",
	"m_strTable" => "user_rightsugmembers",
	"m_srcTableName" => "admin_members"
));

$proto10["m_sql"] = "Provider";
$proto10["m_srcTableName"] = "admin_members";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto12=array();
$proto12["m_link"] = "SQLL_MAIN";
			$proto13=array();
$proto13["m_strName"] = "user_rightsugmembers";
$proto13["m_srcTableName"] = "admin_members";
$proto13["m_columns"] = array();
$proto13["m_columns"][] = "UserName";
$proto13["m_columns"][] = "GroupID";
$proto13["m_columns"][] = "Provider";
$obj = new SQLTable($proto13);

$proto12["m_table"] = $obj;
$proto12["m_sql"] = "user_rightsugmembers";
$proto12["m_alias"] = "";
$proto12["m_srcTableName"] = "admin_members";
$proto14=array();
$proto14["m_sql"] = "";
$proto14["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto14["m_column"]=$obj;
$proto14["m_contained"] = array();
$proto14["m_strCase"] = "";
$proto14["m_havingmode"] = false;
$proto14["m_inBrackets"] = false;
$proto14["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto14);

$proto12["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto12);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="admin_members";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_admin_members = createSqlQuery_admin_members();


	
		;

			

$tdataadmin_members[".sqlquery"] = $queryData_admin_members;



$tdataadmin_members[".hasEvents"] = false;

?>