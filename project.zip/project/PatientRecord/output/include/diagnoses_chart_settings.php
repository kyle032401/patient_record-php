<?php
$tdatadiagnoses_chart = array();
$tdatadiagnoses_chart[".searchableFields"] = array();
$tdatadiagnoses_chart[".ShortName"] = "diagnoses_chart";
$tdatadiagnoses_chart[".OwnerID"] = "";
$tdatadiagnoses_chart[".OriginalTable"] = "diagnoses";


$tdatadiagnoses_chart[".pagesByType"] = my_json_decode( "{\"chart\":[\"chart\"],\"search\":[\"search\"]}" );
$tdatadiagnoses_chart[".originalPagesByType"] = $tdatadiagnoses_chart[".pagesByType"];
$tdatadiagnoses_chart[".pages"] = types2pages( my_json_decode( "{\"chart\":[\"chart\"],\"search\":[\"search\"]}" ) );
$tdatadiagnoses_chart[".originalPages"] = $tdatadiagnoses_chart[".pages"];
$tdatadiagnoses_chart[".defaultPages"] = my_json_decode( "{\"chart\":\"chart\",\"search\":\"search\"}" );
$tdatadiagnoses_chart[".originalDefaultPages"] = $tdatadiagnoses_chart[".defaultPages"];

//	field labels
$fieldLabelsdiagnoses_chart = array();
$fieldToolTipsdiagnoses_chart = array();
$pageTitlesdiagnoses_chart = array();
$placeHoldersdiagnoses_chart = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdiagnoses_chart["English"] = array();
	$fieldToolTipsdiagnoses_chart["English"] = array();
	$placeHoldersdiagnoses_chart["English"] = array();
	$pageTitlesdiagnoses_chart["English"] = array();
	$fieldLabelsdiagnoses_chart["English"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["English"]["id"] = "";
	$placeHoldersdiagnoses_chart["English"]["id"] = "";
	$fieldLabelsdiagnoses_chart["English"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["English"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["English"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["English"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["English"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["English"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["English"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["English"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["English"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["English"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["English"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["English"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["English"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["English"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["English"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["English"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["English"]["Result"] = "";
	$placeHoldersdiagnoses_chart["English"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["English"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsdiagnoses_chart["Afrikaans"] = array();
	$fieldToolTipsdiagnoses_chart["Afrikaans"] = array();
	$placeHoldersdiagnoses_chart["Afrikaans"] = array();
	$pageTitlesdiagnoses_chart["Afrikaans"] = array();
	$fieldLabelsdiagnoses_chart["Afrikaans"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Afrikaans"]["id"] = "";
	$placeHoldersdiagnoses_chart["Afrikaans"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Afrikaans"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Afrikaans"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Afrikaans"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Afrikaans"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Afrikaans"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Afrikaans"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Afrikaans"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Afrikaans"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Afrikaans"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Afrikaans"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Afrikaans"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Afrikaans"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Afrikaans"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Afrikaans"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Afrikaans"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Afrikaans"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Afrikaans"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Afrikaans"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Afrikaans"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsdiagnoses_chart["Arabic"] = array();
	$fieldToolTipsdiagnoses_chart["Arabic"] = array();
	$placeHoldersdiagnoses_chart["Arabic"] = array();
	$pageTitlesdiagnoses_chart["Arabic"] = array();
	$fieldLabelsdiagnoses_chart["Arabic"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Arabic"]["id"] = "";
	$placeHoldersdiagnoses_chart["Arabic"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Arabic"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Arabic"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Arabic"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Arabic"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Arabic"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Arabic"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Arabic"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Arabic"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Arabic"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Arabic"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Arabic"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Arabic"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Arabic"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Arabic"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Arabic"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Arabic"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Arabic"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Arabic"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Arabic"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsdiagnoses_chart["Bosnian"] = array();
	$fieldToolTipsdiagnoses_chart["Bosnian"] = array();
	$placeHoldersdiagnoses_chart["Bosnian"] = array();
	$pageTitlesdiagnoses_chart["Bosnian"] = array();
	$fieldLabelsdiagnoses_chart["Bosnian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Bosnian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Bosnian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Bosnian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Bosnian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Bosnian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Bosnian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Bosnian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Bosnian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Bosnian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Bosnian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Bosnian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Bosnian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Bosnian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Bosnian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Bosnian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Bosnian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Bosnian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Bosnian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Bosnian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Bosnian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Bosnian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsdiagnoses_chart["Bulgarian"] = array();
	$fieldToolTipsdiagnoses_chart["Bulgarian"] = array();
	$placeHoldersdiagnoses_chart["Bulgarian"] = array();
	$pageTitlesdiagnoses_chart["Bulgarian"] = array();
	$fieldLabelsdiagnoses_chart["Bulgarian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Bulgarian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Bulgarian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Bulgarian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Bulgarian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Bulgarian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Bulgarian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Bulgarian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Bulgarian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Bulgarian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Bulgarian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Bulgarian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Bulgarian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Bulgarian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Bulgarian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Bulgarian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Bulgarian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Bulgarian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Bulgarian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Bulgarian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Bulgarian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Bulgarian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsdiagnoses_chart["Catalan"] = array();
	$fieldToolTipsdiagnoses_chart["Catalan"] = array();
	$placeHoldersdiagnoses_chart["Catalan"] = array();
	$pageTitlesdiagnoses_chart["Catalan"] = array();
	$fieldLabelsdiagnoses_chart["Catalan"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Catalan"]["id"] = "";
	$placeHoldersdiagnoses_chart["Catalan"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Catalan"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Catalan"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Catalan"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Catalan"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Catalan"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Catalan"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Catalan"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Catalan"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Catalan"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Catalan"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Catalan"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Catalan"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Catalan"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Catalan"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Catalan"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Catalan"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Catalan"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Catalan"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Catalan"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsdiagnoses_chart["Chinese"] = array();
	$fieldToolTipsdiagnoses_chart["Chinese"] = array();
	$placeHoldersdiagnoses_chart["Chinese"] = array();
	$pageTitlesdiagnoses_chart["Chinese"] = array();
	$fieldLabelsdiagnoses_chart["Chinese"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Chinese"]["id"] = "";
	$placeHoldersdiagnoses_chart["Chinese"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Chinese"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Chinese"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Chinese"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Chinese"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Chinese"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Chinese"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Chinese"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Chinese"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Chinese"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Chinese"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Chinese"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Chinese"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Chinese"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Chinese"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Chinese"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Chinese"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesdiagnoses_chart["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Chinese (Hong Kong S.A.R.)"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"] = array();
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"] = array();
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"] = array();
	$pageTitlesdiagnoses_chart["Chinese (Taiwan)"] = array();
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Chinese (Taiwan)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Chinese (Taiwan)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Chinese (Taiwan)"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsdiagnoses_chart["Croatian"] = array();
	$fieldToolTipsdiagnoses_chart["Croatian"] = array();
	$placeHoldersdiagnoses_chart["Croatian"] = array();
	$pageTitlesdiagnoses_chart["Croatian"] = array();
	$fieldLabelsdiagnoses_chart["Croatian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Croatian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Croatian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Croatian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Croatian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Croatian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Croatian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Croatian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Croatian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Croatian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Croatian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Croatian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Croatian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Croatian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Croatian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Croatian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Croatian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Croatian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Croatian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Croatian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Croatian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Croatian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsdiagnoses_chart["Czech"] = array();
	$fieldToolTipsdiagnoses_chart["Czech"] = array();
	$placeHoldersdiagnoses_chart["Czech"] = array();
	$pageTitlesdiagnoses_chart["Czech"] = array();
	$fieldLabelsdiagnoses_chart["Czech"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Czech"]["id"] = "";
	$placeHoldersdiagnoses_chart["Czech"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Czech"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Czech"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Czech"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Czech"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Czech"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Czech"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Czech"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Czech"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Czech"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Czech"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Czech"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Czech"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Czech"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Czech"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Czech"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Czech"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Czech"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Czech"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Czech"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsdiagnoses_chart["Danish"] = array();
	$fieldToolTipsdiagnoses_chart["Danish"] = array();
	$placeHoldersdiagnoses_chart["Danish"] = array();
	$pageTitlesdiagnoses_chart["Danish"] = array();
	$fieldLabelsdiagnoses_chart["Danish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Danish"]["id"] = "";
	$placeHoldersdiagnoses_chart["Danish"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Danish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Danish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Danish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Danish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Danish"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Danish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Danish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Danish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Danish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Danish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Danish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Danish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Danish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Danish"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Danish"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Danish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Danish"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Danish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Danish"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsdiagnoses_chart["Dutch"] = array();
	$fieldToolTipsdiagnoses_chart["Dutch"] = array();
	$placeHoldersdiagnoses_chart["Dutch"] = array();
	$pageTitlesdiagnoses_chart["Dutch"] = array();
	$fieldLabelsdiagnoses_chart["Dutch"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Dutch"]["id"] = "";
	$placeHoldersdiagnoses_chart["Dutch"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Dutch"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Dutch"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Dutch"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Dutch"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Dutch"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Dutch"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Dutch"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Dutch"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Dutch"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Dutch"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Dutch"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Dutch"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Dutch"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Dutch"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Dutch"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Dutch"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Dutch"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Dutch"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Dutch"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsdiagnoses_chart["Farsi"] = array();
	$fieldToolTipsdiagnoses_chart["Farsi"] = array();
	$placeHoldersdiagnoses_chart["Farsi"] = array();
	$pageTitlesdiagnoses_chart["Farsi"] = array();
	$fieldLabelsdiagnoses_chart["Farsi"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Farsi"]["id"] = "";
	$placeHoldersdiagnoses_chart["Farsi"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Farsi"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Farsi"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Farsi"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Farsi"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Farsi"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Farsi"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Farsi"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Farsi"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Farsi"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Farsi"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Farsi"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Farsi"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Farsi"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Farsi"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Farsi"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Farsi"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Farsi"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Farsi"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Farsi"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsdiagnoses_chart["French"] = array();
	$fieldToolTipsdiagnoses_chart["French"] = array();
	$placeHoldersdiagnoses_chart["French"] = array();
	$pageTitlesdiagnoses_chart["French"] = array();
	$fieldLabelsdiagnoses_chart["French"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["French"]["id"] = "";
	$placeHoldersdiagnoses_chart["French"]["id"] = "";
	$fieldLabelsdiagnoses_chart["French"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["French"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["French"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["French"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["French"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["French"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["French"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["French"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["French"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["French"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["French"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["French"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["French"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["French"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["French"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["French"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["French"]["Result"] = "";
	$placeHoldersdiagnoses_chart["French"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["French"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsdiagnoses_chart["Georgian"] = array();
	$fieldToolTipsdiagnoses_chart["Georgian"] = array();
	$placeHoldersdiagnoses_chart["Georgian"] = array();
	$pageTitlesdiagnoses_chart["Georgian"] = array();
	$fieldLabelsdiagnoses_chart["Georgian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Georgian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Georgian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Georgian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Georgian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Georgian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Georgian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Georgian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Georgian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Georgian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Georgian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Georgian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Georgian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Georgian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Georgian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Georgian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Georgian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Georgian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Georgian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Georgian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Georgian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Georgian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsdiagnoses_chart["German"] = array();
	$fieldToolTipsdiagnoses_chart["German"] = array();
	$placeHoldersdiagnoses_chart["German"] = array();
	$pageTitlesdiagnoses_chart["German"] = array();
	$fieldLabelsdiagnoses_chart["German"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["German"]["id"] = "";
	$placeHoldersdiagnoses_chart["German"]["id"] = "";
	$fieldLabelsdiagnoses_chart["German"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["German"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["German"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["German"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["German"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["German"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["German"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["German"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["German"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["German"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["German"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["German"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["German"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["German"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["German"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["German"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["German"]["Result"] = "";
	$placeHoldersdiagnoses_chart["German"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["German"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsdiagnoses_chart["Greek"] = array();
	$fieldToolTipsdiagnoses_chart["Greek"] = array();
	$placeHoldersdiagnoses_chart["Greek"] = array();
	$pageTitlesdiagnoses_chart["Greek"] = array();
	$fieldLabelsdiagnoses_chart["Greek"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Greek"]["id"] = "";
	$placeHoldersdiagnoses_chart["Greek"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Greek"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Greek"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Greek"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Greek"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Greek"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Greek"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Greek"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Greek"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Greek"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Greek"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Greek"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Greek"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Greek"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Greek"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Greek"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Greek"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Greek"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Greek"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Greek"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsdiagnoses_chart["Hebrew"] = array();
	$fieldToolTipsdiagnoses_chart["Hebrew"] = array();
	$placeHoldersdiagnoses_chart["Hebrew"] = array();
	$pageTitlesdiagnoses_chart["Hebrew"] = array();
	$fieldLabelsdiagnoses_chart["Hebrew"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Hebrew"]["id"] = "";
	$placeHoldersdiagnoses_chart["Hebrew"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Hebrew"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Hebrew"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Hebrew"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Hebrew"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Hebrew"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Hebrew"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Hebrew"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Hebrew"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Hebrew"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Hebrew"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Hebrew"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Hebrew"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Hebrew"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Hebrew"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Hebrew"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Hebrew"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Hebrew"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Hebrew"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Hebrew"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsdiagnoses_chart["Hungarian"] = array();
	$fieldToolTipsdiagnoses_chart["Hungarian"] = array();
	$placeHoldersdiagnoses_chart["Hungarian"] = array();
	$pageTitlesdiagnoses_chart["Hungarian"] = array();
	$fieldLabelsdiagnoses_chart["Hungarian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Hungarian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Hungarian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Hungarian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Hungarian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Hungarian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Hungarian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Hungarian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Hungarian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Hungarian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Hungarian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Hungarian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Hungarian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Hungarian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Hungarian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Hungarian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Hungarian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Hungarian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Hungarian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Hungarian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Hungarian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Hungarian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsdiagnoses_chart["Indonesian"] = array();
	$fieldToolTipsdiagnoses_chart["Indonesian"] = array();
	$placeHoldersdiagnoses_chart["Indonesian"] = array();
	$pageTitlesdiagnoses_chart["Indonesian"] = array();
	$fieldLabelsdiagnoses_chart["Indonesian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Indonesian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Indonesian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Indonesian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Indonesian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Indonesian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Indonesian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Indonesian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Indonesian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Indonesian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Indonesian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Indonesian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Indonesian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Indonesian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Indonesian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Indonesian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Indonesian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Indonesian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Indonesian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Indonesian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Indonesian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Indonesian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsdiagnoses_chart["Italian"] = array();
	$fieldToolTipsdiagnoses_chart["Italian"] = array();
	$placeHoldersdiagnoses_chart["Italian"] = array();
	$pageTitlesdiagnoses_chart["Italian"] = array();
	$fieldLabelsdiagnoses_chart["Italian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Italian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Italian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Italian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Italian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Italian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Italian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Italian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Italian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Italian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Italian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Italian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Italian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Italian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Italian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Italian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Italian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Italian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Italian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Italian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Italian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Italian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsdiagnoses_chart["Japanese"] = array();
	$fieldToolTipsdiagnoses_chart["Japanese"] = array();
	$placeHoldersdiagnoses_chart["Japanese"] = array();
	$pageTitlesdiagnoses_chart["Japanese"] = array();
	$fieldLabelsdiagnoses_chart["Japanese"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Japanese"]["id"] = "";
	$placeHoldersdiagnoses_chart["Japanese"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Japanese"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Japanese"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Japanese"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Japanese"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Japanese"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Japanese"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Japanese"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Japanese"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Japanese"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Japanese"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Japanese"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Japanese"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Japanese"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Japanese"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Japanese"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Japanese"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Japanese"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Japanese"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Japanese"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsdiagnoses_chart["Malay"] = array();
	$fieldToolTipsdiagnoses_chart["Malay"] = array();
	$placeHoldersdiagnoses_chart["Malay"] = array();
	$pageTitlesdiagnoses_chart["Malay"] = array();
	$fieldLabelsdiagnoses_chart["Malay"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Malay"]["id"] = "";
	$placeHoldersdiagnoses_chart["Malay"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Malay"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Malay"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Malay"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Malay"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Malay"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Malay"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Malay"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Malay"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Malay"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Malay"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Malay"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Malay"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Malay"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Malay"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Malay"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Malay"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Malay"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Malay"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Malay"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"] = array();
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"] = array();
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"] = array();
	$pageTitlesdiagnoses_chart["Norwegian(Bokmal)"] = array();
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Norwegian(Bokmal)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Norwegian(Bokmal)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Norwegian(Bokmal)"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsdiagnoses_chart["Polish"] = array();
	$fieldToolTipsdiagnoses_chart["Polish"] = array();
	$placeHoldersdiagnoses_chart["Polish"] = array();
	$pageTitlesdiagnoses_chart["Polish"] = array();
	$fieldLabelsdiagnoses_chart["Polish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Polish"]["id"] = "";
	$placeHoldersdiagnoses_chart["Polish"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Polish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Polish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Polish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Polish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Polish"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Polish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Polish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Polish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Polish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Polish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Polish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Polish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Polish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Polish"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Polish"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Polish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Polish"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Polish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Polish"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"] = array();
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"] = array();
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"] = array();
	$pageTitlesdiagnoses_chart["Portuguese(Brazil)"] = array();
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Brazil)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Brazil)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Portuguese(Brazil)"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"] = array();
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"] = array();
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"] = array();
	$pageTitlesdiagnoses_chart["Portuguese(Standard)"] = array();
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]["id"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Portuguese(Standard)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Portuguese(Standard)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Portuguese(Standard)"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsdiagnoses_chart["Romanian"] = array();
	$fieldToolTipsdiagnoses_chart["Romanian"] = array();
	$placeHoldersdiagnoses_chart["Romanian"] = array();
	$pageTitlesdiagnoses_chart["Romanian"] = array();
	$fieldLabelsdiagnoses_chart["Romanian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Romanian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Romanian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Romanian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Romanian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Romanian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Romanian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Romanian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Romanian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Romanian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Romanian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Romanian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Romanian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Romanian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Romanian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Romanian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Romanian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Romanian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Romanian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Romanian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Romanian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Romanian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsdiagnoses_chart["Russian"] = array();
	$fieldToolTipsdiagnoses_chart["Russian"] = array();
	$placeHoldersdiagnoses_chart["Russian"] = array();
	$pageTitlesdiagnoses_chart["Russian"] = array();
	$fieldLabelsdiagnoses_chart["Russian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Russian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Russian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Russian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Russian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Russian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Russian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Russian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Russian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Russian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Russian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Russian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Russian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Russian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Russian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Russian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Russian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Russian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Russian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Russian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Russian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Russian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsdiagnoses_chart["Serbian"] = array();
	$fieldToolTipsdiagnoses_chart["Serbian"] = array();
	$placeHoldersdiagnoses_chart["Serbian"] = array();
	$pageTitlesdiagnoses_chart["Serbian"] = array();
	$fieldLabelsdiagnoses_chart["Serbian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Serbian"]["id"] = "";
	$placeHoldersdiagnoses_chart["Serbian"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Serbian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Serbian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Serbian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Serbian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Serbian"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Serbian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Serbian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Serbian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Serbian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Serbian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Serbian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Serbian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Serbian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Serbian"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Serbian"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Serbian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Serbian"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Serbian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Serbian"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsdiagnoses_chart["Slovak"] = array();
	$fieldToolTipsdiagnoses_chart["Slovak"] = array();
	$placeHoldersdiagnoses_chart["Slovak"] = array();
	$pageTitlesdiagnoses_chart["Slovak"] = array();
	$fieldLabelsdiagnoses_chart["Slovak"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Slovak"]["id"] = "";
	$placeHoldersdiagnoses_chart["Slovak"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Slovak"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Slovak"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Slovak"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Slovak"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Slovak"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Slovak"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Slovak"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Slovak"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Slovak"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Slovak"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Slovak"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Slovak"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Slovak"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Slovak"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Slovak"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Slovak"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Slovak"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Slovak"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Slovak"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsdiagnoses_chart["Spanish"] = array();
	$fieldToolTipsdiagnoses_chart["Spanish"] = array();
	$placeHoldersdiagnoses_chart["Spanish"] = array();
	$pageTitlesdiagnoses_chart["Spanish"] = array();
	$fieldLabelsdiagnoses_chart["Spanish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Spanish"]["id"] = "";
	$placeHoldersdiagnoses_chart["Spanish"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Spanish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Spanish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Spanish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Spanish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Spanish"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Spanish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Spanish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Spanish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Spanish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Spanish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Spanish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Spanish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Spanish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Spanish"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Spanish"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Spanish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Spanish"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Spanish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Spanish"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsdiagnoses_chart["Swedish"] = array();
	$fieldToolTipsdiagnoses_chart["Swedish"] = array();
	$placeHoldersdiagnoses_chart["Swedish"] = array();
	$pageTitlesdiagnoses_chart["Swedish"] = array();
	$fieldLabelsdiagnoses_chart["Swedish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Swedish"]["id"] = "";
	$placeHoldersdiagnoses_chart["Swedish"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Swedish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Swedish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Swedish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Swedish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Swedish"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Swedish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Swedish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Swedish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Swedish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Swedish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Swedish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Swedish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Swedish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Swedish"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Swedish"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Swedish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Swedish"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Swedish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Swedish"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"] = array();
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"] = array();
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"] = array();
	$pageTitlesdiagnoses_chart["Tagalog(Philippines)"] = array();
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Tagalog(Philippines)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Tagalog(Philippines)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Tagalog(Philippines)"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsdiagnoses_chart["Thai"] = array();
	$fieldToolTipsdiagnoses_chart["Thai"] = array();
	$placeHoldersdiagnoses_chart["Thai"] = array();
	$pageTitlesdiagnoses_chart["Thai"] = array();
	$fieldLabelsdiagnoses_chart["Thai"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Thai"]["id"] = "";
	$placeHoldersdiagnoses_chart["Thai"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Thai"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Thai"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Thai"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Thai"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Thai"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Thai"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Thai"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Thai"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Thai"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Thai"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Thai"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Thai"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Thai"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Thai"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Thai"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Thai"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Thai"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Thai"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Thai"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsdiagnoses_chart["Turkish"] = array();
	$fieldToolTipsdiagnoses_chart["Turkish"] = array();
	$placeHoldersdiagnoses_chart["Turkish"] = array();
	$pageTitlesdiagnoses_chart["Turkish"] = array();
	$fieldLabelsdiagnoses_chart["Turkish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Turkish"]["id"] = "";
	$placeHoldersdiagnoses_chart["Turkish"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Turkish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Turkish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Turkish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Turkish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Turkish"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Turkish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Turkish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Turkish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Turkish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Turkish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Turkish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Turkish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Turkish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Turkish"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Turkish"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Turkish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Turkish"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Turkish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Turkish"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsdiagnoses_chart["Urdu"] = array();
	$fieldToolTipsdiagnoses_chart["Urdu"] = array();
	$placeHoldersdiagnoses_chart["Urdu"] = array();
	$pageTitlesdiagnoses_chart["Urdu"] = array();
	$fieldLabelsdiagnoses_chart["Urdu"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Urdu"]["id"] = "";
	$placeHoldersdiagnoses_chart["Urdu"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Urdu"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Urdu"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Urdu"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Urdu"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Urdu"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Urdu"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Urdu"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Urdu"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Urdu"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Urdu"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Urdu"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Urdu"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Urdu"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Urdu"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Urdu"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Urdu"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Urdu"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Urdu"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Urdu"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsdiagnoses_chart["Welsh"] = array();
	$fieldToolTipsdiagnoses_chart["Welsh"] = array();
	$placeHoldersdiagnoses_chart["Welsh"] = array();
	$pageTitlesdiagnoses_chart["Welsh"] = array();
	$fieldLabelsdiagnoses_chart["Welsh"]["id"] = "Id";
	$fieldToolTipsdiagnoses_chart["Welsh"]["id"] = "";
	$placeHoldersdiagnoses_chart["Welsh"]["id"] = "";
	$fieldLabelsdiagnoses_chart["Welsh"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_chart["Welsh"]["TakenTime"] = "";
	$placeHoldersdiagnoses_chart["Welsh"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_chart["Welsh"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_chart["Welsh"]["Quantity"] = "";
	$placeHoldersdiagnoses_chart["Welsh"]["Quantity"] = "";
	$fieldLabelsdiagnoses_chart["Welsh"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_chart["Welsh"]["treatment_id"] = "";
	$placeHoldersdiagnoses_chart["Welsh"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_chart["Welsh"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_chart["Welsh"]["medicine_id"] = "";
	$placeHoldersdiagnoses_chart["Welsh"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_chart["Welsh"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_chart["Welsh"]["Photo"] = "";
	$placeHoldersdiagnoses_chart["Welsh"]["Photo"] = "";
	$fieldLabelsdiagnoses_chart["Welsh"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_chart["Welsh"]["Result"] = "";
	$placeHoldersdiagnoses_chart["Welsh"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_chart["Welsh"]))
		$tdatadiagnoses_chart[".isUseToolTips"] = true;
}


	$tdatadiagnoses_chart[".NCSearch"] = true;

	$tdatadiagnoses_chart[".ChartRefreshTime"] = 0;


$tdatadiagnoses_chart[".shortTableName"] = "diagnoses_chart";
$tdatadiagnoses_chart[".nSecOptions"] = 0;

$tdatadiagnoses_chart[".mainTableOwnerID"] = "";
$tdatadiagnoses_chart[".entityType"] = 3;
$tdatadiagnoses_chart[".connId"] = "testdb_at_localhost";


$tdatadiagnoses_chart[".strOriginalTableName"] = "diagnoses";

	



$tdatadiagnoses_chart[".showAddInPopup"] = false;

$tdatadiagnoses_chart[".showEditInPopup"] = false;

$tdatadiagnoses_chart[".showViewInPopup"] = false;

$tdatadiagnoses_chart[".listAjax"] = false;
//	temporary
//$tdatadiagnoses_chart[".listAjax"] = false;

	$tdatadiagnoses_chart[".audit"] = false;

	$tdatadiagnoses_chart[".locking"] = false;


$pages = $tdatadiagnoses_chart[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatadiagnoses_chart[".edit"] = true;
	$tdatadiagnoses_chart[".afterEditAction"] = 1;
	$tdatadiagnoses_chart[".closePopupAfterEdit"] = 1;
	$tdatadiagnoses_chart[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatadiagnoses_chart[".add"] = true;
$tdatadiagnoses_chart[".afterAddAction"] = 1;
$tdatadiagnoses_chart[".closePopupAfterAdd"] = 1;
$tdatadiagnoses_chart[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatadiagnoses_chart[".list"] = true;
}



$tdatadiagnoses_chart[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatadiagnoses_chart[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatadiagnoses_chart[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatadiagnoses_chart[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatadiagnoses_chart[".printFriendly"] = true;
}



$tdatadiagnoses_chart[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatadiagnoses_chart[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatadiagnoses_chart[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatadiagnoses_chart[".isUseAjaxSuggest"] = true;





$tdatadiagnoses_chart[".ajaxCodeSnippetAdded"] = false;

$tdatadiagnoses_chart[".buttonsAdded"] = false;

$tdatadiagnoses_chart[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadiagnoses_chart[".isUseTimeForSearch"] = false;


$tdatadiagnoses_chart[".badgeColor"] = "DB7093";


$tdatadiagnoses_chart[".allSearchFields"] = array();
$tdatadiagnoses_chart[".filterFields"] = array();
$tdatadiagnoses_chart[".requiredSearchFields"] = array();

$tdatadiagnoses_chart[".googleLikeFields"] = array();
$tdatadiagnoses_chart[".googleLikeFields"][] = "id";
$tdatadiagnoses_chart[".googleLikeFields"][] = "TakenTime";
$tdatadiagnoses_chart[".googleLikeFields"][] = "Quantity";
$tdatadiagnoses_chart[".googleLikeFields"][] = "treatment_id";
$tdatadiagnoses_chart[".googleLikeFields"][] = "medicine_id";
$tdatadiagnoses_chart[".googleLikeFields"][] = "Photo";
$tdatadiagnoses_chart[".googleLikeFields"][] = "Result";



$tdatadiagnoses_chart[".tableType"] = "chart";

$tdatadiagnoses_chart[".printerPageOrientation"] = 0;
$tdatadiagnoses_chart[".nPrinterPageScale"] = 100;

$tdatadiagnoses_chart[".nPrinterSplitRecords"] = 40;

$tdatadiagnoses_chart[".geocodingEnabled"] = false;



// chart settings
$tdatadiagnoses_chart[".chartType"] = "2DPie";
// end of chart settings

$tdatadiagnoses_chart[".isDisplayLoading"] = true;







$tstrOrderBy = "";
$tdatadiagnoses_chart[".strOrderBy"] = $tstrOrderBy;

$tdatadiagnoses_chart[".orderindexes"] = array();


$tdatadiagnoses_chart[".sqlHead"] = "SELECT id,  	TakenTime,  	Quantity,  	treatment_id,  	medicine_id,  	Photo,  	`Result`";
$tdatadiagnoses_chart[".sqlFrom"] = "FROM diagnoses";
$tdatadiagnoses_chart[".sqlWhereExpr"] = "";
$tdatadiagnoses_chart[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadiagnoses_chart[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadiagnoses_chart[".arrGroupsPerPage"] = $arrGPP;

$tdatadiagnoses_chart[".highlightSearchResults"] = true;

$tableKeysdiagnoses_chart = array();
$tableKeysdiagnoses_chart[] = "id";
$tdatadiagnoses_chart[".Keys"] = $tableKeysdiagnoses_chart;


$tdatadiagnoses_chart[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Chart","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_chart["id"] = $fdata;
		$tdatadiagnoses_chart[".searchableFields"][] = "id";
//	TakenTime
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "TakenTime";
	$fdata["GoodName"] = "TakenTime";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Chart","TakenTime");
	$fdata["FieldType"] = 135;


	
	
			

		$fdata["strField"] = "TakenTime";

		$fdata["sourceSingle"] = "TakenTime";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TakenTime";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_chart["TakenTime"] = $fdata;
		$tdatadiagnoses_chart[".searchableFields"][] = "TakenTime";
//	Quantity
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Quantity";
	$fdata["GoodName"] = "Quantity";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Chart","Quantity");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "Quantity";

		$fdata["sourceSingle"] = "Quantity";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Quantity";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_chart["Quantity"] = $fdata;
		$tdatadiagnoses_chart[".searchableFields"][] = "Quantity";
//	treatment_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "treatment_id";
	$fdata["GoodName"] = "treatment_id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Chart","treatment_id");
	$fdata["FieldType"] = 20;


	
	
			

		$fdata["strField"] = "treatment_id";

		$fdata["sourceSingle"] = "treatment_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "treatment_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "treatments";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "id";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_chart["treatment_id"] = $fdata;
		$tdatadiagnoses_chart[".searchableFields"][] = "treatment_id";
//	medicine_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "medicine_id";
	$fdata["GoodName"] = "medicine_id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Chart","medicine_id");
	$fdata["FieldType"] = 20;


	
	
			

		$fdata["strField"] = "medicine_id";

		$fdata["sourceSingle"] = "medicine_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "medicine_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "medicines";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "MedicineName";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_chart["medicine_id"] = $fdata;
		$tdatadiagnoses_chart[".searchableFields"][] = "medicine_id";
//	Photo
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Photo";
	$fdata["GoodName"] = "Photo";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Chart","Photo");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Photo";

		$fdata["sourceSingle"] = "Photo";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Photo";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "File-based Image");

	
	
				$vdata["ImageWidth"] = 50;
	$vdata["ImageHeight"] = 50;

			$vdata["multipleImgMode"] = 1;
	$vdata["maxImages"] = 0;

			$vdata["showGallery"] = true;
	$vdata["galleryMode"] = 2;
	$vdata["captionMode"] = 2;
	$vdata["captionField"] = "";

	$vdata["imageBorder"] = 1;
	$vdata["imageFullWidth"] = 1;


	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_chart["Photo"] = $fdata;
		$tdatadiagnoses_chart[".searchableFields"][] = "Photo";
//	Result
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "Result";
	$fdata["GoodName"] = "Result";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Chart","Result");
	$fdata["FieldType"] = 129;


	
	
			

		$fdata["strField"] = "Result";

		$fdata["sourceSingle"] = "Result";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Result`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["chart"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
		$edata["LookupType"] = 0;
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 3;

	
	
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "Disease";
	$edata["LookupValues"][] = "Injury";
	$edata["LookupValues"][] = "Normal";
	$edata["LookupValues"][] = "";

		$edata["Multiselect"] = true;

	
// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_chart["Result"] = $fdata;
		$tdatadiagnoses_chart[".searchableFields"][] = "Result";

$tdatadiagnoses_chart[".groupChart"] = true;
$tdatadiagnoses_chart[".chartLabelInterval"] = 0;
$tdatadiagnoses_chart[".chartLabelField"] = "Result";
$tdatadiagnoses_chart[".chartSeries"] = array();
$tdatadiagnoses_chart[".chartSeries"][] = array(
	"field" => "id",
	"total" => "COUNT"
);
	$tdatadiagnoses_chart[".chartXml"] = '<chart>
		<attr value="tables">
			<attr value="0">diagnoses Chart</attr>
		</attr>
		<attr value="chart_type">
			<attr value="type">2d_pie</attr>
		</attr>

		<attr value="parameters">';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="0">
			<attr value="name">id</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="1">
		<attr value="name">Result</attr>
	</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '</attr>
			<attr value="appearance">';


	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="head">'.xmlencode("Diagnoses Chart").'</attr>
<attr value="foot">'.xmlencode("Results").'</attr>
<attr value="y_axis_label">'.xmlencode("Quantity").'</attr>


<attr value="slegend">true</attr>
<attr value="sgrid">true</attr>
<attr value="sname">true</attr>
<attr value="sval">true</attr>
<attr value="sanim">true</attr>
<attr value="sstacked">false</attr>
<attr value="slog">false</attr>
<attr value="aqua">0</attr>
<attr value="cview">0</attr>
<attr value="is3d">1</attr>
<attr value="isstacked">0</attr>
<attr value="linestyle">0</attr>
<attr value="autoupdate">0</attr>
<attr value="autoupmin">60</attr>';
$tdatadiagnoses_chart[".chartXml"] .= '</attr>

<attr value="fields">';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="0">
		<attr value="name">id</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("diagnoses_Chart","id")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="1">
		<attr value="name">TakenTime</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("diagnoses_Chart","TakenTime")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="2">
		<attr value="name">Quantity</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("diagnoses_Chart","Quantity")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="3">
		<attr value="name">treatment_id</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("diagnoses_Chart","treatment_id")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="4">
		<attr value="name">medicine_id</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("diagnoses_Chart","medicine_id")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="5">
		<attr value="name">Photo</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("diagnoses_Chart","Photo")).'</attr>
		<attr value="search"></attr>
	</attr>';
	$tdatadiagnoses_chart[".chartXml"] .= '<attr value="6">
		<attr value="name">Result</attr>
		<attr value="label">'.xmlencode(GetFieldLabel("diagnoses_Chart","Result")).'</attr>
		<attr value="search"></attr>
	</attr>';
$tdatadiagnoses_chart[".chartXml"] .= '</attr>


<attr value="settings">
<attr value="name">diagnoses Chart</attr>
<attr value="short_table_name">diagnoses_chart</attr>
</attr>

</chart>';

$tables_data["diagnoses Chart"]=&$tdatadiagnoses_chart;
$field_labels["diagnoses_Chart"] = &$fieldLabelsdiagnoses_chart;
$fieldToolTips["diagnoses_Chart"] = &$fieldToolTipsdiagnoses_chart;
$placeHolders["diagnoses_Chart"] = &$placeHoldersdiagnoses_chart;
$page_titles["diagnoses_Chart"] = &$pageTitlesdiagnoses_chart;


changeTextControlsToDate( "diagnoses Chart" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["diagnoses Chart"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["diagnoses Chart"] = array();



	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="medicines";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="medicines";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "medicines";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["diagnoses Chart"][0] = $masterParams;
				$masterTablesData["diagnoses Chart"][0]["masterKeys"] = array();
	$masterTablesData["diagnoses Chart"][0]["masterKeys"][]="id";
				$masterTablesData["diagnoses Chart"][0]["detailKeys"] = array();
	$masterTablesData["diagnoses Chart"][0]["detailKeys"][]="medicine_id";
		
	//endif
	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="treatments";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="treatments";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "treatments";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["diagnoses Chart"][1] = $masterParams;
				$masterTablesData["diagnoses Chart"][1]["masterKeys"] = array();
	$masterTablesData["diagnoses Chart"][1]["masterKeys"][]="id";
				$masterTablesData["diagnoses Chart"][1]["detailKeys"] = array();
	$masterTablesData["diagnoses Chart"][1]["detailKeys"][]="treatment_id";
		
	//endif
// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_diagnoses_chart()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	TakenTime,  	Quantity,  	treatment_id,  	medicine_id,  	Photo,  	`Result`";
$proto0["m_strFrom"] = "FROM diagnoses";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Chart"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "diagnoses Chart";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "TakenTime",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Chart"
));

$proto8["m_sql"] = "TakenTime";
$proto8["m_srcTableName"] = "diagnoses Chart";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Quantity",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Chart"
));

$proto10["m_sql"] = "Quantity";
$proto10["m_srcTableName"] = "diagnoses Chart";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "treatment_id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Chart"
));

$proto12["m_sql"] = "treatment_id";
$proto12["m_srcTableName"] = "diagnoses Chart";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "medicine_id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Chart"
));

$proto14["m_sql"] = "medicine_id";
$proto14["m_srcTableName"] = "diagnoses Chart";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "Photo",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Chart"
));

$proto16["m_sql"] = "Photo";
$proto16["m_srcTableName"] = "diagnoses Chart";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "Result",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Chart"
));

$proto18["m_sql"] = "`Result`";
$proto18["m_srcTableName"] = "diagnoses Chart";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto20=array();
$proto20["m_link"] = "SQLL_MAIN";
			$proto21=array();
$proto21["m_strName"] = "diagnoses";
$proto21["m_srcTableName"] = "diagnoses Chart";
$proto21["m_columns"] = array();
$proto21["m_columns"][] = "id";
$proto21["m_columns"][] = "TakenTime";
$proto21["m_columns"][] = "Quantity";
$proto21["m_columns"][] = "treatment_id";
$proto21["m_columns"][] = "medicine_id";
$proto21["m_columns"][] = "Photo";
$proto21["m_columns"][] = "Result";
$obj = new SQLTable($proto21);

$proto20["m_table"] = $obj;
$proto20["m_sql"] = "diagnoses";
$proto20["m_alias"] = "";
$proto20["m_srcTableName"] = "diagnoses Chart";
$proto22=array();
$proto22["m_sql"] = "";
$proto22["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto22["m_column"]=$obj;
$proto22["m_contained"] = array();
$proto22["m_strCase"] = "";
$proto22["m_havingmode"] = false;
$proto22["m_inBrackets"] = false;
$proto22["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto22);

$proto20["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto20);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="diagnoses Chart";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_diagnoses_chart = createSqlQuery_diagnoses_chart();


	
		;

							

$tdatadiagnoses_chart[".sqlquery"] = $queryData_diagnoses_chart;



$tdatadiagnoses_chart[".hasEvents"] = false;

?>