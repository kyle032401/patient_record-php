<?php
$tdatadiagnoses_report = array();
$tdatadiagnoses_report[".searchableFields"] = array();
$tdatadiagnoses_report[".ShortName"] = "diagnoses_report";
$tdatadiagnoses_report[".OwnerID"] = "";
$tdatadiagnoses_report[".OriginalTable"] = "diagnoses";


$tdatadiagnoses_report[".pagesByType"] = my_json_decode( "{\"report\":[\"report\"],\"rprint\":[\"rprint\"],\"search\":[\"search\"]}" );
$tdatadiagnoses_report[".originalPagesByType"] = $tdatadiagnoses_report[".pagesByType"];
$tdatadiagnoses_report[".pages"] = types2pages( my_json_decode( "{\"report\":[\"report\"],\"rprint\":[\"rprint\"],\"search\":[\"search\"]}" ) );
$tdatadiagnoses_report[".originalPages"] = $tdatadiagnoses_report[".pages"];
$tdatadiagnoses_report[".defaultPages"] = my_json_decode( "{\"report\":\"report\",\"rprint\":\"rprint\",\"search\":\"search\"}" );
$tdatadiagnoses_report[".originalDefaultPages"] = $tdatadiagnoses_report[".defaultPages"];

//	field labels
$fieldLabelsdiagnoses_report = array();
$fieldToolTipsdiagnoses_report = array();
$pageTitlesdiagnoses_report = array();
$placeHoldersdiagnoses_report = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdiagnoses_report["English"] = array();
	$fieldToolTipsdiagnoses_report["English"] = array();
	$placeHoldersdiagnoses_report["English"] = array();
	$pageTitlesdiagnoses_report["English"] = array();
	$fieldLabelsdiagnoses_report["English"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["English"]["id"] = "";
	$placeHoldersdiagnoses_report["English"]["id"] = "";
	$fieldLabelsdiagnoses_report["English"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["English"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["English"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["English"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["English"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["English"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["English"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["English"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["English"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["English"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["English"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["English"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["English"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["English"]["Photo"] = "";
	$placeHoldersdiagnoses_report["English"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["English"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["English"]["Result"] = "";
	$placeHoldersdiagnoses_report["English"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["English"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsdiagnoses_report["Afrikaans"] = array();
	$fieldToolTipsdiagnoses_report["Afrikaans"] = array();
	$placeHoldersdiagnoses_report["Afrikaans"] = array();
	$pageTitlesdiagnoses_report["Afrikaans"] = array();
	$fieldLabelsdiagnoses_report["Afrikaans"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Afrikaans"]["id"] = "";
	$placeHoldersdiagnoses_report["Afrikaans"]["id"] = "";
	$fieldLabelsdiagnoses_report["Afrikaans"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Afrikaans"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Afrikaans"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Afrikaans"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Afrikaans"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Afrikaans"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Afrikaans"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Afrikaans"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Afrikaans"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Afrikaans"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Afrikaans"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Afrikaans"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Afrikaans"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Afrikaans"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Afrikaans"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Afrikaans"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Afrikaans"]["Result"] = "";
	$placeHoldersdiagnoses_report["Afrikaans"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Afrikaans"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsdiagnoses_report["Arabic"] = array();
	$fieldToolTipsdiagnoses_report["Arabic"] = array();
	$placeHoldersdiagnoses_report["Arabic"] = array();
	$pageTitlesdiagnoses_report["Arabic"] = array();
	$fieldLabelsdiagnoses_report["Arabic"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Arabic"]["id"] = "";
	$placeHoldersdiagnoses_report["Arabic"]["id"] = "";
	$fieldLabelsdiagnoses_report["Arabic"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Arabic"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Arabic"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Arabic"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Arabic"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Arabic"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Arabic"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Arabic"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Arabic"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Arabic"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Arabic"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Arabic"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Arabic"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Arabic"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Arabic"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Arabic"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Arabic"]["Result"] = "";
	$placeHoldersdiagnoses_report["Arabic"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Arabic"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsdiagnoses_report["Bosnian"] = array();
	$fieldToolTipsdiagnoses_report["Bosnian"] = array();
	$placeHoldersdiagnoses_report["Bosnian"] = array();
	$pageTitlesdiagnoses_report["Bosnian"] = array();
	$fieldLabelsdiagnoses_report["Bosnian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Bosnian"]["id"] = "";
	$placeHoldersdiagnoses_report["Bosnian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Bosnian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Bosnian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Bosnian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Bosnian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Bosnian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Bosnian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Bosnian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Bosnian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Bosnian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Bosnian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Bosnian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Bosnian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Bosnian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Bosnian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Bosnian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Bosnian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Bosnian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Bosnian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Bosnian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsdiagnoses_report["Bulgarian"] = array();
	$fieldToolTipsdiagnoses_report["Bulgarian"] = array();
	$placeHoldersdiagnoses_report["Bulgarian"] = array();
	$pageTitlesdiagnoses_report["Bulgarian"] = array();
	$fieldLabelsdiagnoses_report["Bulgarian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Bulgarian"]["id"] = "";
	$placeHoldersdiagnoses_report["Bulgarian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Bulgarian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Bulgarian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Bulgarian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Bulgarian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Bulgarian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Bulgarian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Bulgarian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Bulgarian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Bulgarian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Bulgarian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Bulgarian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Bulgarian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Bulgarian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Bulgarian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Bulgarian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Bulgarian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Bulgarian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Bulgarian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Bulgarian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsdiagnoses_report["Catalan"] = array();
	$fieldToolTipsdiagnoses_report["Catalan"] = array();
	$placeHoldersdiagnoses_report["Catalan"] = array();
	$pageTitlesdiagnoses_report["Catalan"] = array();
	$fieldLabelsdiagnoses_report["Catalan"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Catalan"]["id"] = "";
	$placeHoldersdiagnoses_report["Catalan"]["id"] = "";
	$fieldLabelsdiagnoses_report["Catalan"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Catalan"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Catalan"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Catalan"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Catalan"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Catalan"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Catalan"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Catalan"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Catalan"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Catalan"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Catalan"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Catalan"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Catalan"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Catalan"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Catalan"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Catalan"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Catalan"]["Result"] = "";
	$placeHoldersdiagnoses_report["Catalan"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Catalan"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsdiagnoses_report["Chinese"] = array();
	$fieldToolTipsdiagnoses_report["Chinese"] = array();
	$placeHoldersdiagnoses_report["Chinese"] = array();
	$pageTitlesdiagnoses_report["Chinese"] = array();
	$fieldLabelsdiagnoses_report["Chinese"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Chinese"]["id"] = "";
	$placeHoldersdiagnoses_report["Chinese"]["id"] = "";
	$fieldLabelsdiagnoses_report["Chinese"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Chinese"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Chinese"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Chinese"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Chinese"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Chinese"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Chinese"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Chinese"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Chinese"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Chinese"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Chinese"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Chinese"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Chinese"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Chinese"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Chinese"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Chinese"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Chinese"]["Result"] = "";
	$placeHoldersdiagnoses_report["Chinese"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Chinese"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesdiagnoses_report["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Result"] = "";
	$placeHoldersdiagnoses_report["Chinese (Hong Kong S.A.R.)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Chinese (Hong Kong S.A.R.)"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"] = array();
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"] = array();
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"] = array();
	$pageTitlesdiagnoses_report["Chinese (Taiwan)"] = array();
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Chinese (Taiwan)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]["Result"] = "";
	$placeHoldersdiagnoses_report["Chinese (Taiwan)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Chinese (Taiwan)"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsdiagnoses_report["Croatian"] = array();
	$fieldToolTipsdiagnoses_report["Croatian"] = array();
	$placeHoldersdiagnoses_report["Croatian"] = array();
	$pageTitlesdiagnoses_report["Croatian"] = array();
	$fieldLabelsdiagnoses_report["Croatian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Croatian"]["id"] = "";
	$placeHoldersdiagnoses_report["Croatian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Croatian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Croatian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Croatian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Croatian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Croatian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Croatian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Croatian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Croatian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Croatian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Croatian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Croatian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Croatian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Croatian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Croatian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Croatian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Croatian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Croatian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Croatian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Croatian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsdiagnoses_report["Czech"] = array();
	$fieldToolTipsdiagnoses_report["Czech"] = array();
	$placeHoldersdiagnoses_report["Czech"] = array();
	$pageTitlesdiagnoses_report["Czech"] = array();
	$fieldLabelsdiagnoses_report["Czech"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Czech"]["id"] = "";
	$placeHoldersdiagnoses_report["Czech"]["id"] = "";
	$fieldLabelsdiagnoses_report["Czech"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Czech"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Czech"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Czech"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Czech"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Czech"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Czech"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Czech"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Czech"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Czech"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Czech"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Czech"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Czech"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Czech"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Czech"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Czech"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Czech"]["Result"] = "";
	$placeHoldersdiagnoses_report["Czech"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Czech"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsdiagnoses_report["Danish"] = array();
	$fieldToolTipsdiagnoses_report["Danish"] = array();
	$placeHoldersdiagnoses_report["Danish"] = array();
	$pageTitlesdiagnoses_report["Danish"] = array();
	$fieldLabelsdiagnoses_report["Danish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Danish"]["id"] = "";
	$placeHoldersdiagnoses_report["Danish"]["id"] = "";
	$fieldLabelsdiagnoses_report["Danish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Danish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Danish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Danish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Danish"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Danish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Danish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Danish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Danish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Danish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Danish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Danish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Danish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Danish"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Danish"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Danish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Danish"]["Result"] = "";
	$placeHoldersdiagnoses_report["Danish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Danish"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsdiagnoses_report["Dutch"] = array();
	$fieldToolTipsdiagnoses_report["Dutch"] = array();
	$placeHoldersdiagnoses_report["Dutch"] = array();
	$pageTitlesdiagnoses_report["Dutch"] = array();
	$fieldLabelsdiagnoses_report["Dutch"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Dutch"]["id"] = "";
	$placeHoldersdiagnoses_report["Dutch"]["id"] = "";
	$fieldLabelsdiagnoses_report["Dutch"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Dutch"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Dutch"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Dutch"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Dutch"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Dutch"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Dutch"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Dutch"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Dutch"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Dutch"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Dutch"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Dutch"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Dutch"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Dutch"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Dutch"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Dutch"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Dutch"]["Result"] = "";
	$placeHoldersdiagnoses_report["Dutch"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Dutch"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsdiagnoses_report["Farsi"] = array();
	$fieldToolTipsdiagnoses_report["Farsi"] = array();
	$placeHoldersdiagnoses_report["Farsi"] = array();
	$pageTitlesdiagnoses_report["Farsi"] = array();
	$fieldLabelsdiagnoses_report["Farsi"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Farsi"]["id"] = "";
	$placeHoldersdiagnoses_report["Farsi"]["id"] = "";
	$fieldLabelsdiagnoses_report["Farsi"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Farsi"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Farsi"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Farsi"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Farsi"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Farsi"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Farsi"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Farsi"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Farsi"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Farsi"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Farsi"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Farsi"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Farsi"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Farsi"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Farsi"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Farsi"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Farsi"]["Result"] = "";
	$placeHoldersdiagnoses_report["Farsi"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Farsi"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsdiagnoses_report["French"] = array();
	$fieldToolTipsdiagnoses_report["French"] = array();
	$placeHoldersdiagnoses_report["French"] = array();
	$pageTitlesdiagnoses_report["French"] = array();
	$fieldLabelsdiagnoses_report["French"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["French"]["id"] = "";
	$placeHoldersdiagnoses_report["French"]["id"] = "";
	$fieldLabelsdiagnoses_report["French"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["French"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["French"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["French"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["French"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["French"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["French"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["French"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["French"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["French"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["French"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["French"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["French"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["French"]["Photo"] = "";
	$placeHoldersdiagnoses_report["French"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["French"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["French"]["Result"] = "";
	$placeHoldersdiagnoses_report["French"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["French"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsdiagnoses_report["Georgian"] = array();
	$fieldToolTipsdiagnoses_report["Georgian"] = array();
	$placeHoldersdiagnoses_report["Georgian"] = array();
	$pageTitlesdiagnoses_report["Georgian"] = array();
	$fieldLabelsdiagnoses_report["Georgian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Georgian"]["id"] = "";
	$placeHoldersdiagnoses_report["Georgian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Georgian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Georgian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Georgian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Georgian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Georgian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Georgian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Georgian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Georgian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Georgian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Georgian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Georgian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Georgian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Georgian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Georgian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Georgian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Georgian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Georgian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Georgian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Georgian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsdiagnoses_report["German"] = array();
	$fieldToolTipsdiagnoses_report["German"] = array();
	$placeHoldersdiagnoses_report["German"] = array();
	$pageTitlesdiagnoses_report["German"] = array();
	$fieldLabelsdiagnoses_report["German"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["German"]["id"] = "";
	$placeHoldersdiagnoses_report["German"]["id"] = "";
	$fieldLabelsdiagnoses_report["German"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["German"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["German"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["German"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["German"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["German"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["German"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["German"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["German"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["German"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["German"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["German"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["German"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["German"]["Photo"] = "";
	$placeHoldersdiagnoses_report["German"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["German"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["German"]["Result"] = "";
	$placeHoldersdiagnoses_report["German"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["German"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsdiagnoses_report["Greek"] = array();
	$fieldToolTipsdiagnoses_report["Greek"] = array();
	$placeHoldersdiagnoses_report["Greek"] = array();
	$pageTitlesdiagnoses_report["Greek"] = array();
	$fieldLabelsdiagnoses_report["Greek"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Greek"]["id"] = "";
	$placeHoldersdiagnoses_report["Greek"]["id"] = "";
	$fieldLabelsdiagnoses_report["Greek"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Greek"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Greek"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Greek"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Greek"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Greek"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Greek"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Greek"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Greek"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Greek"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Greek"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Greek"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Greek"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Greek"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Greek"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Greek"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Greek"]["Result"] = "";
	$placeHoldersdiagnoses_report["Greek"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Greek"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsdiagnoses_report["Hebrew"] = array();
	$fieldToolTipsdiagnoses_report["Hebrew"] = array();
	$placeHoldersdiagnoses_report["Hebrew"] = array();
	$pageTitlesdiagnoses_report["Hebrew"] = array();
	$fieldLabelsdiagnoses_report["Hebrew"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Hebrew"]["id"] = "";
	$placeHoldersdiagnoses_report["Hebrew"]["id"] = "";
	$fieldLabelsdiagnoses_report["Hebrew"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Hebrew"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Hebrew"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Hebrew"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Hebrew"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Hebrew"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Hebrew"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Hebrew"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Hebrew"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Hebrew"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Hebrew"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Hebrew"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Hebrew"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Hebrew"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Hebrew"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Hebrew"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Hebrew"]["Result"] = "";
	$placeHoldersdiagnoses_report["Hebrew"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Hebrew"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsdiagnoses_report["Hungarian"] = array();
	$fieldToolTipsdiagnoses_report["Hungarian"] = array();
	$placeHoldersdiagnoses_report["Hungarian"] = array();
	$pageTitlesdiagnoses_report["Hungarian"] = array();
	$fieldLabelsdiagnoses_report["Hungarian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Hungarian"]["id"] = "";
	$placeHoldersdiagnoses_report["Hungarian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Hungarian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Hungarian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Hungarian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Hungarian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Hungarian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Hungarian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Hungarian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Hungarian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Hungarian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Hungarian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Hungarian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Hungarian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Hungarian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Hungarian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Hungarian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Hungarian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Hungarian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Hungarian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Hungarian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsdiagnoses_report["Indonesian"] = array();
	$fieldToolTipsdiagnoses_report["Indonesian"] = array();
	$placeHoldersdiagnoses_report["Indonesian"] = array();
	$pageTitlesdiagnoses_report["Indonesian"] = array();
	$fieldLabelsdiagnoses_report["Indonesian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Indonesian"]["id"] = "";
	$placeHoldersdiagnoses_report["Indonesian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Indonesian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Indonesian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Indonesian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Indonesian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Indonesian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Indonesian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Indonesian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Indonesian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Indonesian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Indonesian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Indonesian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Indonesian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Indonesian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Indonesian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Indonesian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Indonesian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Indonesian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Indonesian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Indonesian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsdiagnoses_report["Italian"] = array();
	$fieldToolTipsdiagnoses_report["Italian"] = array();
	$placeHoldersdiagnoses_report["Italian"] = array();
	$pageTitlesdiagnoses_report["Italian"] = array();
	$fieldLabelsdiagnoses_report["Italian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Italian"]["id"] = "";
	$placeHoldersdiagnoses_report["Italian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Italian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Italian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Italian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Italian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Italian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Italian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Italian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Italian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Italian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Italian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Italian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Italian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Italian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Italian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Italian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Italian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Italian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Italian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Italian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsdiagnoses_report["Japanese"] = array();
	$fieldToolTipsdiagnoses_report["Japanese"] = array();
	$placeHoldersdiagnoses_report["Japanese"] = array();
	$pageTitlesdiagnoses_report["Japanese"] = array();
	$fieldLabelsdiagnoses_report["Japanese"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Japanese"]["id"] = "";
	$placeHoldersdiagnoses_report["Japanese"]["id"] = "";
	$fieldLabelsdiagnoses_report["Japanese"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Japanese"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Japanese"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Japanese"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Japanese"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Japanese"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Japanese"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Japanese"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Japanese"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Japanese"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Japanese"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Japanese"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Japanese"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Japanese"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Japanese"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Japanese"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Japanese"]["Result"] = "";
	$placeHoldersdiagnoses_report["Japanese"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Japanese"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsdiagnoses_report["Malay"] = array();
	$fieldToolTipsdiagnoses_report["Malay"] = array();
	$placeHoldersdiagnoses_report["Malay"] = array();
	$pageTitlesdiagnoses_report["Malay"] = array();
	$fieldLabelsdiagnoses_report["Malay"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Malay"]["id"] = "";
	$placeHoldersdiagnoses_report["Malay"]["id"] = "";
	$fieldLabelsdiagnoses_report["Malay"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Malay"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Malay"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Malay"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Malay"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Malay"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Malay"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Malay"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Malay"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Malay"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Malay"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Malay"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Malay"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Malay"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Malay"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Malay"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Malay"]["Result"] = "";
	$placeHoldersdiagnoses_report["Malay"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Malay"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"] = array();
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"] = array();
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"] = array();
	$pageTitlesdiagnoses_report["Norwegian(Bokmal)"] = array();
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Norwegian(Bokmal)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]["Result"] = "";
	$placeHoldersdiagnoses_report["Norwegian(Bokmal)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Norwegian(Bokmal)"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsdiagnoses_report["Polish"] = array();
	$fieldToolTipsdiagnoses_report["Polish"] = array();
	$placeHoldersdiagnoses_report["Polish"] = array();
	$pageTitlesdiagnoses_report["Polish"] = array();
	$fieldLabelsdiagnoses_report["Polish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Polish"]["id"] = "";
	$placeHoldersdiagnoses_report["Polish"]["id"] = "";
	$fieldLabelsdiagnoses_report["Polish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Polish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Polish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Polish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Polish"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Polish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Polish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Polish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Polish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Polish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Polish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Polish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Polish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Polish"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Polish"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Polish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Polish"]["Result"] = "";
	$placeHoldersdiagnoses_report["Polish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Polish"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"] = array();
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"] = array();
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"] = array();
	$pageTitlesdiagnoses_report["Portuguese(Brazil)"] = array();
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Brazil)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]["Result"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Brazil)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Portuguese(Brazil)"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"] = array();
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"] = array();
	$placeHoldersdiagnoses_report["Portuguese(Standard)"] = array();
	$pageTitlesdiagnoses_report["Portuguese(Standard)"] = array();
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"]["id"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Standard)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Standard)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Standard)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Standard)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Standard)"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Portuguese(Standard)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Portuguese(Standard)"]["Result"] = "";
	$placeHoldersdiagnoses_report["Portuguese(Standard)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Portuguese(Standard)"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsdiagnoses_report["Romanian"] = array();
	$fieldToolTipsdiagnoses_report["Romanian"] = array();
	$placeHoldersdiagnoses_report["Romanian"] = array();
	$pageTitlesdiagnoses_report["Romanian"] = array();
	$fieldLabelsdiagnoses_report["Romanian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Romanian"]["id"] = "";
	$placeHoldersdiagnoses_report["Romanian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Romanian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Romanian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Romanian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Romanian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Romanian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Romanian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Romanian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Romanian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Romanian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Romanian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Romanian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Romanian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Romanian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Romanian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Romanian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Romanian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Romanian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Romanian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Romanian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsdiagnoses_report["Russian"] = array();
	$fieldToolTipsdiagnoses_report["Russian"] = array();
	$placeHoldersdiagnoses_report["Russian"] = array();
	$pageTitlesdiagnoses_report["Russian"] = array();
	$fieldLabelsdiagnoses_report["Russian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Russian"]["id"] = "";
	$placeHoldersdiagnoses_report["Russian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Russian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Russian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Russian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Russian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Russian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Russian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Russian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Russian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Russian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Russian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Russian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Russian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Russian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Russian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Russian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Russian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Russian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Russian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Russian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsdiagnoses_report["Serbian"] = array();
	$fieldToolTipsdiagnoses_report["Serbian"] = array();
	$placeHoldersdiagnoses_report["Serbian"] = array();
	$pageTitlesdiagnoses_report["Serbian"] = array();
	$fieldLabelsdiagnoses_report["Serbian"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Serbian"]["id"] = "";
	$placeHoldersdiagnoses_report["Serbian"]["id"] = "";
	$fieldLabelsdiagnoses_report["Serbian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Serbian"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Serbian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Serbian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Serbian"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Serbian"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Serbian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Serbian"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Serbian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Serbian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Serbian"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Serbian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Serbian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Serbian"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Serbian"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Serbian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Serbian"]["Result"] = "";
	$placeHoldersdiagnoses_report["Serbian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Serbian"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsdiagnoses_report["Slovak"] = array();
	$fieldToolTipsdiagnoses_report["Slovak"] = array();
	$placeHoldersdiagnoses_report["Slovak"] = array();
	$pageTitlesdiagnoses_report["Slovak"] = array();
	$fieldLabelsdiagnoses_report["Slovak"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Slovak"]["id"] = "";
	$placeHoldersdiagnoses_report["Slovak"]["id"] = "";
	$fieldLabelsdiagnoses_report["Slovak"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Slovak"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Slovak"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Slovak"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Slovak"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Slovak"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Slovak"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Slovak"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Slovak"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Slovak"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Slovak"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Slovak"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Slovak"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Slovak"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Slovak"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Slovak"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Slovak"]["Result"] = "";
	$placeHoldersdiagnoses_report["Slovak"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Slovak"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsdiagnoses_report["Spanish"] = array();
	$fieldToolTipsdiagnoses_report["Spanish"] = array();
	$placeHoldersdiagnoses_report["Spanish"] = array();
	$pageTitlesdiagnoses_report["Spanish"] = array();
	$fieldLabelsdiagnoses_report["Spanish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Spanish"]["id"] = "";
	$placeHoldersdiagnoses_report["Spanish"]["id"] = "";
	$fieldLabelsdiagnoses_report["Spanish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Spanish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Spanish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Spanish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Spanish"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Spanish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Spanish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Spanish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Spanish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Spanish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Spanish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Spanish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Spanish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Spanish"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Spanish"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Spanish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Spanish"]["Result"] = "";
	$placeHoldersdiagnoses_report["Spanish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Spanish"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsdiagnoses_report["Swedish"] = array();
	$fieldToolTipsdiagnoses_report["Swedish"] = array();
	$placeHoldersdiagnoses_report["Swedish"] = array();
	$pageTitlesdiagnoses_report["Swedish"] = array();
	$fieldLabelsdiagnoses_report["Swedish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Swedish"]["id"] = "";
	$placeHoldersdiagnoses_report["Swedish"]["id"] = "";
	$fieldLabelsdiagnoses_report["Swedish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Swedish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Swedish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Swedish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Swedish"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Swedish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Swedish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Swedish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Swedish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Swedish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Swedish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Swedish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Swedish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Swedish"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Swedish"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Swedish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Swedish"]["Result"] = "";
	$placeHoldersdiagnoses_report["Swedish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Swedish"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"] = array();
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"] = array();
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"] = array();
	$pageTitlesdiagnoses_report["Tagalog(Philippines)"] = array();
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Tagalog(Philippines)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]["Result"] = "";
	$placeHoldersdiagnoses_report["Tagalog(Philippines)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Tagalog(Philippines)"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsdiagnoses_report["Thai"] = array();
	$fieldToolTipsdiagnoses_report["Thai"] = array();
	$placeHoldersdiagnoses_report["Thai"] = array();
	$pageTitlesdiagnoses_report["Thai"] = array();
	$fieldLabelsdiagnoses_report["Thai"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Thai"]["id"] = "";
	$placeHoldersdiagnoses_report["Thai"]["id"] = "";
	$fieldLabelsdiagnoses_report["Thai"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Thai"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Thai"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Thai"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Thai"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Thai"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Thai"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Thai"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Thai"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Thai"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Thai"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Thai"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Thai"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Thai"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Thai"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Thai"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Thai"]["Result"] = "";
	$placeHoldersdiagnoses_report["Thai"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Thai"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsdiagnoses_report["Turkish"] = array();
	$fieldToolTipsdiagnoses_report["Turkish"] = array();
	$placeHoldersdiagnoses_report["Turkish"] = array();
	$pageTitlesdiagnoses_report["Turkish"] = array();
	$fieldLabelsdiagnoses_report["Turkish"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Turkish"]["id"] = "";
	$placeHoldersdiagnoses_report["Turkish"]["id"] = "";
	$fieldLabelsdiagnoses_report["Turkish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Turkish"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Turkish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Turkish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Turkish"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Turkish"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Turkish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Turkish"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Turkish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Turkish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Turkish"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Turkish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Turkish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Turkish"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Turkish"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Turkish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Turkish"]["Result"] = "";
	$placeHoldersdiagnoses_report["Turkish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Turkish"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsdiagnoses_report["Urdu"] = array();
	$fieldToolTipsdiagnoses_report["Urdu"] = array();
	$placeHoldersdiagnoses_report["Urdu"] = array();
	$pageTitlesdiagnoses_report["Urdu"] = array();
	$fieldLabelsdiagnoses_report["Urdu"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Urdu"]["id"] = "";
	$placeHoldersdiagnoses_report["Urdu"]["id"] = "";
	$fieldLabelsdiagnoses_report["Urdu"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Urdu"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Urdu"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Urdu"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Urdu"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Urdu"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Urdu"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Urdu"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Urdu"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Urdu"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Urdu"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Urdu"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Urdu"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Urdu"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Urdu"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Urdu"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Urdu"]["Result"] = "";
	$placeHoldersdiagnoses_report["Urdu"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Urdu"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsdiagnoses_report["Welsh"] = array();
	$fieldToolTipsdiagnoses_report["Welsh"] = array();
	$placeHoldersdiagnoses_report["Welsh"] = array();
	$pageTitlesdiagnoses_report["Welsh"] = array();
	$fieldLabelsdiagnoses_report["Welsh"]["id"] = "Id";
	$fieldToolTipsdiagnoses_report["Welsh"]["id"] = "";
	$placeHoldersdiagnoses_report["Welsh"]["id"] = "";
	$fieldLabelsdiagnoses_report["Welsh"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses_report["Welsh"]["TakenTime"] = "";
	$placeHoldersdiagnoses_report["Welsh"]["TakenTime"] = "";
	$fieldLabelsdiagnoses_report["Welsh"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses_report["Welsh"]["Quantity"] = "";
	$placeHoldersdiagnoses_report["Welsh"]["Quantity"] = "";
	$fieldLabelsdiagnoses_report["Welsh"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses_report["Welsh"]["treatment_id"] = "";
	$placeHoldersdiagnoses_report["Welsh"]["treatment_id"] = "";
	$fieldLabelsdiagnoses_report["Welsh"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses_report["Welsh"]["medicine_id"] = "";
	$placeHoldersdiagnoses_report["Welsh"]["medicine_id"] = "";
	$fieldLabelsdiagnoses_report["Welsh"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses_report["Welsh"]["Photo"] = "";
	$placeHoldersdiagnoses_report["Welsh"]["Photo"] = "";
	$fieldLabelsdiagnoses_report["Welsh"]["Result"] = "Result";
	$fieldToolTipsdiagnoses_report["Welsh"]["Result"] = "";
	$placeHoldersdiagnoses_report["Welsh"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses_report["Welsh"]))
		$tdatadiagnoses_report[".isUseToolTips"] = true;
}


	$tdatadiagnoses_report[".NCSearch"] = true;



$tdatadiagnoses_report[".shortTableName"] = "diagnoses_report";
$tdatadiagnoses_report[".nSecOptions"] = 0;

$tdatadiagnoses_report[".mainTableOwnerID"] = "";
$tdatadiagnoses_report[".entityType"] = 2;
$tdatadiagnoses_report[".connId"] = "testdb_at_localhost";


$tdatadiagnoses_report[".strOriginalTableName"] = "diagnoses";

	



$tdatadiagnoses_report[".showAddInPopup"] = false;

$tdatadiagnoses_report[".showEditInPopup"] = false;

$tdatadiagnoses_report[".showViewInPopup"] = false;

$tdatadiagnoses_report[".listAjax"] = false;
//	temporary
//$tdatadiagnoses_report[".listAjax"] = false;

	$tdatadiagnoses_report[".audit"] = false;

	$tdatadiagnoses_report[".locking"] = false;


$pages = $tdatadiagnoses_report[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatadiagnoses_report[".edit"] = true;
	$tdatadiagnoses_report[".afterEditAction"] = 1;
	$tdatadiagnoses_report[".closePopupAfterEdit"] = 1;
	$tdatadiagnoses_report[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatadiagnoses_report[".add"] = true;
$tdatadiagnoses_report[".afterAddAction"] = 1;
$tdatadiagnoses_report[".closePopupAfterAdd"] = 1;
$tdatadiagnoses_report[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatadiagnoses_report[".list"] = true;
}



$tdatadiagnoses_report[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatadiagnoses_report[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatadiagnoses_report[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatadiagnoses_report[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatadiagnoses_report[".printFriendly"] = true;
}



$tdatadiagnoses_report[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatadiagnoses_report[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatadiagnoses_report[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatadiagnoses_report[".isUseAjaxSuggest"] = true;





$tdatadiagnoses_report[".ajaxCodeSnippetAdded"] = false;

$tdatadiagnoses_report[".buttonsAdded"] = false;

$tdatadiagnoses_report[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadiagnoses_report[".isUseTimeForSearch"] = false;


$tdatadiagnoses_report[".badgeColor"] = "3CB371";


$tdatadiagnoses_report[".allSearchFields"] = array();
$tdatadiagnoses_report[".filterFields"] = array();
$tdatadiagnoses_report[".requiredSearchFields"] = array();

$tdatadiagnoses_report[".googleLikeFields"] = array();
$tdatadiagnoses_report[".googleLikeFields"][] = "id";
$tdatadiagnoses_report[".googleLikeFields"][] = "TakenTime";
$tdatadiagnoses_report[".googleLikeFields"][] = "Quantity";
$tdatadiagnoses_report[".googleLikeFields"][] = "treatment_id";
$tdatadiagnoses_report[".googleLikeFields"][] = "medicine_id";
$tdatadiagnoses_report[".googleLikeFields"][] = "Photo";
$tdatadiagnoses_report[".googleLikeFields"][] = "Result";



$tdatadiagnoses_report[".tableType"] = "report";

$tdatadiagnoses_report[".printerPageOrientation"] = 0;
$tdatadiagnoses_report[".nPrinterPageScale"] = 100;

$tdatadiagnoses_report[".nPrinterSplitRecords"] = 40;

$tdatadiagnoses_report[".geocodingEnabled"] = false;

//report settings

$tdatadiagnoses_report[".reportPrintGroupsPerPage"] = 3;
$tdatadiagnoses_report[".reportPrintRecordsPerPage"] = 40;

$tdatadiagnoses_report[".pageSizeGroups"] = 5;
$tdatadiagnoses_report[".pageSizeRecords"] = 20;


//end of report settings










$tstrOrderBy = "";
$tdatadiagnoses_report[".strOrderBy"] = $tstrOrderBy;

$tdatadiagnoses_report[".orderindexes"] = array();


$tdatadiagnoses_report[".sqlHead"] = "SELECT id,  	TakenTime,  	Quantity,  	treatment_id,  	medicine_id,  	Photo,  	`Result`";
$tdatadiagnoses_report[".sqlFrom"] = "FROM diagnoses";
$tdatadiagnoses_report[".sqlWhereExpr"] = "";
$tdatadiagnoses_report[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadiagnoses_report[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadiagnoses_report[".arrGroupsPerPage"] = $arrGPP;

$tdatadiagnoses_report[".highlightSearchResults"] = true;

$tableKeysdiagnoses_report = array();
$tableKeysdiagnoses_report[] = "id";
$tdatadiagnoses_report[".Keys"] = $tableKeysdiagnoses_report;


$tdatadiagnoses_report[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Report","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_report["id"] = $fdata;
		$tdatadiagnoses_report[".searchableFields"][] = "id";
//	TakenTime
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "TakenTime";
	$fdata["GoodName"] = "TakenTime";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Report","TakenTime");
	$fdata["FieldType"] = 135;


	
	
			

		$fdata["strField"] = "TakenTime";

		$fdata["sourceSingle"] = "TakenTime";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TakenTime";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_report["TakenTime"] = $fdata;
		$tdatadiagnoses_report[".searchableFields"][] = "TakenTime";
//	Quantity
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Quantity";
	$fdata["GoodName"] = "Quantity";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Report","Quantity");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "Quantity";

		$fdata["sourceSingle"] = "Quantity";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Quantity";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_report["Quantity"] = $fdata;
		$tdatadiagnoses_report[".searchableFields"][] = "Quantity";
//	treatment_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "treatment_id";
	$fdata["GoodName"] = "treatment_id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Report","treatment_id");
	$fdata["FieldType"] = 20;


	
	
			

		$fdata["strField"] = "treatment_id";

		$fdata["sourceSingle"] = "treatment_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "treatment_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "treatments";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "id";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_report["treatment_id"] = $fdata;
		$tdatadiagnoses_report[".searchableFields"][] = "treatment_id";
//	medicine_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "medicine_id";
	$fdata["GoodName"] = "medicine_id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Report","medicine_id");
	$fdata["FieldType"] = 20;


	
	
			

		$fdata["strField"] = "medicine_id";

		$fdata["sourceSingle"] = "medicine_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "medicine_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "medicines";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "MedicineName";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_report["medicine_id"] = $fdata;
		$tdatadiagnoses_report[".searchableFields"][] = "medicine_id";
//	Photo
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Photo";
	$fdata["GoodName"] = "Photo";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Report","Photo");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Photo";

		$fdata["sourceSingle"] = "Photo";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Photo";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "File-based Image");

	
	
				$vdata["ImageWidth"] = 600;
	$vdata["ImageHeight"] = 400;

			$vdata["multipleImgMode"] = 1;
	$vdata["maxImages"] = 0;

			$vdata["showGallery"] = true;
	$vdata["galleryMode"] = 2;
	$vdata["captionMode"] = 2;
	$vdata["captionField"] = "";

	$vdata["imageBorder"] = 1;
	$vdata["imageFullWidth"] = 1;


	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_report["Photo"] = $fdata;
		$tdatadiagnoses_report[".searchableFields"][] = "Photo";
//	Result
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "Result";
	$fdata["GoodName"] = "Result";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses_Report","Result");
	$fdata["FieldType"] = 129;


	
	
			

		$fdata["strField"] = "Result";

		$fdata["sourceSingle"] = "Result";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Result`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
		$edata["LookupType"] = 0;
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 3;

	
	
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "Disease";
	$edata["LookupValues"][] = "Injury";
	$edata["LookupValues"][] = "Normal";
	$edata["LookupValues"][] = "";

		$edata["Multiselect"] = true;

	
// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses_report["Result"] = $fdata;
		$tdatadiagnoses_report[".searchableFields"][] = "Result";


$tables_data["diagnoses Report"]=&$tdatadiagnoses_report;
$field_labels["diagnoses_Report"] = &$fieldLabelsdiagnoses_report;
$fieldToolTips["diagnoses_Report"] = &$fieldToolTipsdiagnoses_report;
$placeHolders["diagnoses_Report"] = &$placeHoldersdiagnoses_report;
$page_titles["diagnoses_Report"] = &$pageTitlesdiagnoses_report;


changeTextControlsToDate( "diagnoses Report" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["diagnoses Report"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["diagnoses Report"] = array();



	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="medicines";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="medicines";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "medicines";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["diagnoses Report"][0] = $masterParams;
				$masterTablesData["diagnoses Report"][0]["masterKeys"] = array();
	$masterTablesData["diagnoses Report"][0]["masterKeys"][]="id";
				$masterTablesData["diagnoses Report"][0]["detailKeys"] = array();
	$masterTablesData["diagnoses Report"][0]["detailKeys"][]="medicine_id";
		
	//endif
	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="treatments";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="treatments";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "treatments";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["diagnoses Report"][1] = $masterParams;
				$masterTablesData["diagnoses Report"][1]["masterKeys"] = array();
	$masterTablesData["diagnoses Report"][1]["masterKeys"][]="id";
				$masterTablesData["diagnoses Report"][1]["detailKeys"] = array();
	$masterTablesData["diagnoses Report"][1]["detailKeys"][]="treatment_id";
		
	//endif
// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_diagnoses_report()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	TakenTime,  	Quantity,  	treatment_id,  	medicine_id,  	Photo,  	`Result`";
$proto0["m_strFrom"] = "FROM diagnoses";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Report"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "diagnoses Report";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "TakenTime",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Report"
));

$proto8["m_sql"] = "TakenTime";
$proto8["m_srcTableName"] = "diagnoses Report";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Quantity",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Report"
));

$proto10["m_sql"] = "Quantity";
$proto10["m_srcTableName"] = "diagnoses Report";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "treatment_id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Report"
));

$proto12["m_sql"] = "treatment_id";
$proto12["m_srcTableName"] = "diagnoses Report";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "medicine_id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Report"
));

$proto14["m_sql"] = "medicine_id";
$proto14["m_srcTableName"] = "diagnoses Report";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "Photo",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Report"
));

$proto16["m_sql"] = "Photo";
$proto16["m_srcTableName"] = "diagnoses Report";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "Result",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses Report"
));

$proto18["m_sql"] = "`Result`";
$proto18["m_srcTableName"] = "diagnoses Report";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto20=array();
$proto20["m_link"] = "SQLL_MAIN";
			$proto21=array();
$proto21["m_strName"] = "diagnoses";
$proto21["m_srcTableName"] = "diagnoses Report";
$proto21["m_columns"] = array();
$proto21["m_columns"][] = "id";
$proto21["m_columns"][] = "TakenTime";
$proto21["m_columns"][] = "Quantity";
$proto21["m_columns"][] = "treatment_id";
$proto21["m_columns"][] = "medicine_id";
$proto21["m_columns"][] = "Photo";
$proto21["m_columns"][] = "Result";
$obj = new SQLTable($proto21);

$proto20["m_table"] = $obj;
$proto20["m_sql"] = "diagnoses";
$proto20["m_alias"] = "";
$proto20["m_srcTableName"] = "diagnoses Report";
$proto22=array();
$proto22["m_sql"] = "";
$proto22["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto22["m_column"]=$obj;
$proto22["m_contained"] = array();
$proto22["m_strCase"] = "";
$proto22["m_havingmode"] = false;
$proto22["m_inBrackets"] = false;
$proto22["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto22);

$proto20["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto20);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="diagnoses Report";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_diagnoses_report = createSqlQuery_diagnoses_report();


	
		;

							

$tdatadiagnoses_report[".sqlquery"] = $queryData_diagnoses_report;



$tdatadiagnoses_report[".hasEvents"] = false;

?>