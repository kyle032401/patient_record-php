<?php
$tdatadoctors = array();
$tdatadoctors[".searchableFields"] = array();
$tdatadoctors[".ShortName"] = "doctors";
$tdatadoctors[".OwnerID"] = "";
$tdatadoctors[".OriginalTable"] = "doctors";


$tdatadoctors[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatadoctors[".originalPagesByType"] = $tdatadoctors[".pagesByType"];
$tdatadoctors[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatadoctors[".originalPages"] = $tdatadoctors[".pages"];
$tdatadoctors[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"masterlist\":\"masterlist\",\"masterprint\":\"masterprint\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatadoctors[".originalDefaultPages"] = $tdatadoctors[".defaultPages"];

//	field labels
$fieldLabelsdoctors = array();
$fieldToolTipsdoctors = array();
$pageTitlesdoctors = array();
$placeHoldersdoctors = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdoctors["English"] = array();
	$fieldToolTipsdoctors["English"] = array();
	$placeHoldersdoctors["English"] = array();
	$pageTitlesdoctors["English"] = array();
	$fieldLabelsdoctors["English"]["id"] = "Id";
	$fieldToolTipsdoctors["English"]["id"] = "";
	$placeHoldersdoctors["English"]["id"] = "";
	$fieldLabelsdoctors["English"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["English"]["DoctorName"] = "";
	$placeHoldersdoctors["English"]["DoctorName"] = "";
	$fieldLabelsdoctors["English"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["English"]["ContactNumber"] = "";
	$placeHoldersdoctors["English"]["ContactNumber"] = "";
	$fieldLabelsdoctors["English"]["Email"] = "Email";
	$fieldToolTipsdoctors["English"]["Email"] = "";
	$placeHoldersdoctors["English"]["Email"] = "";
	$fieldLabelsdoctors["English"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["English"]["Photo"] = "";
	$placeHoldersdoctors["English"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["English"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsdoctors["Afrikaans"] = array();
	$fieldToolTipsdoctors["Afrikaans"] = array();
	$placeHoldersdoctors["Afrikaans"] = array();
	$pageTitlesdoctors["Afrikaans"] = array();
	$fieldLabelsdoctors["Afrikaans"]["id"] = "Id";
	$fieldToolTipsdoctors["Afrikaans"]["id"] = "";
	$placeHoldersdoctors["Afrikaans"]["id"] = "";
	$fieldLabelsdoctors["Afrikaans"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Afrikaans"]["DoctorName"] = "";
	$placeHoldersdoctors["Afrikaans"]["DoctorName"] = "";
	$fieldLabelsdoctors["Afrikaans"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Afrikaans"]["ContactNumber"] = "";
	$placeHoldersdoctors["Afrikaans"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Afrikaans"]["Email"] = "Email";
	$fieldToolTipsdoctors["Afrikaans"]["Email"] = "";
	$placeHoldersdoctors["Afrikaans"]["Email"] = "";
	$fieldLabelsdoctors["Afrikaans"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Afrikaans"]["Photo"] = "";
	$placeHoldersdoctors["Afrikaans"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Afrikaans"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsdoctors["Arabic"] = array();
	$fieldToolTipsdoctors["Arabic"] = array();
	$placeHoldersdoctors["Arabic"] = array();
	$pageTitlesdoctors["Arabic"] = array();
	$fieldLabelsdoctors["Arabic"]["id"] = "Id";
	$fieldToolTipsdoctors["Arabic"]["id"] = "";
	$placeHoldersdoctors["Arabic"]["id"] = "";
	$fieldLabelsdoctors["Arabic"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Arabic"]["DoctorName"] = "";
	$placeHoldersdoctors["Arabic"]["DoctorName"] = "";
	$fieldLabelsdoctors["Arabic"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Arabic"]["ContactNumber"] = "";
	$placeHoldersdoctors["Arabic"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Arabic"]["Email"] = "Email";
	$fieldToolTipsdoctors["Arabic"]["Email"] = "";
	$placeHoldersdoctors["Arabic"]["Email"] = "";
	$fieldLabelsdoctors["Arabic"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Arabic"]["Photo"] = "";
	$placeHoldersdoctors["Arabic"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Arabic"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsdoctors["Bosnian"] = array();
	$fieldToolTipsdoctors["Bosnian"] = array();
	$placeHoldersdoctors["Bosnian"] = array();
	$pageTitlesdoctors["Bosnian"] = array();
	$fieldLabelsdoctors["Bosnian"]["id"] = "Id";
	$fieldToolTipsdoctors["Bosnian"]["id"] = "";
	$placeHoldersdoctors["Bosnian"]["id"] = "";
	$fieldLabelsdoctors["Bosnian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Bosnian"]["DoctorName"] = "";
	$placeHoldersdoctors["Bosnian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Bosnian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Bosnian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Bosnian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Bosnian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Bosnian"]["Email"] = "";
	$placeHoldersdoctors["Bosnian"]["Email"] = "";
	$fieldLabelsdoctors["Bosnian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Bosnian"]["Photo"] = "";
	$placeHoldersdoctors["Bosnian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Bosnian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsdoctors["Bulgarian"] = array();
	$fieldToolTipsdoctors["Bulgarian"] = array();
	$placeHoldersdoctors["Bulgarian"] = array();
	$pageTitlesdoctors["Bulgarian"] = array();
	$fieldLabelsdoctors["Bulgarian"]["id"] = "Id";
	$fieldToolTipsdoctors["Bulgarian"]["id"] = "";
	$placeHoldersdoctors["Bulgarian"]["id"] = "";
	$fieldLabelsdoctors["Bulgarian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Bulgarian"]["DoctorName"] = "";
	$placeHoldersdoctors["Bulgarian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Bulgarian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Bulgarian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Bulgarian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Bulgarian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Bulgarian"]["Email"] = "";
	$placeHoldersdoctors["Bulgarian"]["Email"] = "";
	$fieldLabelsdoctors["Bulgarian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Bulgarian"]["Photo"] = "";
	$placeHoldersdoctors["Bulgarian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Bulgarian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsdoctors["Catalan"] = array();
	$fieldToolTipsdoctors["Catalan"] = array();
	$placeHoldersdoctors["Catalan"] = array();
	$pageTitlesdoctors["Catalan"] = array();
	$fieldLabelsdoctors["Catalan"]["id"] = "Id";
	$fieldToolTipsdoctors["Catalan"]["id"] = "";
	$placeHoldersdoctors["Catalan"]["id"] = "";
	$fieldLabelsdoctors["Catalan"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Catalan"]["DoctorName"] = "";
	$placeHoldersdoctors["Catalan"]["DoctorName"] = "";
	$fieldLabelsdoctors["Catalan"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Catalan"]["ContactNumber"] = "";
	$placeHoldersdoctors["Catalan"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Catalan"]["Email"] = "Email";
	$fieldToolTipsdoctors["Catalan"]["Email"] = "";
	$placeHoldersdoctors["Catalan"]["Email"] = "";
	$fieldLabelsdoctors["Catalan"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Catalan"]["Photo"] = "";
	$placeHoldersdoctors["Catalan"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Catalan"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsdoctors["Chinese"] = array();
	$fieldToolTipsdoctors["Chinese"] = array();
	$placeHoldersdoctors["Chinese"] = array();
	$pageTitlesdoctors["Chinese"] = array();
	$fieldLabelsdoctors["Chinese"]["id"] = "Id";
	$fieldToolTipsdoctors["Chinese"]["id"] = "";
	$placeHoldersdoctors["Chinese"]["id"] = "";
	$fieldLabelsdoctors["Chinese"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Chinese"]["DoctorName"] = "";
	$placeHoldersdoctors["Chinese"]["DoctorName"] = "";
	$fieldLabelsdoctors["Chinese"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Chinese"]["ContactNumber"] = "";
	$placeHoldersdoctors["Chinese"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Chinese"]["Email"] = "Email";
	$fieldToolTipsdoctors["Chinese"]["Email"] = "";
	$placeHoldersdoctors["Chinese"]["Email"] = "";
	$fieldLabelsdoctors["Chinese"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Chinese"]["Photo"] = "";
	$placeHoldersdoctors["Chinese"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Chinese"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsdoctors["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsdoctors["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersdoctors["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesdoctors["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsdoctors["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsdoctors["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersdoctors["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsdoctors["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "";
	$placeHoldersdoctors["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "";
	$fieldLabelsdoctors["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "";
	$placeHoldersdoctors["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Chinese (Hong Kong S.A.R.)"]["Email"] = "Email";
	$fieldToolTipsdoctors["Chinese (Hong Kong S.A.R.)"]["Email"] = "";
	$placeHoldersdoctors["Chinese (Hong Kong S.A.R.)"]["Email"] = "";
	$fieldLabelsdoctors["Chinese (Hong Kong S.A.R.)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$placeHoldersdoctors["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Chinese (Hong Kong S.A.R.)"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsdoctors["Chinese (Taiwan)"] = array();
	$fieldToolTipsdoctors["Chinese (Taiwan)"] = array();
	$placeHoldersdoctors["Chinese (Taiwan)"] = array();
	$pageTitlesdoctors["Chinese (Taiwan)"] = array();
	$fieldLabelsdoctors["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsdoctors["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersdoctors["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsdoctors["Chinese (Taiwan)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Chinese (Taiwan)"]["DoctorName"] = "";
	$placeHoldersdoctors["Chinese (Taiwan)"]["DoctorName"] = "";
	$fieldLabelsdoctors["Chinese (Taiwan)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Chinese (Taiwan)"]["ContactNumber"] = "";
	$placeHoldersdoctors["Chinese (Taiwan)"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Chinese (Taiwan)"]["Email"] = "Email";
	$fieldToolTipsdoctors["Chinese (Taiwan)"]["Email"] = "";
	$placeHoldersdoctors["Chinese (Taiwan)"]["Email"] = "";
	$fieldLabelsdoctors["Chinese (Taiwan)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Chinese (Taiwan)"]["Photo"] = "";
	$placeHoldersdoctors["Chinese (Taiwan)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Chinese (Taiwan)"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsdoctors["Croatian"] = array();
	$fieldToolTipsdoctors["Croatian"] = array();
	$placeHoldersdoctors["Croatian"] = array();
	$pageTitlesdoctors["Croatian"] = array();
	$fieldLabelsdoctors["Croatian"]["id"] = "Id";
	$fieldToolTipsdoctors["Croatian"]["id"] = "";
	$placeHoldersdoctors["Croatian"]["id"] = "";
	$fieldLabelsdoctors["Croatian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Croatian"]["DoctorName"] = "";
	$placeHoldersdoctors["Croatian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Croatian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Croatian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Croatian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Croatian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Croatian"]["Email"] = "";
	$placeHoldersdoctors["Croatian"]["Email"] = "";
	$fieldLabelsdoctors["Croatian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Croatian"]["Photo"] = "";
	$placeHoldersdoctors["Croatian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Croatian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsdoctors["Czech"] = array();
	$fieldToolTipsdoctors["Czech"] = array();
	$placeHoldersdoctors["Czech"] = array();
	$pageTitlesdoctors["Czech"] = array();
	$fieldLabelsdoctors["Czech"]["id"] = "Id";
	$fieldToolTipsdoctors["Czech"]["id"] = "";
	$placeHoldersdoctors["Czech"]["id"] = "";
	$fieldLabelsdoctors["Czech"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Czech"]["DoctorName"] = "";
	$placeHoldersdoctors["Czech"]["DoctorName"] = "";
	$fieldLabelsdoctors["Czech"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Czech"]["ContactNumber"] = "";
	$placeHoldersdoctors["Czech"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Czech"]["Email"] = "Email";
	$fieldToolTipsdoctors["Czech"]["Email"] = "";
	$placeHoldersdoctors["Czech"]["Email"] = "";
	$fieldLabelsdoctors["Czech"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Czech"]["Photo"] = "";
	$placeHoldersdoctors["Czech"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Czech"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsdoctors["Danish"] = array();
	$fieldToolTipsdoctors["Danish"] = array();
	$placeHoldersdoctors["Danish"] = array();
	$pageTitlesdoctors["Danish"] = array();
	$fieldLabelsdoctors["Danish"]["id"] = "Id";
	$fieldToolTipsdoctors["Danish"]["id"] = "";
	$placeHoldersdoctors["Danish"]["id"] = "";
	$fieldLabelsdoctors["Danish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Danish"]["DoctorName"] = "";
	$placeHoldersdoctors["Danish"]["DoctorName"] = "";
	$fieldLabelsdoctors["Danish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Danish"]["ContactNumber"] = "";
	$placeHoldersdoctors["Danish"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Danish"]["Email"] = "Email";
	$fieldToolTipsdoctors["Danish"]["Email"] = "";
	$placeHoldersdoctors["Danish"]["Email"] = "";
	$fieldLabelsdoctors["Danish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Danish"]["Photo"] = "";
	$placeHoldersdoctors["Danish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Danish"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsdoctors["Dutch"] = array();
	$fieldToolTipsdoctors["Dutch"] = array();
	$placeHoldersdoctors["Dutch"] = array();
	$pageTitlesdoctors["Dutch"] = array();
	$fieldLabelsdoctors["Dutch"]["id"] = "Id";
	$fieldToolTipsdoctors["Dutch"]["id"] = "";
	$placeHoldersdoctors["Dutch"]["id"] = "";
	$fieldLabelsdoctors["Dutch"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Dutch"]["DoctorName"] = "";
	$placeHoldersdoctors["Dutch"]["DoctorName"] = "";
	$fieldLabelsdoctors["Dutch"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Dutch"]["ContactNumber"] = "";
	$placeHoldersdoctors["Dutch"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Dutch"]["Email"] = "Email";
	$fieldToolTipsdoctors["Dutch"]["Email"] = "";
	$placeHoldersdoctors["Dutch"]["Email"] = "";
	$fieldLabelsdoctors["Dutch"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Dutch"]["Photo"] = "";
	$placeHoldersdoctors["Dutch"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Dutch"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsdoctors["Farsi"] = array();
	$fieldToolTipsdoctors["Farsi"] = array();
	$placeHoldersdoctors["Farsi"] = array();
	$pageTitlesdoctors["Farsi"] = array();
	$fieldLabelsdoctors["Farsi"]["id"] = "Id";
	$fieldToolTipsdoctors["Farsi"]["id"] = "";
	$placeHoldersdoctors["Farsi"]["id"] = "";
	$fieldLabelsdoctors["Farsi"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Farsi"]["DoctorName"] = "";
	$placeHoldersdoctors["Farsi"]["DoctorName"] = "";
	$fieldLabelsdoctors["Farsi"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Farsi"]["ContactNumber"] = "";
	$placeHoldersdoctors["Farsi"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Farsi"]["Email"] = "Email";
	$fieldToolTipsdoctors["Farsi"]["Email"] = "";
	$placeHoldersdoctors["Farsi"]["Email"] = "";
	$fieldLabelsdoctors["Farsi"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Farsi"]["Photo"] = "";
	$placeHoldersdoctors["Farsi"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Farsi"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsdoctors["French"] = array();
	$fieldToolTipsdoctors["French"] = array();
	$placeHoldersdoctors["French"] = array();
	$pageTitlesdoctors["French"] = array();
	$fieldLabelsdoctors["French"]["id"] = "Id";
	$fieldToolTipsdoctors["French"]["id"] = "";
	$placeHoldersdoctors["French"]["id"] = "";
	$fieldLabelsdoctors["French"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["French"]["DoctorName"] = "";
	$placeHoldersdoctors["French"]["DoctorName"] = "";
	$fieldLabelsdoctors["French"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["French"]["ContactNumber"] = "";
	$placeHoldersdoctors["French"]["ContactNumber"] = "";
	$fieldLabelsdoctors["French"]["Email"] = "Email";
	$fieldToolTipsdoctors["French"]["Email"] = "";
	$placeHoldersdoctors["French"]["Email"] = "";
	$fieldLabelsdoctors["French"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["French"]["Photo"] = "";
	$placeHoldersdoctors["French"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["French"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsdoctors["Georgian"] = array();
	$fieldToolTipsdoctors["Georgian"] = array();
	$placeHoldersdoctors["Georgian"] = array();
	$pageTitlesdoctors["Georgian"] = array();
	$fieldLabelsdoctors["Georgian"]["id"] = "Id";
	$fieldToolTipsdoctors["Georgian"]["id"] = "";
	$placeHoldersdoctors["Georgian"]["id"] = "";
	$fieldLabelsdoctors["Georgian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Georgian"]["DoctorName"] = "";
	$placeHoldersdoctors["Georgian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Georgian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Georgian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Georgian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Georgian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Georgian"]["Email"] = "";
	$placeHoldersdoctors["Georgian"]["Email"] = "";
	$fieldLabelsdoctors["Georgian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Georgian"]["Photo"] = "";
	$placeHoldersdoctors["Georgian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Georgian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsdoctors["German"] = array();
	$fieldToolTipsdoctors["German"] = array();
	$placeHoldersdoctors["German"] = array();
	$pageTitlesdoctors["German"] = array();
	$fieldLabelsdoctors["German"]["id"] = "Id";
	$fieldToolTipsdoctors["German"]["id"] = "";
	$placeHoldersdoctors["German"]["id"] = "";
	$fieldLabelsdoctors["German"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["German"]["DoctorName"] = "";
	$placeHoldersdoctors["German"]["DoctorName"] = "";
	$fieldLabelsdoctors["German"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["German"]["ContactNumber"] = "";
	$placeHoldersdoctors["German"]["ContactNumber"] = "";
	$fieldLabelsdoctors["German"]["Email"] = "Email";
	$fieldToolTipsdoctors["German"]["Email"] = "";
	$placeHoldersdoctors["German"]["Email"] = "";
	$fieldLabelsdoctors["German"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["German"]["Photo"] = "";
	$placeHoldersdoctors["German"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["German"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsdoctors["Greek"] = array();
	$fieldToolTipsdoctors["Greek"] = array();
	$placeHoldersdoctors["Greek"] = array();
	$pageTitlesdoctors["Greek"] = array();
	$fieldLabelsdoctors["Greek"]["id"] = "Id";
	$fieldToolTipsdoctors["Greek"]["id"] = "";
	$placeHoldersdoctors["Greek"]["id"] = "";
	$fieldLabelsdoctors["Greek"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Greek"]["DoctorName"] = "";
	$placeHoldersdoctors["Greek"]["DoctorName"] = "";
	$fieldLabelsdoctors["Greek"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Greek"]["ContactNumber"] = "";
	$placeHoldersdoctors["Greek"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Greek"]["Email"] = "Email";
	$fieldToolTipsdoctors["Greek"]["Email"] = "";
	$placeHoldersdoctors["Greek"]["Email"] = "";
	$fieldLabelsdoctors["Greek"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Greek"]["Photo"] = "";
	$placeHoldersdoctors["Greek"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Greek"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsdoctors["Hebrew"] = array();
	$fieldToolTipsdoctors["Hebrew"] = array();
	$placeHoldersdoctors["Hebrew"] = array();
	$pageTitlesdoctors["Hebrew"] = array();
	$fieldLabelsdoctors["Hebrew"]["id"] = "Id";
	$fieldToolTipsdoctors["Hebrew"]["id"] = "";
	$placeHoldersdoctors["Hebrew"]["id"] = "";
	$fieldLabelsdoctors["Hebrew"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Hebrew"]["DoctorName"] = "";
	$placeHoldersdoctors["Hebrew"]["DoctorName"] = "";
	$fieldLabelsdoctors["Hebrew"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Hebrew"]["ContactNumber"] = "";
	$placeHoldersdoctors["Hebrew"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Hebrew"]["Email"] = "Email";
	$fieldToolTipsdoctors["Hebrew"]["Email"] = "";
	$placeHoldersdoctors["Hebrew"]["Email"] = "";
	$fieldLabelsdoctors["Hebrew"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Hebrew"]["Photo"] = "";
	$placeHoldersdoctors["Hebrew"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Hebrew"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsdoctors["Hungarian"] = array();
	$fieldToolTipsdoctors["Hungarian"] = array();
	$placeHoldersdoctors["Hungarian"] = array();
	$pageTitlesdoctors["Hungarian"] = array();
	$fieldLabelsdoctors["Hungarian"]["id"] = "Id";
	$fieldToolTipsdoctors["Hungarian"]["id"] = "";
	$placeHoldersdoctors["Hungarian"]["id"] = "";
	$fieldLabelsdoctors["Hungarian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Hungarian"]["DoctorName"] = "";
	$placeHoldersdoctors["Hungarian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Hungarian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Hungarian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Hungarian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Hungarian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Hungarian"]["Email"] = "";
	$placeHoldersdoctors["Hungarian"]["Email"] = "";
	$fieldLabelsdoctors["Hungarian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Hungarian"]["Photo"] = "";
	$placeHoldersdoctors["Hungarian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Hungarian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsdoctors["Indonesian"] = array();
	$fieldToolTipsdoctors["Indonesian"] = array();
	$placeHoldersdoctors["Indonesian"] = array();
	$pageTitlesdoctors["Indonesian"] = array();
	$fieldLabelsdoctors["Indonesian"]["id"] = "Id";
	$fieldToolTipsdoctors["Indonesian"]["id"] = "";
	$placeHoldersdoctors["Indonesian"]["id"] = "";
	$fieldLabelsdoctors["Indonesian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Indonesian"]["DoctorName"] = "";
	$placeHoldersdoctors["Indonesian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Indonesian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Indonesian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Indonesian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Indonesian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Indonesian"]["Email"] = "";
	$placeHoldersdoctors["Indonesian"]["Email"] = "";
	$fieldLabelsdoctors["Indonesian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Indonesian"]["Photo"] = "";
	$placeHoldersdoctors["Indonesian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Indonesian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsdoctors["Italian"] = array();
	$fieldToolTipsdoctors["Italian"] = array();
	$placeHoldersdoctors["Italian"] = array();
	$pageTitlesdoctors["Italian"] = array();
	$fieldLabelsdoctors["Italian"]["id"] = "Id";
	$fieldToolTipsdoctors["Italian"]["id"] = "";
	$placeHoldersdoctors["Italian"]["id"] = "";
	$fieldLabelsdoctors["Italian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Italian"]["DoctorName"] = "";
	$placeHoldersdoctors["Italian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Italian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Italian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Italian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Italian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Italian"]["Email"] = "";
	$placeHoldersdoctors["Italian"]["Email"] = "";
	$fieldLabelsdoctors["Italian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Italian"]["Photo"] = "";
	$placeHoldersdoctors["Italian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Italian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsdoctors["Japanese"] = array();
	$fieldToolTipsdoctors["Japanese"] = array();
	$placeHoldersdoctors["Japanese"] = array();
	$pageTitlesdoctors["Japanese"] = array();
	$fieldLabelsdoctors["Japanese"]["id"] = "Id";
	$fieldToolTipsdoctors["Japanese"]["id"] = "";
	$placeHoldersdoctors["Japanese"]["id"] = "";
	$fieldLabelsdoctors["Japanese"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Japanese"]["DoctorName"] = "";
	$placeHoldersdoctors["Japanese"]["DoctorName"] = "";
	$fieldLabelsdoctors["Japanese"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Japanese"]["ContactNumber"] = "";
	$placeHoldersdoctors["Japanese"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Japanese"]["Email"] = "Email";
	$fieldToolTipsdoctors["Japanese"]["Email"] = "";
	$placeHoldersdoctors["Japanese"]["Email"] = "";
	$fieldLabelsdoctors["Japanese"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Japanese"]["Photo"] = "";
	$placeHoldersdoctors["Japanese"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Japanese"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsdoctors["Malay"] = array();
	$fieldToolTipsdoctors["Malay"] = array();
	$placeHoldersdoctors["Malay"] = array();
	$pageTitlesdoctors["Malay"] = array();
	$fieldLabelsdoctors["Malay"]["id"] = "Id";
	$fieldToolTipsdoctors["Malay"]["id"] = "";
	$placeHoldersdoctors["Malay"]["id"] = "";
	$fieldLabelsdoctors["Malay"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Malay"]["DoctorName"] = "";
	$placeHoldersdoctors["Malay"]["DoctorName"] = "";
	$fieldLabelsdoctors["Malay"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Malay"]["ContactNumber"] = "";
	$placeHoldersdoctors["Malay"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Malay"]["Email"] = "Email";
	$fieldToolTipsdoctors["Malay"]["Email"] = "";
	$placeHoldersdoctors["Malay"]["Email"] = "";
	$fieldLabelsdoctors["Malay"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Malay"]["Photo"] = "";
	$placeHoldersdoctors["Malay"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Malay"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsdoctors["Norwegian(Bokmal)"] = array();
	$fieldToolTipsdoctors["Norwegian(Bokmal)"] = array();
	$placeHoldersdoctors["Norwegian(Bokmal)"] = array();
	$pageTitlesdoctors["Norwegian(Bokmal)"] = array();
	$fieldLabelsdoctors["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsdoctors["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersdoctors["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsdoctors["Norwegian(Bokmal)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Norwegian(Bokmal)"]["DoctorName"] = "";
	$placeHoldersdoctors["Norwegian(Bokmal)"]["DoctorName"] = "";
	$fieldLabelsdoctors["Norwegian(Bokmal)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Norwegian(Bokmal)"]["ContactNumber"] = "";
	$placeHoldersdoctors["Norwegian(Bokmal)"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Norwegian(Bokmal)"]["Email"] = "Email";
	$fieldToolTipsdoctors["Norwegian(Bokmal)"]["Email"] = "";
	$placeHoldersdoctors["Norwegian(Bokmal)"]["Email"] = "";
	$fieldLabelsdoctors["Norwegian(Bokmal)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Norwegian(Bokmal)"]["Photo"] = "";
	$placeHoldersdoctors["Norwegian(Bokmal)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Norwegian(Bokmal)"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsdoctors["Polish"] = array();
	$fieldToolTipsdoctors["Polish"] = array();
	$placeHoldersdoctors["Polish"] = array();
	$pageTitlesdoctors["Polish"] = array();
	$fieldLabelsdoctors["Polish"]["id"] = "Id";
	$fieldToolTipsdoctors["Polish"]["id"] = "";
	$placeHoldersdoctors["Polish"]["id"] = "";
	$fieldLabelsdoctors["Polish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Polish"]["DoctorName"] = "";
	$placeHoldersdoctors["Polish"]["DoctorName"] = "";
	$fieldLabelsdoctors["Polish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Polish"]["ContactNumber"] = "";
	$placeHoldersdoctors["Polish"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Polish"]["Email"] = "Email";
	$fieldToolTipsdoctors["Polish"]["Email"] = "";
	$placeHoldersdoctors["Polish"]["Email"] = "";
	$fieldLabelsdoctors["Polish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Polish"]["Photo"] = "";
	$placeHoldersdoctors["Polish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Polish"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsdoctors["Portuguese(Brazil)"] = array();
	$fieldToolTipsdoctors["Portuguese(Brazil)"] = array();
	$placeHoldersdoctors["Portuguese(Brazil)"] = array();
	$pageTitlesdoctors["Portuguese(Brazil)"] = array();
	$fieldLabelsdoctors["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsdoctors["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersdoctors["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsdoctors["Portuguese(Brazil)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Portuguese(Brazil)"]["DoctorName"] = "";
	$placeHoldersdoctors["Portuguese(Brazil)"]["DoctorName"] = "";
	$fieldLabelsdoctors["Portuguese(Brazil)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Portuguese(Brazil)"]["ContactNumber"] = "";
	$placeHoldersdoctors["Portuguese(Brazil)"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Portuguese(Brazil)"]["Email"] = "Email";
	$fieldToolTipsdoctors["Portuguese(Brazil)"]["Email"] = "";
	$placeHoldersdoctors["Portuguese(Brazil)"]["Email"] = "";
	$fieldLabelsdoctors["Portuguese(Brazil)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Portuguese(Brazil)"]["Photo"] = "";
	$placeHoldersdoctors["Portuguese(Brazil)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Portuguese(Brazil)"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsdoctors["Portuguese(Standard)"] = array();
	$fieldToolTipsdoctors["Portuguese(Standard)"] = array();
	$placeHoldersdoctors["Portuguese(Standard)"] = array();
	$pageTitlesdoctors["Portuguese(Standard)"] = array();
	$fieldLabelsdoctors["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsdoctors["Portuguese(Standard)"]["id"] = "";
	$placeHoldersdoctors["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsdoctors["Portuguese(Standard)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Portuguese(Standard)"]["DoctorName"] = "";
	$placeHoldersdoctors["Portuguese(Standard)"]["DoctorName"] = "";
	$fieldLabelsdoctors["Portuguese(Standard)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Portuguese(Standard)"]["ContactNumber"] = "";
	$placeHoldersdoctors["Portuguese(Standard)"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Portuguese(Standard)"]["Email"] = "Email";
	$fieldToolTipsdoctors["Portuguese(Standard)"]["Email"] = "";
	$placeHoldersdoctors["Portuguese(Standard)"]["Email"] = "";
	$fieldLabelsdoctors["Portuguese(Standard)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Portuguese(Standard)"]["Photo"] = "";
	$placeHoldersdoctors["Portuguese(Standard)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Portuguese(Standard)"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsdoctors["Romanian"] = array();
	$fieldToolTipsdoctors["Romanian"] = array();
	$placeHoldersdoctors["Romanian"] = array();
	$pageTitlesdoctors["Romanian"] = array();
	$fieldLabelsdoctors["Romanian"]["id"] = "Id";
	$fieldToolTipsdoctors["Romanian"]["id"] = "";
	$placeHoldersdoctors["Romanian"]["id"] = "";
	$fieldLabelsdoctors["Romanian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Romanian"]["DoctorName"] = "";
	$placeHoldersdoctors["Romanian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Romanian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Romanian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Romanian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Romanian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Romanian"]["Email"] = "";
	$placeHoldersdoctors["Romanian"]["Email"] = "";
	$fieldLabelsdoctors["Romanian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Romanian"]["Photo"] = "";
	$placeHoldersdoctors["Romanian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Romanian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsdoctors["Russian"] = array();
	$fieldToolTipsdoctors["Russian"] = array();
	$placeHoldersdoctors["Russian"] = array();
	$pageTitlesdoctors["Russian"] = array();
	$fieldLabelsdoctors["Russian"]["id"] = "Id";
	$fieldToolTipsdoctors["Russian"]["id"] = "";
	$placeHoldersdoctors["Russian"]["id"] = "";
	$fieldLabelsdoctors["Russian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Russian"]["DoctorName"] = "";
	$placeHoldersdoctors["Russian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Russian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Russian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Russian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Russian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Russian"]["Email"] = "";
	$placeHoldersdoctors["Russian"]["Email"] = "";
	$fieldLabelsdoctors["Russian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Russian"]["Photo"] = "";
	$placeHoldersdoctors["Russian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Russian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsdoctors["Serbian"] = array();
	$fieldToolTipsdoctors["Serbian"] = array();
	$placeHoldersdoctors["Serbian"] = array();
	$pageTitlesdoctors["Serbian"] = array();
	$fieldLabelsdoctors["Serbian"]["id"] = "Id";
	$fieldToolTipsdoctors["Serbian"]["id"] = "";
	$placeHoldersdoctors["Serbian"]["id"] = "";
	$fieldLabelsdoctors["Serbian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Serbian"]["DoctorName"] = "";
	$placeHoldersdoctors["Serbian"]["DoctorName"] = "";
	$fieldLabelsdoctors["Serbian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Serbian"]["ContactNumber"] = "";
	$placeHoldersdoctors["Serbian"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Serbian"]["Email"] = "Email";
	$fieldToolTipsdoctors["Serbian"]["Email"] = "";
	$placeHoldersdoctors["Serbian"]["Email"] = "";
	$fieldLabelsdoctors["Serbian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Serbian"]["Photo"] = "";
	$placeHoldersdoctors["Serbian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Serbian"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsdoctors["Slovak"] = array();
	$fieldToolTipsdoctors["Slovak"] = array();
	$placeHoldersdoctors["Slovak"] = array();
	$pageTitlesdoctors["Slovak"] = array();
	$fieldLabelsdoctors["Slovak"]["id"] = "Id";
	$fieldToolTipsdoctors["Slovak"]["id"] = "";
	$placeHoldersdoctors["Slovak"]["id"] = "";
	$fieldLabelsdoctors["Slovak"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Slovak"]["DoctorName"] = "";
	$placeHoldersdoctors["Slovak"]["DoctorName"] = "";
	$fieldLabelsdoctors["Slovak"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Slovak"]["ContactNumber"] = "";
	$placeHoldersdoctors["Slovak"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Slovak"]["Email"] = "Email";
	$fieldToolTipsdoctors["Slovak"]["Email"] = "";
	$placeHoldersdoctors["Slovak"]["Email"] = "";
	$fieldLabelsdoctors["Slovak"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Slovak"]["Photo"] = "";
	$placeHoldersdoctors["Slovak"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Slovak"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsdoctors["Spanish"] = array();
	$fieldToolTipsdoctors["Spanish"] = array();
	$placeHoldersdoctors["Spanish"] = array();
	$pageTitlesdoctors["Spanish"] = array();
	$fieldLabelsdoctors["Spanish"]["id"] = "Id";
	$fieldToolTipsdoctors["Spanish"]["id"] = "";
	$placeHoldersdoctors["Spanish"]["id"] = "";
	$fieldLabelsdoctors["Spanish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Spanish"]["DoctorName"] = "";
	$placeHoldersdoctors["Spanish"]["DoctorName"] = "";
	$fieldLabelsdoctors["Spanish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Spanish"]["ContactNumber"] = "";
	$placeHoldersdoctors["Spanish"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Spanish"]["Email"] = "Email";
	$fieldToolTipsdoctors["Spanish"]["Email"] = "";
	$placeHoldersdoctors["Spanish"]["Email"] = "";
	$fieldLabelsdoctors["Spanish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Spanish"]["Photo"] = "";
	$placeHoldersdoctors["Spanish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Spanish"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsdoctors["Swedish"] = array();
	$fieldToolTipsdoctors["Swedish"] = array();
	$placeHoldersdoctors["Swedish"] = array();
	$pageTitlesdoctors["Swedish"] = array();
	$fieldLabelsdoctors["Swedish"]["id"] = "Id";
	$fieldToolTipsdoctors["Swedish"]["id"] = "";
	$placeHoldersdoctors["Swedish"]["id"] = "";
	$fieldLabelsdoctors["Swedish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Swedish"]["DoctorName"] = "";
	$placeHoldersdoctors["Swedish"]["DoctorName"] = "";
	$fieldLabelsdoctors["Swedish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Swedish"]["ContactNumber"] = "";
	$placeHoldersdoctors["Swedish"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Swedish"]["Email"] = "Email";
	$fieldToolTipsdoctors["Swedish"]["Email"] = "";
	$placeHoldersdoctors["Swedish"]["Email"] = "";
	$fieldLabelsdoctors["Swedish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Swedish"]["Photo"] = "";
	$placeHoldersdoctors["Swedish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Swedish"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsdoctors["Tagalog(Philippines)"] = array();
	$fieldToolTipsdoctors["Tagalog(Philippines)"] = array();
	$placeHoldersdoctors["Tagalog(Philippines)"] = array();
	$pageTitlesdoctors["Tagalog(Philippines)"] = array();
	$fieldLabelsdoctors["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsdoctors["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersdoctors["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsdoctors["Tagalog(Philippines)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Tagalog(Philippines)"]["DoctorName"] = "";
	$placeHoldersdoctors["Tagalog(Philippines)"]["DoctorName"] = "";
	$fieldLabelsdoctors["Tagalog(Philippines)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Tagalog(Philippines)"]["ContactNumber"] = "";
	$placeHoldersdoctors["Tagalog(Philippines)"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Tagalog(Philippines)"]["Email"] = "Email";
	$fieldToolTipsdoctors["Tagalog(Philippines)"]["Email"] = "";
	$placeHoldersdoctors["Tagalog(Philippines)"]["Email"] = "";
	$fieldLabelsdoctors["Tagalog(Philippines)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Tagalog(Philippines)"]["Photo"] = "";
	$placeHoldersdoctors["Tagalog(Philippines)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Tagalog(Philippines)"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsdoctors["Thai"] = array();
	$fieldToolTipsdoctors["Thai"] = array();
	$placeHoldersdoctors["Thai"] = array();
	$pageTitlesdoctors["Thai"] = array();
	$fieldLabelsdoctors["Thai"]["id"] = "Id";
	$fieldToolTipsdoctors["Thai"]["id"] = "";
	$placeHoldersdoctors["Thai"]["id"] = "";
	$fieldLabelsdoctors["Thai"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Thai"]["DoctorName"] = "";
	$placeHoldersdoctors["Thai"]["DoctorName"] = "";
	$fieldLabelsdoctors["Thai"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Thai"]["ContactNumber"] = "";
	$placeHoldersdoctors["Thai"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Thai"]["Email"] = "Email";
	$fieldToolTipsdoctors["Thai"]["Email"] = "";
	$placeHoldersdoctors["Thai"]["Email"] = "";
	$fieldLabelsdoctors["Thai"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Thai"]["Photo"] = "";
	$placeHoldersdoctors["Thai"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Thai"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsdoctors["Turkish"] = array();
	$fieldToolTipsdoctors["Turkish"] = array();
	$placeHoldersdoctors["Turkish"] = array();
	$pageTitlesdoctors["Turkish"] = array();
	$fieldLabelsdoctors["Turkish"]["id"] = "Id";
	$fieldToolTipsdoctors["Turkish"]["id"] = "";
	$placeHoldersdoctors["Turkish"]["id"] = "";
	$fieldLabelsdoctors["Turkish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Turkish"]["DoctorName"] = "";
	$placeHoldersdoctors["Turkish"]["DoctorName"] = "";
	$fieldLabelsdoctors["Turkish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Turkish"]["ContactNumber"] = "";
	$placeHoldersdoctors["Turkish"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Turkish"]["Email"] = "Email";
	$fieldToolTipsdoctors["Turkish"]["Email"] = "";
	$placeHoldersdoctors["Turkish"]["Email"] = "";
	$fieldLabelsdoctors["Turkish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Turkish"]["Photo"] = "";
	$placeHoldersdoctors["Turkish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Turkish"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsdoctors["Urdu"] = array();
	$fieldToolTipsdoctors["Urdu"] = array();
	$placeHoldersdoctors["Urdu"] = array();
	$pageTitlesdoctors["Urdu"] = array();
	$fieldLabelsdoctors["Urdu"]["id"] = "Id";
	$fieldToolTipsdoctors["Urdu"]["id"] = "";
	$placeHoldersdoctors["Urdu"]["id"] = "";
	$fieldLabelsdoctors["Urdu"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Urdu"]["DoctorName"] = "";
	$placeHoldersdoctors["Urdu"]["DoctorName"] = "";
	$fieldLabelsdoctors["Urdu"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Urdu"]["ContactNumber"] = "";
	$placeHoldersdoctors["Urdu"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Urdu"]["Email"] = "Email";
	$fieldToolTipsdoctors["Urdu"]["Email"] = "";
	$placeHoldersdoctors["Urdu"]["Email"] = "";
	$fieldLabelsdoctors["Urdu"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Urdu"]["Photo"] = "";
	$placeHoldersdoctors["Urdu"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Urdu"]))
		$tdatadoctors[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsdoctors["Welsh"] = array();
	$fieldToolTipsdoctors["Welsh"] = array();
	$placeHoldersdoctors["Welsh"] = array();
	$pageTitlesdoctors["Welsh"] = array();
	$fieldLabelsdoctors["Welsh"]["id"] = "Id";
	$fieldToolTipsdoctors["Welsh"]["id"] = "";
	$placeHoldersdoctors["Welsh"]["id"] = "";
	$fieldLabelsdoctors["Welsh"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors["Welsh"]["DoctorName"] = "";
	$placeHoldersdoctors["Welsh"]["DoctorName"] = "";
	$fieldLabelsdoctors["Welsh"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors["Welsh"]["ContactNumber"] = "";
	$placeHoldersdoctors["Welsh"]["ContactNumber"] = "";
	$fieldLabelsdoctors["Welsh"]["Email"] = "Email";
	$fieldToolTipsdoctors["Welsh"]["Email"] = "";
	$placeHoldersdoctors["Welsh"]["Email"] = "";
	$fieldLabelsdoctors["Welsh"]["Photo"] = "Photo";
	$fieldToolTipsdoctors["Welsh"]["Photo"] = "";
	$placeHoldersdoctors["Welsh"]["Photo"] = "";
	if (count($fieldToolTipsdoctors["Welsh"]))
		$tdatadoctors[".isUseToolTips"] = true;
}


	$tdatadoctors[".NCSearch"] = true;



$tdatadoctors[".shortTableName"] = "doctors";
$tdatadoctors[".nSecOptions"] = 0;

$tdatadoctors[".mainTableOwnerID"] = "";
$tdatadoctors[".entityType"] = 0;
$tdatadoctors[".connId"] = "testdb_at_localhost";


$tdatadoctors[".strOriginalTableName"] = "doctors";

	



$tdatadoctors[".showAddInPopup"] = false;

$tdatadoctors[".showEditInPopup"] = false;

$tdatadoctors[".showViewInPopup"] = false;

	$tdatadoctors[".listAjax"] = true;
//	temporary
//$tdatadoctors[".listAjax"] = false;

	$tdatadoctors[".audit"] = false;

	$tdatadoctors[".locking"] = false;


$pages = $tdatadoctors[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatadoctors[".edit"] = true;
	$tdatadoctors[".afterEditAction"] = 1;
	$tdatadoctors[".closePopupAfterEdit"] = 1;
	$tdatadoctors[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatadoctors[".add"] = true;
$tdatadoctors[".afterAddAction"] = 1;
$tdatadoctors[".closePopupAfterAdd"] = 1;
$tdatadoctors[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatadoctors[".list"] = true;
}



$tdatadoctors[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatadoctors[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatadoctors[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatadoctors[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatadoctors[".printFriendly"] = true;
}



$tdatadoctors[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatadoctors[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatadoctors[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatadoctors[".isUseAjaxSuggest"] = true;





$tdatadoctors[".ajaxCodeSnippetAdded"] = false;

$tdatadoctors[".buttonsAdded"] = false;

$tdatadoctors[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadoctors[".isUseTimeForSearch"] = false;


$tdatadoctors[".badgeColor"] = "6493EA";


$tdatadoctors[".allSearchFields"] = array();
$tdatadoctors[".filterFields"] = array();
$tdatadoctors[".requiredSearchFields"] = array();

$tdatadoctors[".googleLikeFields"] = array();
$tdatadoctors[".googleLikeFields"][] = "id";
$tdatadoctors[".googleLikeFields"][] = "DoctorName";
$tdatadoctors[".googleLikeFields"][] = "ContactNumber";
$tdatadoctors[".googleLikeFields"][] = "Email";
$tdatadoctors[".googleLikeFields"][] = "Photo";



$tdatadoctors[".tableType"] = "list";

$tdatadoctors[".printerPageOrientation"] = 0;
$tdatadoctors[".nPrinterPageScale"] = 100;

$tdatadoctors[".nPrinterSplitRecords"] = 40;

$tdatadoctors[".geocodingEnabled"] = false;




$tdatadoctors[".isDisplayLoading"] = true;






$tdatadoctors[".pageSize"] = 20;

$tdatadoctors[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdatadoctors[".strOrderBy"] = $tstrOrderBy;

$tdatadoctors[".orderindexes"] = array();


$tdatadoctors[".sqlHead"] = "SELECT id,  	DoctorName,  	ContactNumber,  	Email,  	Photo";
$tdatadoctors[".sqlFrom"] = "FROM doctors";
$tdatadoctors[".sqlWhereExpr"] = "";
$tdatadoctors[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadoctors[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadoctors[".arrGroupsPerPage"] = $arrGPP;

$tdatadoctors[".highlightSearchResults"] = true;

$tableKeysdoctors = array();
$tableKeysdoctors[] = "id";
$tdatadoctors[".Keys"] = $tableKeysdoctors;


$tdatadoctors[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors["id"] = $fdata;
		$tdatadoctors[".searchableFields"][] = "id";
//	DoctorName
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "DoctorName";
	$fdata["GoodName"] = "DoctorName";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors","DoctorName");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DoctorName";

		$fdata["sourceSingle"] = "DoctorName";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DoctorName";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors["DoctorName"] = $fdata;
		$tdatadoctors[".searchableFields"][] = "DoctorName";
//	ContactNumber
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "ContactNumber";
	$fdata["GoodName"] = "ContactNumber";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors","ContactNumber");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "ContactNumber";

		$fdata["sourceSingle"] = "ContactNumber";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ContactNumber";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors["ContactNumber"] = $fdata;
		$tdatadoctors[".searchableFields"][] = "ContactNumber";
//	Email
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Email";
	$fdata["GoodName"] = "Email";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors","Email");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Email";

		$fdata["sourceSingle"] = "Email";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Email";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors["Email"] = $fdata;
		$tdatadoctors[".searchableFields"][] = "Email";
//	Photo
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Photo";
	$fdata["GoodName"] = "Photo";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors","Photo");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Photo";

		$fdata["sourceSingle"] = "Photo";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Photo";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "File-based Image");

	
	
				$vdata["ImageWidth"] = 50;
	$vdata["ImageHeight"] = 50;

			$vdata["multipleImgMode"] = 1;
	$vdata["maxImages"] = 0;

			$vdata["showGallery"] = true;
	$vdata["galleryMode"] = 2;
	$vdata["captionMode"] = 2;
	$vdata["captionField"] = "";

	$vdata["imageBorder"] = 1;
	$vdata["imageFullWidth"] = 1;


	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
		$fdata["filterTotalFields"] = "id";
		$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors["Photo"] = $fdata;
		$tdatadoctors[".searchableFields"][] = "Photo";


$tables_data["doctors"]=&$tdatadoctors;
$field_labels["doctors"] = &$fieldLabelsdoctors;
$fieldToolTips["doctors"] = &$fieldToolTipsdoctors;
$placeHolders["doctors"] = &$placeHoldersdoctors;
$page_titles["doctors"] = &$pageTitlesdoctors;


changeTextControlsToDate( "doctors" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["doctors"] = array();
//	treatments
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="treatments";
		$detailsParam["dOriginalTable"] = "treatments";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "treatments";
	$detailsParam["dCaptionTable"] = GetTableCaption("treatments");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["doctors"][$dIndex] = $detailsParam;

	
		$detailsTablesData["doctors"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["doctors"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["doctors"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["doctors"][$dIndex]["detailKeys"][]="doctor_id";
//	treatments Chart
	
	

		$dIndex = 1;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="treatments Chart";
		$detailsParam["dOriginalTable"] = "treatments";



			$detailsParam["dType"]=PAGE_CHART;

		$detailsParam["dShortTable"] = "treatments_chart";
	$detailsParam["dCaptionTable"] = GetTableCaption("treatments_Chart");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["doctors"][$dIndex] = $detailsParam;

	
		$detailsTablesData["doctors"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["doctors"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["doctors"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["doctors"][$dIndex]["detailKeys"][]="doctor_id";
//	patients Chart
	
	

		$dIndex = 2;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="patients Chart";
		$detailsParam["dOriginalTable"] = "treatments";



			$detailsParam["dType"]=PAGE_CHART;

		$detailsParam["dShortTable"] = "patients_chart";
	$detailsParam["dCaptionTable"] = GetTableCaption("patients_Chart");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["doctors"][$dIndex] = $detailsParam;

	
		$detailsTablesData["doctors"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["doctors"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["doctors"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["doctors"][$dIndex]["detailKeys"][]="doctor_id";
//endif

// tables which are master tables for current table (detail)
$masterTablesData["doctors"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_doctors()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	DoctorName,  	ContactNumber,  	Email,  	Photo";
$proto0["m_strFrom"] = "FROM doctors";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "doctors";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "DoctorName",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors"
));

$proto8["m_sql"] = "DoctorName";
$proto8["m_srcTableName"] = "doctors";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "ContactNumber",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors"
));

$proto10["m_sql"] = "ContactNumber";
$proto10["m_srcTableName"] = "doctors";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Email",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors"
));

$proto12["m_sql"] = "Email";
$proto12["m_srcTableName"] = "doctors";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Photo",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors"
));

$proto14["m_sql"] = "Photo";
$proto14["m_srcTableName"] = "doctors";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "doctors";
$proto17["m_srcTableName"] = "doctors";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "DoctorName";
$proto17["m_columns"][] = "ContactNumber";
$proto17["m_columns"][] = "Email";
$proto17["m_columns"][] = "Photo";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "doctors";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "doctors";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="doctors";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_doctors = createSqlQuery_doctors();


	
		;

					

$tdatadoctors[".sqlquery"] = $queryData_doctors;



$tdatadoctors[".hasEvents"] = false;

?>