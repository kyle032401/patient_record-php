<?php
$dDebug = false;
$debug2Factor = false;
$dSQL = "";

$tables_data = array();
$page_layouts = array();
$page_options = array();
$pd_pages = array();
$all_pd_layouts = array();
$field_labels = array();
$fieldToolTips = array();
$page_titles = array();
$placeHolders = array();
$all_page_layouts = array();
$all_page_types = null;
$all_pages = null;
$detailsTablesData = array();
$masterTablesData = array();

// .NET convertor needs this
$tdataGLOBAL = array();
$pages = array();
$defaultPages = array();
$topsArray = array();

/**
 * Breadcrumb label templates

 *	Label without master table
 *	$breadcrumb_titles[<language>][<table>][<page>]["."] = "..."

 *	Label with master active
 *	$breadcrumb_titles[<language>][<table>][<page>][<master>] = "..."

 *	Label for the page with no table
 *	$breadcrumb_titles[<language>]["."][<page>]["."] = "..."
 */
$breadcrumb_labels = array();


$lookupTableLinks = array();

$_gmdays = array(0=>31,1=>31,2=>28,3=>31,4=>30,5=>31,6=>30,7=>31,8=>31,9=>30,10=>31,11=>30,12=>31);

include(getabspath('classes/layout.php'));
include(getabspath('classes/pdlayout.php'));


//	custom labels
$custom_labels = array();
$custom_labels["Afrikaans"] = array();
	$custom_labels["Afrikaans"]['CUSTOM'] = "";
																																						$custom_labels["Arabic"] = array();
		$custom_labels["Arabic"]['CUSTOM'] = "";
																																					$custom_labels["Bosnian"] = array();
			$custom_labels["Bosnian"]['CUSTOM'] = "";
																																				$custom_labels["Bulgarian"] = array();
				$custom_labels["Bulgarian"]['CUSTOM'] = "";
																																			$custom_labels["Catalan"] = array();
					$custom_labels["Catalan"]['CUSTOM'] = "";
																																		$custom_labels["Chinese"] = array();
						$custom_labels["Chinese"]['CUSTOM'] = "";
																																	$custom_labels["Chinese (Hong Kong S.A.R.)"] = array();
							$custom_labels["Chinese (Hong Kong S.A.R.)"]['CUSTOM'] = "";
																																$custom_labels["Chinese (Taiwan)"] = array();
								$custom_labels["Chinese (Taiwan)"]['CUSTOM'] = "";
																															$custom_labels["Croatian"] = array();
									$custom_labels["Croatian"]['CUSTOM'] = "";
																														$custom_labels["Czech"] = array();
										$custom_labels["Czech"]['CUSTOM'] = "";
																													$custom_labels["Danish"] = array();
											$custom_labels["Danish"]['CUSTOM'] = "";
																												$custom_labels["Dutch"] = array();
												$custom_labels["Dutch"]['CUSTOM'] = "";
																											$custom_labels["English"] = array();
													$custom_labels["English"]['CUSTOM'] = "";
																										$custom_labels["Farsi"] = array();
														$custom_labels["Farsi"]['CUSTOM'] = "";
																									$custom_labels["French"] = array();
															$custom_labels["French"]['CUSTOM'] = "";
																								$custom_labels["Georgian"] = array();
																$custom_labels["Georgian"]['CUSTOM'] = "";
																							$custom_labels["German"] = array();
																	$custom_labels["German"]['CUSTOM'] = "";
																						$custom_labels["Greek"] = array();
																		$custom_labels["Greek"]['CUSTOM'] = "";
																					$custom_labels["Hebrew"] = array();
																			$custom_labels["Hebrew"]['CUSTOM'] = "";
																				$custom_labels["Hungarian"] = array();
																				$custom_labels["Hungarian"]['CUSTOM'] = "";
																			$custom_labels["Indonesian"] = array();
																					$custom_labels["Indonesian"]['CUSTOM'] = "";
																		$custom_labels["Italian"] = array();
																						$custom_labels["Italian"]['CUSTOM'] = "";
																	$custom_labels["Japanese"] = array();
																							$custom_labels["Japanese"]['CUSTOM'] = "";
																$custom_labels["Malay"] = array();
																								$custom_labels["Malay"]['CUSTOM'] = "";
															$custom_labels["Norwegian(Bokmal)"] = array();
																									$custom_labels["Norwegian(Bokmal)"]['CUSTOM'] = "";
														$custom_labels["Polish"] = array();
																										$custom_labels["Polish"]['CUSTOM'] = "";
													$custom_labels["Portuguese(Brazil)"] = array();
																											$custom_labels["Portuguese(Brazil)"]['CUSTOM'] = "";
												$custom_labels["Portuguese(Standard)"] = array();
																												$custom_labels["Portuguese(Standard)"]['CUSTOM'] = "";
											$custom_labels["Romanian"] = array();
																													$custom_labels["Romanian"]['CUSTOM'] = "";
										$custom_labels["Russian"] = array();
																														$custom_labels["Russian"]['CUSTOM'] = "";
									$custom_labels["Serbian"] = array();
																															$custom_labels["Serbian"]['CUSTOM'] = "";
								$custom_labels["Slovak"] = array();
																																$custom_labels["Slovak"]['CUSTOM'] = "";
							$custom_labels["Spanish"] = array();
																																	$custom_labels["Spanish"]['CUSTOM'] = "";
						$custom_labels["Swedish"] = array();
																																		$custom_labels["Swedish"]['CUSTOM'] = "";
					$custom_labels["Tagalog(Philippines)"] = array();
																																			$custom_labels["Tagalog(Philippines)"]['CUSTOM'] = "";
				$custom_labels["Thai"] = array();
																																				$custom_labels["Thai"]['CUSTOM'] = "";
			$custom_labels["Turkish"] = array();
																																					$custom_labels["Turkish"]['CUSTOM'] = "";
		$custom_labels["Urdu"] = array();
																																						$custom_labels["Urdu"]['CUSTOM'] = "";
	$custom_labels["Welsh"] = array();
																																							$custom_labels["Welsh"]['CUSTOM'] = "";

define('GLOBAL_PAGES_SHORT', "_global");
define('GLOBAL_PAGES', "<global>");

/**
 *  Define constants of page name
 */
define('PAGE_LIST',"list");
define('PAGE_MASTER_INFO_LIST',"masterlist");
define('PAGE_ADD',"add");
define('PAGE_EDIT',"edit");
define('PAGE_VIEW',"view");
define('PAGE_MENU',"menu");
define('PAGE_LOGIN',"login");
define('PAGE_REGISTER',"register");
define('PAGE_REMIND',"remind");
define('PAGE_REMIND_SUCCESS',"remind_success");
define('PAGE_CHANGEPASS',"changepwd");
define('PAGE_SEARCH',"search");
define('PAGE_REPORT',"report");
define('PAGE_MASTER_INFO_REPORT',"masterreport");
define('PAGE_CHART',"chart");
define('PAGE_PRINT',"print");
define('PAGE_MASTER_INFO_PRINT',"masterprint");
define('PAGE_RPRINT',"rprint");
define('PAGE_MASTER_INFO_RPRINT',"masterrprint");
define('PAGE_EXPORT',"export");
define('PAGE_IMPORT',"import");
define('PAGE_INLINEADD',"inlineadd");
define('PAGE_INLINEEDIT',"inlineedit");
define('PAGE_DASHBOARD',"dashboard");
define('PAGE_DASHMAP', "map");
define('PAGE_ADMIN_RIGHTS', "admin_rights_list");
define('PAGE_ADMIN_MEMBERS', "admin_members_list");
define('PAGE_ADMIN_ADMEMBERS', "admin_admembers_list");
define('PAGE_USERINFO',"userinfo");
define('PAGE_SESSION_EXPIRED',"session_expired");

define('ADMIN_USERS',"admin_users");


define('FORMAT_VIEW',"ViewFormats");
define('FORMAT_EDIT',"EditFormats");
/**
 *  Define constants of view format
 */
define("FORMAT_NONE","");
define("FORMAT_DATE_SHORT","Short Date");
define("FORMAT_DATE_LONG","Long Date");
define("FORMAT_DATE_TIME","Datetime");
define("FORMAT_TIME","Time");
define("FORMAT_CURRENCY","Currency");
define("FORMAT_PERCENT","Percent");
define("FORMAT_HYPERLINK","Hyperlink");
define("FORMAT_EMAILHYPERLINK","Email Hyperlink");
define("FORMAT_FILE_IMAGE","File-based Image");
define("FORMAT_FILE_IMAGE_OLD","Old file-based Image");
define("FORMAT_DATABASE_IMAGE","Database Image");
define("FORMAT_DATABASE_FILE","Database File");
define("FORMAT_FILE","Document Download");
define("FORMAT_LOOKUP_WIZARD","Lookup wizard");
define("FORMAT_PHONE_NUMBER","Phone Number");
define("FORMAT_NUMBER","Number");
define("FORMAT_HTML","HTML");
define("FORMAT_CHECKBOX","Checkbox");
define("FORMAT_MAP","Map");
define("FORMAT_CUSTOM","Custom");
define("FORMAT_AUDIO", "Audio file");
define("FORMAT_DATABASE_AUDIO", "Database audio");
define("FORMAT_VIDEO", "Video file");
define("FORMAT_VIDEO_HTML5", "Video file HTML5");
define("FORMAT_DATABASE_VIDEO", "Database video");
/**
 *  Define constants of edit format
 */
define("EDIT_FORMAT_NONE","");
define("EDIT_FORMAT_TEXT_FIELD","Text field");
define("EDIT_FORMAT_TEXT_AREA","Text area");
define("EDIT_FORMAT_PASSWORD","Password");
define("EDIT_FORMAT_DATE","Date");
define("EDIT_FORMAT_TIME","Time");
define("EDIT_FORMAT_RADIO","Radio button");
define("EDIT_FORMAT_CHECKBOX","Checkbox");
define("EDIT_FORMAT_DATABASE_IMAGE","Database image");
define("EDIT_FORMAT_DATABASE_FILE","Database file");
define("EDIT_FORMAT_FILE","Document upload");
define("EDIT_FORMAT_LOOKUP_WIZARD","Lookup wizard");
define("EDIT_FORMAT_HIDDEN","Hidden field");
define("EDIT_FORMAT_READONLY","Readonly");

define("EDIT_DATE_SIMPLE",0);
define("EDIT_DATE_SIMPLE_INLINE",2);
define("EDIT_DATE_SIMPLE_DP",11);
define("EDIT_DATE_DD",12);
define("EDIT_DATE_DD_INLINE",5);
define("EDIT_DATE_DD_DP",13);

define("MODE_ADD",0);
define("MODE_EDIT",1);
define("MODE_SEARCH",2);
define("MODE_LIST",3);
define("MODE_PRINT",4);
define("MODE_VIEW",5);
define("MODE_INLINE_ADD",6);
define("MODE_INLINE_EDIT",7);
define("MODE_EXPORT",8);

define("LOGIN_HARDCODED",0);
define("LOGIN_TABLE",1);
define("LOGIN_AD",2);

define("SECURITY_NONE",-1);
define("SECURITY_HARDCODED", 0);
define("SECURITY_TABLE", 1);
define("SECURITY_AD", 2);

define("ADVSECURITY_ALL",0);
define("ADVSECURITY_VIEW_OWN",1);
define("ADVSECURITY_EDIT_OWN",2);
define("ADVSECURITY_NONE",3);

define("ACCESS_LEVEL_ADMIN","Admin");
define("ACCESS_LEVEL_ADMINGROUP","AdminGroup");
define("ACCESS_LEVEL_USER","User");
define("ACCESS_LEVEL_GUEST","Guest");

define("nDATABASE_MySQL",0);
define("nDATABASE_Oracle",1);
define("nDATABASE_MSSQLServer",2);
define("nDATABASE_Access",3);
define("nDATABASE_PostgreSQL",4);
define("nDATABASE_Informix",5);
define("nDATABASE_SQLite3",6);
define("nDATABASE_DB2",7);
define("nDATABASE_Interbase", 16);
define("nDATABASE_REST", 19 );

define("ADD_SIMPLE",0);
define("ADD_INLINE",1);
define("ADD_ONTHEFLY",2);
define("ADD_MASTER",3);
define("ADD_POPUP",4);
define("ADD_DASHBOARD",5);
define("ADD_MASTER_POPUP",6);
define("ADD_MASTER_DASH",7);

//	Edit page modes
define("EDIT_SIMPLE",0); 	//	standalone Edit page
define("EDIT_INLINE",1);	//	inlineEdit
define("EDIT_POPUP",3);		//	edit page in popup
define("EDIT_DASHBOARD",4);	//	edit page in dashboard
define("EDIT_SELECTED_SIMPLE",5);
define("EDIT_SELECTED_POPUP",6);


//	View page modes
define("VIEW_SIMPLE",0); 	//	standalone View page
define("VIEW_POPUP",1); 	//	View page in popup
define("VIEW_DASHBOARD",2); 	//	View page in dashboard
define("VIEW_PDFJSON",3); 	//	prepare json for PDF

define("LOGIN_SIMPLE", 0);
define("LOGIN_POPUP", 1);
define("LOGIN_EMBEDED", 2);

define("REGISTER_SIMPLE", 0);
define("REGISTER_POPUP", 1);

define("REMIND_SIMPLE", 0);
define("REMIND_POPUP", 1);

define("EXPORT_SIMPLE", 0);
define("EXPORT_POPUP", 1);

define("EXPORT_RAW", 0);
define("EXPORT_FORMATTED", 1);
define("EXPORT_BOTH", 2);


define("CHANGEPASS_SIMPLE", 0);
define("CHANGEPASS_POPUP", 1);

define("USERINFO_SIMPLE", 0 );
define("USERINFO_2FACTOR", 1 );

define("SESSION_EXPIRED_SIMPLE", 0 );
define("SESSION_EXPIRED_POPUP", 1 );

define("titTABLE",0);
define("titVIEW",1);
define("titREPORT",2);
define("titCHART",3);
define("titDASHBOARD",4);
define("titSQL",6);
define("titREST",7);
define("titSQL_REPORT",8);
define("titSQL_CHART",9);
define("titREST_REPORT",10);
define("titREST_CHART",11);

define("TAB_TYPE_TAB", 0);
define("TAB_TYPE_SECTION", 1);
define("TAB_TYPE_STEP", 2);

// for report lib
define("REPORT_STEPPED", 0);
define("REPORT_BLOCK", 1);
define("REPORT_OUTLINE", 2);
define("REPORT_ALIGN", 3);
define("REPORT_TABULAR", 6);

define("TOTAL_NONE", -1);
define("TOTAL_MAX", 0);
define("TOTAL_AVG", 1);
define("TOTAL_SUM", 3);
define("TOTAL_MIN", 4);

define("TOTALS_ALL_DATA", 0);
define("TOTALS_DISPLAYED_RECORDS", 1);

define("LIST_SIMPLE",0);
define("LIST_LOOKUP",1);
define("LIST_DETAILS",3);
define("LIST_AJAX",4);
define("RIGHTS_PAGE", 5);
define("MEMBERS_PAGE", 6);
define("LIST_DASHBOARD", 7);
define("LIST_DASHDETAILS", 8);
define("MAP_DASHBOARD", 9);
define("LIST_MASTER",10);
define("PRINT_MASTER",11);
define("LIST_POPUPDETAILS",12);
define("PRINT_SIMPLE",13);
define("PRINT_PDFJSON",14); 	//	prepare json for PDF
define("LIST_PDFJSON",15); 	//	prepare details table json for PDF



define("REPORT_SIMPLE", 0);
define("REPORT_POPUPDETAILS", 1);
define("REPORT_DASHBOARD", 2);
define("REPORT_DETAILS", 3);
define("REPORT_DASHDETAILS", 4);

define("CHART_SIMPLE", 0);
define("CHART_POPUPDETAILS", 1);
define("CHART_DASHBOARD", 2);
define("CHART_DETAILS", 3);
define("CHART_DASHDETAILS", 4);

define("DP_POPUP",0);
define("DP_INLINE",1);
define("DP_NONE",2);

define("DL_SINGLE",0);
define("DL_INDIVIDUAL",1);
define("DL_NONE",2);

define("SEARCH_SIMPLE", 0);
define("SEARCH_LOAD_CONTROL", 1);
define("SEARCH_DASHBOARD", 2);
define("SEARCH_POPUP", 3);

define("LCT_DROPDOWN",0);
define("LCT_AJAX",1);
define("LCT_LIST",2);
define("LCT_CBLIST",3);
define("LCT_RADIO",4);

define("LT_LISTOFVALUES",0);
// lookup table is not added to the project
define("LT_LOOKUPTABLE",1);
define("LT_QUERY", 2);

define("ENCRYPTION_NONE", 0);
define("ENCRYPTION_DB", 1);
define("ENCRYPTION_PHP", 2);
define("ENCRYPTION_ALG_DES", 1);
define("ENCRYPTION_ALG_AES", 128);
define("ENCRYPTION_ALG_AES_256", 256);

define("SETTING_TYPE_GLOBAL", "global");
define("SETTING_TYPE_VIEW", "view");
define("SETTING_TYPE_EDIT", "edit");

define('otNone',0);
define('otUseMobile',1);
define('otUseDesktop',2);


define("CONTAINS", "Contains");
define("EQUALS", "Equals");
define("STARTS_WITH", "Starts with");
define("MORE_THAN", "More than");
define("LESS_THAN", "Less than");
define("BETWEEN", "Between");
define("EMPTY_SEARCH", "Empty");
define("NOT_CONTAINS", "NOT Contains");
define("NOT_EQUALS", "NOT Equals");
define("NOT_STARTS_WITH", "NOT Starts with");
define("NOT_MORE_THAN", "NOT More than");
define("NOT_LESS_THAN", "NOT Less than");
define("NOT_BETWEEN", "NOT Between");
define("NOT_EMPTY", "NOT Empty");

define("SEARCHID_SIMPLE", 1);
define("SEARCHID_PANEL", 10);
define("SEARCHID_ALL", 10000);


/* Define constants for the filters settings */
//fiter totals
define("FT_NONE", 0);
define("FT_COUNT", 1);
define("FT_MIN", 2);
define("FT_MAX", 3);
//filter multiselect
define("FM_NONE", 0);
define("FM_ON_DEMAND", 1);
define("FM_ALWAYS", 2);
//filter format
define("FF_VALUE_LIST", "Values list");
define("FF_BOOLEAN", "Options list");
define("FF_INTERVAL_LIST", "Interval list");
define("FF_INTERVAL_SLIDER", "Interval slider");
//define filter interval limits' constants
define("FIL_NONE", 0);
define("FIL_MORE_THAN", 1);
define("FIL_LESS_THAN", 1);
define("FIL_LESS_THAN_OR_EQUAL", 2);
define("FIL_MORE_THAN_OR_EQUAL", 2);
define("FIL_REMAINDER", 3);
//define slider filter constants
define("FS_BOTH", 0);
define("FS_MIN_ONLY", 1);
define("FS_MAX_ONLY", 2);
//define slider step types
define("FSST_SECONDS", 0);
define("FSST_MINUTES", 1);
define("FSST_HOURS", 2);
define("FSST_DAYS", 3);
define("FSST_MONTHS", 4);
define("FSST_YEARS", 5);
//sorting constants
define('SORT_BY_DISP_VALUE', 0);
define('SORT_BY_DB_VALUE', 1);
define('SORT_BY_GR_VALUE', 2);
/**/


define("gltHORIZONTAL", 0);
define("gltVERTICAL", 1);
define("gltCOLUMNS", 2);
define("gltFLEXIBLE", 3);

/* Define comstamts for hidden columns devices*/
define("DESKTOP", 1);
define("TABLET_10_IN", 2);
define("TABLET_7_IN", 3);
define("SMARTPHONE_LANDSCAPE", 4);
define("SMARTPHONE_PORTRAIT", 5);
/**/

/* Dashboard types */
define("DASHBOARD_LIST", 0);
define("DASHBOARD_CHART", 1);
define("DASHBOARD_REPORT", 2);
define("DASHBOARD_RECORD", 3);
define("DASHBOARD_SEARCH", 4);
define("DASHBOARD_DETAILS", 5);
define("DASHBOARD_MAP", 6);
define("DASHBOARD_SNIPPET", 7);
/**/

/* Define message type constants */
define("MESSAGE_INFO", 1);
define("MESSAGE_ERROR", 2);

/* Define ML String type constants */
define("ML_TEXT", 0);
define("ML_CUSTOM_LABEL", 1);
define("ML_MESSAGE", 2);


/* Define print page and pdf page constants */
define("PRINT_PAGE_WIDTH", 700);
define("PRINT_PAGE_HEIGHT", 900);
define("PDF_PAGE_WIDTH", 750);
define("PDF_PAGE_HEIGHT", 1060);

/* Defined maps type */
define("GOOGLE_MAPS", 0);
define("OPEN_STREET_MAPS", 1);
define("BING_MAPS", 2);
define("HERE_MAPS", 3);
define("MAPQUEST_MAPS", 4);

/* Defined captcha type */
define("FLASH_CAPTCHA", 0);
define("RE_CAPTCHA", 1);

/* Define 'after record added/edited actions' constants*/
define("AA_TO_LIST", 0);
define("AA_TO_ADD", 1);
define("AA_TO_VIEW", 2);
define("AA_TO_EDIT", 3);
define("AA_TO_DETAIL_ADD", 4);
define("AA_TO_DETAIL_LIST", 5);

define("AE_TO_LIST", 0);
define("AE_TO_EDIT", 1);
define("AE_TO_VIEW", 2);
define("AE_TO_NEXT_EDIT", 3);
define("AE_TO_PREV_EDIT", 4);
define("AE_TO_DETAIL_LIST", 5);
/**/

define('BOOTSTRAP_LAYOUT', 3);
define('PD_BS_LAYOUT', 4); // temp

define('ICON_NONE', 0);
define('ICON_FILE', 1);
define('ICON_BOOTSTRAP_GLYPH', 2);
define('ICON_FONT_AWESOME', 3);


define('WELCOME_MENU', "welcome_page");

define('MENU_VERTICAL', "v");
define('MENU_HORIZONTAL', "h");
define('MENU_QUICKJUMP', "q");

// paramsLogger types
define('SSEARCH_PARAMS_TYPE', 1);
define('CRESIZE_PARAMS_TYPE', 2);
define('SHFIELDS_PARAMS_TYPE', 3);
define('FORDER_PARAMS_TYPE', 4);

// remind password method
define('RPM_SEND', 0 );
define('RPM_RESET', 1 );

define('CONTEXT_GLOBAL', 0);	//	global context
define('CONTEXT_PAGE', 1);		//	page where pageObject is available
define('CONTEXT_BUTTON', 2);	// 	button or other AJAX event
define('CONTEXT_LOOKUP', 3);	//	dependent lookup
define('CONTEXT_ROW', 4);		// 	processing grid row on multiple-records page (list)
define('CONTEXT_COMMAND', 5);	// 	DsCommand context
define('CONTEXT_SEARCH', 6);	// 	Search object context
define('CONTEXT_MASTER', 7);	// 	Master-details context

define('BOTH_RECORDS', 0);
define('NEXT_RECORD', 1);
define('PREV_RECORD', 2);

// login form types
define('LOGIN_SEPARATE', 0);
//define('LOGIN_POPUP', 1);
//define('LOGIN_EMBEDED', 2);
define('NO_LOGIN', 3);

define('MEDIA_DESKTOP', 0);
define('MEDIA_MOBILE', 1);
define('MEDIA_MOBILE_EXPANDED', 2);

define('WEBREPORTS_TABLE', "{04AFFBE6-86C0-47b0-ADD3-BA7FA19CA6FC}" );

define( 'WR_REPORT', 1 );
define( 'WR_CHART', 0 );

define('REST_BASIC', 1);
define('REST_APIKEY', 2);
define('REST_JWT', 3);
define('REST_OAUTH', 4);

define('TWOFACTOR_EMAIL', 0);
define('TWOFACTOR_PHONE', 1);
define('TWOFACTOR_APP', 2);


define("TIME_FORMAT_TIME_OF_DAY", 0);
define("TIME_FORMAT_DURATION", 1);

// user session levels
define("LOGGED_NONE", 0 );
//	logged in
define("LOGGED_FULL", 1 );
//	user has entered username & password, has to do 2factor authentication
define("LOGGED_2F_PENDING", 2 );
//	user has logged in, must setup 2factor authentication
define("LOGGED_2FSETUP_PENDING", 3 );
//	user has logged in, acount not activated, must confirm email address
define("LOGGED_ACTIVATION_PENDING", 4 );


define("stNONE", '%none' );
define("stHARDCODED", '%hardcoded' );
define("stDB", '%db' );
define("stAD", '%ad' );
define("stGOOGLE", '%google' );
define("stOPENID", '%openid' );
define("stFACEBOOK", '%facebook' );
define("stAZURE", '%azure' );
define("stSAML", '%saml' );
define("stOKTA", '%okta' );

//	storage providers
define("stpDISK", 0 );
define("stpAMAZON", 1 );
define("stpGOOGLEDRIVE", 2 );
define("stpONEDRIVE", 3 );
define("stpDROPBOX", 4 );
define("stpWASABI", 5 );

define( "spidGOOGLEDRIVE", "_PHPRunnerGoogleDriveConnection" );
define( "spidAMAZON", "_PHPRunnerAmazonS3Connection" );
define( "spidONEDRIVE", "_PHPRunnerOneDriveConnection" );
define( "spidDROPBOX", "_PHPRunnerDropboxConnection" );
define( "spidWASABI", "_PHPRunnerWasabiS3Connection" );

//	REST View payload format
define( "pfJSON", 1 );
define( "pfFORM", 4 );

$globalSettings = array();
$g_defaultOptionValues = array();
$g_settingsType = array();

$twilioSID = "";
$twilioAuth = "";
$twilioNumber = "";

// Update edit format for date text fields
$editTextAsDate = false;


/**
 * An option to be added to the wizard
 * Controls 'Remeber me' option
 */
$globalSettings["keepLoggedIn"] = true;

$globalSettings["bEncryptPasswords"] = true;
$globalSettings["nEncryptPasswordMethod"] = "0";

//mail settings
$globalSettings["useBuiltInMailer"] = false;

$globalSettings["useCustomSMTPSettings"] = true;

$globalSettings["strSMTPUser"] = "";
$globalSettings["strSMTPServer"] = "localhost";
$globalSettings["strSMTPPort"] = "25";
$globalSettings["strSMTPPassword"] = "";
$globalSettings["strFromEmail"] = "";

//

/*
$globalSettings["ADDomain"] = "";
$globalSettings["ADServer"] = "";
$globalSettings["ADFollowRefs"] = ;
$globalSettings["ADBaseDN"] = "";
if( !$globalSettings["ADBaseDN"] ) {
	$globalSettings["ADBaseDN"] = ldap_Domain2DN( $globalSettings["ADDomain"] );
}

$globalSettings["customLDAP"] = false;
*/
$customLDAPSettings = array(); //#9409

//	if user is member of group A, and group A is a memeber of group B,
//	count the user as member of group B
$adNestedPermissions = false;

$ajaxSearchStartsWith = true;

$globalSettings["staticGuestLogin"] = true;


$globalSettings["LandingPageType"] = 0;
$globalSettings["LandingTable"] = "";
$globalSettings["LandingPage"] = "";
$globalSettings["LandingURL"] = "";
$globalSettings["LandingPageId"] = "";

$globalSettings["ProjectLogo"] = array();
$globalSettings["ProjectLogo"]["Afrikaans"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Arabic"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Bosnian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Bulgarian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Catalan"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Chinese"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Chinese (Hong Kong S.A.R.)"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Chinese (Taiwan)"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Croatian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Czech"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Danish"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Dutch"] = "PatientRecord";
$globalSettings["ProjectLogo"]["English"] = "Patient Record";
$globalSettings["ProjectLogo"]["Farsi"] = "PatientRecord";
$globalSettings["ProjectLogo"]["French"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Georgian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["German"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Greek"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Hebrew"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Hungarian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Indonesian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Italian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Japanese"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Malay"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Norwegian(Bokmal)"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Polish"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Portuguese(Brazil)"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Portuguese(Standard)"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Romanian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Russian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Serbian"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Slovak"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Spanish"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Swedish"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Tagalog(Philippines)"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Thai"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Turkish"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Urdu"] = "PatientRecord";
$globalSettings["ProjectLogo"]["Welsh"] = "PatientRecord";

$globalSettings["CookieBanner"] = array();

$globalSettings["useCookieBanner"] = 1 != 0;

$globalSettings["htmlEmailTemplates"] = array();


$globalSettings["createLoginPage"] = true;
$globalSettings["userGroupCount"] = 2;


$globalSettings["apiGoogleMapsCode"] = "";

$globalSettings["useEmbedMapsAPI"] = 1 != 0;



/**
 * If true then detail table name will be printed before detail table on the view page
 * @var {bool}
 */
$globalSettings["printDetailTableName"] = true;

/**
 * Alias for custom expression in display field in ListPage_Lookup
 * @var {string}
 */
$globalSettings["dispFieldAlias"] = "rrdf1";

/**
 * If true then search suggest result will be handled in Lookup control
 * @var {bool}
 */
$globalSettings["handleSearchSuggestInLookup"] = true;

/**
 * Maximum size of search suggest result string
 * @var {int}
 */
$globalSettings["suggestStringSize"] = 40;

/**
 * The number of seach suggests displayed
 */
$globalSettings["searchSuggestsNumber"] = 10;

$globalSettings["override"] = array();


$styleOverrides = array();


$globalSettings["mapProvider"]=0;

$globalSettings["CaptchaSettings"] = array();
$globalSettings["CaptchaSettings"]["type"] = 0;
$globalSettings["CaptchaSettings"]["siteKey"] = "";
$globalSettings["CaptchaSettings"]["secretKey"] = "";
$globalSettings["CaptchaSettings"]["captchaPassesCount"] = "5";






$bsProjectTheme = "cerulean";
$bsProjectSize = "normal";

$wr_pagestylepath = "webreports";
$wr_is_standalone = false;
$WRAdminPagePassword = "";



/**
 * Legacy variables for pre-10.6 business templates only.
 * DEPRECATED
 */
$cLoginTable = "users";
$cDisplayNameField = "fullname";
$cUserNameField	= "username";
$cPasswordField	= "password";
$cUserGroupField = "username";
$cEmailField = "email";
$cUserpicField = "userpic";
$loginKeyFields= array();
$loginKeyFields[] = "ID";

//	legacy use only
$cKeyFields = $loginKeyFields;

/**
 * End Legacy csection
 */


$globalSettings["usersDatasourceTable"] = "users";


$globalSettings["jwtSecret"] = "eHpxTmhhSqdepMh9xpCU";


$arrCustomPages = array();


$gPermissionsRefreshTime = 5;
$gPermissionsRead = false;

//	-1 - undetermined, 0 - nah, 1 - yep
$gGuestHasPermissions = -1;

$useAJAX = true;
$suggestAllContent = true;

$strLastSQL = "";
$showCustomMarkerOnPrint = false;

$projectBuildKey = "126_1696351967";
$wizardBuildKey = "41242";
$projectBuildNumber = "126";

$mlang_messages = array();
$mlang_charsets = array();


$projectMenus = array();
$projectMenus[] = "main";
$projectMenus[] = "secondary";


$menuTreelikeFlags = array();
$menuTreelikeFlags["main"] = 1;

//	save menu objects
$menuCache = array();
$menuNodesCache = array();

$menuTreelikeFlags["secondary"] = 1;



// table captions
$tableCaptions = array();
$tableCaptions["English"] = array();
$tableCaptions["English"][""] = "";
$tableCaptions["English"]["diagnoses"] = "Diagnoses";
$tableCaptions["English"]["doctors"] = "Doctors";
$tableCaptions["English"]["medicines"] = "Medicines";
$tableCaptions["English"]["patients"] = "Patients";
$tableCaptions["English"]["treatments"] = "Treatments";
$tableCaptions["English"]["users"] = "Users";
$tableCaptions["English"]["admin_rights"] = "Admin Rights";
$tableCaptions["English"]["admin_members"] = "Admin Members";
$tableCaptions["English"]["admin_users"] = "Admin Users";
$tableCaptions["English"]["Dashboard"] = "Dashboard";
$tableCaptions["English"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["English"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["English"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["English"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Afrikaans"] = array();
$tableCaptions["Afrikaans"][""] = "";
$tableCaptions["Afrikaans"]["diagnoses"] = "Diagnoses";
$tableCaptions["Afrikaans"]["doctors"] = "Doctors";
$tableCaptions["Afrikaans"]["medicines"] = "Medicines";
$tableCaptions["Afrikaans"]["patients"] = "Patients";
$tableCaptions["Afrikaans"]["treatments"] = "Treatments";
$tableCaptions["Afrikaans"]["users"] = "Users";
$tableCaptions["Afrikaans"]["admin_rights"] = "Admin Rights";
$tableCaptions["Afrikaans"]["admin_members"] = "Admin Members";
$tableCaptions["Afrikaans"]["admin_users"] = "Admin Users";
$tableCaptions["Afrikaans"]["Dashboard"] = "Dashboard";
$tableCaptions["Afrikaans"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Afrikaans"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Afrikaans"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Afrikaans"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Arabic"] = array();
$tableCaptions["Arabic"][""] = "";
$tableCaptions["Arabic"]["diagnoses"] = "Diagnoses";
$tableCaptions["Arabic"]["doctors"] = "Doctors";
$tableCaptions["Arabic"]["medicines"] = "Medicines";
$tableCaptions["Arabic"]["patients"] = "Patients";
$tableCaptions["Arabic"]["treatments"] = "Treatments";
$tableCaptions["Arabic"]["users"] = "Users";
$tableCaptions["Arabic"]["admin_rights"] = "Admin Rights";
$tableCaptions["Arabic"]["admin_members"] = "Admin Members";
$tableCaptions["Arabic"]["admin_users"] = "Admin Users";
$tableCaptions["Arabic"]["Dashboard"] = "Dashboard";
$tableCaptions["Arabic"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Arabic"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Arabic"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Arabic"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Bosnian"] = array();
$tableCaptions["Bosnian"][""] = "";
$tableCaptions["Bosnian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Bosnian"]["doctors"] = "Doctors";
$tableCaptions["Bosnian"]["medicines"] = "Medicines";
$tableCaptions["Bosnian"]["patients"] = "Patients";
$tableCaptions["Bosnian"]["treatments"] = "Treatments";
$tableCaptions["Bosnian"]["users"] = "Users";
$tableCaptions["Bosnian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Bosnian"]["admin_members"] = "Admin Members";
$tableCaptions["Bosnian"]["admin_users"] = "Admin Users";
$tableCaptions["Bosnian"]["Dashboard"] = "Dashboard";
$tableCaptions["Bosnian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Bosnian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Bosnian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Bosnian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Bulgarian"] = array();
$tableCaptions["Bulgarian"][""] = "";
$tableCaptions["Bulgarian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Bulgarian"]["doctors"] = "Doctors";
$tableCaptions["Bulgarian"]["medicines"] = "Medicines";
$tableCaptions["Bulgarian"]["patients"] = "Patients";
$tableCaptions["Bulgarian"]["treatments"] = "Treatments";
$tableCaptions["Bulgarian"]["users"] = "Users";
$tableCaptions["Bulgarian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Bulgarian"]["admin_members"] = "Admin Members";
$tableCaptions["Bulgarian"]["admin_users"] = "Admin Users";
$tableCaptions["Bulgarian"]["Dashboard"] = "Dashboard";
$tableCaptions["Bulgarian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Bulgarian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Bulgarian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Bulgarian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Catalan"] = array();
$tableCaptions["Catalan"][""] = "";
$tableCaptions["Catalan"]["diagnoses"] = "Diagnoses";
$tableCaptions["Catalan"]["doctors"] = "Doctors";
$tableCaptions["Catalan"]["medicines"] = "Medicines";
$tableCaptions["Catalan"]["patients"] = "Patients";
$tableCaptions["Catalan"]["treatments"] = "Treatments";
$tableCaptions["Catalan"]["users"] = "Users";
$tableCaptions["Catalan"]["admin_rights"] = "Admin Rights";
$tableCaptions["Catalan"]["admin_members"] = "Admin Members";
$tableCaptions["Catalan"]["admin_users"] = "Admin Users";
$tableCaptions["Catalan"]["Dashboard"] = "Dashboard";
$tableCaptions["Catalan"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Catalan"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Catalan"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Catalan"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Chinese"] = array();
$tableCaptions["Chinese"][""] = "";
$tableCaptions["Chinese"]["diagnoses"] = "Diagnoses";
$tableCaptions["Chinese"]["doctors"] = "Doctors";
$tableCaptions["Chinese"]["medicines"] = "Medicines";
$tableCaptions["Chinese"]["patients"] = "Patients";
$tableCaptions["Chinese"]["treatments"] = "Treatments";
$tableCaptions["Chinese"]["users"] = "Users";
$tableCaptions["Chinese"]["admin_rights"] = "Admin Rights";
$tableCaptions["Chinese"]["admin_members"] = "Admin Members";
$tableCaptions["Chinese"]["admin_users"] = "Admin Users";
$tableCaptions["Chinese"]["Dashboard"] = "Dashboard";
$tableCaptions["Chinese"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Chinese"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Chinese"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Chinese"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Chinese (Hong Kong S.A.R.)"] = array();
$tableCaptions["Chinese (Hong Kong S.A.R.)"][""] = "";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["diagnoses"] = "Diagnoses";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["doctors"] = "Doctors";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["medicines"] = "Medicines";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["patients"] = "Patients";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["treatments"] = "Treatments";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["users"] = "Users";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["admin_rights"] = "Admin Rights";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["admin_members"] = "Admin Members";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["admin_users"] = "Admin Users";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["Dashboard"] = "Dashboard";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Chinese (Hong Kong S.A.R.)"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Chinese (Taiwan)"] = array();
$tableCaptions["Chinese (Taiwan)"][""] = "";
$tableCaptions["Chinese (Taiwan)"]["diagnoses"] = "Diagnoses";
$tableCaptions["Chinese (Taiwan)"]["doctors"] = "Doctors";
$tableCaptions["Chinese (Taiwan)"]["medicines"] = "Medicines";
$tableCaptions["Chinese (Taiwan)"]["patients"] = "Patients";
$tableCaptions["Chinese (Taiwan)"]["treatments"] = "Treatments";
$tableCaptions["Chinese (Taiwan)"]["users"] = "Users";
$tableCaptions["Chinese (Taiwan)"]["admin_rights"] = "Admin Rights";
$tableCaptions["Chinese (Taiwan)"]["admin_members"] = "Admin Members";
$tableCaptions["Chinese (Taiwan)"]["admin_users"] = "Admin Users";
$tableCaptions["Chinese (Taiwan)"]["Dashboard"] = "Dashboard";
$tableCaptions["Chinese (Taiwan)"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Chinese (Taiwan)"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Chinese (Taiwan)"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Chinese (Taiwan)"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Croatian"] = array();
$tableCaptions["Croatian"][""] = "";
$tableCaptions["Croatian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Croatian"]["doctors"] = "Doctors";
$tableCaptions["Croatian"]["medicines"] = "Medicines";
$tableCaptions["Croatian"]["patients"] = "Patients";
$tableCaptions["Croatian"]["treatments"] = "Treatments";
$tableCaptions["Croatian"]["users"] = "Users";
$tableCaptions["Croatian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Croatian"]["admin_members"] = "Admin Members";
$tableCaptions["Croatian"]["admin_users"] = "Admin Users";
$tableCaptions["Croatian"]["Dashboard"] = "Dashboard";
$tableCaptions["Croatian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Croatian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Croatian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Croatian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Czech"] = array();
$tableCaptions["Czech"][""] = "";
$tableCaptions["Czech"]["diagnoses"] = "Diagnoses";
$tableCaptions["Czech"]["doctors"] = "Doctors";
$tableCaptions["Czech"]["medicines"] = "Medicines";
$tableCaptions["Czech"]["patients"] = "Patients";
$tableCaptions["Czech"]["treatments"] = "Treatments";
$tableCaptions["Czech"]["users"] = "Users";
$tableCaptions["Czech"]["admin_rights"] = "Admin Rights";
$tableCaptions["Czech"]["admin_members"] = "Admin Members";
$tableCaptions["Czech"]["admin_users"] = "Admin Users";
$tableCaptions["Czech"]["Dashboard"] = "Dashboard";
$tableCaptions["Czech"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Czech"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Czech"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Czech"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Danish"] = array();
$tableCaptions["Danish"][""] = "";
$tableCaptions["Danish"]["diagnoses"] = "Diagnoses";
$tableCaptions["Danish"]["doctors"] = "Doctors";
$tableCaptions["Danish"]["medicines"] = "Medicines";
$tableCaptions["Danish"]["patients"] = "Patients";
$tableCaptions["Danish"]["treatments"] = "Treatments";
$tableCaptions["Danish"]["users"] = "Users";
$tableCaptions["Danish"]["admin_rights"] = "Admin Rights";
$tableCaptions["Danish"]["admin_members"] = "Admin Members";
$tableCaptions["Danish"]["admin_users"] = "Admin Users";
$tableCaptions["Danish"]["Dashboard"] = "Dashboard";
$tableCaptions["Danish"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Danish"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Danish"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Danish"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Dutch"] = array();
$tableCaptions["Dutch"][""] = "";
$tableCaptions["Dutch"]["diagnoses"] = "Diagnoses";
$tableCaptions["Dutch"]["doctors"] = "Doctors";
$tableCaptions["Dutch"]["medicines"] = "Medicines";
$tableCaptions["Dutch"]["patients"] = "Patients";
$tableCaptions["Dutch"]["treatments"] = "Treatments";
$tableCaptions["Dutch"]["users"] = "Users";
$tableCaptions["Dutch"]["admin_rights"] = "Admin Rights";
$tableCaptions["Dutch"]["admin_members"] = "Admin Members";
$tableCaptions["Dutch"]["admin_users"] = "Admin Users";
$tableCaptions["Dutch"]["Dashboard"] = "Dashboard";
$tableCaptions["Dutch"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Dutch"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Dutch"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Dutch"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Farsi"] = array();
$tableCaptions["Farsi"][""] = "";
$tableCaptions["Farsi"]["diagnoses"] = "Diagnoses";
$tableCaptions["Farsi"]["doctors"] = "Doctors";
$tableCaptions["Farsi"]["medicines"] = "Medicines";
$tableCaptions["Farsi"]["patients"] = "Patients";
$tableCaptions["Farsi"]["treatments"] = "Treatments";
$tableCaptions["Farsi"]["users"] = "Users";
$tableCaptions["Farsi"]["admin_rights"] = "Admin Rights";
$tableCaptions["Farsi"]["admin_members"] = "Admin Members";
$tableCaptions["Farsi"]["admin_users"] = "Admin Users";
$tableCaptions["Farsi"]["Dashboard"] = "Dashboard";
$tableCaptions["Farsi"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Farsi"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Farsi"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Farsi"]["patients_Chart"] = "Patients Chart";
$tableCaptions["French"] = array();
$tableCaptions["French"][""] = "";
$tableCaptions["French"]["diagnoses"] = "Diagnoses";
$tableCaptions["French"]["doctors"] = "Doctors";
$tableCaptions["French"]["medicines"] = "Medicines";
$tableCaptions["French"]["patients"] = "Patients";
$tableCaptions["French"]["treatments"] = "Treatments";
$tableCaptions["French"]["users"] = "Users";
$tableCaptions["French"]["admin_rights"] = "Admin Rights";
$tableCaptions["French"]["admin_members"] = "Admin Members";
$tableCaptions["French"]["admin_users"] = "Admin Users";
$tableCaptions["French"]["Dashboard"] = "Dashboard";
$tableCaptions["French"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["French"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["French"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["French"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Georgian"] = array();
$tableCaptions["Georgian"][""] = "";
$tableCaptions["Georgian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Georgian"]["doctors"] = "Doctors";
$tableCaptions["Georgian"]["medicines"] = "Medicines";
$tableCaptions["Georgian"]["patients"] = "Patients";
$tableCaptions["Georgian"]["treatments"] = "Treatments";
$tableCaptions["Georgian"]["users"] = "Users";
$tableCaptions["Georgian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Georgian"]["admin_members"] = "Admin Members";
$tableCaptions["Georgian"]["admin_users"] = "Admin Users";
$tableCaptions["Georgian"]["Dashboard"] = "Dashboard";
$tableCaptions["Georgian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Georgian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Georgian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Georgian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["German"] = array();
$tableCaptions["German"][""] = "";
$tableCaptions["German"]["diagnoses"] = "Diagnoses";
$tableCaptions["German"]["doctors"] = "Doctors";
$tableCaptions["German"]["medicines"] = "Medicines";
$tableCaptions["German"]["patients"] = "Patients";
$tableCaptions["German"]["treatments"] = "Treatments";
$tableCaptions["German"]["users"] = "Users";
$tableCaptions["German"]["admin_rights"] = "Admin Rights";
$tableCaptions["German"]["admin_members"] = "Admin Members";
$tableCaptions["German"]["admin_users"] = "Admin Users";
$tableCaptions["German"]["Dashboard"] = "Dashboard";
$tableCaptions["German"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["German"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["German"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["German"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Greek"] = array();
$tableCaptions["Greek"][""] = "";
$tableCaptions["Greek"]["diagnoses"] = "Diagnoses";
$tableCaptions["Greek"]["doctors"] = "Doctors";
$tableCaptions["Greek"]["medicines"] = "Medicines";
$tableCaptions["Greek"]["patients"] = "Patients";
$tableCaptions["Greek"]["treatments"] = "Treatments";
$tableCaptions["Greek"]["users"] = "Users";
$tableCaptions["Greek"]["admin_rights"] = "Admin Rights";
$tableCaptions["Greek"]["admin_members"] = "Admin Members";
$tableCaptions["Greek"]["admin_users"] = "Admin Users";
$tableCaptions["Greek"]["Dashboard"] = "Dashboard";
$tableCaptions["Greek"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Greek"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Greek"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Greek"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Hebrew"] = array();
$tableCaptions["Hebrew"][""] = "";
$tableCaptions["Hebrew"]["diagnoses"] = "Diagnoses";
$tableCaptions["Hebrew"]["doctors"] = "Doctors";
$tableCaptions["Hebrew"]["medicines"] = "Medicines";
$tableCaptions["Hebrew"]["patients"] = "Patients";
$tableCaptions["Hebrew"]["treatments"] = "Treatments";
$tableCaptions["Hebrew"]["users"] = "Users";
$tableCaptions["Hebrew"]["admin_rights"] = "Admin Rights";
$tableCaptions["Hebrew"]["admin_members"] = "Admin Members";
$tableCaptions["Hebrew"]["admin_users"] = "Admin Users";
$tableCaptions["Hebrew"]["Dashboard"] = "Dashboard";
$tableCaptions["Hebrew"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Hebrew"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Hebrew"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Hebrew"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Hungarian"] = array();
$tableCaptions["Hungarian"][""] = "";
$tableCaptions["Hungarian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Hungarian"]["doctors"] = "Doctors";
$tableCaptions["Hungarian"]["medicines"] = "Medicines";
$tableCaptions["Hungarian"]["patients"] = "Patients";
$tableCaptions["Hungarian"]["treatments"] = "Treatments";
$tableCaptions["Hungarian"]["users"] = "Users";
$tableCaptions["Hungarian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Hungarian"]["admin_members"] = "Admin Members";
$tableCaptions["Hungarian"]["admin_users"] = "Admin Users";
$tableCaptions["Hungarian"]["Dashboard"] = "Dashboard";
$tableCaptions["Hungarian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Hungarian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Hungarian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Hungarian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Indonesian"] = array();
$tableCaptions["Indonesian"][""] = "";
$tableCaptions["Indonesian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Indonesian"]["doctors"] = "Doctors";
$tableCaptions["Indonesian"]["medicines"] = "Medicines";
$tableCaptions["Indonesian"]["patients"] = "Patients";
$tableCaptions["Indonesian"]["treatments"] = "Treatments";
$tableCaptions["Indonesian"]["users"] = "Users";
$tableCaptions["Indonesian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Indonesian"]["admin_members"] = "Admin Members";
$tableCaptions["Indonesian"]["admin_users"] = "Admin Users";
$tableCaptions["Indonesian"]["Dashboard"] = "Dashboard";
$tableCaptions["Indonesian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Indonesian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Indonesian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Indonesian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Italian"] = array();
$tableCaptions["Italian"][""] = "";
$tableCaptions["Italian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Italian"]["doctors"] = "Doctors";
$tableCaptions["Italian"]["medicines"] = "Medicines";
$tableCaptions["Italian"]["patients"] = "Patients";
$tableCaptions["Italian"]["treatments"] = "Treatments";
$tableCaptions["Italian"]["users"] = "Users";
$tableCaptions["Italian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Italian"]["admin_members"] = "Admin Members";
$tableCaptions["Italian"]["admin_users"] = "Admin Users";
$tableCaptions["Italian"]["Dashboard"] = "Dashboard";
$tableCaptions["Italian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Italian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Italian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Italian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Japanese"] = array();
$tableCaptions["Japanese"][""] = "";
$tableCaptions["Japanese"]["diagnoses"] = "Diagnoses";
$tableCaptions["Japanese"]["doctors"] = "Doctors";
$tableCaptions["Japanese"]["medicines"] = "Medicines";
$tableCaptions["Japanese"]["patients"] = "Patients";
$tableCaptions["Japanese"]["treatments"] = "Treatments";
$tableCaptions["Japanese"]["users"] = "Users";
$tableCaptions["Japanese"]["admin_rights"] = "Admin Rights";
$tableCaptions["Japanese"]["admin_members"] = "Admin Members";
$tableCaptions["Japanese"]["admin_users"] = "Admin Users";
$tableCaptions["Japanese"]["Dashboard"] = "Dashboard";
$tableCaptions["Japanese"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Japanese"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Japanese"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Japanese"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Malay"] = array();
$tableCaptions["Malay"][""] = "";
$tableCaptions["Malay"]["diagnoses"] = "Diagnoses";
$tableCaptions["Malay"]["doctors"] = "Doctors";
$tableCaptions["Malay"]["medicines"] = "Medicines";
$tableCaptions["Malay"]["patients"] = "Patients";
$tableCaptions["Malay"]["treatments"] = "Treatments";
$tableCaptions["Malay"]["users"] = "Users";
$tableCaptions["Malay"]["admin_rights"] = "Admin Rights";
$tableCaptions["Malay"]["admin_members"] = "Admin Members";
$tableCaptions["Malay"]["admin_users"] = "Admin Users";
$tableCaptions["Malay"]["Dashboard"] = "Dashboard";
$tableCaptions["Malay"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Malay"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Malay"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Malay"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Norwegian(Bokmal)"] = array();
$tableCaptions["Norwegian(Bokmal)"][""] = "";
$tableCaptions["Norwegian(Bokmal)"]["diagnoses"] = "Diagnoses";
$tableCaptions["Norwegian(Bokmal)"]["doctors"] = "Doctors";
$tableCaptions["Norwegian(Bokmal)"]["medicines"] = "Medicines";
$tableCaptions["Norwegian(Bokmal)"]["patients"] = "Patients";
$tableCaptions["Norwegian(Bokmal)"]["treatments"] = "Treatments";
$tableCaptions["Norwegian(Bokmal)"]["users"] = "Users";
$tableCaptions["Norwegian(Bokmal)"]["admin_rights"] = "Admin Rights";
$tableCaptions["Norwegian(Bokmal)"]["admin_members"] = "Admin Members";
$tableCaptions["Norwegian(Bokmal)"]["admin_users"] = "Admin Users";
$tableCaptions["Norwegian(Bokmal)"]["Dashboard"] = "Dashboard";
$tableCaptions["Norwegian(Bokmal)"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Norwegian(Bokmal)"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Norwegian(Bokmal)"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Norwegian(Bokmal)"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Polish"] = array();
$tableCaptions["Polish"][""] = "";
$tableCaptions["Polish"]["diagnoses"] = "Diagnoses";
$tableCaptions["Polish"]["doctors"] = "Doctors";
$tableCaptions["Polish"]["medicines"] = "Medicines";
$tableCaptions["Polish"]["patients"] = "Patients";
$tableCaptions["Polish"]["treatments"] = "Treatments";
$tableCaptions["Polish"]["users"] = "Users";
$tableCaptions["Polish"]["admin_rights"] = "Admin Rights";
$tableCaptions["Polish"]["admin_members"] = "Admin Members";
$tableCaptions["Polish"]["admin_users"] = "Admin Users";
$tableCaptions["Polish"]["Dashboard"] = "Dashboard";
$tableCaptions["Polish"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Polish"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Polish"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Polish"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Portuguese(Brazil)"] = array();
$tableCaptions["Portuguese(Brazil)"][""] = "";
$tableCaptions["Portuguese(Brazil)"]["diagnoses"] = "Diagnoses";
$tableCaptions["Portuguese(Brazil)"]["doctors"] = "Doctors";
$tableCaptions["Portuguese(Brazil)"]["medicines"] = "Medicines";
$tableCaptions["Portuguese(Brazil)"]["patients"] = "Patients";
$tableCaptions["Portuguese(Brazil)"]["treatments"] = "Treatments";
$tableCaptions["Portuguese(Brazil)"]["users"] = "Users";
$tableCaptions["Portuguese(Brazil)"]["admin_rights"] = "Admin Rights";
$tableCaptions["Portuguese(Brazil)"]["admin_members"] = "Admin Members";
$tableCaptions["Portuguese(Brazil)"]["admin_users"] = "Admin Users";
$tableCaptions["Portuguese(Brazil)"]["Dashboard"] = "Dashboard";
$tableCaptions["Portuguese(Brazil)"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Portuguese(Brazil)"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Portuguese(Brazil)"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Portuguese(Brazil)"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Portuguese(Standard)"] = array();
$tableCaptions["Portuguese(Standard)"][""] = "";
$tableCaptions["Portuguese(Standard)"]["diagnoses"] = "Diagnoses";
$tableCaptions["Portuguese(Standard)"]["doctors"] = "Doctors";
$tableCaptions["Portuguese(Standard)"]["medicines"] = "Medicines";
$tableCaptions["Portuguese(Standard)"]["patients"] = "Patients";
$tableCaptions["Portuguese(Standard)"]["treatments"] = "Treatments";
$tableCaptions["Portuguese(Standard)"]["users"] = "Users";
$tableCaptions["Portuguese(Standard)"]["admin_rights"] = "Admin Rights";
$tableCaptions["Portuguese(Standard)"]["admin_members"] = "Admin Members";
$tableCaptions["Portuguese(Standard)"]["admin_users"] = "Admin Users";
$tableCaptions["Portuguese(Standard)"]["Dashboard"] = "Dashboard";
$tableCaptions["Portuguese(Standard)"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Portuguese(Standard)"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Portuguese(Standard)"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Portuguese(Standard)"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Romanian"] = array();
$tableCaptions["Romanian"][""] = "";
$tableCaptions["Romanian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Romanian"]["doctors"] = "Doctors";
$tableCaptions["Romanian"]["medicines"] = "Medicines";
$tableCaptions["Romanian"]["patients"] = "Patients";
$tableCaptions["Romanian"]["treatments"] = "Treatments";
$tableCaptions["Romanian"]["users"] = "Users";
$tableCaptions["Romanian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Romanian"]["admin_members"] = "Admin Members";
$tableCaptions["Romanian"]["admin_users"] = "Admin Users";
$tableCaptions["Romanian"]["Dashboard"] = "Dashboard";
$tableCaptions["Romanian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Romanian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Romanian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Romanian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Russian"] = array();
$tableCaptions["Russian"][""] = "";
$tableCaptions["Russian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Russian"]["doctors"] = "Doctors";
$tableCaptions["Russian"]["medicines"] = "Medicines";
$tableCaptions["Russian"]["patients"] = "Patients";
$tableCaptions["Russian"]["treatments"] = "Treatments";
$tableCaptions["Russian"]["users"] = "Users";
$tableCaptions["Russian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Russian"]["admin_members"] = "Admin Members";
$tableCaptions["Russian"]["admin_users"] = "Admin Users";
$tableCaptions["Russian"]["Dashboard"] = "Dashboard";
$tableCaptions["Russian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Russian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Russian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Russian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Serbian"] = array();
$tableCaptions["Serbian"][""] = "";
$tableCaptions["Serbian"]["diagnoses"] = "Diagnoses";
$tableCaptions["Serbian"]["doctors"] = "Doctors";
$tableCaptions["Serbian"]["medicines"] = "Medicines";
$tableCaptions["Serbian"]["patients"] = "Patients";
$tableCaptions["Serbian"]["treatments"] = "Treatments";
$tableCaptions["Serbian"]["users"] = "Users";
$tableCaptions["Serbian"]["admin_rights"] = "Admin Rights";
$tableCaptions["Serbian"]["admin_members"] = "Admin Members";
$tableCaptions["Serbian"]["admin_users"] = "Admin Users";
$tableCaptions["Serbian"]["Dashboard"] = "Dashboard";
$tableCaptions["Serbian"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Serbian"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Serbian"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Serbian"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Slovak"] = array();
$tableCaptions["Slovak"][""] = "";
$tableCaptions["Slovak"]["diagnoses"] = "Diagnoses";
$tableCaptions["Slovak"]["doctors"] = "Doctors";
$tableCaptions["Slovak"]["medicines"] = "Medicines";
$tableCaptions["Slovak"]["patients"] = "Patients";
$tableCaptions["Slovak"]["treatments"] = "Treatments";
$tableCaptions["Slovak"]["users"] = "Users";
$tableCaptions["Slovak"]["admin_rights"] = "Admin Rights";
$tableCaptions["Slovak"]["admin_members"] = "Admin Members";
$tableCaptions["Slovak"]["admin_users"] = "Admin Users";
$tableCaptions["Slovak"]["Dashboard"] = "Dashboard";
$tableCaptions["Slovak"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Slovak"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Slovak"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Slovak"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Spanish"] = array();
$tableCaptions["Spanish"][""] = "";
$tableCaptions["Spanish"]["diagnoses"] = "Diagnoses";
$tableCaptions["Spanish"]["doctors"] = "Doctors";
$tableCaptions["Spanish"]["medicines"] = "Medicines";
$tableCaptions["Spanish"]["patients"] = "Patients";
$tableCaptions["Spanish"]["treatments"] = "Treatments";
$tableCaptions["Spanish"]["users"] = "Users";
$tableCaptions["Spanish"]["admin_rights"] = "Admin Rights";
$tableCaptions["Spanish"]["admin_members"] = "Admin Members";
$tableCaptions["Spanish"]["admin_users"] = "Admin Users";
$tableCaptions["Spanish"]["Dashboard"] = "Dashboard";
$tableCaptions["Spanish"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Spanish"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Spanish"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Spanish"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Swedish"] = array();
$tableCaptions["Swedish"][""] = "";
$tableCaptions["Swedish"]["diagnoses"] = "Diagnoses";
$tableCaptions["Swedish"]["doctors"] = "Doctors";
$tableCaptions["Swedish"]["medicines"] = "Medicines";
$tableCaptions["Swedish"]["patients"] = "Patients";
$tableCaptions["Swedish"]["treatments"] = "Treatments";
$tableCaptions["Swedish"]["users"] = "Users";
$tableCaptions["Swedish"]["admin_rights"] = "Admin Rights";
$tableCaptions["Swedish"]["admin_members"] = "Admin Members";
$tableCaptions["Swedish"]["admin_users"] = "Admin Users";
$tableCaptions["Swedish"]["Dashboard"] = "Dashboard";
$tableCaptions["Swedish"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Swedish"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Swedish"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Swedish"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Tagalog(Philippines)"] = array();
$tableCaptions["Tagalog(Philippines)"][""] = "";
$tableCaptions["Tagalog(Philippines)"]["diagnoses"] = "Diagnoses";
$tableCaptions["Tagalog(Philippines)"]["doctors"] = "Doctors";
$tableCaptions["Tagalog(Philippines)"]["medicines"] = "Medicines";
$tableCaptions["Tagalog(Philippines)"]["patients"] = "Patients";
$tableCaptions["Tagalog(Philippines)"]["treatments"] = "Treatments";
$tableCaptions["Tagalog(Philippines)"]["users"] = "Users";
$tableCaptions["Tagalog(Philippines)"]["admin_rights"] = "Admin Rights";
$tableCaptions["Tagalog(Philippines)"]["admin_members"] = "Admin Members";
$tableCaptions["Tagalog(Philippines)"]["admin_users"] = "Admin Users";
$tableCaptions["Tagalog(Philippines)"]["Dashboard"] = "Dashboard";
$tableCaptions["Tagalog(Philippines)"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Tagalog(Philippines)"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Tagalog(Philippines)"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Tagalog(Philippines)"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Thai"] = array();
$tableCaptions["Thai"][""] = "";
$tableCaptions["Thai"]["diagnoses"] = "Diagnoses";
$tableCaptions["Thai"]["doctors"] = "Doctors";
$tableCaptions["Thai"]["medicines"] = "Medicines";
$tableCaptions["Thai"]["patients"] = "Patients";
$tableCaptions["Thai"]["treatments"] = "Treatments";
$tableCaptions["Thai"]["users"] = "Users";
$tableCaptions["Thai"]["admin_rights"] = "Admin Rights";
$tableCaptions["Thai"]["admin_members"] = "Admin Members";
$tableCaptions["Thai"]["admin_users"] = "Admin Users";
$tableCaptions["Thai"]["Dashboard"] = "Dashboard";
$tableCaptions["Thai"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Thai"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Thai"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Thai"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Turkish"] = array();
$tableCaptions["Turkish"][""] = "";
$tableCaptions["Turkish"]["diagnoses"] = "Diagnoses";
$tableCaptions["Turkish"]["doctors"] = "Doctors";
$tableCaptions["Turkish"]["medicines"] = "Medicines";
$tableCaptions["Turkish"]["patients"] = "Patients";
$tableCaptions["Turkish"]["treatments"] = "Treatments";
$tableCaptions["Turkish"]["users"] = "Users";
$tableCaptions["Turkish"]["admin_rights"] = "Admin Rights";
$tableCaptions["Turkish"]["admin_members"] = "Admin Members";
$tableCaptions["Turkish"]["admin_users"] = "Admin Users";
$tableCaptions["Turkish"]["Dashboard"] = "Dashboard";
$tableCaptions["Turkish"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Turkish"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Turkish"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Turkish"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Urdu"] = array();
$tableCaptions["Urdu"][""] = "";
$tableCaptions["Urdu"]["diagnoses"] = "Diagnoses";
$tableCaptions["Urdu"]["doctors"] = "Doctors";
$tableCaptions["Urdu"]["medicines"] = "Medicines";
$tableCaptions["Urdu"]["patients"] = "Patients";
$tableCaptions["Urdu"]["treatments"] = "Treatments";
$tableCaptions["Urdu"]["users"] = "Users";
$tableCaptions["Urdu"]["admin_rights"] = "Admin Rights";
$tableCaptions["Urdu"]["admin_members"] = "Admin Members";
$tableCaptions["Urdu"]["admin_users"] = "Admin Users";
$tableCaptions["Urdu"]["Dashboard"] = "Dashboard";
$tableCaptions["Urdu"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Urdu"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Urdu"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Urdu"]["patients_Chart"] = "Patients Chart";
$tableCaptions["Welsh"] = array();
$tableCaptions["Welsh"][""] = "";
$tableCaptions["Welsh"]["diagnoses"] = "Diagnoses";
$tableCaptions["Welsh"]["doctors"] = "Doctors";
$tableCaptions["Welsh"]["medicines"] = "Medicines";
$tableCaptions["Welsh"]["patients"] = "Patients";
$tableCaptions["Welsh"]["treatments"] = "Treatments";
$tableCaptions["Welsh"]["users"] = "Users";
$tableCaptions["Welsh"]["admin_rights"] = "Admin Rights";
$tableCaptions["Welsh"]["admin_members"] = "Admin Members";
$tableCaptions["Welsh"]["admin_users"] = "Admin Users";
$tableCaptions["Welsh"]["Dashboard"] = "Dashboard";
$tableCaptions["Welsh"]["diagnoses_Chart"] = "Diagnoses Chart";
$tableCaptions["Welsh"]["medicines_Chart"] = "Medicines Chart";
$tableCaptions["Welsh"]["treatments_Chart"] = "Treatments Chart";
$tableCaptions["Welsh"]["patients_Chart"] = "Patients Chart";


$globalEvents = new class_GlobalEvents;
$dummyEvents = new eventsBase;
$tableEvents = array();
$dalTables = array();
$tableinfo_cache = array();

$projectLanguage = "php";

importSecuritySettings();


require_once( getabspath('classes/labels.php') );
require_once( getabspath('classes/security.php') );
require_once( getabspath("connections/dbfunctions_legacy.php") );
require_once( getabspath("classes/datasource/httprequest.php") );
require_once( getabspath("connections/ConnectionManager.php") );
require_once( getabspath("connections/apis.php") );
require_once( getabspath('classes/searchclause.php'));
require_once( getabspath('classes/projectsettings.php'));
include_once( getabspath('classes/runnerpage.php'));
include_once( getabspath("classes/controls/ViewControl.php"));
require_once( getabspath('classes/db.php') );
require_once( getabspath('classes/context.php') );
require_once( getabspath("classes/cipherer.php"));
require_once( getabspath('classes/wheretabs.php') );
require_once( getabspath('classes/datasource/datacontext.php') );
require_once( getabspath("classes/filesystem/filesystem.php") );
require_once( getabspath("classes/runnermenu.php") );

$pageTypesForView = array();
$pageTypesForView[] = "list";
$pageTypesForView[] = "view";
$pageTypesForView[] = "export";
$pageTypesForView[] = "print";
$pageTypesForView[] = "report";
$pageTypesForView[] = "rprint";
$pageTypesForView[] = "chart";
$pageTypesForView[] = "masterlist";
$pageTypesForView[] = "masterprint";

$pageTypesForEdit = array();
$pageTypesForEdit[] = "add";
$pageTypesForEdit[] = "edit";
$pageTypesForEdit[] = "search";
$pageTypesForEdit[] = "register";


$projectEntities = array();
$projectEntitiesReverse = array();
$tablesByGoodName = array();
$tablesByUpperCase = array();
$tablesByUpperGoodname = array();


$contextStack = new RunnerContext;

$cman = new ConnectionManager();
$restApis = new RestManager();
$restResultCache = array();

/**
 * substitute for $_SESSION when in REST API (stateless) mode
 */
$restStorage = array();

$currentConnection = null;

$mlang_defaultlang = getDefaultLanguage();

include(getabspath("include/languages.php"));

$mediaType = isset($_COOKIE["mediaType"]) ? $_COOKIE["mediaType"] : 0;



$page_titles[GLOBAL_PAGES_SHORT] = array();
if(mlang_getcurrentlang()=="English")
{
}
if(mlang_getcurrentlang()=="Afrikaans")
{
}
if(mlang_getcurrentlang()=="Arabic")
{
}
if(mlang_getcurrentlang()=="Bosnian")
{
}
if(mlang_getcurrentlang()=="Bulgarian")
{
}
if(mlang_getcurrentlang()=="Catalan")
{
}
if(mlang_getcurrentlang()=="Chinese")
{
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
}
if(mlang_getcurrentlang()=="Croatian")
{
}
if(mlang_getcurrentlang()=="Czech")
{
}
if(mlang_getcurrentlang()=="Danish")
{
}
if(mlang_getcurrentlang()=="Dutch")
{
}
if(mlang_getcurrentlang()=="Farsi")
{
}
if(mlang_getcurrentlang()=="French")
{
}
if(mlang_getcurrentlang()=="Georgian")
{
}
if(mlang_getcurrentlang()=="German")
{
}
if(mlang_getcurrentlang()=="Greek")
{
}
if(mlang_getcurrentlang()=="Hebrew")
{
}
if(mlang_getcurrentlang()=="Hungarian")
{
}
if(mlang_getcurrentlang()=="Indonesian")
{
}
if(mlang_getcurrentlang()=="Italian")
{
}
if(mlang_getcurrentlang()=="Japanese")
{
}
if(mlang_getcurrentlang()=="Malay")
{
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
}
if(mlang_getcurrentlang()=="Polish")
{
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
}
if(mlang_getcurrentlang()=="Romanian")
{
}
if(mlang_getcurrentlang()=="Russian")
{
}
if(mlang_getcurrentlang()=="Serbian")
{
}
if(mlang_getcurrentlang()=="Slovak")
{
}
if(mlang_getcurrentlang()=="Spanish")
{
}
if(mlang_getcurrentlang()=="Swedish")
{
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
}
if(mlang_getcurrentlang()=="Thai")
{
}
if(mlang_getcurrentlang()=="Turkish")
{
}
if(mlang_getcurrentlang()=="Urdu")
{
}
if(mlang_getcurrentlang()=="Welsh")
{
}

$globalSettings["showDetailedError"] = true;



$globalSettings["mapMarkerCount"] = 50;

// SearchClause::getSearchObject
$_cachedSeachClauses = array();

/**
 * Lazy initialization dictionaries such as mime types for mimeTypeByExt go here
 */
$onDemnadVariables = array();


$auditMaxFieldLength = 300;
$mysqlSupportDates0000 = false;

$csrfProtectionOff = false;
$cacheImages = true;
/**
 * When true, read user permissions and write them into the session.
 */
$gReadPermissions = true;

$resizeImagesOnClient = false;


$fieldFilterMaxDisplayValueLength = 50;
$fieldFilterMaxSearchValueLength = 200;
$fieldFilterMaxValuesCount = 3000;
$fieldFilterDefaultValue = "";
$fieldFilterValueShrinkPostfix = "...";




// default connection link #9875
$conn = $cman->getDefault()->conn;


//	delete old username & password cookies
if( $_COOKIE["password"] ) {
	runner_setcookie("username", "", time() - 1, "", "", false, false);
	runner_setcookie("password", "", time() - 1, "", "", false, false);
}


$logoutPerformed = false;
Security::autoLoginAsGuest();
Security::updateCSRFCookie();


$isUseRTEBasic = true;

$isUseRTECK = false;

$isUseRTEInnova = false;

$menuNodesIndex=0;

/**
 *	Sundry data the page classes want pass to their JS counterparts
 *
 *	$pagesData[<pageid>] = array( 	<key> => <value>
 *									<key> => <value> ... )
 *					)
 */
$pagesData = array();

$pageInConstruction = null;


?>