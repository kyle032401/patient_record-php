<?php
$tdatadiagnoses = array();
$tdatadiagnoses[".searchableFields"] = array();
$tdatadiagnoses[".ShortName"] = "diagnoses";
$tdatadiagnoses[".OwnerID"] = "id";
$tdatadiagnoses[".OriginalTable"] = "diagnoses";


$tdatadiagnoses[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatadiagnoses[".originalPagesByType"] = $tdatadiagnoses[".pagesByType"];
$tdatadiagnoses[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatadiagnoses[".originalPages"] = $tdatadiagnoses[".pages"];
$tdatadiagnoses[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatadiagnoses[".originalDefaultPages"] = $tdatadiagnoses[".defaultPages"];

//	field labels
$fieldLabelsdiagnoses = array();
$fieldToolTipsdiagnoses = array();
$pageTitlesdiagnoses = array();
$placeHoldersdiagnoses = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdiagnoses["English"] = array();
	$fieldToolTipsdiagnoses["English"] = array();
	$placeHoldersdiagnoses["English"] = array();
	$pageTitlesdiagnoses["English"] = array();
	$fieldLabelsdiagnoses["English"]["id"] = "Id";
	$fieldToolTipsdiagnoses["English"]["id"] = "";
	$placeHoldersdiagnoses["English"]["id"] = "";
	$fieldLabelsdiagnoses["English"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["English"]["TakenTime"] = "";
	$placeHoldersdiagnoses["English"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["English"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["English"]["Quantity"] = "";
	$placeHoldersdiagnoses["English"]["Quantity"] = "";
	$fieldLabelsdiagnoses["English"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["English"]["treatment_id"] = "";
	$placeHoldersdiagnoses["English"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["English"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["English"]["medicine_id"] = "";
	$placeHoldersdiagnoses["English"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["English"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["English"]["Photo"] = "";
	$placeHoldersdiagnoses["English"]["Photo"] = "";
	$fieldLabelsdiagnoses["English"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["English"]["Result"] = "";
	$placeHoldersdiagnoses["English"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["English"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsdiagnoses["Afrikaans"] = array();
	$fieldToolTipsdiagnoses["Afrikaans"] = array();
	$placeHoldersdiagnoses["Afrikaans"] = array();
	$pageTitlesdiagnoses["Afrikaans"] = array();
	$fieldLabelsdiagnoses["Afrikaans"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Afrikaans"]["id"] = "";
	$placeHoldersdiagnoses["Afrikaans"]["id"] = "";
	$fieldLabelsdiagnoses["Afrikaans"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Afrikaans"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Afrikaans"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Afrikaans"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Afrikaans"]["Quantity"] = "";
	$placeHoldersdiagnoses["Afrikaans"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Afrikaans"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Afrikaans"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Afrikaans"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Afrikaans"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Afrikaans"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Afrikaans"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Afrikaans"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Afrikaans"]["Photo"] = "";
	$placeHoldersdiagnoses["Afrikaans"]["Photo"] = "";
	$fieldLabelsdiagnoses["Afrikaans"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Afrikaans"]["Result"] = "";
	$placeHoldersdiagnoses["Afrikaans"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Afrikaans"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsdiagnoses["Arabic"] = array();
	$fieldToolTipsdiagnoses["Arabic"] = array();
	$placeHoldersdiagnoses["Arabic"] = array();
	$pageTitlesdiagnoses["Arabic"] = array();
	$fieldLabelsdiagnoses["Arabic"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Arabic"]["id"] = "";
	$placeHoldersdiagnoses["Arabic"]["id"] = "";
	$fieldLabelsdiagnoses["Arabic"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Arabic"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Arabic"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Arabic"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Arabic"]["Quantity"] = "";
	$placeHoldersdiagnoses["Arabic"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Arabic"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Arabic"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Arabic"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Arabic"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Arabic"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Arabic"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Arabic"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Arabic"]["Photo"] = "";
	$placeHoldersdiagnoses["Arabic"]["Photo"] = "";
	$fieldLabelsdiagnoses["Arabic"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Arabic"]["Result"] = "";
	$placeHoldersdiagnoses["Arabic"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Arabic"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsdiagnoses["Bosnian"] = array();
	$fieldToolTipsdiagnoses["Bosnian"] = array();
	$placeHoldersdiagnoses["Bosnian"] = array();
	$pageTitlesdiagnoses["Bosnian"] = array();
	$fieldLabelsdiagnoses["Bosnian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Bosnian"]["id"] = "";
	$placeHoldersdiagnoses["Bosnian"]["id"] = "";
	$fieldLabelsdiagnoses["Bosnian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Bosnian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Bosnian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Bosnian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Bosnian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Bosnian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Bosnian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Bosnian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Bosnian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Bosnian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Bosnian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Bosnian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Bosnian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Bosnian"]["Photo"] = "";
	$placeHoldersdiagnoses["Bosnian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Bosnian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Bosnian"]["Result"] = "";
	$placeHoldersdiagnoses["Bosnian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Bosnian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsdiagnoses["Bulgarian"] = array();
	$fieldToolTipsdiagnoses["Bulgarian"] = array();
	$placeHoldersdiagnoses["Bulgarian"] = array();
	$pageTitlesdiagnoses["Bulgarian"] = array();
	$fieldLabelsdiagnoses["Bulgarian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Bulgarian"]["id"] = "";
	$placeHoldersdiagnoses["Bulgarian"]["id"] = "";
	$fieldLabelsdiagnoses["Bulgarian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Bulgarian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Bulgarian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Bulgarian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Bulgarian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Bulgarian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Bulgarian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Bulgarian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Bulgarian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Bulgarian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Bulgarian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Bulgarian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Bulgarian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Bulgarian"]["Photo"] = "";
	$placeHoldersdiagnoses["Bulgarian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Bulgarian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Bulgarian"]["Result"] = "";
	$placeHoldersdiagnoses["Bulgarian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Bulgarian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsdiagnoses["Catalan"] = array();
	$fieldToolTipsdiagnoses["Catalan"] = array();
	$placeHoldersdiagnoses["Catalan"] = array();
	$pageTitlesdiagnoses["Catalan"] = array();
	$fieldLabelsdiagnoses["Catalan"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Catalan"]["id"] = "";
	$placeHoldersdiagnoses["Catalan"]["id"] = "";
	$fieldLabelsdiagnoses["Catalan"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Catalan"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Catalan"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Catalan"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Catalan"]["Quantity"] = "";
	$placeHoldersdiagnoses["Catalan"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Catalan"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Catalan"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Catalan"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Catalan"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Catalan"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Catalan"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Catalan"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Catalan"]["Photo"] = "";
	$placeHoldersdiagnoses["Catalan"]["Photo"] = "";
	$fieldLabelsdiagnoses["Catalan"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Catalan"]["Result"] = "";
	$placeHoldersdiagnoses["Catalan"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Catalan"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsdiagnoses["Chinese"] = array();
	$fieldToolTipsdiagnoses["Chinese"] = array();
	$placeHoldersdiagnoses["Chinese"] = array();
	$pageTitlesdiagnoses["Chinese"] = array();
	$fieldLabelsdiagnoses["Chinese"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Chinese"]["id"] = "";
	$placeHoldersdiagnoses["Chinese"]["id"] = "";
	$fieldLabelsdiagnoses["Chinese"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Chinese"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Chinese"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Chinese"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Chinese"]["Quantity"] = "";
	$placeHoldersdiagnoses["Chinese"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Chinese"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Chinese"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Chinese"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Chinese"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Chinese"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Chinese"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Chinese"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Chinese"]["Photo"] = "";
	$placeHoldersdiagnoses["Chinese"]["Photo"] = "";
	$fieldLabelsdiagnoses["Chinese"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Chinese"]["Result"] = "";
	$placeHoldersdiagnoses["Chinese"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Chinese"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesdiagnoses["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "";
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$fieldLabelsdiagnoses["Chinese (Hong Kong S.A.R.)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]["Result"] = "";
	$placeHoldersdiagnoses["Chinese (Hong Kong S.A.R.)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Chinese (Hong Kong S.A.R.)"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsdiagnoses["Chinese (Taiwan)"] = array();
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"] = array();
	$placeHoldersdiagnoses["Chinese (Taiwan)"] = array();
	$pageTitlesdiagnoses["Chinese (Taiwan)"] = array();
	$fieldLabelsdiagnoses["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersdiagnoses["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsdiagnoses["Chinese (Taiwan)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Chinese (Taiwan)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Chinese (Taiwan)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"]["Quantity"] = "";
	$placeHoldersdiagnoses["Chinese (Taiwan)"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Chinese (Taiwan)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Chinese (Taiwan)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Chinese (Taiwan)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Chinese (Taiwan)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Chinese (Taiwan)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"]["Photo"] = "";
	$placeHoldersdiagnoses["Chinese (Taiwan)"]["Photo"] = "";
	$fieldLabelsdiagnoses["Chinese (Taiwan)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Chinese (Taiwan)"]["Result"] = "";
	$placeHoldersdiagnoses["Chinese (Taiwan)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Chinese (Taiwan)"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsdiagnoses["Croatian"] = array();
	$fieldToolTipsdiagnoses["Croatian"] = array();
	$placeHoldersdiagnoses["Croatian"] = array();
	$pageTitlesdiagnoses["Croatian"] = array();
	$fieldLabelsdiagnoses["Croatian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Croatian"]["id"] = "";
	$placeHoldersdiagnoses["Croatian"]["id"] = "";
	$fieldLabelsdiagnoses["Croatian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Croatian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Croatian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Croatian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Croatian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Croatian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Croatian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Croatian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Croatian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Croatian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Croatian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Croatian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Croatian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Croatian"]["Photo"] = "";
	$placeHoldersdiagnoses["Croatian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Croatian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Croatian"]["Result"] = "";
	$placeHoldersdiagnoses["Croatian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Croatian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsdiagnoses["Czech"] = array();
	$fieldToolTipsdiagnoses["Czech"] = array();
	$placeHoldersdiagnoses["Czech"] = array();
	$pageTitlesdiagnoses["Czech"] = array();
	$fieldLabelsdiagnoses["Czech"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Czech"]["id"] = "";
	$placeHoldersdiagnoses["Czech"]["id"] = "";
	$fieldLabelsdiagnoses["Czech"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Czech"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Czech"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Czech"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Czech"]["Quantity"] = "";
	$placeHoldersdiagnoses["Czech"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Czech"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Czech"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Czech"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Czech"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Czech"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Czech"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Czech"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Czech"]["Photo"] = "";
	$placeHoldersdiagnoses["Czech"]["Photo"] = "";
	$fieldLabelsdiagnoses["Czech"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Czech"]["Result"] = "";
	$placeHoldersdiagnoses["Czech"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Czech"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsdiagnoses["Danish"] = array();
	$fieldToolTipsdiagnoses["Danish"] = array();
	$placeHoldersdiagnoses["Danish"] = array();
	$pageTitlesdiagnoses["Danish"] = array();
	$fieldLabelsdiagnoses["Danish"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Danish"]["id"] = "";
	$placeHoldersdiagnoses["Danish"]["id"] = "";
	$fieldLabelsdiagnoses["Danish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Danish"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Danish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Danish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Danish"]["Quantity"] = "";
	$placeHoldersdiagnoses["Danish"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Danish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Danish"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Danish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Danish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Danish"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Danish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Danish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Danish"]["Photo"] = "";
	$placeHoldersdiagnoses["Danish"]["Photo"] = "";
	$fieldLabelsdiagnoses["Danish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Danish"]["Result"] = "";
	$placeHoldersdiagnoses["Danish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Danish"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsdiagnoses["Dutch"] = array();
	$fieldToolTipsdiagnoses["Dutch"] = array();
	$placeHoldersdiagnoses["Dutch"] = array();
	$pageTitlesdiagnoses["Dutch"] = array();
	$fieldLabelsdiagnoses["Dutch"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Dutch"]["id"] = "";
	$placeHoldersdiagnoses["Dutch"]["id"] = "";
	$fieldLabelsdiagnoses["Dutch"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Dutch"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Dutch"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Dutch"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Dutch"]["Quantity"] = "";
	$placeHoldersdiagnoses["Dutch"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Dutch"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Dutch"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Dutch"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Dutch"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Dutch"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Dutch"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Dutch"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Dutch"]["Photo"] = "";
	$placeHoldersdiagnoses["Dutch"]["Photo"] = "";
	$fieldLabelsdiagnoses["Dutch"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Dutch"]["Result"] = "";
	$placeHoldersdiagnoses["Dutch"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Dutch"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsdiagnoses["Farsi"] = array();
	$fieldToolTipsdiagnoses["Farsi"] = array();
	$placeHoldersdiagnoses["Farsi"] = array();
	$pageTitlesdiagnoses["Farsi"] = array();
	$fieldLabelsdiagnoses["Farsi"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Farsi"]["id"] = "";
	$placeHoldersdiagnoses["Farsi"]["id"] = "";
	$fieldLabelsdiagnoses["Farsi"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Farsi"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Farsi"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Farsi"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Farsi"]["Quantity"] = "";
	$placeHoldersdiagnoses["Farsi"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Farsi"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Farsi"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Farsi"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Farsi"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Farsi"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Farsi"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Farsi"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Farsi"]["Photo"] = "";
	$placeHoldersdiagnoses["Farsi"]["Photo"] = "";
	$fieldLabelsdiagnoses["Farsi"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Farsi"]["Result"] = "";
	$placeHoldersdiagnoses["Farsi"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Farsi"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsdiagnoses["French"] = array();
	$fieldToolTipsdiagnoses["French"] = array();
	$placeHoldersdiagnoses["French"] = array();
	$pageTitlesdiagnoses["French"] = array();
	$fieldLabelsdiagnoses["French"]["id"] = "Id";
	$fieldToolTipsdiagnoses["French"]["id"] = "";
	$placeHoldersdiagnoses["French"]["id"] = "";
	$fieldLabelsdiagnoses["French"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["French"]["TakenTime"] = "";
	$placeHoldersdiagnoses["French"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["French"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["French"]["Quantity"] = "";
	$placeHoldersdiagnoses["French"]["Quantity"] = "";
	$fieldLabelsdiagnoses["French"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["French"]["treatment_id"] = "";
	$placeHoldersdiagnoses["French"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["French"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["French"]["medicine_id"] = "";
	$placeHoldersdiagnoses["French"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["French"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["French"]["Photo"] = "";
	$placeHoldersdiagnoses["French"]["Photo"] = "";
	$fieldLabelsdiagnoses["French"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["French"]["Result"] = "";
	$placeHoldersdiagnoses["French"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["French"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsdiagnoses["Georgian"] = array();
	$fieldToolTipsdiagnoses["Georgian"] = array();
	$placeHoldersdiagnoses["Georgian"] = array();
	$pageTitlesdiagnoses["Georgian"] = array();
	$fieldLabelsdiagnoses["Georgian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Georgian"]["id"] = "";
	$placeHoldersdiagnoses["Georgian"]["id"] = "";
	$fieldLabelsdiagnoses["Georgian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Georgian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Georgian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Georgian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Georgian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Georgian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Georgian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Georgian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Georgian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Georgian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Georgian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Georgian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Georgian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Georgian"]["Photo"] = "";
	$placeHoldersdiagnoses["Georgian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Georgian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Georgian"]["Result"] = "";
	$placeHoldersdiagnoses["Georgian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Georgian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsdiagnoses["German"] = array();
	$fieldToolTipsdiagnoses["German"] = array();
	$placeHoldersdiagnoses["German"] = array();
	$pageTitlesdiagnoses["German"] = array();
	$fieldLabelsdiagnoses["German"]["id"] = "Id";
	$fieldToolTipsdiagnoses["German"]["id"] = "";
	$placeHoldersdiagnoses["German"]["id"] = "";
	$fieldLabelsdiagnoses["German"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["German"]["TakenTime"] = "";
	$placeHoldersdiagnoses["German"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["German"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["German"]["Quantity"] = "";
	$placeHoldersdiagnoses["German"]["Quantity"] = "";
	$fieldLabelsdiagnoses["German"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["German"]["treatment_id"] = "";
	$placeHoldersdiagnoses["German"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["German"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["German"]["medicine_id"] = "";
	$placeHoldersdiagnoses["German"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["German"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["German"]["Photo"] = "";
	$placeHoldersdiagnoses["German"]["Photo"] = "";
	$fieldLabelsdiagnoses["German"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["German"]["Result"] = "";
	$placeHoldersdiagnoses["German"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["German"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsdiagnoses["Greek"] = array();
	$fieldToolTipsdiagnoses["Greek"] = array();
	$placeHoldersdiagnoses["Greek"] = array();
	$pageTitlesdiagnoses["Greek"] = array();
	$fieldLabelsdiagnoses["Greek"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Greek"]["id"] = "";
	$placeHoldersdiagnoses["Greek"]["id"] = "";
	$fieldLabelsdiagnoses["Greek"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Greek"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Greek"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Greek"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Greek"]["Quantity"] = "";
	$placeHoldersdiagnoses["Greek"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Greek"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Greek"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Greek"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Greek"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Greek"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Greek"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Greek"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Greek"]["Photo"] = "";
	$placeHoldersdiagnoses["Greek"]["Photo"] = "";
	$fieldLabelsdiagnoses["Greek"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Greek"]["Result"] = "";
	$placeHoldersdiagnoses["Greek"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Greek"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsdiagnoses["Hebrew"] = array();
	$fieldToolTipsdiagnoses["Hebrew"] = array();
	$placeHoldersdiagnoses["Hebrew"] = array();
	$pageTitlesdiagnoses["Hebrew"] = array();
	$fieldLabelsdiagnoses["Hebrew"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Hebrew"]["id"] = "";
	$placeHoldersdiagnoses["Hebrew"]["id"] = "";
	$fieldLabelsdiagnoses["Hebrew"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Hebrew"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Hebrew"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Hebrew"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Hebrew"]["Quantity"] = "";
	$placeHoldersdiagnoses["Hebrew"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Hebrew"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Hebrew"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Hebrew"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Hebrew"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Hebrew"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Hebrew"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Hebrew"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Hebrew"]["Photo"] = "";
	$placeHoldersdiagnoses["Hebrew"]["Photo"] = "";
	$fieldLabelsdiagnoses["Hebrew"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Hebrew"]["Result"] = "";
	$placeHoldersdiagnoses["Hebrew"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Hebrew"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsdiagnoses["Hungarian"] = array();
	$fieldToolTipsdiagnoses["Hungarian"] = array();
	$placeHoldersdiagnoses["Hungarian"] = array();
	$pageTitlesdiagnoses["Hungarian"] = array();
	$fieldLabelsdiagnoses["Hungarian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Hungarian"]["id"] = "";
	$placeHoldersdiagnoses["Hungarian"]["id"] = "";
	$fieldLabelsdiagnoses["Hungarian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Hungarian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Hungarian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Hungarian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Hungarian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Hungarian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Hungarian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Hungarian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Hungarian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Hungarian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Hungarian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Hungarian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Hungarian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Hungarian"]["Photo"] = "";
	$placeHoldersdiagnoses["Hungarian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Hungarian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Hungarian"]["Result"] = "";
	$placeHoldersdiagnoses["Hungarian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Hungarian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsdiagnoses["Indonesian"] = array();
	$fieldToolTipsdiagnoses["Indonesian"] = array();
	$placeHoldersdiagnoses["Indonesian"] = array();
	$pageTitlesdiagnoses["Indonesian"] = array();
	$fieldLabelsdiagnoses["Indonesian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Indonesian"]["id"] = "";
	$placeHoldersdiagnoses["Indonesian"]["id"] = "";
	$fieldLabelsdiagnoses["Indonesian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Indonesian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Indonesian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Indonesian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Indonesian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Indonesian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Indonesian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Indonesian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Indonesian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Indonesian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Indonesian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Indonesian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Indonesian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Indonesian"]["Photo"] = "";
	$placeHoldersdiagnoses["Indonesian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Indonesian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Indonesian"]["Result"] = "";
	$placeHoldersdiagnoses["Indonesian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Indonesian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsdiagnoses["Italian"] = array();
	$fieldToolTipsdiagnoses["Italian"] = array();
	$placeHoldersdiagnoses["Italian"] = array();
	$pageTitlesdiagnoses["Italian"] = array();
	$fieldLabelsdiagnoses["Italian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Italian"]["id"] = "";
	$placeHoldersdiagnoses["Italian"]["id"] = "";
	$fieldLabelsdiagnoses["Italian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Italian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Italian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Italian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Italian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Italian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Italian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Italian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Italian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Italian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Italian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Italian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Italian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Italian"]["Photo"] = "";
	$placeHoldersdiagnoses["Italian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Italian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Italian"]["Result"] = "";
	$placeHoldersdiagnoses["Italian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Italian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsdiagnoses["Japanese"] = array();
	$fieldToolTipsdiagnoses["Japanese"] = array();
	$placeHoldersdiagnoses["Japanese"] = array();
	$pageTitlesdiagnoses["Japanese"] = array();
	$fieldLabelsdiagnoses["Japanese"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Japanese"]["id"] = "";
	$placeHoldersdiagnoses["Japanese"]["id"] = "";
	$fieldLabelsdiagnoses["Japanese"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Japanese"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Japanese"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Japanese"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Japanese"]["Quantity"] = "";
	$placeHoldersdiagnoses["Japanese"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Japanese"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Japanese"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Japanese"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Japanese"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Japanese"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Japanese"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Japanese"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Japanese"]["Photo"] = "";
	$placeHoldersdiagnoses["Japanese"]["Photo"] = "";
	$fieldLabelsdiagnoses["Japanese"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Japanese"]["Result"] = "";
	$placeHoldersdiagnoses["Japanese"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Japanese"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsdiagnoses["Malay"] = array();
	$fieldToolTipsdiagnoses["Malay"] = array();
	$placeHoldersdiagnoses["Malay"] = array();
	$pageTitlesdiagnoses["Malay"] = array();
	$fieldLabelsdiagnoses["Malay"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Malay"]["id"] = "";
	$placeHoldersdiagnoses["Malay"]["id"] = "";
	$fieldLabelsdiagnoses["Malay"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Malay"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Malay"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Malay"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Malay"]["Quantity"] = "";
	$placeHoldersdiagnoses["Malay"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Malay"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Malay"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Malay"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Malay"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Malay"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Malay"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Malay"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Malay"]["Photo"] = "";
	$placeHoldersdiagnoses["Malay"]["Photo"] = "";
	$fieldLabelsdiagnoses["Malay"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Malay"]["Result"] = "";
	$placeHoldersdiagnoses["Malay"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Malay"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"] = array();
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"] = array();
	$placeHoldersdiagnoses["Norwegian(Bokmal)"] = array();
	$pageTitlesdiagnoses["Norwegian(Bokmal)"] = array();
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersdiagnoses["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Norwegian(Bokmal)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"]["Quantity"] = "";
	$placeHoldersdiagnoses["Norwegian(Bokmal)"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Norwegian(Bokmal)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Norwegian(Bokmal)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"]["Photo"] = "";
	$placeHoldersdiagnoses["Norwegian(Bokmal)"]["Photo"] = "";
	$fieldLabelsdiagnoses["Norwegian(Bokmal)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Norwegian(Bokmal)"]["Result"] = "";
	$placeHoldersdiagnoses["Norwegian(Bokmal)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Norwegian(Bokmal)"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsdiagnoses["Polish"] = array();
	$fieldToolTipsdiagnoses["Polish"] = array();
	$placeHoldersdiagnoses["Polish"] = array();
	$pageTitlesdiagnoses["Polish"] = array();
	$fieldLabelsdiagnoses["Polish"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Polish"]["id"] = "";
	$placeHoldersdiagnoses["Polish"]["id"] = "";
	$fieldLabelsdiagnoses["Polish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Polish"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Polish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Polish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Polish"]["Quantity"] = "";
	$placeHoldersdiagnoses["Polish"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Polish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Polish"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Polish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Polish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Polish"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Polish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Polish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Polish"]["Photo"] = "";
	$placeHoldersdiagnoses["Polish"]["Photo"] = "";
	$fieldLabelsdiagnoses["Polish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Polish"]["Result"] = "";
	$placeHoldersdiagnoses["Polish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Polish"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsdiagnoses["Portuguese(Brazil)"] = array();
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"] = array();
	$placeHoldersdiagnoses["Portuguese(Brazil)"] = array();
	$pageTitlesdiagnoses["Portuguese(Brazil)"] = array();
	$fieldLabelsdiagnoses["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersdiagnoses["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsdiagnoses["Portuguese(Brazil)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Portuguese(Brazil)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Portuguese(Brazil)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"]["Quantity"] = "";
	$placeHoldersdiagnoses["Portuguese(Brazil)"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Portuguese(Brazil)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Portuguese(Brazil)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Portuguese(Brazil)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Portuguese(Brazil)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Portuguese(Brazil)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"]["Photo"] = "";
	$placeHoldersdiagnoses["Portuguese(Brazil)"]["Photo"] = "";
	$fieldLabelsdiagnoses["Portuguese(Brazil)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Portuguese(Brazil)"]["Result"] = "";
	$placeHoldersdiagnoses["Portuguese(Brazil)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Portuguese(Brazil)"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsdiagnoses["Portuguese(Standard)"] = array();
	$fieldToolTipsdiagnoses["Portuguese(Standard)"] = array();
	$placeHoldersdiagnoses["Portuguese(Standard)"] = array();
	$pageTitlesdiagnoses["Portuguese(Standard)"] = array();
	$fieldLabelsdiagnoses["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Portuguese(Standard)"]["id"] = "";
	$placeHoldersdiagnoses["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsdiagnoses["Portuguese(Standard)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Portuguese(Standard)"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Portuguese(Standard)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Portuguese(Standard)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Portuguese(Standard)"]["Quantity"] = "";
	$placeHoldersdiagnoses["Portuguese(Standard)"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Portuguese(Standard)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Portuguese(Standard)"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Portuguese(Standard)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Portuguese(Standard)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Portuguese(Standard)"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Portuguese(Standard)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Portuguese(Standard)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Portuguese(Standard)"]["Photo"] = "";
	$placeHoldersdiagnoses["Portuguese(Standard)"]["Photo"] = "";
	$fieldLabelsdiagnoses["Portuguese(Standard)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Portuguese(Standard)"]["Result"] = "";
	$placeHoldersdiagnoses["Portuguese(Standard)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Portuguese(Standard)"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsdiagnoses["Romanian"] = array();
	$fieldToolTipsdiagnoses["Romanian"] = array();
	$placeHoldersdiagnoses["Romanian"] = array();
	$pageTitlesdiagnoses["Romanian"] = array();
	$fieldLabelsdiagnoses["Romanian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Romanian"]["id"] = "";
	$placeHoldersdiagnoses["Romanian"]["id"] = "";
	$fieldLabelsdiagnoses["Romanian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Romanian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Romanian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Romanian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Romanian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Romanian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Romanian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Romanian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Romanian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Romanian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Romanian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Romanian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Romanian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Romanian"]["Photo"] = "";
	$placeHoldersdiagnoses["Romanian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Romanian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Romanian"]["Result"] = "";
	$placeHoldersdiagnoses["Romanian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Romanian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsdiagnoses["Russian"] = array();
	$fieldToolTipsdiagnoses["Russian"] = array();
	$placeHoldersdiagnoses["Russian"] = array();
	$pageTitlesdiagnoses["Russian"] = array();
	$fieldLabelsdiagnoses["Russian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Russian"]["id"] = "";
	$placeHoldersdiagnoses["Russian"]["id"] = "";
	$fieldLabelsdiagnoses["Russian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Russian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Russian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Russian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Russian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Russian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Russian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Russian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Russian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Russian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Russian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Russian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Russian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Russian"]["Photo"] = "";
	$placeHoldersdiagnoses["Russian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Russian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Russian"]["Result"] = "";
	$placeHoldersdiagnoses["Russian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Russian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsdiagnoses["Serbian"] = array();
	$fieldToolTipsdiagnoses["Serbian"] = array();
	$placeHoldersdiagnoses["Serbian"] = array();
	$pageTitlesdiagnoses["Serbian"] = array();
	$fieldLabelsdiagnoses["Serbian"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Serbian"]["id"] = "";
	$placeHoldersdiagnoses["Serbian"]["id"] = "";
	$fieldLabelsdiagnoses["Serbian"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Serbian"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Serbian"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Serbian"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Serbian"]["Quantity"] = "";
	$placeHoldersdiagnoses["Serbian"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Serbian"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Serbian"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Serbian"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Serbian"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Serbian"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Serbian"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Serbian"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Serbian"]["Photo"] = "";
	$placeHoldersdiagnoses["Serbian"]["Photo"] = "";
	$fieldLabelsdiagnoses["Serbian"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Serbian"]["Result"] = "";
	$placeHoldersdiagnoses["Serbian"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Serbian"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsdiagnoses["Slovak"] = array();
	$fieldToolTipsdiagnoses["Slovak"] = array();
	$placeHoldersdiagnoses["Slovak"] = array();
	$pageTitlesdiagnoses["Slovak"] = array();
	$fieldLabelsdiagnoses["Slovak"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Slovak"]["id"] = "";
	$placeHoldersdiagnoses["Slovak"]["id"] = "";
	$fieldLabelsdiagnoses["Slovak"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Slovak"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Slovak"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Slovak"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Slovak"]["Quantity"] = "";
	$placeHoldersdiagnoses["Slovak"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Slovak"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Slovak"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Slovak"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Slovak"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Slovak"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Slovak"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Slovak"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Slovak"]["Photo"] = "";
	$placeHoldersdiagnoses["Slovak"]["Photo"] = "";
	$fieldLabelsdiagnoses["Slovak"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Slovak"]["Result"] = "";
	$placeHoldersdiagnoses["Slovak"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Slovak"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsdiagnoses["Spanish"] = array();
	$fieldToolTipsdiagnoses["Spanish"] = array();
	$placeHoldersdiagnoses["Spanish"] = array();
	$pageTitlesdiagnoses["Spanish"] = array();
	$fieldLabelsdiagnoses["Spanish"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Spanish"]["id"] = "";
	$placeHoldersdiagnoses["Spanish"]["id"] = "";
	$fieldLabelsdiagnoses["Spanish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Spanish"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Spanish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Spanish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Spanish"]["Quantity"] = "";
	$placeHoldersdiagnoses["Spanish"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Spanish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Spanish"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Spanish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Spanish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Spanish"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Spanish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Spanish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Spanish"]["Photo"] = "";
	$placeHoldersdiagnoses["Spanish"]["Photo"] = "";
	$fieldLabelsdiagnoses["Spanish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Spanish"]["Result"] = "";
	$placeHoldersdiagnoses["Spanish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Spanish"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsdiagnoses["Swedish"] = array();
	$fieldToolTipsdiagnoses["Swedish"] = array();
	$placeHoldersdiagnoses["Swedish"] = array();
	$pageTitlesdiagnoses["Swedish"] = array();
	$fieldLabelsdiagnoses["Swedish"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Swedish"]["id"] = "";
	$placeHoldersdiagnoses["Swedish"]["id"] = "";
	$fieldLabelsdiagnoses["Swedish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Swedish"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Swedish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Swedish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Swedish"]["Quantity"] = "";
	$placeHoldersdiagnoses["Swedish"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Swedish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Swedish"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Swedish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Swedish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Swedish"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Swedish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Swedish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Swedish"]["Photo"] = "";
	$placeHoldersdiagnoses["Swedish"]["Photo"] = "";
	$fieldLabelsdiagnoses["Swedish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Swedish"]["Result"] = "";
	$placeHoldersdiagnoses["Swedish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Swedish"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsdiagnoses["Tagalog(Philippines)"] = array();
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"] = array();
	$placeHoldersdiagnoses["Tagalog(Philippines)"] = array();
	$pageTitlesdiagnoses["Tagalog(Philippines)"] = array();
	$fieldLabelsdiagnoses["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersdiagnoses["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsdiagnoses["Tagalog(Philippines)"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Tagalog(Philippines)"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Tagalog(Philippines)"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"]["Quantity"] = "";
	$placeHoldersdiagnoses["Tagalog(Philippines)"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Tagalog(Philippines)"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Tagalog(Philippines)"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Tagalog(Philippines)"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Tagalog(Philippines)"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Tagalog(Philippines)"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"]["Photo"] = "";
	$placeHoldersdiagnoses["Tagalog(Philippines)"]["Photo"] = "";
	$fieldLabelsdiagnoses["Tagalog(Philippines)"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Tagalog(Philippines)"]["Result"] = "";
	$placeHoldersdiagnoses["Tagalog(Philippines)"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Tagalog(Philippines)"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsdiagnoses["Thai"] = array();
	$fieldToolTipsdiagnoses["Thai"] = array();
	$placeHoldersdiagnoses["Thai"] = array();
	$pageTitlesdiagnoses["Thai"] = array();
	$fieldLabelsdiagnoses["Thai"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Thai"]["id"] = "";
	$placeHoldersdiagnoses["Thai"]["id"] = "";
	$fieldLabelsdiagnoses["Thai"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Thai"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Thai"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Thai"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Thai"]["Quantity"] = "";
	$placeHoldersdiagnoses["Thai"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Thai"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Thai"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Thai"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Thai"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Thai"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Thai"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Thai"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Thai"]["Photo"] = "";
	$placeHoldersdiagnoses["Thai"]["Photo"] = "";
	$fieldLabelsdiagnoses["Thai"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Thai"]["Result"] = "";
	$placeHoldersdiagnoses["Thai"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Thai"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsdiagnoses["Turkish"] = array();
	$fieldToolTipsdiagnoses["Turkish"] = array();
	$placeHoldersdiagnoses["Turkish"] = array();
	$pageTitlesdiagnoses["Turkish"] = array();
	$fieldLabelsdiagnoses["Turkish"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Turkish"]["id"] = "";
	$placeHoldersdiagnoses["Turkish"]["id"] = "";
	$fieldLabelsdiagnoses["Turkish"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Turkish"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Turkish"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Turkish"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Turkish"]["Quantity"] = "";
	$placeHoldersdiagnoses["Turkish"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Turkish"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Turkish"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Turkish"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Turkish"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Turkish"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Turkish"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Turkish"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Turkish"]["Photo"] = "";
	$placeHoldersdiagnoses["Turkish"]["Photo"] = "";
	$fieldLabelsdiagnoses["Turkish"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Turkish"]["Result"] = "";
	$placeHoldersdiagnoses["Turkish"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Turkish"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsdiagnoses["Urdu"] = array();
	$fieldToolTipsdiagnoses["Urdu"] = array();
	$placeHoldersdiagnoses["Urdu"] = array();
	$pageTitlesdiagnoses["Urdu"] = array();
	$fieldLabelsdiagnoses["Urdu"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Urdu"]["id"] = "";
	$placeHoldersdiagnoses["Urdu"]["id"] = "";
	$fieldLabelsdiagnoses["Urdu"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Urdu"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Urdu"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Urdu"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Urdu"]["Quantity"] = "";
	$placeHoldersdiagnoses["Urdu"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Urdu"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Urdu"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Urdu"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Urdu"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Urdu"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Urdu"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Urdu"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Urdu"]["Photo"] = "";
	$placeHoldersdiagnoses["Urdu"]["Photo"] = "";
	$fieldLabelsdiagnoses["Urdu"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Urdu"]["Result"] = "";
	$placeHoldersdiagnoses["Urdu"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Urdu"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsdiagnoses["Welsh"] = array();
	$fieldToolTipsdiagnoses["Welsh"] = array();
	$placeHoldersdiagnoses["Welsh"] = array();
	$pageTitlesdiagnoses["Welsh"] = array();
	$fieldLabelsdiagnoses["Welsh"]["id"] = "Id";
	$fieldToolTipsdiagnoses["Welsh"]["id"] = "";
	$placeHoldersdiagnoses["Welsh"]["id"] = "";
	$fieldLabelsdiagnoses["Welsh"]["TakenTime"] = "Taken Time";
	$fieldToolTipsdiagnoses["Welsh"]["TakenTime"] = "";
	$placeHoldersdiagnoses["Welsh"]["TakenTime"] = "";
	$fieldLabelsdiagnoses["Welsh"]["Quantity"] = "Quantity";
	$fieldToolTipsdiagnoses["Welsh"]["Quantity"] = "";
	$placeHoldersdiagnoses["Welsh"]["Quantity"] = "";
	$fieldLabelsdiagnoses["Welsh"]["treatment_id"] = "Treatment Id";
	$fieldToolTipsdiagnoses["Welsh"]["treatment_id"] = "";
	$placeHoldersdiagnoses["Welsh"]["treatment_id"] = "";
	$fieldLabelsdiagnoses["Welsh"]["medicine_id"] = "Medicine Id";
	$fieldToolTipsdiagnoses["Welsh"]["medicine_id"] = "";
	$placeHoldersdiagnoses["Welsh"]["medicine_id"] = "";
	$fieldLabelsdiagnoses["Welsh"]["Photo"] = "Photo";
	$fieldToolTipsdiagnoses["Welsh"]["Photo"] = "";
	$placeHoldersdiagnoses["Welsh"]["Photo"] = "";
	$fieldLabelsdiagnoses["Welsh"]["Result"] = "Result";
	$fieldToolTipsdiagnoses["Welsh"]["Result"] = "";
	$placeHoldersdiagnoses["Welsh"]["Result"] = "";
	if (count($fieldToolTipsdiagnoses["Welsh"]))
		$tdatadiagnoses[".isUseToolTips"] = true;
}


	$tdatadiagnoses[".NCSearch"] = true;



$tdatadiagnoses[".shortTableName"] = "diagnoses";
$tdatadiagnoses[".nSecOptions"] = 0;

$tdatadiagnoses[".mainTableOwnerID"] = "id";
$tdatadiagnoses[".entityType"] = 0;
$tdatadiagnoses[".connId"] = "testdb_at_localhost";


$tdatadiagnoses[".strOriginalTableName"] = "diagnoses";

	



$tdatadiagnoses[".showAddInPopup"] = false;

$tdatadiagnoses[".showEditInPopup"] = false;

$tdatadiagnoses[".showViewInPopup"] = false;

	$tdatadiagnoses[".listAjax"] = true;
//	temporary
//$tdatadiagnoses[".listAjax"] = false;

	$tdatadiagnoses[".audit"] = false;

	$tdatadiagnoses[".locking"] = false;


$pages = $tdatadiagnoses[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatadiagnoses[".edit"] = true;
	$tdatadiagnoses[".afterEditAction"] = 1;
	$tdatadiagnoses[".closePopupAfterEdit"] = 1;
	$tdatadiagnoses[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatadiagnoses[".add"] = true;
$tdatadiagnoses[".afterAddAction"] = 1;
$tdatadiagnoses[".closePopupAfterAdd"] = 1;
$tdatadiagnoses[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatadiagnoses[".list"] = true;
}



$tdatadiagnoses[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatadiagnoses[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatadiagnoses[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatadiagnoses[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatadiagnoses[".printFriendly"] = true;
}



$tdatadiagnoses[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatadiagnoses[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatadiagnoses[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatadiagnoses[".isUseAjaxSuggest"] = true;





$tdatadiagnoses[".ajaxCodeSnippetAdded"] = false;

$tdatadiagnoses[".buttonsAdded"] = false;

$tdatadiagnoses[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadiagnoses[".isUseTimeForSearch"] = false;


$tdatadiagnoses[".badgeColor"] = "DB7093";


$tdatadiagnoses[".allSearchFields"] = array();
$tdatadiagnoses[".filterFields"] = array();
$tdatadiagnoses[".requiredSearchFields"] = array();

$tdatadiagnoses[".googleLikeFields"] = array();
$tdatadiagnoses[".googleLikeFields"][] = "id";
$tdatadiagnoses[".googleLikeFields"][] = "TakenTime";
$tdatadiagnoses[".googleLikeFields"][] = "Quantity";
$tdatadiagnoses[".googleLikeFields"][] = "treatment_id";
$tdatadiagnoses[".googleLikeFields"][] = "medicine_id";
$tdatadiagnoses[".googleLikeFields"][] = "Photo";
$tdatadiagnoses[".googleLikeFields"][] = "Result";



$tdatadiagnoses[".tableType"] = "list";

$tdatadiagnoses[".printerPageOrientation"] = 0;
$tdatadiagnoses[".nPrinterPageScale"] = 100;

$tdatadiagnoses[".nPrinterSplitRecords"] = 40;

$tdatadiagnoses[".geocodingEnabled"] = false;




$tdatadiagnoses[".isDisplayLoading"] = true;






$tdatadiagnoses[".pageSize"] = 20;

$tdatadiagnoses[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdatadiagnoses[".strOrderBy"] = $tstrOrderBy;

$tdatadiagnoses[".orderindexes"] = array();


$tdatadiagnoses[".sqlHead"] = "SELECT id,  	TakenTime,  	Quantity,  	treatment_id,  	medicine_id,  	Photo,  	`Result`";
$tdatadiagnoses[".sqlFrom"] = "FROM diagnoses";
$tdatadiagnoses[".sqlWhereExpr"] = "";
$tdatadiagnoses[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadiagnoses[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadiagnoses[".arrGroupsPerPage"] = $arrGPP;

$tdatadiagnoses[".highlightSearchResults"] = true;

$tableKeysdiagnoses = array();
$tableKeysdiagnoses[] = "id";
$tdatadiagnoses[".Keys"] = $tableKeysdiagnoses;


$tdatadiagnoses[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses["id"] = $fdata;
		$tdatadiagnoses[".searchableFields"][] = "id";
//	TakenTime
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "TakenTime";
	$fdata["GoodName"] = "TakenTime";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses","TakenTime");
	$fdata["FieldType"] = 135;


	
	
			

		$fdata["strField"] = "TakenTime";

		$fdata["sourceSingle"] = "TakenTime";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TakenTime";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses["TakenTime"] = $fdata;
		$tdatadiagnoses[".searchableFields"][] = "TakenTime";
//	Quantity
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Quantity";
	$fdata["GoodName"] = "Quantity";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses","Quantity");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "Quantity";

		$fdata["sourceSingle"] = "Quantity";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Quantity";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses["Quantity"] = $fdata;
		$tdatadiagnoses[".searchableFields"][] = "Quantity";
//	treatment_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "treatment_id";
	$fdata["GoodName"] = "treatment_id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses","treatment_id");
	$fdata["FieldType"] = 20;


	
	
			

		$fdata["strField"] = "treatment_id";

		$fdata["sourceSingle"] = "treatment_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "treatment_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "treatments";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "id";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses["treatment_id"] = $fdata;
		$tdatadiagnoses[".searchableFields"][] = "treatment_id";
//	medicine_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "medicine_id";
	$fdata["GoodName"] = "medicine_id";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses","medicine_id");
	$fdata["FieldType"] = 20;


	
	
			

		$fdata["strField"] = "medicine_id";

		$fdata["sourceSingle"] = "medicine_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "medicine_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "medicines";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "MedicineName";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses["medicine_id"] = $fdata;
		$tdatadiagnoses[".searchableFields"][] = "medicine_id";
//	Photo
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Photo";
	$fdata["GoodName"] = "Photo";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses","Photo");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Photo";

		$fdata["sourceSingle"] = "Photo";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Photo";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "File-based Image");

	
	
				$vdata["ImageWidth"] = 50;
	$vdata["ImageHeight"] = 50;

			$vdata["multipleImgMode"] = 1;
	$vdata["maxImages"] = 0;

			$vdata["showGallery"] = true;
	$vdata["galleryMode"] = 2;
	$vdata["captionMode"] = 2;
	$vdata["captionField"] = "";

	$vdata["imageBorder"] = 1;
	$vdata["imageFullWidth"] = 1;


	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
		$fdata["filterTotalFields"] = "id";
		$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses["Photo"] = $fdata;
		$tdatadiagnoses[".searchableFields"][] = "Photo";
//	Result
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "Result";
	$fdata["GoodName"] = "Result";
	$fdata["ownerTable"] = "diagnoses";
	$fdata["Label"] = GetFieldLabel("diagnoses","Result");
	$fdata["FieldType"] = 129;


	
	
			

		$fdata["strField"] = "Result";

		$fdata["sourceSingle"] = "Result";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Result`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
		$edata["LookupType"] = 0;
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 3;

	
	
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "Disease";
	$edata["LookupValues"][] = "Injury";
	$edata["LookupValues"][] = "Normal";
	$edata["LookupValues"][] = "";

		$edata["Multiselect"] = true;

	
// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadiagnoses["Result"] = $fdata;
		$tdatadiagnoses[".searchableFields"][] = "Result";


$tables_data["diagnoses"]=&$tdatadiagnoses;
$field_labels["diagnoses"] = &$fieldLabelsdiagnoses;
$fieldToolTips["diagnoses"] = &$fieldToolTipsdiagnoses;
$placeHolders["diagnoses"] = &$placeHoldersdiagnoses;
$page_titles["diagnoses"] = &$pageTitlesdiagnoses;


changeTextControlsToDate( "diagnoses" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["diagnoses"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["diagnoses"] = array();



	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="medicines";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="medicines";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "medicines";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["diagnoses"][0] = $masterParams;
				$masterTablesData["diagnoses"][0]["masterKeys"] = array();
	$masterTablesData["diagnoses"][0]["masterKeys"][]="id";
				$masterTablesData["diagnoses"][0]["detailKeys"] = array();
	$masterTablesData["diagnoses"][0]["detailKeys"][]="medicine_id";
		
	//endif
	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="treatments";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="treatments";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "treatments";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["diagnoses"][1] = $masterParams;
				$masterTablesData["diagnoses"][1]["masterKeys"] = array();
	$masterTablesData["diagnoses"][1]["masterKeys"][]="id";
				$masterTablesData["diagnoses"][1]["detailKeys"] = array();
	$masterTablesData["diagnoses"][1]["detailKeys"][]="treatment_id";
		
	//endif
	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="medicines";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="medicines Chart";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "medicines_chart";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
			$masterParams["type"] = PAGE_CHART;
			$masterTablesData["diagnoses"][2] = $masterParams;
				$masterTablesData["diagnoses"][2]["masterKeys"] = array();
	$masterTablesData["diagnoses"][2]["masterKeys"][]="id";
				$masterTablesData["diagnoses"][2]["detailKeys"] = array();
	$masterTablesData["diagnoses"][2]["detailKeys"][]="medicine_id";
		
	//endif
	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="treatments";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="treatments Chart";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "treatments_chart";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
			$masterParams["type"] = PAGE_CHART;
			$masterTablesData["diagnoses"][3] = $masterParams;
				$masterTablesData["diagnoses"][3]["masterKeys"] = array();
	$masterTablesData["diagnoses"][3]["masterKeys"][]="id";
				$masterTablesData["diagnoses"][3]["detailKeys"] = array();
	$masterTablesData["diagnoses"][3]["detailKeys"][]="treatment_id";
		
	//endif
	
	//if !@t.bReportCrossTab
			$strOriginalDetailsTable="treatments";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="patients Chart";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "patients_chart";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
			$masterParams["type"] = PAGE_CHART;
			$masterTablesData["diagnoses"][4] = $masterParams;
				$masterTablesData["diagnoses"][4]["masterKeys"] = array();
	$masterTablesData["diagnoses"][4]["masterKeys"][]="id";
				$masterTablesData["diagnoses"][4]["detailKeys"] = array();
	$masterTablesData["diagnoses"][4]["detailKeys"][]="treatment_id";
		
	//endif
// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_diagnoses()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	TakenTime,  	Quantity,  	treatment_id,  	medicine_id,  	Photo,  	`Result`";
$proto0["m_strFrom"] = "FROM diagnoses";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "diagnoses";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "TakenTime",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses"
));

$proto8["m_sql"] = "TakenTime";
$proto8["m_srcTableName"] = "diagnoses";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Quantity",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses"
));

$proto10["m_sql"] = "Quantity";
$proto10["m_srcTableName"] = "diagnoses";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "treatment_id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses"
));

$proto12["m_sql"] = "treatment_id";
$proto12["m_srcTableName"] = "diagnoses";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "medicine_id",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses"
));

$proto14["m_sql"] = "medicine_id";
$proto14["m_srcTableName"] = "diagnoses";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "Photo",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses"
));

$proto16["m_sql"] = "Photo";
$proto16["m_srcTableName"] = "diagnoses";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "Result",
	"m_strTable" => "diagnoses",
	"m_srcTableName" => "diagnoses"
));

$proto18["m_sql"] = "`Result`";
$proto18["m_srcTableName"] = "diagnoses";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto20=array();
$proto20["m_link"] = "SQLL_MAIN";
			$proto21=array();
$proto21["m_strName"] = "diagnoses";
$proto21["m_srcTableName"] = "diagnoses";
$proto21["m_columns"] = array();
$proto21["m_columns"][] = "id";
$proto21["m_columns"][] = "TakenTime";
$proto21["m_columns"][] = "Quantity";
$proto21["m_columns"][] = "treatment_id";
$proto21["m_columns"][] = "medicine_id";
$proto21["m_columns"][] = "Photo";
$proto21["m_columns"][] = "Result";
$obj = new SQLTable($proto21);

$proto20["m_table"] = $obj;
$proto20["m_sql"] = "diagnoses";
$proto20["m_alias"] = "";
$proto20["m_srcTableName"] = "diagnoses";
$proto22=array();
$proto22["m_sql"] = "";
$proto22["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto22["m_column"]=$obj;
$proto22["m_contained"] = array();
$proto22["m_strCase"] = "";
$proto22["m_havingmode"] = false;
$proto22["m_inBrackets"] = false;
$proto22["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto22);

$proto20["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto20);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="diagnoses";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_diagnoses = createSqlQuery_diagnoses();


	
		;

							

$tdatadiagnoses[".sqlquery"] = $queryData_diagnoses;



$tdatadiagnoses[".hasEvents"] = false;

?>