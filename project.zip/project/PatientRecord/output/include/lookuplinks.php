<?php

/**
* getLookupMainTableSettings - tests whether the lookup link exists between the tables
*
*  returns array with ProjectSettings class for main table if the link exists in project settings.
*  returns NULL otherwise
*/
function getLookupMainTableSettings($lookupTable, $mainTableShortName, $mainField, $desiredPage = "")
{
	global $lookupTableLinks;
	if(!isset($lookupTableLinks[$lookupTable]))
		return null;
	if(!isset($lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField]))
		return null;
	$arr = &$lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField];
	$effectivePage = $desiredPage;
	if(!isset($arr[$effectivePage]))
	{
		$effectivePage = PAGE_EDIT;
		if(!isset($arr[$effectivePage]))
		{
			if($desiredPage == "" && 0 < count($arr))
			{
				$effectivePage = $arr[0];
			}
			else
				return null;
		}
	}
	return new ProjectSettings($arr[$effectivePage]["table"], $effectivePage);
}

/** 
* $lookupTableLinks array stores all lookup links between tables in the project
*/
function InitLookupLinks()
{
	global $lookupTableLinks;

	$lookupTableLinks = array();

		if( !isset( $lookupTableLinks["treatments"] ) ) {
			$lookupTableLinks["treatments"] = array();
		}
		if( !isset( $lookupTableLinks["treatments"]["diagnoses.treatment_id"] )) {
			$lookupTableLinks["treatments"]["diagnoses.treatment_id"] = array();
		}
		$lookupTableLinks["treatments"]["diagnoses.treatment_id"]["edit"] = array("table" => "diagnoses", "field" => "treatment_id", "page" => "edit");
		if( !isset( $lookupTableLinks["medicines"] ) ) {
			$lookupTableLinks["medicines"] = array();
		}
		if( !isset( $lookupTableLinks["medicines"]["diagnoses.medicine_id"] )) {
			$lookupTableLinks["medicines"]["diagnoses.medicine_id"] = array();
		}
		$lookupTableLinks["medicines"]["diagnoses.medicine_id"]["edit"] = array("table" => "diagnoses", "field" => "medicine_id", "page" => "edit");
		if( !isset( $lookupTableLinks["patients"] ) ) {
			$lookupTableLinks["patients"] = array();
		}
		if( !isset( $lookupTableLinks["patients"]["treatments.patient_id"] )) {
			$lookupTableLinks["patients"]["treatments.patient_id"] = array();
		}
		$lookupTableLinks["patients"]["treatments.patient_id"]["edit"] = array("table" => "treatments", "field" => "patient_id", "page" => "edit");
		if( !isset( $lookupTableLinks["doctors"] ) ) {
			$lookupTableLinks["doctors"] = array();
		}
		if( !isset( $lookupTableLinks["doctors"]["treatments.doctor_id"] )) {
			$lookupTableLinks["doctors"]["treatments.doctor_id"] = array();
		}
		$lookupTableLinks["doctors"]["treatments.doctor_id"]["edit"] = array("table" => "treatments", "field" => "doctor_id", "page" => "edit");
		if( !isset( $lookupTableLinks["treatments"] ) ) {
			$lookupTableLinks["treatments"] = array();
		}
		if( !isset( $lookupTableLinks["treatments"]["diagnoses_chart.treatment_id"] )) {
			$lookupTableLinks["treatments"]["diagnoses_chart.treatment_id"] = array();
		}
		$lookupTableLinks["treatments"]["diagnoses_chart.treatment_id"]["search"] = array("table" => "diagnoses Chart", "field" => "treatment_id", "page" => "search");
		if( !isset( $lookupTableLinks["medicines"] ) ) {
			$lookupTableLinks["medicines"] = array();
		}
		if( !isset( $lookupTableLinks["medicines"]["diagnoses_chart.medicine_id"] )) {
			$lookupTableLinks["medicines"]["diagnoses_chart.medicine_id"] = array();
		}
		$lookupTableLinks["medicines"]["diagnoses_chart.medicine_id"]["search"] = array("table" => "diagnoses Chart", "field" => "medicine_id", "page" => "search");
		if( !isset( $lookupTableLinks["patients"] ) ) {
			$lookupTableLinks["patients"] = array();
		}
		if( !isset( $lookupTableLinks["patients"]["treatments_chart.patient_id"] )) {
			$lookupTableLinks["patients"]["treatments_chart.patient_id"] = array();
		}
		$lookupTableLinks["patients"]["treatments_chart.patient_id"]["search"] = array("table" => "treatments Chart", "field" => "patient_id", "page" => "search");
		if( !isset( $lookupTableLinks["doctors"] ) ) {
			$lookupTableLinks["doctors"] = array();
		}
		if( !isset( $lookupTableLinks["doctors"]["treatments_chart.doctor_id"] )) {
			$lookupTableLinks["doctors"]["treatments_chart.doctor_id"] = array();
		}
		$lookupTableLinks["doctors"]["treatments_chart.doctor_id"]["search"] = array("table" => "treatments Chart", "field" => "doctor_id", "page" => "search");
		if( !isset( $lookupTableLinks["patients"] ) ) {
			$lookupTableLinks["patients"] = array();
		}
		if( !isset( $lookupTableLinks["patients"]["patients_chart.patient_id"] )) {
			$lookupTableLinks["patients"]["patients_chart.patient_id"] = array();
		}
		$lookupTableLinks["patients"]["patients_chart.patient_id"]["search"] = array("table" => "patients Chart", "field" => "patient_id", "page" => "search");
		if( !isset( $lookupTableLinks["doctors"] ) ) {
			$lookupTableLinks["doctors"] = array();
		}
		if( !isset( $lookupTableLinks["doctors"]["patients_chart.doctor_id"] )) {
			$lookupTableLinks["doctors"]["patients_chart.doctor_id"] = array();
		}
		$lookupTableLinks["doctors"]["patients_chart.doctor_id"]["search"] = array("table" => "patients Chart", "field" => "doctor_id", "page" => "search");
}

?>