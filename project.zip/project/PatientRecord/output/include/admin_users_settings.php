<?php
$tdataadmin_users = array();
$tdataadmin_users[".searchableFields"] = array();
$tdataadmin_users[".ShortName"] = "admin_users";
$tdataadmin_users[".OwnerID"] = "";
$tdataadmin_users[".OriginalTable"] = "users";


$tdataadmin_users[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdataadmin_users[".originalPagesByType"] = $tdataadmin_users[".pagesByType"];
$tdataadmin_users[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdataadmin_users[".originalPages"] = $tdataadmin_users[".pages"];
$tdataadmin_users[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdataadmin_users[".originalDefaultPages"] = $tdataadmin_users[".defaultPages"];

//	field labels
$fieldLabelsadmin_users = array();
$fieldToolTipsadmin_users = array();
$pageTitlesadmin_users = array();
$placeHoldersadmin_users = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsadmin_users["English"] = array();
	$fieldToolTipsadmin_users["English"] = array();
	$placeHoldersadmin_users["English"] = array();
	$pageTitlesadmin_users["English"] = array();
	$fieldLabelsadmin_users["English"]["ID"] = "ID";
	$fieldToolTipsadmin_users["English"]["ID"] = "";
	$placeHoldersadmin_users["English"]["ID"] = "";
	$fieldLabelsadmin_users["English"]["username"] = "Username";
	$fieldToolTipsadmin_users["English"]["username"] = "";
	$placeHoldersadmin_users["English"]["username"] = "";
	$fieldLabelsadmin_users["English"]["password"] = "Password";
	$fieldToolTipsadmin_users["English"]["password"] = "";
	$placeHoldersadmin_users["English"]["password"] = "";
	$fieldLabelsadmin_users["English"]["email"] = "Email";
	$fieldToolTipsadmin_users["English"]["email"] = "";
	$placeHoldersadmin_users["English"]["email"] = "";
	$fieldLabelsadmin_users["English"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["English"]["fullname"] = "";
	$placeHoldersadmin_users["English"]["fullname"] = "";
	$fieldLabelsadmin_users["English"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["English"]["groupid"] = "";
	$placeHoldersadmin_users["English"]["groupid"] = "";
	$fieldLabelsadmin_users["English"]["active"] = "Active";
	$fieldToolTipsadmin_users["English"]["active"] = "";
	$placeHoldersadmin_users["English"]["active"] = "";
	$fieldLabelsadmin_users["English"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["English"]["ext_security_id"] = "";
	$placeHoldersadmin_users["English"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["English"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsadmin_users["Afrikaans"] = array();
	$fieldToolTipsadmin_users["Afrikaans"] = array();
	$placeHoldersadmin_users["Afrikaans"] = array();
	$pageTitlesadmin_users["Afrikaans"] = array();
	$fieldLabelsadmin_users["Afrikaans"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Afrikaans"]["ID"] = "";
	$placeHoldersadmin_users["Afrikaans"]["ID"] = "";
	$fieldLabelsadmin_users["Afrikaans"]["username"] = "Username";
	$fieldToolTipsadmin_users["Afrikaans"]["username"] = "";
	$placeHoldersadmin_users["Afrikaans"]["username"] = "";
	$fieldLabelsadmin_users["Afrikaans"]["password"] = "Password";
	$fieldToolTipsadmin_users["Afrikaans"]["password"] = "";
	$placeHoldersadmin_users["Afrikaans"]["password"] = "";
	$fieldLabelsadmin_users["Afrikaans"]["email"] = "Email";
	$fieldToolTipsadmin_users["Afrikaans"]["email"] = "";
	$placeHoldersadmin_users["Afrikaans"]["email"] = "";
	$fieldLabelsadmin_users["Afrikaans"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Afrikaans"]["fullname"] = "";
	$placeHoldersadmin_users["Afrikaans"]["fullname"] = "";
	$fieldLabelsadmin_users["Afrikaans"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Afrikaans"]["groupid"] = "";
	$placeHoldersadmin_users["Afrikaans"]["groupid"] = "";
	$fieldLabelsadmin_users["Afrikaans"]["active"] = "Active";
	$fieldToolTipsadmin_users["Afrikaans"]["active"] = "";
	$placeHoldersadmin_users["Afrikaans"]["active"] = "";
	$fieldLabelsadmin_users["Afrikaans"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Afrikaans"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Afrikaans"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Afrikaans"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsadmin_users["Arabic"] = array();
	$fieldToolTipsadmin_users["Arabic"] = array();
	$placeHoldersadmin_users["Arabic"] = array();
	$pageTitlesadmin_users["Arabic"] = array();
	$fieldLabelsadmin_users["Arabic"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Arabic"]["ID"] = "";
	$placeHoldersadmin_users["Arabic"]["ID"] = "";
	$fieldLabelsadmin_users["Arabic"]["username"] = "Username";
	$fieldToolTipsadmin_users["Arabic"]["username"] = "";
	$placeHoldersadmin_users["Arabic"]["username"] = "";
	$fieldLabelsadmin_users["Arabic"]["password"] = "Password";
	$fieldToolTipsadmin_users["Arabic"]["password"] = "";
	$placeHoldersadmin_users["Arabic"]["password"] = "";
	$fieldLabelsadmin_users["Arabic"]["email"] = "Email";
	$fieldToolTipsadmin_users["Arabic"]["email"] = "";
	$placeHoldersadmin_users["Arabic"]["email"] = "";
	$fieldLabelsadmin_users["Arabic"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Arabic"]["fullname"] = "";
	$placeHoldersadmin_users["Arabic"]["fullname"] = "";
	$fieldLabelsadmin_users["Arabic"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Arabic"]["groupid"] = "";
	$placeHoldersadmin_users["Arabic"]["groupid"] = "";
	$fieldLabelsadmin_users["Arabic"]["active"] = "Active";
	$fieldToolTipsadmin_users["Arabic"]["active"] = "";
	$placeHoldersadmin_users["Arabic"]["active"] = "";
	$fieldLabelsadmin_users["Arabic"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Arabic"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Arabic"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Arabic"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsadmin_users["Bosnian"] = array();
	$fieldToolTipsadmin_users["Bosnian"] = array();
	$placeHoldersadmin_users["Bosnian"] = array();
	$pageTitlesadmin_users["Bosnian"] = array();
	$fieldLabelsadmin_users["Bosnian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Bosnian"]["ID"] = "";
	$placeHoldersadmin_users["Bosnian"]["ID"] = "";
	$fieldLabelsadmin_users["Bosnian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Bosnian"]["username"] = "";
	$placeHoldersadmin_users["Bosnian"]["username"] = "";
	$fieldLabelsadmin_users["Bosnian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Bosnian"]["password"] = "";
	$placeHoldersadmin_users["Bosnian"]["password"] = "";
	$fieldLabelsadmin_users["Bosnian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Bosnian"]["email"] = "";
	$placeHoldersadmin_users["Bosnian"]["email"] = "";
	$fieldLabelsadmin_users["Bosnian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Bosnian"]["fullname"] = "";
	$placeHoldersadmin_users["Bosnian"]["fullname"] = "";
	$fieldLabelsadmin_users["Bosnian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Bosnian"]["groupid"] = "";
	$placeHoldersadmin_users["Bosnian"]["groupid"] = "";
	$fieldLabelsadmin_users["Bosnian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Bosnian"]["active"] = "";
	$placeHoldersadmin_users["Bosnian"]["active"] = "";
	$fieldLabelsadmin_users["Bosnian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Bosnian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Bosnian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Bosnian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsadmin_users["Bulgarian"] = array();
	$fieldToolTipsadmin_users["Bulgarian"] = array();
	$placeHoldersadmin_users["Bulgarian"] = array();
	$pageTitlesadmin_users["Bulgarian"] = array();
	$fieldLabelsadmin_users["Bulgarian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Bulgarian"]["ID"] = "";
	$placeHoldersadmin_users["Bulgarian"]["ID"] = "";
	$fieldLabelsadmin_users["Bulgarian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Bulgarian"]["username"] = "";
	$placeHoldersadmin_users["Bulgarian"]["username"] = "";
	$fieldLabelsadmin_users["Bulgarian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Bulgarian"]["password"] = "";
	$placeHoldersadmin_users["Bulgarian"]["password"] = "";
	$fieldLabelsadmin_users["Bulgarian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Bulgarian"]["email"] = "";
	$placeHoldersadmin_users["Bulgarian"]["email"] = "";
	$fieldLabelsadmin_users["Bulgarian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Bulgarian"]["fullname"] = "";
	$placeHoldersadmin_users["Bulgarian"]["fullname"] = "";
	$fieldLabelsadmin_users["Bulgarian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Bulgarian"]["groupid"] = "";
	$placeHoldersadmin_users["Bulgarian"]["groupid"] = "";
	$fieldLabelsadmin_users["Bulgarian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Bulgarian"]["active"] = "";
	$placeHoldersadmin_users["Bulgarian"]["active"] = "";
	$fieldLabelsadmin_users["Bulgarian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Bulgarian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Bulgarian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Bulgarian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsadmin_users["Catalan"] = array();
	$fieldToolTipsadmin_users["Catalan"] = array();
	$placeHoldersadmin_users["Catalan"] = array();
	$pageTitlesadmin_users["Catalan"] = array();
	$fieldLabelsadmin_users["Catalan"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Catalan"]["ID"] = "";
	$placeHoldersadmin_users["Catalan"]["ID"] = "";
	$fieldLabelsadmin_users["Catalan"]["username"] = "Username";
	$fieldToolTipsadmin_users["Catalan"]["username"] = "";
	$placeHoldersadmin_users["Catalan"]["username"] = "";
	$fieldLabelsadmin_users["Catalan"]["password"] = "Password";
	$fieldToolTipsadmin_users["Catalan"]["password"] = "";
	$placeHoldersadmin_users["Catalan"]["password"] = "";
	$fieldLabelsadmin_users["Catalan"]["email"] = "Email";
	$fieldToolTipsadmin_users["Catalan"]["email"] = "";
	$placeHoldersadmin_users["Catalan"]["email"] = "";
	$fieldLabelsadmin_users["Catalan"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Catalan"]["fullname"] = "";
	$placeHoldersadmin_users["Catalan"]["fullname"] = "";
	$fieldLabelsadmin_users["Catalan"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Catalan"]["groupid"] = "";
	$placeHoldersadmin_users["Catalan"]["groupid"] = "";
	$fieldLabelsadmin_users["Catalan"]["active"] = "Active";
	$fieldToolTipsadmin_users["Catalan"]["active"] = "";
	$placeHoldersadmin_users["Catalan"]["active"] = "";
	$fieldLabelsadmin_users["Catalan"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Catalan"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Catalan"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Catalan"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsadmin_users["Chinese"] = array();
	$fieldToolTipsadmin_users["Chinese"] = array();
	$placeHoldersadmin_users["Chinese"] = array();
	$pageTitlesadmin_users["Chinese"] = array();
	$fieldLabelsadmin_users["Chinese"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Chinese"]["ID"] = "";
	$placeHoldersadmin_users["Chinese"]["ID"] = "";
	$fieldLabelsadmin_users["Chinese"]["username"] = "Username";
	$fieldToolTipsadmin_users["Chinese"]["username"] = "";
	$placeHoldersadmin_users["Chinese"]["username"] = "";
	$fieldLabelsadmin_users["Chinese"]["password"] = "Password";
	$fieldToolTipsadmin_users["Chinese"]["password"] = "";
	$placeHoldersadmin_users["Chinese"]["password"] = "";
	$fieldLabelsadmin_users["Chinese"]["email"] = "Email";
	$fieldToolTipsadmin_users["Chinese"]["email"] = "";
	$placeHoldersadmin_users["Chinese"]["email"] = "";
	$fieldLabelsadmin_users["Chinese"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Chinese"]["fullname"] = "";
	$placeHoldersadmin_users["Chinese"]["fullname"] = "";
	$fieldLabelsadmin_users["Chinese"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Chinese"]["groupid"] = "";
	$placeHoldersadmin_users["Chinese"]["groupid"] = "";
	$fieldLabelsadmin_users["Chinese"]["active"] = "Active";
	$fieldToolTipsadmin_users["Chinese"]["active"] = "";
	$placeHoldersadmin_users["Chinese"]["active"] = "";
	$fieldLabelsadmin_users["Chinese"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Chinese"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Chinese"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Chinese"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesadmin_users["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["ID"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["ID"] = "";
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["username"] = "Username";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["username"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["username"] = "";
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["password"] = "Password";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["password"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["password"] = "";
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["email"] = "Email";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["email"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["email"] = "";
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["fullname"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["fullname"] = "";
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["groupid"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["groupid"] = "";
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["active"] = "Active";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["active"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["active"] = "";
	$fieldLabelsadmin_users["Chinese (Hong Kong S.A.R.)"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Chinese (Hong Kong S.A.R.)"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Chinese (Hong Kong S.A.R.)"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsadmin_users["Chinese (Taiwan)"] = array();
	$fieldToolTipsadmin_users["Chinese (Taiwan)"] = array();
	$placeHoldersadmin_users["Chinese (Taiwan)"] = array();
	$pageTitlesadmin_users["Chinese (Taiwan)"] = array();
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["ID"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["ID"] = "";
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["username"] = "Username";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["username"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["username"] = "";
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["password"] = "Password";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["password"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["password"] = "";
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["email"] = "Email";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["email"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["email"] = "";
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["fullname"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["fullname"] = "";
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["groupid"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["groupid"] = "";
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["active"] = "Active";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["active"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["active"] = "";
	$fieldLabelsadmin_users["Chinese (Taiwan)"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Chinese (Taiwan)"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Chinese (Taiwan)"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Chinese (Taiwan)"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsadmin_users["Croatian"] = array();
	$fieldToolTipsadmin_users["Croatian"] = array();
	$placeHoldersadmin_users["Croatian"] = array();
	$pageTitlesadmin_users["Croatian"] = array();
	$fieldLabelsadmin_users["Croatian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Croatian"]["ID"] = "";
	$placeHoldersadmin_users["Croatian"]["ID"] = "";
	$fieldLabelsadmin_users["Croatian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Croatian"]["username"] = "";
	$placeHoldersadmin_users["Croatian"]["username"] = "";
	$fieldLabelsadmin_users["Croatian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Croatian"]["password"] = "";
	$placeHoldersadmin_users["Croatian"]["password"] = "";
	$fieldLabelsadmin_users["Croatian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Croatian"]["email"] = "";
	$placeHoldersadmin_users["Croatian"]["email"] = "";
	$fieldLabelsadmin_users["Croatian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Croatian"]["fullname"] = "";
	$placeHoldersadmin_users["Croatian"]["fullname"] = "";
	$fieldLabelsadmin_users["Croatian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Croatian"]["groupid"] = "";
	$placeHoldersadmin_users["Croatian"]["groupid"] = "";
	$fieldLabelsadmin_users["Croatian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Croatian"]["active"] = "";
	$placeHoldersadmin_users["Croatian"]["active"] = "";
	$fieldLabelsadmin_users["Croatian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Croatian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Croatian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Croatian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsadmin_users["Czech"] = array();
	$fieldToolTipsadmin_users["Czech"] = array();
	$placeHoldersadmin_users["Czech"] = array();
	$pageTitlesadmin_users["Czech"] = array();
	$fieldLabelsadmin_users["Czech"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Czech"]["ID"] = "";
	$placeHoldersadmin_users["Czech"]["ID"] = "";
	$fieldLabelsadmin_users["Czech"]["username"] = "Username";
	$fieldToolTipsadmin_users["Czech"]["username"] = "";
	$placeHoldersadmin_users["Czech"]["username"] = "";
	$fieldLabelsadmin_users["Czech"]["password"] = "Password";
	$fieldToolTipsadmin_users["Czech"]["password"] = "";
	$placeHoldersadmin_users["Czech"]["password"] = "";
	$fieldLabelsadmin_users["Czech"]["email"] = "Email";
	$fieldToolTipsadmin_users["Czech"]["email"] = "";
	$placeHoldersadmin_users["Czech"]["email"] = "";
	$fieldLabelsadmin_users["Czech"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Czech"]["fullname"] = "";
	$placeHoldersadmin_users["Czech"]["fullname"] = "";
	$fieldLabelsadmin_users["Czech"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Czech"]["groupid"] = "";
	$placeHoldersadmin_users["Czech"]["groupid"] = "";
	$fieldLabelsadmin_users["Czech"]["active"] = "Active";
	$fieldToolTipsadmin_users["Czech"]["active"] = "";
	$placeHoldersadmin_users["Czech"]["active"] = "";
	$fieldLabelsadmin_users["Czech"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Czech"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Czech"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Czech"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsadmin_users["Danish"] = array();
	$fieldToolTipsadmin_users["Danish"] = array();
	$placeHoldersadmin_users["Danish"] = array();
	$pageTitlesadmin_users["Danish"] = array();
	$fieldLabelsadmin_users["Danish"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Danish"]["ID"] = "";
	$placeHoldersadmin_users["Danish"]["ID"] = "";
	$fieldLabelsadmin_users["Danish"]["username"] = "Username";
	$fieldToolTipsadmin_users["Danish"]["username"] = "";
	$placeHoldersadmin_users["Danish"]["username"] = "";
	$fieldLabelsadmin_users["Danish"]["password"] = "Password";
	$fieldToolTipsadmin_users["Danish"]["password"] = "";
	$placeHoldersadmin_users["Danish"]["password"] = "";
	$fieldLabelsadmin_users["Danish"]["email"] = "Email";
	$fieldToolTipsadmin_users["Danish"]["email"] = "";
	$placeHoldersadmin_users["Danish"]["email"] = "";
	$fieldLabelsadmin_users["Danish"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Danish"]["fullname"] = "";
	$placeHoldersadmin_users["Danish"]["fullname"] = "";
	$fieldLabelsadmin_users["Danish"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Danish"]["groupid"] = "";
	$placeHoldersadmin_users["Danish"]["groupid"] = "";
	$fieldLabelsadmin_users["Danish"]["active"] = "Active";
	$fieldToolTipsadmin_users["Danish"]["active"] = "";
	$placeHoldersadmin_users["Danish"]["active"] = "";
	$fieldLabelsadmin_users["Danish"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Danish"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Danish"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Danish"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsadmin_users["Dutch"] = array();
	$fieldToolTipsadmin_users["Dutch"] = array();
	$placeHoldersadmin_users["Dutch"] = array();
	$pageTitlesadmin_users["Dutch"] = array();
	$fieldLabelsadmin_users["Dutch"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Dutch"]["ID"] = "";
	$placeHoldersadmin_users["Dutch"]["ID"] = "";
	$fieldLabelsadmin_users["Dutch"]["username"] = "Username";
	$fieldToolTipsadmin_users["Dutch"]["username"] = "";
	$placeHoldersadmin_users["Dutch"]["username"] = "";
	$fieldLabelsadmin_users["Dutch"]["password"] = "Password";
	$fieldToolTipsadmin_users["Dutch"]["password"] = "";
	$placeHoldersadmin_users["Dutch"]["password"] = "";
	$fieldLabelsadmin_users["Dutch"]["email"] = "Email";
	$fieldToolTipsadmin_users["Dutch"]["email"] = "";
	$placeHoldersadmin_users["Dutch"]["email"] = "";
	$fieldLabelsadmin_users["Dutch"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Dutch"]["fullname"] = "";
	$placeHoldersadmin_users["Dutch"]["fullname"] = "";
	$fieldLabelsadmin_users["Dutch"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Dutch"]["groupid"] = "";
	$placeHoldersadmin_users["Dutch"]["groupid"] = "";
	$fieldLabelsadmin_users["Dutch"]["active"] = "Active";
	$fieldToolTipsadmin_users["Dutch"]["active"] = "";
	$placeHoldersadmin_users["Dutch"]["active"] = "";
	$fieldLabelsadmin_users["Dutch"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Dutch"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Dutch"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Dutch"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsadmin_users["Farsi"] = array();
	$fieldToolTipsadmin_users["Farsi"] = array();
	$placeHoldersadmin_users["Farsi"] = array();
	$pageTitlesadmin_users["Farsi"] = array();
	$fieldLabelsadmin_users["Farsi"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Farsi"]["ID"] = "";
	$placeHoldersadmin_users["Farsi"]["ID"] = "";
	$fieldLabelsadmin_users["Farsi"]["username"] = "Username";
	$fieldToolTipsadmin_users["Farsi"]["username"] = "";
	$placeHoldersadmin_users["Farsi"]["username"] = "";
	$fieldLabelsadmin_users["Farsi"]["password"] = "Password";
	$fieldToolTipsadmin_users["Farsi"]["password"] = "";
	$placeHoldersadmin_users["Farsi"]["password"] = "";
	$fieldLabelsadmin_users["Farsi"]["email"] = "Email";
	$fieldToolTipsadmin_users["Farsi"]["email"] = "";
	$placeHoldersadmin_users["Farsi"]["email"] = "";
	$fieldLabelsadmin_users["Farsi"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Farsi"]["fullname"] = "";
	$placeHoldersadmin_users["Farsi"]["fullname"] = "";
	$fieldLabelsadmin_users["Farsi"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Farsi"]["groupid"] = "";
	$placeHoldersadmin_users["Farsi"]["groupid"] = "";
	$fieldLabelsadmin_users["Farsi"]["active"] = "Active";
	$fieldToolTipsadmin_users["Farsi"]["active"] = "";
	$placeHoldersadmin_users["Farsi"]["active"] = "";
	$fieldLabelsadmin_users["Farsi"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Farsi"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Farsi"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Farsi"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsadmin_users["French"] = array();
	$fieldToolTipsadmin_users["French"] = array();
	$placeHoldersadmin_users["French"] = array();
	$pageTitlesadmin_users["French"] = array();
	$fieldLabelsadmin_users["French"]["ID"] = "ID";
	$fieldToolTipsadmin_users["French"]["ID"] = "";
	$placeHoldersadmin_users["French"]["ID"] = "";
	$fieldLabelsadmin_users["French"]["username"] = "Username";
	$fieldToolTipsadmin_users["French"]["username"] = "";
	$placeHoldersadmin_users["French"]["username"] = "";
	$fieldLabelsadmin_users["French"]["password"] = "Password";
	$fieldToolTipsadmin_users["French"]["password"] = "";
	$placeHoldersadmin_users["French"]["password"] = "";
	$fieldLabelsadmin_users["French"]["email"] = "Email";
	$fieldToolTipsadmin_users["French"]["email"] = "";
	$placeHoldersadmin_users["French"]["email"] = "";
	$fieldLabelsadmin_users["French"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["French"]["fullname"] = "";
	$placeHoldersadmin_users["French"]["fullname"] = "";
	$fieldLabelsadmin_users["French"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["French"]["groupid"] = "";
	$placeHoldersadmin_users["French"]["groupid"] = "";
	$fieldLabelsadmin_users["French"]["active"] = "Active";
	$fieldToolTipsadmin_users["French"]["active"] = "";
	$placeHoldersadmin_users["French"]["active"] = "";
	$fieldLabelsadmin_users["French"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["French"]["ext_security_id"] = "";
	$placeHoldersadmin_users["French"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["French"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsadmin_users["Georgian"] = array();
	$fieldToolTipsadmin_users["Georgian"] = array();
	$placeHoldersadmin_users["Georgian"] = array();
	$pageTitlesadmin_users["Georgian"] = array();
	$fieldLabelsadmin_users["Georgian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Georgian"]["ID"] = "";
	$placeHoldersadmin_users["Georgian"]["ID"] = "";
	$fieldLabelsadmin_users["Georgian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Georgian"]["username"] = "";
	$placeHoldersadmin_users["Georgian"]["username"] = "";
	$fieldLabelsadmin_users["Georgian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Georgian"]["password"] = "";
	$placeHoldersadmin_users["Georgian"]["password"] = "";
	$fieldLabelsadmin_users["Georgian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Georgian"]["email"] = "";
	$placeHoldersadmin_users["Georgian"]["email"] = "";
	$fieldLabelsadmin_users["Georgian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Georgian"]["fullname"] = "";
	$placeHoldersadmin_users["Georgian"]["fullname"] = "";
	$fieldLabelsadmin_users["Georgian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Georgian"]["groupid"] = "";
	$placeHoldersadmin_users["Georgian"]["groupid"] = "";
	$fieldLabelsadmin_users["Georgian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Georgian"]["active"] = "";
	$placeHoldersadmin_users["Georgian"]["active"] = "";
	$fieldLabelsadmin_users["Georgian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Georgian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Georgian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Georgian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsadmin_users["German"] = array();
	$fieldToolTipsadmin_users["German"] = array();
	$placeHoldersadmin_users["German"] = array();
	$pageTitlesadmin_users["German"] = array();
	$fieldLabelsadmin_users["German"]["ID"] = "ID";
	$fieldToolTipsadmin_users["German"]["ID"] = "";
	$placeHoldersadmin_users["German"]["ID"] = "";
	$fieldLabelsadmin_users["German"]["username"] = "Username";
	$fieldToolTipsadmin_users["German"]["username"] = "";
	$placeHoldersadmin_users["German"]["username"] = "";
	$fieldLabelsadmin_users["German"]["password"] = "Password";
	$fieldToolTipsadmin_users["German"]["password"] = "";
	$placeHoldersadmin_users["German"]["password"] = "";
	$fieldLabelsadmin_users["German"]["email"] = "Email";
	$fieldToolTipsadmin_users["German"]["email"] = "";
	$placeHoldersadmin_users["German"]["email"] = "";
	$fieldLabelsadmin_users["German"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["German"]["fullname"] = "";
	$placeHoldersadmin_users["German"]["fullname"] = "";
	$fieldLabelsadmin_users["German"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["German"]["groupid"] = "";
	$placeHoldersadmin_users["German"]["groupid"] = "";
	$fieldLabelsadmin_users["German"]["active"] = "Active";
	$fieldToolTipsadmin_users["German"]["active"] = "";
	$placeHoldersadmin_users["German"]["active"] = "";
	$fieldLabelsadmin_users["German"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["German"]["ext_security_id"] = "";
	$placeHoldersadmin_users["German"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["German"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsadmin_users["Greek"] = array();
	$fieldToolTipsadmin_users["Greek"] = array();
	$placeHoldersadmin_users["Greek"] = array();
	$pageTitlesadmin_users["Greek"] = array();
	$fieldLabelsadmin_users["Greek"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Greek"]["ID"] = "";
	$placeHoldersadmin_users["Greek"]["ID"] = "";
	$fieldLabelsadmin_users["Greek"]["username"] = "Username";
	$fieldToolTipsadmin_users["Greek"]["username"] = "";
	$placeHoldersadmin_users["Greek"]["username"] = "";
	$fieldLabelsadmin_users["Greek"]["password"] = "Password";
	$fieldToolTipsadmin_users["Greek"]["password"] = "";
	$placeHoldersadmin_users["Greek"]["password"] = "";
	$fieldLabelsadmin_users["Greek"]["email"] = "Email";
	$fieldToolTipsadmin_users["Greek"]["email"] = "";
	$placeHoldersadmin_users["Greek"]["email"] = "";
	$fieldLabelsadmin_users["Greek"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Greek"]["fullname"] = "";
	$placeHoldersadmin_users["Greek"]["fullname"] = "";
	$fieldLabelsadmin_users["Greek"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Greek"]["groupid"] = "";
	$placeHoldersadmin_users["Greek"]["groupid"] = "";
	$fieldLabelsadmin_users["Greek"]["active"] = "Active";
	$fieldToolTipsadmin_users["Greek"]["active"] = "";
	$placeHoldersadmin_users["Greek"]["active"] = "";
	$fieldLabelsadmin_users["Greek"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Greek"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Greek"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Greek"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsadmin_users["Hebrew"] = array();
	$fieldToolTipsadmin_users["Hebrew"] = array();
	$placeHoldersadmin_users["Hebrew"] = array();
	$pageTitlesadmin_users["Hebrew"] = array();
	$fieldLabelsadmin_users["Hebrew"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Hebrew"]["ID"] = "";
	$placeHoldersadmin_users["Hebrew"]["ID"] = "";
	$fieldLabelsadmin_users["Hebrew"]["username"] = "Username";
	$fieldToolTipsadmin_users["Hebrew"]["username"] = "";
	$placeHoldersadmin_users["Hebrew"]["username"] = "";
	$fieldLabelsadmin_users["Hebrew"]["password"] = "Password";
	$fieldToolTipsadmin_users["Hebrew"]["password"] = "";
	$placeHoldersadmin_users["Hebrew"]["password"] = "";
	$fieldLabelsadmin_users["Hebrew"]["email"] = "Email";
	$fieldToolTipsadmin_users["Hebrew"]["email"] = "";
	$placeHoldersadmin_users["Hebrew"]["email"] = "";
	$fieldLabelsadmin_users["Hebrew"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Hebrew"]["fullname"] = "";
	$placeHoldersadmin_users["Hebrew"]["fullname"] = "";
	$fieldLabelsadmin_users["Hebrew"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Hebrew"]["groupid"] = "";
	$placeHoldersadmin_users["Hebrew"]["groupid"] = "";
	$fieldLabelsadmin_users["Hebrew"]["active"] = "Active";
	$fieldToolTipsadmin_users["Hebrew"]["active"] = "";
	$placeHoldersadmin_users["Hebrew"]["active"] = "";
	$fieldLabelsadmin_users["Hebrew"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Hebrew"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Hebrew"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Hebrew"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsadmin_users["Hungarian"] = array();
	$fieldToolTipsadmin_users["Hungarian"] = array();
	$placeHoldersadmin_users["Hungarian"] = array();
	$pageTitlesadmin_users["Hungarian"] = array();
	$fieldLabelsadmin_users["Hungarian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Hungarian"]["ID"] = "";
	$placeHoldersadmin_users["Hungarian"]["ID"] = "";
	$fieldLabelsadmin_users["Hungarian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Hungarian"]["username"] = "";
	$placeHoldersadmin_users["Hungarian"]["username"] = "";
	$fieldLabelsadmin_users["Hungarian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Hungarian"]["password"] = "";
	$placeHoldersadmin_users["Hungarian"]["password"] = "";
	$fieldLabelsadmin_users["Hungarian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Hungarian"]["email"] = "";
	$placeHoldersadmin_users["Hungarian"]["email"] = "";
	$fieldLabelsadmin_users["Hungarian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Hungarian"]["fullname"] = "";
	$placeHoldersadmin_users["Hungarian"]["fullname"] = "";
	$fieldLabelsadmin_users["Hungarian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Hungarian"]["groupid"] = "";
	$placeHoldersadmin_users["Hungarian"]["groupid"] = "";
	$fieldLabelsadmin_users["Hungarian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Hungarian"]["active"] = "";
	$placeHoldersadmin_users["Hungarian"]["active"] = "";
	$fieldLabelsadmin_users["Hungarian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Hungarian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Hungarian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Hungarian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsadmin_users["Indonesian"] = array();
	$fieldToolTipsadmin_users["Indonesian"] = array();
	$placeHoldersadmin_users["Indonesian"] = array();
	$pageTitlesadmin_users["Indonesian"] = array();
	$fieldLabelsadmin_users["Indonesian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Indonesian"]["ID"] = "";
	$placeHoldersadmin_users["Indonesian"]["ID"] = "";
	$fieldLabelsadmin_users["Indonesian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Indonesian"]["username"] = "";
	$placeHoldersadmin_users["Indonesian"]["username"] = "";
	$fieldLabelsadmin_users["Indonesian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Indonesian"]["password"] = "";
	$placeHoldersadmin_users["Indonesian"]["password"] = "";
	$fieldLabelsadmin_users["Indonesian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Indonesian"]["email"] = "";
	$placeHoldersadmin_users["Indonesian"]["email"] = "";
	$fieldLabelsadmin_users["Indonesian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Indonesian"]["fullname"] = "";
	$placeHoldersadmin_users["Indonesian"]["fullname"] = "";
	$fieldLabelsadmin_users["Indonesian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Indonesian"]["groupid"] = "";
	$placeHoldersadmin_users["Indonesian"]["groupid"] = "";
	$fieldLabelsadmin_users["Indonesian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Indonesian"]["active"] = "";
	$placeHoldersadmin_users["Indonesian"]["active"] = "";
	$fieldLabelsadmin_users["Indonesian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Indonesian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Indonesian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Indonesian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsadmin_users["Italian"] = array();
	$fieldToolTipsadmin_users["Italian"] = array();
	$placeHoldersadmin_users["Italian"] = array();
	$pageTitlesadmin_users["Italian"] = array();
	$fieldLabelsadmin_users["Italian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Italian"]["ID"] = "";
	$placeHoldersadmin_users["Italian"]["ID"] = "";
	$fieldLabelsadmin_users["Italian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Italian"]["username"] = "";
	$placeHoldersadmin_users["Italian"]["username"] = "";
	$fieldLabelsadmin_users["Italian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Italian"]["password"] = "";
	$placeHoldersadmin_users["Italian"]["password"] = "";
	$fieldLabelsadmin_users["Italian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Italian"]["email"] = "";
	$placeHoldersadmin_users["Italian"]["email"] = "";
	$fieldLabelsadmin_users["Italian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Italian"]["fullname"] = "";
	$placeHoldersadmin_users["Italian"]["fullname"] = "";
	$fieldLabelsadmin_users["Italian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Italian"]["groupid"] = "";
	$placeHoldersadmin_users["Italian"]["groupid"] = "";
	$fieldLabelsadmin_users["Italian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Italian"]["active"] = "";
	$placeHoldersadmin_users["Italian"]["active"] = "";
	$fieldLabelsadmin_users["Italian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Italian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Italian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Italian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsadmin_users["Japanese"] = array();
	$fieldToolTipsadmin_users["Japanese"] = array();
	$placeHoldersadmin_users["Japanese"] = array();
	$pageTitlesadmin_users["Japanese"] = array();
	$fieldLabelsadmin_users["Japanese"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Japanese"]["ID"] = "";
	$placeHoldersadmin_users["Japanese"]["ID"] = "";
	$fieldLabelsadmin_users["Japanese"]["username"] = "Username";
	$fieldToolTipsadmin_users["Japanese"]["username"] = "";
	$placeHoldersadmin_users["Japanese"]["username"] = "";
	$fieldLabelsadmin_users["Japanese"]["password"] = "Password";
	$fieldToolTipsadmin_users["Japanese"]["password"] = "";
	$placeHoldersadmin_users["Japanese"]["password"] = "";
	$fieldLabelsadmin_users["Japanese"]["email"] = "Email";
	$fieldToolTipsadmin_users["Japanese"]["email"] = "";
	$placeHoldersadmin_users["Japanese"]["email"] = "";
	$fieldLabelsadmin_users["Japanese"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Japanese"]["fullname"] = "";
	$placeHoldersadmin_users["Japanese"]["fullname"] = "";
	$fieldLabelsadmin_users["Japanese"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Japanese"]["groupid"] = "";
	$placeHoldersadmin_users["Japanese"]["groupid"] = "";
	$fieldLabelsadmin_users["Japanese"]["active"] = "Active";
	$fieldToolTipsadmin_users["Japanese"]["active"] = "";
	$placeHoldersadmin_users["Japanese"]["active"] = "";
	$fieldLabelsadmin_users["Japanese"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Japanese"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Japanese"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Japanese"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsadmin_users["Malay"] = array();
	$fieldToolTipsadmin_users["Malay"] = array();
	$placeHoldersadmin_users["Malay"] = array();
	$pageTitlesadmin_users["Malay"] = array();
	$fieldLabelsadmin_users["Malay"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Malay"]["ID"] = "";
	$placeHoldersadmin_users["Malay"]["ID"] = "";
	$fieldLabelsadmin_users["Malay"]["username"] = "Username";
	$fieldToolTipsadmin_users["Malay"]["username"] = "";
	$placeHoldersadmin_users["Malay"]["username"] = "";
	$fieldLabelsadmin_users["Malay"]["password"] = "Password";
	$fieldToolTipsadmin_users["Malay"]["password"] = "";
	$placeHoldersadmin_users["Malay"]["password"] = "";
	$fieldLabelsadmin_users["Malay"]["email"] = "Email";
	$fieldToolTipsadmin_users["Malay"]["email"] = "";
	$placeHoldersadmin_users["Malay"]["email"] = "";
	$fieldLabelsadmin_users["Malay"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Malay"]["fullname"] = "";
	$placeHoldersadmin_users["Malay"]["fullname"] = "";
	$fieldLabelsadmin_users["Malay"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Malay"]["groupid"] = "";
	$placeHoldersadmin_users["Malay"]["groupid"] = "";
	$fieldLabelsadmin_users["Malay"]["active"] = "Active";
	$fieldToolTipsadmin_users["Malay"]["active"] = "";
	$placeHoldersadmin_users["Malay"]["active"] = "";
	$fieldLabelsadmin_users["Malay"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Malay"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Malay"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Malay"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsadmin_users["Norwegian(Bokmal)"] = array();
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"] = array();
	$placeHoldersadmin_users["Norwegian(Bokmal)"] = array();
	$pageTitlesadmin_users["Norwegian(Bokmal)"] = array();
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["ID"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["ID"] = "";
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["username"] = "Username";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["username"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["username"] = "";
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["password"] = "Password";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["password"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["password"] = "";
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["email"] = "Email";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["email"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["email"] = "";
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["fullname"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["fullname"] = "";
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["groupid"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["groupid"] = "";
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["active"] = "Active";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["active"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["active"] = "";
	$fieldLabelsadmin_users["Norwegian(Bokmal)"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Norwegian(Bokmal)"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Norwegian(Bokmal)"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Norwegian(Bokmal)"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsadmin_users["Polish"] = array();
	$fieldToolTipsadmin_users["Polish"] = array();
	$placeHoldersadmin_users["Polish"] = array();
	$pageTitlesadmin_users["Polish"] = array();
	$fieldLabelsadmin_users["Polish"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Polish"]["ID"] = "";
	$placeHoldersadmin_users["Polish"]["ID"] = "";
	$fieldLabelsadmin_users["Polish"]["username"] = "Username";
	$fieldToolTipsadmin_users["Polish"]["username"] = "";
	$placeHoldersadmin_users["Polish"]["username"] = "";
	$fieldLabelsadmin_users["Polish"]["password"] = "Password";
	$fieldToolTipsadmin_users["Polish"]["password"] = "";
	$placeHoldersadmin_users["Polish"]["password"] = "";
	$fieldLabelsadmin_users["Polish"]["email"] = "Email";
	$fieldToolTipsadmin_users["Polish"]["email"] = "";
	$placeHoldersadmin_users["Polish"]["email"] = "";
	$fieldLabelsadmin_users["Polish"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Polish"]["fullname"] = "";
	$placeHoldersadmin_users["Polish"]["fullname"] = "";
	$fieldLabelsadmin_users["Polish"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Polish"]["groupid"] = "";
	$placeHoldersadmin_users["Polish"]["groupid"] = "";
	$fieldLabelsadmin_users["Polish"]["active"] = "Active";
	$fieldToolTipsadmin_users["Polish"]["active"] = "";
	$placeHoldersadmin_users["Polish"]["active"] = "";
	$fieldLabelsadmin_users["Polish"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Polish"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Polish"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Polish"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsadmin_users["Portuguese(Brazil)"] = array();
	$fieldToolTipsadmin_users["Portuguese(Brazil)"] = array();
	$placeHoldersadmin_users["Portuguese(Brazil)"] = array();
	$pageTitlesadmin_users["Portuguese(Brazil)"] = array();
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["ID"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["ID"] = "";
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["username"] = "Username";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["username"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["username"] = "";
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["password"] = "Password";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["password"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["password"] = "";
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["email"] = "Email";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["email"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["email"] = "";
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["fullname"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["fullname"] = "";
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["groupid"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["groupid"] = "";
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["active"] = "Active";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["active"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["active"] = "";
	$fieldLabelsadmin_users["Portuguese(Brazil)"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Portuguese(Brazil)"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Portuguese(Brazil)"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Portuguese(Brazil)"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsadmin_users["Portuguese(Standard)"] = array();
	$fieldToolTipsadmin_users["Portuguese(Standard)"] = array();
	$placeHoldersadmin_users["Portuguese(Standard)"] = array();
	$pageTitlesadmin_users["Portuguese(Standard)"] = array();
	$fieldLabelsadmin_users["Portuguese(Standard)"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["ID"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["ID"] = "";
	$fieldLabelsadmin_users["Portuguese(Standard)"]["username"] = "Username";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["username"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["username"] = "";
	$fieldLabelsadmin_users["Portuguese(Standard)"]["password"] = "Password";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["password"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["password"] = "";
	$fieldLabelsadmin_users["Portuguese(Standard)"]["email"] = "Email";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["email"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["email"] = "";
	$fieldLabelsadmin_users["Portuguese(Standard)"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["fullname"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["fullname"] = "";
	$fieldLabelsadmin_users["Portuguese(Standard)"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["groupid"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["groupid"] = "";
	$fieldLabelsadmin_users["Portuguese(Standard)"]["active"] = "Active";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["active"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["active"] = "";
	$fieldLabelsadmin_users["Portuguese(Standard)"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Portuguese(Standard)"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Portuguese(Standard)"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Portuguese(Standard)"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsadmin_users["Romanian"] = array();
	$fieldToolTipsadmin_users["Romanian"] = array();
	$placeHoldersadmin_users["Romanian"] = array();
	$pageTitlesadmin_users["Romanian"] = array();
	$fieldLabelsadmin_users["Romanian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Romanian"]["ID"] = "";
	$placeHoldersadmin_users["Romanian"]["ID"] = "";
	$fieldLabelsadmin_users["Romanian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Romanian"]["username"] = "";
	$placeHoldersadmin_users["Romanian"]["username"] = "";
	$fieldLabelsadmin_users["Romanian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Romanian"]["password"] = "";
	$placeHoldersadmin_users["Romanian"]["password"] = "";
	$fieldLabelsadmin_users["Romanian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Romanian"]["email"] = "";
	$placeHoldersadmin_users["Romanian"]["email"] = "";
	$fieldLabelsadmin_users["Romanian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Romanian"]["fullname"] = "";
	$placeHoldersadmin_users["Romanian"]["fullname"] = "";
	$fieldLabelsadmin_users["Romanian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Romanian"]["groupid"] = "";
	$placeHoldersadmin_users["Romanian"]["groupid"] = "";
	$fieldLabelsadmin_users["Romanian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Romanian"]["active"] = "";
	$placeHoldersadmin_users["Romanian"]["active"] = "";
	$fieldLabelsadmin_users["Romanian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Romanian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Romanian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Romanian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsadmin_users["Russian"] = array();
	$fieldToolTipsadmin_users["Russian"] = array();
	$placeHoldersadmin_users["Russian"] = array();
	$pageTitlesadmin_users["Russian"] = array();
	$fieldLabelsadmin_users["Russian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Russian"]["ID"] = "";
	$placeHoldersadmin_users["Russian"]["ID"] = "";
	$fieldLabelsadmin_users["Russian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Russian"]["username"] = "";
	$placeHoldersadmin_users["Russian"]["username"] = "";
	$fieldLabelsadmin_users["Russian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Russian"]["password"] = "";
	$placeHoldersadmin_users["Russian"]["password"] = "";
	$fieldLabelsadmin_users["Russian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Russian"]["email"] = "";
	$placeHoldersadmin_users["Russian"]["email"] = "";
	$fieldLabelsadmin_users["Russian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Russian"]["fullname"] = "";
	$placeHoldersadmin_users["Russian"]["fullname"] = "";
	$fieldLabelsadmin_users["Russian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Russian"]["groupid"] = "";
	$placeHoldersadmin_users["Russian"]["groupid"] = "";
	$fieldLabelsadmin_users["Russian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Russian"]["active"] = "";
	$placeHoldersadmin_users["Russian"]["active"] = "";
	$fieldLabelsadmin_users["Russian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Russian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Russian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Russian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsadmin_users["Serbian"] = array();
	$fieldToolTipsadmin_users["Serbian"] = array();
	$placeHoldersadmin_users["Serbian"] = array();
	$pageTitlesadmin_users["Serbian"] = array();
	$fieldLabelsadmin_users["Serbian"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Serbian"]["ID"] = "";
	$placeHoldersadmin_users["Serbian"]["ID"] = "";
	$fieldLabelsadmin_users["Serbian"]["username"] = "Username";
	$fieldToolTipsadmin_users["Serbian"]["username"] = "";
	$placeHoldersadmin_users["Serbian"]["username"] = "";
	$fieldLabelsadmin_users["Serbian"]["password"] = "Password";
	$fieldToolTipsadmin_users["Serbian"]["password"] = "";
	$placeHoldersadmin_users["Serbian"]["password"] = "";
	$fieldLabelsadmin_users["Serbian"]["email"] = "Email";
	$fieldToolTipsadmin_users["Serbian"]["email"] = "";
	$placeHoldersadmin_users["Serbian"]["email"] = "";
	$fieldLabelsadmin_users["Serbian"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Serbian"]["fullname"] = "";
	$placeHoldersadmin_users["Serbian"]["fullname"] = "";
	$fieldLabelsadmin_users["Serbian"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Serbian"]["groupid"] = "";
	$placeHoldersadmin_users["Serbian"]["groupid"] = "";
	$fieldLabelsadmin_users["Serbian"]["active"] = "Active";
	$fieldToolTipsadmin_users["Serbian"]["active"] = "";
	$placeHoldersadmin_users["Serbian"]["active"] = "";
	$fieldLabelsadmin_users["Serbian"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Serbian"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Serbian"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Serbian"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsadmin_users["Slovak"] = array();
	$fieldToolTipsadmin_users["Slovak"] = array();
	$placeHoldersadmin_users["Slovak"] = array();
	$pageTitlesadmin_users["Slovak"] = array();
	$fieldLabelsadmin_users["Slovak"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Slovak"]["ID"] = "";
	$placeHoldersadmin_users["Slovak"]["ID"] = "";
	$fieldLabelsadmin_users["Slovak"]["username"] = "Username";
	$fieldToolTipsadmin_users["Slovak"]["username"] = "";
	$placeHoldersadmin_users["Slovak"]["username"] = "";
	$fieldLabelsadmin_users["Slovak"]["password"] = "Password";
	$fieldToolTipsadmin_users["Slovak"]["password"] = "";
	$placeHoldersadmin_users["Slovak"]["password"] = "";
	$fieldLabelsadmin_users["Slovak"]["email"] = "Email";
	$fieldToolTipsadmin_users["Slovak"]["email"] = "";
	$placeHoldersadmin_users["Slovak"]["email"] = "";
	$fieldLabelsadmin_users["Slovak"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Slovak"]["fullname"] = "";
	$placeHoldersadmin_users["Slovak"]["fullname"] = "";
	$fieldLabelsadmin_users["Slovak"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Slovak"]["groupid"] = "";
	$placeHoldersadmin_users["Slovak"]["groupid"] = "";
	$fieldLabelsadmin_users["Slovak"]["active"] = "Active";
	$fieldToolTipsadmin_users["Slovak"]["active"] = "";
	$placeHoldersadmin_users["Slovak"]["active"] = "";
	$fieldLabelsadmin_users["Slovak"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Slovak"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Slovak"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Slovak"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsadmin_users["Spanish"] = array();
	$fieldToolTipsadmin_users["Spanish"] = array();
	$placeHoldersadmin_users["Spanish"] = array();
	$pageTitlesadmin_users["Spanish"] = array();
	$fieldLabelsadmin_users["Spanish"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Spanish"]["ID"] = "";
	$placeHoldersadmin_users["Spanish"]["ID"] = "";
	$fieldLabelsadmin_users["Spanish"]["username"] = "Username";
	$fieldToolTipsadmin_users["Spanish"]["username"] = "";
	$placeHoldersadmin_users["Spanish"]["username"] = "";
	$fieldLabelsadmin_users["Spanish"]["password"] = "Password";
	$fieldToolTipsadmin_users["Spanish"]["password"] = "";
	$placeHoldersadmin_users["Spanish"]["password"] = "";
	$fieldLabelsadmin_users["Spanish"]["email"] = "Email";
	$fieldToolTipsadmin_users["Spanish"]["email"] = "";
	$placeHoldersadmin_users["Spanish"]["email"] = "";
	$fieldLabelsadmin_users["Spanish"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Spanish"]["fullname"] = "";
	$placeHoldersadmin_users["Spanish"]["fullname"] = "";
	$fieldLabelsadmin_users["Spanish"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Spanish"]["groupid"] = "";
	$placeHoldersadmin_users["Spanish"]["groupid"] = "";
	$fieldLabelsadmin_users["Spanish"]["active"] = "Active";
	$fieldToolTipsadmin_users["Spanish"]["active"] = "";
	$placeHoldersadmin_users["Spanish"]["active"] = "";
	$fieldLabelsadmin_users["Spanish"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Spanish"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Spanish"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Spanish"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsadmin_users["Swedish"] = array();
	$fieldToolTipsadmin_users["Swedish"] = array();
	$placeHoldersadmin_users["Swedish"] = array();
	$pageTitlesadmin_users["Swedish"] = array();
	$fieldLabelsadmin_users["Swedish"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Swedish"]["ID"] = "";
	$placeHoldersadmin_users["Swedish"]["ID"] = "";
	$fieldLabelsadmin_users["Swedish"]["username"] = "Username";
	$fieldToolTipsadmin_users["Swedish"]["username"] = "";
	$placeHoldersadmin_users["Swedish"]["username"] = "";
	$fieldLabelsadmin_users["Swedish"]["password"] = "Password";
	$fieldToolTipsadmin_users["Swedish"]["password"] = "";
	$placeHoldersadmin_users["Swedish"]["password"] = "";
	$fieldLabelsadmin_users["Swedish"]["email"] = "Email";
	$fieldToolTipsadmin_users["Swedish"]["email"] = "";
	$placeHoldersadmin_users["Swedish"]["email"] = "";
	$fieldLabelsadmin_users["Swedish"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Swedish"]["fullname"] = "";
	$placeHoldersadmin_users["Swedish"]["fullname"] = "";
	$fieldLabelsadmin_users["Swedish"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Swedish"]["groupid"] = "";
	$placeHoldersadmin_users["Swedish"]["groupid"] = "";
	$fieldLabelsadmin_users["Swedish"]["active"] = "Active";
	$fieldToolTipsadmin_users["Swedish"]["active"] = "";
	$placeHoldersadmin_users["Swedish"]["active"] = "";
	$fieldLabelsadmin_users["Swedish"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Swedish"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Swedish"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Swedish"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsadmin_users["Tagalog(Philippines)"] = array();
	$fieldToolTipsadmin_users["Tagalog(Philippines)"] = array();
	$placeHoldersadmin_users["Tagalog(Philippines)"] = array();
	$pageTitlesadmin_users["Tagalog(Philippines)"] = array();
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["ID"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["ID"] = "";
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["username"] = "Username";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["username"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["username"] = "";
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["password"] = "Password";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["password"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["password"] = "";
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["email"] = "Email";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["email"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["email"] = "";
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["fullname"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["fullname"] = "";
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["groupid"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["groupid"] = "";
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["active"] = "Active";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["active"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["active"] = "";
	$fieldLabelsadmin_users["Tagalog(Philippines)"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Tagalog(Philippines)"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Tagalog(Philippines)"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Tagalog(Philippines)"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsadmin_users["Thai"] = array();
	$fieldToolTipsadmin_users["Thai"] = array();
	$placeHoldersadmin_users["Thai"] = array();
	$pageTitlesadmin_users["Thai"] = array();
	$fieldLabelsadmin_users["Thai"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Thai"]["ID"] = "";
	$placeHoldersadmin_users["Thai"]["ID"] = "";
	$fieldLabelsadmin_users["Thai"]["username"] = "Username";
	$fieldToolTipsadmin_users["Thai"]["username"] = "";
	$placeHoldersadmin_users["Thai"]["username"] = "";
	$fieldLabelsadmin_users["Thai"]["password"] = "Password";
	$fieldToolTipsadmin_users["Thai"]["password"] = "";
	$placeHoldersadmin_users["Thai"]["password"] = "";
	$fieldLabelsadmin_users["Thai"]["email"] = "Email";
	$fieldToolTipsadmin_users["Thai"]["email"] = "";
	$placeHoldersadmin_users["Thai"]["email"] = "";
	$fieldLabelsadmin_users["Thai"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Thai"]["fullname"] = "";
	$placeHoldersadmin_users["Thai"]["fullname"] = "";
	$fieldLabelsadmin_users["Thai"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Thai"]["groupid"] = "";
	$placeHoldersadmin_users["Thai"]["groupid"] = "";
	$fieldLabelsadmin_users["Thai"]["active"] = "Active";
	$fieldToolTipsadmin_users["Thai"]["active"] = "";
	$placeHoldersadmin_users["Thai"]["active"] = "";
	$fieldLabelsadmin_users["Thai"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Thai"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Thai"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Thai"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsadmin_users["Turkish"] = array();
	$fieldToolTipsadmin_users["Turkish"] = array();
	$placeHoldersadmin_users["Turkish"] = array();
	$pageTitlesadmin_users["Turkish"] = array();
	$fieldLabelsadmin_users["Turkish"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Turkish"]["ID"] = "";
	$placeHoldersadmin_users["Turkish"]["ID"] = "";
	$fieldLabelsadmin_users["Turkish"]["username"] = "Username";
	$fieldToolTipsadmin_users["Turkish"]["username"] = "";
	$placeHoldersadmin_users["Turkish"]["username"] = "";
	$fieldLabelsadmin_users["Turkish"]["password"] = "Password";
	$fieldToolTipsadmin_users["Turkish"]["password"] = "";
	$placeHoldersadmin_users["Turkish"]["password"] = "";
	$fieldLabelsadmin_users["Turkish"]["email"] = "Email";
	$fieldToolTipsadmin_users["Turkish"]["email"] = "";
	$placeHoldersadmin_users["Turkish"]["email"] = "";
	$fieldLabelsadmin_users["Turkish"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Turkish"]["fullname"] = "";
	$placeHoldersadmin_users["Turkish"]["fullname"] = "";
	$fieldLabelsadmin_users["Turkish"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Turkish"]["groupid"] = "";
	$placeHoldersadmin_users["Turkish"]["groupid"] = "";
	$fieldLabelsadmin_users["Turkish"]["active"] = "Active";
	$fieldToolTipsadmin_users["Turkish"]["active"] = "";
	$placeHoldersadmin_users["Turkish"]["active"] = "";
	$fieldLabelsadmin_users["Turkish"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Turkish"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Turkish"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Turkish"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsadmin_users["Urdu"] = array();
	$fieldToolTipsadmin_users["Urdu"] = array();
	$placeHoldersadmin_users["Urdu"] = array();
	$pageTitlesadmin_users["Urdu"] = array();
	$fieldLabelsadmin_users["Urdu"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Urdu"]["ID"] = "";
	$placeHoldersadmin_users["Urdu"]["ID"] = "";
	$fieldLabelsadmin_users["Urdu"]["username"] = "Username";
	$fieldToolTipsadmin_users["Urdu"]["username"] = "";
	$placeHoldersadmin_users["Urdu"]["username"] = "";
	$fieldLabelsadmin_users["Urdu"]["password"] = "Password";
	$fieldToolTipsadmin_users["Urdu"]["password"] = "";
	$placeHoldersadmin_users["Urdu"]["password"] = "";
	$fieldLabelsadmin_users["Urdu"]["email"] = "Email";
	$fieldToolTipsadmin_users["Urdu"]["email"] = "";
	$placeHoldersadmin_users["Urdu"]["email"] = "";
	$fieldLabelsadmin_users["Urdu"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Urdu"]["fullname"] = "";
	$placeHoldersadmin_users["Urdu"]["fullname"] = "";
	$fieldLabelsadmin_users["Urdu"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Urdu"]["groupid"] = "";
	$placeHoldersadmin_users["Urdu"]["groupid"] = "";
	$fieldLabelsadmin_users["Urdu"]["active"] = "Active";
	$fieldToolTipsadmin_users["Urdu"]["active"] = "";
	$placeHoldersadmin_users["Urdu"]["active"] = "";
	$fieldLabelsadmin_users["Urdu"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Urdu"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Urdu"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Urdu"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsadmin_users["Welsh"] = array();
	$fieldToolTipsadmin_users["Welsh"] = array();
	$placeHoldersadmin_users["Welsh"] = array();
	$pageTitlesadmin_users["Welsh"] = array();
	$fieldLabelsadmin_users["Welsh"]["ID"] = "ID";
	$fieldToolTipsadmin_users["Welsh"]["ID"] = "";
	$placeHoldersadmin_users["Welsh"]["ID"] = "";
	$fieldLabelsadmin_users["Welsh"]["username"] = "Username";
	$fieldToolTipsadmin_users["Welsh"]["username"] = "";
	$placeHoldersadmin_users["Welsh"]["username"] = "";
	$fieldLabelsadmin_users["Welsh"]["password"] = "Password";
	$fieldToolTipsadmin_users["Welsh"]["password"] = "";
	$placeHoldersadmin_users["Welsh"]["password"] = "";
	$fieldLabelsadmin_users["Welsh"]["email"] = "Email";
	$fieldToolTipsadmin_users["Welsh"]["email"] = "";
	$placeHoldersadmin_users["Welsh"]["email"] = "";
	$fieldLabelsadmin_users["Welsh"]["fullname"] = "Fullname";
	$fieldToolTipsadmin_users["Welsh"]["fullname"] = "";
	$placeHoldersadmin_users["Welsh"]["fullname"] = "";
	$fieldLabelsadmin_users["Welsh"]["groupid"] = "Groupid";
	$fieldToolTipsadmin_users["Welsh"]["groupid"] = "";
	$placeHoldersadmin_users["Welsh"]["groupid"] = "";
	$fieldLabelsadmin_users["Welsh"]["active"] = "Active";
	$fieldToolTipsadmin_users["Welsh"]["active"] = "";
	$placeHoldersadmin_users["Welsh"]["active"] = "";
	$fieldLabelsadmin_users["Welsh"]["ext_security_id"] = "Ext Security Id";
	$fieldToolTipsadmin_users["Welsh"]["ext_security_id"] = "";
	$placeHoldersadmin_users["Welsh"]["ext_security_id"] = "";
	if (count($fieldToolTipsadmin_users["Welsh"]))
		$tdataadmin_users[".isUseToolTips"] = true;
}


	$tdataadmin_users[".NCSearch"] = true;



$tdataadmin_users[".shortTableName"] = "admin_users";
$tdataadmin_users[".nSecOptions"] = 0;

$tdataadmin_users[".mainTableOwnerID"] = "";
$tdataadmin_users[".entityType"] = 1;
$tdataadmin_users[".connId"] = "testdb_at_localhost";


$tdataadmin_users[".strOriginalTableName"] = "users";

	



$tdataadmin_users[".showAddInPopup"] = false;

$tdataadmin_users[".showEditInPopup"] = false;

$tdataadmin_users[".showViewInPopup"] = false;

	$tdataadmin_users[".listAjax"] = true;
//	temporary
//$tdataadmin_users[".listAjax"] = false;

	$tdataadmin_users[".audit"] = false;

	$tdataadmin_users[".locking"] = false;


$pages = $tdataadmin_users[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataadmin_users[".edit"] = true;
	$tdataadmin_users[".afterEditAction"] = 1;
	$tdataadmin_users[".closePopupAfterEdit"] = 1;
	$tdataadmin_users[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataadmin_users[".add"] = true;
$tdataadmin_users[".afterAddAction"] = 1;
$tdataadmin_users[".closePopupAfterAdd"] = 1;
$tdataadmin_users[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataadmin_users[".list"] = true;
}



$tdataadmin_users[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataadmin_users[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataadmin_users[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataadmin_users[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataadmin_users[".printFriendly"] = true;
}



$tdataadmin_users[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataadmin_users[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataadmin_users[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataadmin_users[".isUseAjaxSuggest"] = true;





$tdataadmin_users[".ajaxCodeSnippetAdded"] = false;

$tdataadmin_users[".buttonsAdded"] = false;

$tdataadmin_users[".addPageEvents"] = false;

// use timepicker for search panel
$tdataadmin_users[".isUseTimeForSearch"] = false;


$tdataadmin_users[".badgeColor"] = "00C2C5";


$tdataadmin_users[".allSearchFields"] = array();
$tdataadmin_users[".filterFields"] = array();
$tdataadmin_users[".requiredSearchFields"] = array();

$tdataadmin_users[".googleLikeFields"] = array();
$tdataadmin_users[".googleLikeFields"][] = "ID";
$tdataadmin_users[".googleLikeFields"][] = "username";
$tdataadmin_users[".googleLikeFields"][] = "password";
$tdataadmin_users[".googleLikeFields"][] = "email";
$tdataadmin_users[".googleLikeFields"][] = "fullname";
$tdataadmin_users[".googleLikeFields"][] = "groupid";
$tdataadmin_users[".googleLikeFields"][] = "active";
$tdataadmin_users[".googleLikeFields"][] = "ext_security_id";



$tdataadmin_users[".tableType"] = "list";

$tdataadmin_users[".printerPageOrientation"] = 0;
$tdataadmin_users[".nPrinterPageScale"] = 100;

$tdataadmin_users[".nPrinterSplitRecords"] = 40;

$tdataadmin_users[".geocodingEnabled"] = false;




$tdataadmin_users[".isDisplayLoading"] = true;






$tdataadmin_users[".pageSize"] = 20;

$tdataadmin_users[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdataadmin_users[".strOrderBy"] = $tstrOrderBy;

$tdataadmin_users[".orderindexes"] = array();


$tdataadmin_users[".sqlHead"] = "SELECT ID,  	username,  	password,  	email,  	fullname,  	groupid,  	active,  	ext_security_id";
$tdataadmin_users[".sqlFrom"] = "FROM users";
$tdataadmin_users[".sqlWhereExpr"] = "";
$tdataadmin_users[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataadmin_users[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataadmin_users[".arrGroupsPerPage"] = $arrGPP;

$tdataadmin_users[".highlightSearchResults"] = true;

$tableKeysadmin_users = array();
$tableKeysadmin_users[] = "ID";
$tdataadmin_users[".Keys"] = $tableKeysadmin_users;


$tdataadmin_users[".hideMobileList"] = array();




//	ID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID";
	$fdata["GoodName"] = "ID";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","ID");
	$fdata["FieldType"] = 3;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "ID";

		$fdata["sourceSingle"] = "ID";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["ID"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "ID";
//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","username");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "username";

		$fdata["sourceSingle"] = "username";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["username"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "username";
//	password
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "password";
	$fdata["GoodName"] = "password";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","password");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "password";

		$fdata["sourceSingle"] = "password";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "password";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["password"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "password";
//	email
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "email";
	$fdata["GoodName"] = "email";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","email");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "email";

		$fdata["sourceSingle"] = "email";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "email";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["email"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "email";
//	fullname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "fullname";
	$fdata["GoodName"] = "fullname";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","fullname");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "fullname";

		$fdata["sourceSingle"] = "fullname";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "fullname";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["fullname"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "fullname";
//	groupid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "groupid";
	$fdata["GoodName"] = "groupid";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","groupid");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "groupid";

		$fdata["sourceSingle"] = "groupid";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "groupid";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["groupid"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "groupid";
//	active
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "active";
	$fdata["GoodName"] = "active";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","active");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "active";

		$fdata["sourceSingle"] = "active";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "active";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["active"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "active";
//	ext_security_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "ext_security_id";
	$fdata["GoodName"] = "ext_security_id";
	$fdata["ownerTable"] = "users";
	$fdata["Label"] = GetFieldLabel("admin_users","ext_security_id");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "ext_security_id";

		$fdata["sourceSingle"] = "ext_security_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ext_security_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataadmin_users["ext_security_id"] = $fdata;
		$tdataadmin_users[".searchableFields"][] = "ext_security_id";


$tables_data["admin_users"]=&$tdataadmin_users;
$field_labels["admin_users"] = &$fieldLabelsadmin_users;
$fieldToolTips["admin_users"] = &$fieldToolTipsadmin_users;
$placeHolders["admin_users"] = &$placeHoldersadmin_users;
$page_titles["admin_users"] = &$pageTitlesadmin_users;


changeTextControlsToDate( "admin_users" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["admin_users"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["admin_users"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_admin_users()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "ID,  	username,  	password,  	email,  	fullname,  	groupid,  	active,  	ext_security_id";
$proto0["m_strFrom"] = "FROM users";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "ID",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto6["m_sql"] = "ID";
$proto6["m_srcTableName"] = "admin_users";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto8["m_sql"] = "username";
$proto8["m_srcTableName"] = "admin_users";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "password",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto10["m_sql"] = "password";
$proto10["m_srcTableName"] = "admin_users";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "email",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto12["m_sql"] = "email";
$proto12["m_srcTableName"] = "admin_users";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "fullname",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto14["m_sql"] = "fullname";
$proto14["m_srcTableName"] = "admin_users";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "groupid",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto16["m_sql"] = "groupid";
$proto16["m_srcTableName"] = "admin_users";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "active",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto18["m_sql"] = "active";
$proto18["m_srcTableName"] = "admin_users";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "ext_security_id",
	"m_strTable" => "users",
	"m_srcTableName" => "admin_users"
));

$proto20["m_sql"] = "ext_security_id";
$proto20["m_srcTableName"] = "admin_users";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto22=array();
$proto22["m_link"] = "SQLL_MAIN";
			$proto23=array();
$proto23["m_strName"] = "users";
$proto23["m_srcTableName"] = "admin_users";
$proto23["m_columns"] = array();
$proto23["m_columns"][] = "ID";
$proto23["m_columns"][] = "username";
$proto23["m_columns"][] = "password";
$proto23["m_columns"][] = "email";
$proto23["m_columns"][] = "fullname";
$proto23["m_columns"][] = "groupid";
$proto23["m_columns"][] = "active";
$proto23["m_columns"][] = "ext_security_id";
$proto23["m_columns"][] = "reset_token";
$proto23["m_columns"][] = "reset_date";
$proto23["m_columns"][] = "userpic";
$obj = new SQLTable($proto23);

$proto22["m_table"] = $obj;
$proto22["m_sql"] = "users";
$proto22["m_alias"] = "";
$proto22["m_srcTableName"] = "admin_users";
$proto24=array();
$proto24["m_sql"] = "";
$proto24["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto24["m_column"]=$obj;
$proto24["m_contained"] = array();
$proto24["m_strCase"] = "";
$proto24["m_havingmode"] = false;
$proto24["m_inBrackets"] = false;
$proto24["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto24);

$proto22["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto22);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="admin_users";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_admin_users = createSqlQuery_admin_users();


	
		;

																														

$tdataadmin_users[".sqlquery"] = $queryData_admin_users;



$tdataadmin_users[".hasEvents"] = false;

?>