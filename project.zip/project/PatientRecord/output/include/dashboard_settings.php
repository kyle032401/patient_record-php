<?php
require_once(getabspath("classes/cipherer.php"));



$tdatadashboard = array();
$tdatadashboard[".ShortName"] = "dashboard";

$tdatadashboard[".pagesByType"] = my_json_decode( "{\"dashboard\":[\"dashboard\"]}" );
$tdatadashboard[".originalPagesByType"] = $tdatadashboard[".pagesByType"];
$tdatadashboard[".pages"] = types2pages( my_json_decode( "{\"dashboard\":[\"dashboard\"]}" ) );
$tdatadashboard[".originalPages"] = $tdatadashboard[".pages"];
$tdatadashboard[".defaultPages"] = my_json_decode( "{\"dashboard\":\"dashboard\"}" );
$tdatadashboard[".originalDefaultPages"] = $tdatadashboard[".defaultPages"];


//	field labels
$fieldLabelsdashboard = array();
$pageTitlesdashboard = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdashboard["English"] = array();
	$fieldLabelsdashboard["English"]["diagnoses_Chart_id"] = "Id";
	$fieldLabelsdashboard["English"]["diagnoses_Chart_TakenTime"] = "Taken Time";
	$fieldLabelsdashboard["English"]["diagnoses_Chart_Quantity"] = "Quantity";
	$fieldLabelsdashboard["English"]["diagnoses_Chart_treatment_id"] = "Treatment Id";
	$fieldLabelsdashboard["English"]["diagnoses_Chart_medicine_id"] = "Medicine Id";
	$fieldLabelsdashboard["English"]["diagnoses_Chart_Photo"] = "Photo";
	$fieldLabelsdashboard["English"]["diagnoses_Chart_Result"] = "Result";
	$fieldLabelsdashboard["English"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["English"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["English"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["English"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["English"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["English"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["English"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["English"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["English"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["English"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["English"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["English"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["English"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["English"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsdashboard["Afrikaans"] = array();
	$fieldLabelsdashboard["Afrikaans"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Afrikaans"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Afrikaans"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Afrikaans"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Afrikaans"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Afrikaans"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Afrikaans"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Afrikaans"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Afrikaans"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Afrikaans"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Afrikaans"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Afrikaans"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Afrikaans"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Afrikaans"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Afrikaans"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Afrikaans"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Afrikaans"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Afrikaans"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Afrikaans"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Afrikaans"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Afrikaans"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsdashboard["Arabic"] = array();
	$fieldLabelsdashboard["Arabic"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Arabic"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Arabic"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Arabic"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Arabic"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Arabic"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Arabic"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Arabic"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Arabic"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Arabic"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Arabic"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Arabic"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Arabic"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Arabic"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Arabic"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Arabic"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Arabic"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Arabic"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Arabic"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Arabic"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Arabic"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsdashboard["Bosnian"] = array();
	$fieldLabelsdashboard["Bosnian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Bosnian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Bosnian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Bosnian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Bosnian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Bosnian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Bosnian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Bosnian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Bosnian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Bosnian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Bosnian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Bosnian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Bosnian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Bosnian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Bosnian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Bosnian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Bosnian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Bosnian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Bosnian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Bosnian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Bosnian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsdashboard["Bulgarian"] = array();
	$fieldLabelsdashboard["Bulgarian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Bulgarian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Bulgarian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Bulgarian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Bulgarian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Bulgarian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Bulgarian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Bulgarian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Bulgarian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Bulgarian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Bulgarian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Bulgarian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Bulgarian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Bulgarian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Bulgarian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Bulgarian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Bulgarian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Bulgarian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Bulgarian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Bulgarian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Bulgarian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsdashboard["Catalan"] = array();
	$fieldLabelsdashboard["Catalan"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Catalan"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Catalan"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Catalan"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Catalan"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Catalan"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Catalan"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Catalan"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Catalan"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Catalan"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Catalan"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Catalan"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Catalan"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Catalan"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Catalan"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Catalan"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Catalan"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Catalan"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Catalan"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Catalan"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Catalan"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsdashboard["Chinese"] = array();
	$fieldLabelsdashboard["Chinese"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Chinese"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Chinese"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Chinese"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Chinese"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Chinese"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Chinese"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Chinese"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Chinese"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Chinese"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Chinese"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Chinese"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Chinese"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Chinese"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Chinese"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Chinese"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Chinese"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Chinese"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Chinese (Hong Kong S.A.R.)"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsdashboard["Chinese (Taiwan)"] = array();
	$fieldLabelsdashboard["Chinese (Taiwan)"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Chinese (Taiwan)"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsdashboard["Croatian"] = array();
	$fieldLabelsdashboard["Croatian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Croatian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Croatian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Croatian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Croatian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Croatian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Croatian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Croatian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Croatian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Croatian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Croatian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Croatian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Croatian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Croatian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Croatian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Croatian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Croatian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Croatian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Croatian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Croatian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Croatian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsdashboard["Czech"] = array();
	$fieldLabelsdashboard["Czech"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Czech"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Czech"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Czech"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Czech"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Czech"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Czech"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Czech"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Czech"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Czech"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Czech"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Czech"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Czech"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Czech"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Czech"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Czech"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Czech"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Czech"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Czech"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Czech"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Czech"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsdashboard["Danish"] = array();
	$fieldLabelsdashboard["Danish"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Danish"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Danish"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Danish"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Danish"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Danish"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Danish"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Danish"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Danish"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Danish"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Danish"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Danish"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Danish"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Danish"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Danish"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Danish"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Danish"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Danish"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Danish"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Danish"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Danish"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsdashboard["Dutch"] = array();
	$fieldLabelsdashboard["Dutch"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Dutch"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Dutch"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Dutch"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Dutch"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Dutch"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Dutch"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Dutch"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Dutch"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Dutch"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Dutch"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Dutch"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Dutch"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Dutch"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Dutch"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Dutch"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Dutch"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Dutch"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Dutch"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Dutch"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Dutch"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsdashboard["Farsi"] = array();
	$fieldLabelsdashboard["Farsi"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Farsi"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Farsi"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Farsi"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Farsi"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Farsi"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Farsi"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Farsi"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Farsi"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Farsi"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Farsi"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Farsi"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Farsi"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Farsi"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Farsi"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Farsi"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Farsi"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Farsi"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Farsi"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Farsi"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Farsi"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsdashboard["French"] = array();
	$fieldLabelsdashboard["French"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["French"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["French"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["French"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["French"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["French"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["French"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["French"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["French"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["French"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["French"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["French"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["French"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["French"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["French"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["French"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["French"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["French"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["French"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["French"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["French"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsdashboard["Georgian"] = array();
	$fieldLabelsdashboard["Georgian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Georgian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Georgian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Georgian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Georgian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Georgian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Georgian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Georgian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Georgian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Georgian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Georgian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Georgian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Georgian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Georgian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Georgian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Georgian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Georgian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Georgian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Georgian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Georgian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Georgian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsdashboard["German"] = array();
	$fieldLabelsdashboard["German"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["German"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["German"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["German"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["German"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["German"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["German"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["German"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["German"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["German"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["German"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["German"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["German"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["German"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["German"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["German"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["German"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["German"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["German"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["German"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["German"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsdashboard["Greek"] = array();
	$fieldLabelsdashboard["Greek"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Greek"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Greek"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Greek"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Greek"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Greek"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Greek"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Greek"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Greek"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Greek"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Greek"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Greek"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Greek"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Greek"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Greek"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Greek"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Greek"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Greek"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Greek"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Greek"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Greek"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsdashboard["Hebrew"] = array();
	$fieldLabelsdashboard["Hebrew"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Hebrew"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Hebrew"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Hebrew"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Hebrew"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Hebrew"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Hebrew"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Hebrew"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Hebrew"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Hebrew"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Hebrew"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Hebrew"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Hebrew"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Hebrew"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Hebrew"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Hebrew"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Hebrew"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Hebrew"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Hebrew"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Hebrew"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Hebrew"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsdashboard["Hungarian"] = array();
	$fieldLabelsdashboard["Hungarian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Hungarian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Hungarian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Hungarian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Hungarian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Hungarian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Hungarian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Hungarian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Hungarian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Hungarian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Hungarian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Hungarian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Hungarian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Hungarian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Hungarian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Hungarian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Hungarian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Hungarian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Hungarian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Hungarian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Hungarian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsdashboard["Indonesian"] = array();
	$fieldLabelsdashboard["Indonesian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Indonesian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Indonesian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Indonesian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Indonesian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Indonesian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Indonesian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Indonesian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Indonesian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Indonesian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Indonesian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Indonesian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Indonesian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Indonesian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Indonesian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Indonesian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Indonesian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Indonesian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Indonesian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Indonesian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Indonesian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsdashboard["Italian"] = array();
	$fieldLabelsdashboard["Italian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Italian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Italian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Italian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Italian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Italian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Italian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Italian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Italian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Italian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Italian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Italian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Italian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Italian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Italian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Italian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Italian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Italian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Italian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Italian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Italian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsdashboard["Japanese"] = array();
	$fieldLabelsdashboard["Japanese"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Japanese"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Japanese"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Japanese"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Japanese"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Japanese"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Japanese"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Japanese"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Japanese"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Japanese"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Japanese"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Japanese"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Japanese"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Japanese"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Japanese"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Japanese"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Japanese"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Japanese"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Japanese"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Japanese"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Japanese"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsdashboard["Malay"] = array();
	$fieldLabelsdashboard["Malay"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Malay"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Malay"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Malay"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Malay"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Malay"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Malay"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Malay"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Malay"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Malay"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Malay"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Malay"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Malay"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Malay"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Malay"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Malay"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Malay"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Malay"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Malay"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Malay"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Malay"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsdashboard["Norwegian(Bokmal)"] = array();
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Norwegian(Bokmal)"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsdashboard["Polish"] = array();
	$fieldLabelsdashboard["Polish"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Polish"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Polish"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Polish"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Polish"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Polish"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Polish"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Polish"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Polish"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Polish"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Polish"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Polish"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Polish"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Polish"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Polish"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Polish"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Polish"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Polish"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Polish"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Polish"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Polish"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsdashboard["Portuguese(Brazil)"] = array();
	$fieldLabelsdashboard["Portuguese(Brazil)"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Portuguese(Brazil)"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsdashboard["Portuguese(Standard)"] = array();
	$fieldLabelsdashboard["Portuguese(Standard)"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Portuguese(Standard)"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Portuguese(Standard)"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Portuguese(Standard)"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Portuguese(Standard)"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Portuguese(Standard)"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Portuguese(Standard)"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Portuguese(Standard)"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Portuguese(Standard)"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Portuguese(Standard)"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Portuguese(Standard)"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Portuguese(Standard)"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Portuguese(Standard)"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Portuguese(Standard)"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Portuguese(Standard)"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Portuguese(Standard)"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Portuguese(Standard)"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Portuguese(Standard)"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Portuguese(Standard)"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Portuguese(Standard)"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Portuguese(Standard)"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsdashboard["Romanian"] = array();
	$fieldLabelsdashboard["Romanian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Romanian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Romanian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Romanian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Romanian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Romanian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Romanian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Romanian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Romanian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Romanian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Romanian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Romanian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Romanian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Romanian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Romanian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Romanian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Romanian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Romanian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Romanian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Romanian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Romanian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsdashboard["Russian"] = array();
	$fieldLabelsdashboard["Russian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Russian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Russian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Russian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Russian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Russian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Russian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Russian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Russian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Russian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Russian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Russian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Russian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Russian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Russian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Russian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Russian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Russian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Russian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Russian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Russian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsdashboard["Serbian"] = array();
	$fieldLabelsdashboard["Serbian"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Serbian"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Serbian"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Serbian"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Serbian"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Serbian"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Serbian"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Serbian"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Serbian"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Serbian"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Serbian"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Serbian"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Serbian"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Serbian"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Serbian"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Serbian"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Serbian"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Serbian"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Serbian"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Serbian"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Serbian"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsdashboard["Slovak"] = array();
	$fieldLabelsdashboard["Slovak"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Slovak"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Slovak"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Slovak"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Slovak"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Slovak"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Slovak"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Slovak"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Slovak"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Slovak"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Slovak"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Slovak"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Slovak"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Slovak"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Slovak"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Slovak"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Slovak"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Slovak"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Slovak"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Slovak"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Slovak"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsdashboard["Spanish"] = array();
	$fieldLabelsdashboard["Spanish"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Spanish"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Spanish"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Spanish"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Spanish"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Spanish"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Spanish"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Spanish"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Spanish"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Spanish"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Spanish"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Spanish"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Spanish"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Spanish"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Spanish"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Spanish"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Spanish"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Spanish"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Spanish"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Spanish"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Spanish"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsdashboard["Swedish"] = array();
	$fieldLabelsdashboard["Swedish"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Swedish"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Swedish"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Swedish"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Swedish"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Swedish"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Swedish"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Swedish"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Swedish"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Swedish"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Swedish"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Swedish"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Swedish"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Swedish"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Swedish"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Swedish"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Swedish"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Swedish"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Swedish"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Swedish"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Swedish"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsdashboard["Tagalog(Philippines)"] = array();
	$fieldLabelsdashboard["Tagalog(Philippines)"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Tagalog(Philippines)"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsdashboard["Thai"] = array();
	$fieldLabelsdashboard["Thai"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Thai"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Thai"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Thai"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Thai"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Thai"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Thai"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Thai"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Thai"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Thai"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Thai"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Thai"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Thai"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Thai"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Thai"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Thai"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Thai"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Thai"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Thai"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Thai"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Thai"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsdashboard["Turkish"] = array();
	$fieldLabelsdashboard["Turkish"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Turkish"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Turkish"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Turkish"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Turkish"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Turkish"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Turkish"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Turkish"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Turkish"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Turkish"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Turkish"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Turkish"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Turkish"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Turkish"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Turkish"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Turkish"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Turkish"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Turkish"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Turkish"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Turkish"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Turkish"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsdashboard["Urdu"] = array();
	$fieldLabelsdashboard["Urdu"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Urdu"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Urdu"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Urdu"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Urdu"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Urdu"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Urdu"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Urdu"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Urdu"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Urdu"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Urdu"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Urdu"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Urdu"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Urdu"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Urdu"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Urdu"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Urdu"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Urdu"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Urdu"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Urdu"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Urdu"]["patients_Chart_doctor_id"] = "Doctor Id";
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsdashboard["Welsh"] = array();
	$fieldLabelsdashboard["Welsh"]["diagnoses_Chart_id"] = "";
	$fieldLabelsdashboard["Welsh"]["diagnoses_Chart_TakenTime"] = "";
	$fieldLabelsdashboard["Welsh"]["diagnoses_Chart_Quantity"] = "";
	$fieldLabelsdashboard["Welsh"]["diagnoses_Chart_treatment_id"] = "";
	$fieldLabelsdashboard["Welsh"]["diagnoses_Chart_medicine_id"] = "";
	$fieldLabelsdashboard["Welsh"]["diagnoses_Chart_Photo"] = "";
	$fieldLabelsdashboard["Welsh"]["diagnoses_Chart_Result"] = "";
	$fieldLabelsdashboard["Welsh"]["medicines_Chart_id"] = "Id";
	$fieldLabelsdashboard["Welsh"]["medicines_Chart_MedicineName"] = "Medicine Name";
	$fieldLabelsdashboard["Welsh"]["medicines_Chart_Description"] = "Description";
	$fieldLabelsdashboard["Welsh"]["medicines_Chart_Type"] = "Type";
	$fieldLabelsdashboard["Welsh"]["treatments_Chart_id"] = "Id";
	$fieldLabelsdashboard["Welsh"]["treatments_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Welsh"]["treatments_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Welsh"]["treatments_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Welsh"]["treatments_Chart_doctor_id"] = "Doctor Id";
	$fieldLabelsdashboard["Welsh"]["patients_Chart_id"] = "Id";
	$fieldLabelsdashboard["Welsh"]["patients_Chart_TreatmentDate"] = "Treatment Date";
	$fieldLabelsdashboard["Welsh"]["patients_Chart_TreatmentTIme"] = "Treatment TIme";
	$fieldLabelsdashboard["Welsh"]["patients_Chart_patient_id"] = "Patient Id";
	$fieldLabelsdashboard["Welsh"]["patients_Chart_doctor_id"] = "Doctor Id";
}

/*
//	search fields
$tdatadashboard[".searchFields"] = array();
$dashField = array();
$dashField[] = array( "table"=>"diagnoses Chart", "field"=>"id" );
$tdatadashboard[".searchFields"]["diagnoses_Chart_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"diagnoses Chart", "field"=>"TakenTime" );
$tdatadashboard[".searchFields"]["diagnoses_Chart_TakenTime"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"diagnoses Chart", "field"=>"Quantity" );
$tdatadashboard[".searchFields"]["diagnoses_Chart_Quantity"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"diagnoses Chart", "field"=>"treatment_id" );
$tdatadashboard[".searchFields"]["diagnoses_Chart_treatment_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"diagnoses Chart", "field"=>"medicine_id" );
$tdatadashboard[".searchFields"]["diagnoses_Chart_medicine_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"diagnoses Chart", "field"=>"Photo" );
$tdatadashboard[".searchFields"]["diagnoses_Chart_Photo"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"diagnoses Chart", "field"=>"Result" );
$tdatadashboard[".searchFields"]["diagnoses_Chart_Result"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"medicines Chart", "field"=>"id" );
$tdatadashboard[".searchFields"]["medicines_Chart_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"medicines Chart", "field"=>"MedicineName" );
$tdatadashboard[".searchFields"]["medicines_Chart_MedicineName"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"medicines Chart", "field"=>"Description" );
$tdatadashboard[".searchFields"]["medicines_Chart_Description"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"medicines Chart", "field"=>"Type" );
$tdatadashboard[".searchFields"]["medicines_Chart_Type"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"treatments Chart", "field"=>"id" );
$tdatadashboard[".searchFields"]["treatments_Chart_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"treatments Chart", "field"=>"TreatmentDate" );
$tdatadashboard[".searchFields"]["treatments_Chart_TreatmentDate"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"treatments Chart", "field"=>"TreatmentTIme" );
$tdatadashboard[".searchFields"]["treatments_Chart_TreatmentTIme"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"treatments Chart", "field"=>"patient_id" );
$tdatadashboard[".searchFields"]["treatments_Chart_patient_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"treatments Chart", "field"=>"doctor_id" );
$tdatadashboard[".searchFields"]["treatments_Chart_doctor_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"patients Chart", "field"=>"id" );
$tdatadashboard[".searchFields"]["patients_Chart_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"patients Chart", "field"=>"TreatmentDate" );
$tdatadashboard[".searchFields"]["patients_Chart_TreatmentDate"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"patients Chart", "field"=>"TreatmentTIme" );
$tdatadashboard[".searchFields"]["patients_Chart_TreatmentTIme"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"patients Chart", "field"=>"patient_id" );
$tdatadashboard[".searchFields"]["patients_Chart_patient_id"] = $dashField;
$dashField = array();
$dashField[] = array( "table"=>"patients Chart", "field"=>"doctor_id" );
$tdatadashboard[".searchFields"]["patients_Chart_doctor_id"] = $dashField;

// all search fields
$tdatadashboard[".allSearchFields"] = array();
$tdatadashboard[".allSearchFields"][] = "diagnoses_Chart_id";
$tdatadashboard[".allSearchFields"][] = "diagnoses_Chart_TakenTime";
$tdatadashboard[".allSearchFields"][] = "diagnoses_Chart_Quantity";
$tdatadashboard[".allSearchFields"][] = "diagnoses_Chart_treatment_id";
$tdatadashboard[".allSearchFields"][] = "diagnoses_Chart_medicine_id";
$tdatadashboard[".allSearchFields"][] = "diagnoses_Chart_Photo";
$tdatadashboard[".allSearchFields"][] = "diagnoses_Chart_Result";
$tdatadashboard[".allSearchFields"][] = "medicines_Chart_id";
$tdatadashboard[".allSearchFields"][] = "medicines_Chart_MedicineName";
$tdatadashboard[".allSearchFields"][] = "medicines_Chart_Description";
$tdatadashboard[".allSearchFields"][] = "medicines_Chart_Type";
$tdatadashboard[".allSearchFields"][] = "treatments_Chart_id";
$tdatadashboard[".allSearchFields"][] = "treatments_Chart_TreatmentDate";
$tdatadashboard[".allSearchFields"][] = "treatments_Chart_TreatmentTIme";
$tdatadashboard[".allSearchFields"][] = "treatments_Chart_patient_id";
$tdatadashboard[".allSearchFields"][] = "treatments_Chart_doctor_id";
$tdatadashboard[".allSearchFields"][] = "patients_Chart_id";
$tdatadashboard[".allSearchFields"][] = "patients_Chart_TreatmentDate";
$tdatadashboard[".allSearchFields"][] = "patients_Chart_TreatmentTIme";
$tdatadashboard[".allSearchFields"][] = "patients_Chart_patient_id";
$tdatadashboard[".allSearchFields"][] = "patients_Chart_doctor_id";

// good like search fields
$tdatadashboard[".googleLikeFields"] = array();
*/

/*
$tdatadashboard[".dashElements"] = array();

	$dbelement = array( "elementName" => "diagnoses_Chart_chart", "table" => "diagnoses Chart",
		 "pageName" => "","type" => 1);
	$dbelement["cellName"] = "";

		$dbelement["reload"] = 60;
		$dbelement["width"] = 800;
		$dbelement["height"] = 600;


	$tdatadashboard[".dashElements"][] = $dbelement;
	$dbelement = array( "elementName" => "medicines_Chart_chart", "table" => "medicines Chart",
		 "pageName" => "","type" => 1);
	$dbelement["cellName"] = "";

		$dbelement["reload"] = 60;
		$dbelement["width"] = 800;
		$dbelement["height"] = 600;


	$tdatadashboard[".dashElements"][] = $dbelement;
	$dbelement = array( "elementName" => "treatments_Chart_chart", "table" => "treatments Chart",
		 "pageName" => "","type" => 1);
	$dbelement["cellName"] = "";

		$dbelement["reload"] = 60;
		$dbelement["width"] = 800;
		$dbelement["height"] = 600;


	$tdatadashboard[".dashElements"][] = $dbelement;
	$dbelement = array( "elementName" => "patients_Chart_chart", "table" => "patients Chart",
		 "pageName" => "","type" => 1);
	$dbelement["cellName"] = "";

		$dbelement["reload"] = 60;
		$dbelement["width"] = 800;
		$dbelement["height"] = 600;


	$tdatadashboard[".dashElements"][] = $dbelement;
*/
$tdatadashboard[".shortTableName"] = "dashboard";
$tdatadashboard[".entityType"] = 4;




$tdatadashboard[".hasEvents"] = false;


$tdatadashboard[".tableType"] = "dashboard";



$tdatadashboard[".addPageEvents"] = false;

$tdatadashboard[".isUseAjaxSuggest"] = true;

$tables_data["Dashboard"]=&$tdatadashboard;
$field_labels["Dashboard"] = &$fieldLabelsdashboard;
$page_titles["Dashboard"] = &$pageTitlesdashboard;

?>