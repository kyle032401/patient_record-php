<?php
$tdatadoctors_report = array();
$tdatadoctors_report[".searchableFields"] = array();
$tdatadoctors_report[".ShortName"] = "doctors_report";
$tdatadoctors_report[".OwnerID"] = "";
$tdatadoctors_report[".OriginalTable"] = "doctors";


$tdatadoctors_report[".pagesByType"] = my_json_decode( "{\"masterreport\":[\"masterreport\"],\"masterrprint\":[\"masterrprint\"],\"report\":[\"report\"],\"rprint\":[\"rprint\"],\"search\":[\"search\"]}" );
$tdatadoctors_report[".originalPagesByType"] = $tdatadoctors_report[".pagesByType"];
$tdatadoctors_report[".pages"] = types2pages( my_json_decode( "{\"masterreport\":[\"masterreport\"],\"masterrprint\":[\"masterrprint\"],\"report\":[\"report\"],\"rprint\":[\"rprint\"],\"search\":[\"search\"]}" ) );
$tdatadoctors_report[".originalPages"] = $tdatadoctors_report[".pages"];
$tdatadoctors_report[".defaultPages"] = my_json_decode( "{\"masterreport\":\"masterreport\",\"masterrprint\":\"masterrprint\",\"report\":\"report\",\"rprint\":\"rprint\",\"search\":\"search\"}" );
$tdatadoctors_report[".originalDefaultPages"] = $tdatadoctors_report[".defaultPages"];

//	field labels
$fieldLabelsdoctors_report = array();
$fieldToolTipsdoctors_report = array();
$pageTitlesdoctors_report = array();
$placeHoldersdoctors_report = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdoctors_report["English"] = array();
	$fieldToolTipsdoctors_report["English"] = array();
	$placeHoldersdoctors_report["English"] = array();
	$pageTitlesdoctors_report["English"] = array();
	$fieldLabelsdoctors_report["English"]["id"] = "Id";
	$fieldToolTipsdoctors_report["English"]["id"] = "";
	$placeHoldersdoctors_report["English"]["id"] = "";
	$fieldLabelsdoctors_report["English"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["English"]["DoctorName"] = "";
	$placeHoldersdoctors_report["English"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["English"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["English"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["English"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["English"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["English"]["Email"] = "";
	$placeHoldersdoctors_report["English"]["Email"] = "";
	$fieldLabelsdoctors_report["English"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["English"]["Photo"] = "";
	$placeHoldersdoctors_report["English"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["English"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Afrikaans")
{
	$fieldLabelsdoctors_report["Afrikaans"] = array();
	$fieldToolTipsdoctors_report["Afrikaans"] = array();
	$placeHoldersdoctors_report["Afrikaans"] = array();
	$pageTitlesdoctors_report["Afrikaans"] = array();
	$fieldLabelsdoctors_report["Afrikaans"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Afrikaans"]["id"] = "";
	$placeHoldersdoctors_report["Afrikaans"]["id"] = "";
	$fieldLabelsdoctors_report["Afrikaans"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Afrikaans"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Afrikaans"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Afrikaans"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Afrikaans"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Afrikaans"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Afrikaans"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Afrikaans"]["Email"] = "";
	$placeHoldersdoctors_report["Afrikaans"]["Email"] = "";
	$fieldLabelsdoctors_report["Afrikaans"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Afrikaans"]["Photo"] = "";
	$placeHoldersdoctors_report["Afrikaans"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Afrikaans"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Arabic")
{
	$fieldLabelsdoctors_report["Arabic"] = array();
	$fieldToolTipsdoctors_report["Arabic"] = array();
	$placeHoldersdoctors_report["Arabic"] = array();
	$pageTitlesdoctors_report["Arabic"] = array();
	$fieldLabelsdoctors_report["Arabic"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Arabic"]["id"] = "";
	$placeHoldersdoctors_report["Arabic"]["id"] = "";
	$fieldLabelsdoctors_report["Arabic"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Arabic"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Arabic"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Arabic"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Arabic"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Arabic"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Arabic"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Arabic"]["Email"] = "";
	$placeHoldersdoctors_report["Arabic"]["Email"] = "";
	$fieldLabelsdoctors_report["Arabic"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Arabic"]["Photo"] = "";
	$placeHoldersdoctors_report["Arabic"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Arabic"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bosnian")
{
	$fieldLabelsdoctors_report["Bosnian"] = array();
	$fieldToolTipsdoctors_report["Bosnian"] = array();
	$placeHoldersdoctors_report["Bosnian"] = array();
	$pageTitlesdoctors_report["Bosnian"] = array();
	$fieldLabelsdoctors_report["Bosnian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Bosnian"]["id"] = "";
	$placeHoldersdoctors_report["Bosnian"]["id"] = "";
	$fieldLabelsdoctors_report["Bosnian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Bosnian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Bosnian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Bosnian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Bosnian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Bosnian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Bosnian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Bosnian"]["Email"] = "";
	$placeHoldersdoctors_report["Bosnian"]["Email"] = "";
	$fieldLabelsdoctors_report["Bosnian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Bosnian"]["Photo"] = "";
	$placeHoldersdoctors_report["Bosnian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Bosnian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Bulgarian")
{
	$fieldLabelsdoctors_report["Bulgarian"] = array();
	$fieldToolTipsdoctors_report["Bulgarian"] = array();
	$placeHoldersdoctors_report["Bulgarian"] = array();
	$pageTitlesdoctors_report["Bulgarian"] = array();
	$fieldLabelsdoctors_report["Bulgarian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Bulgarian"]["id"] = "";
	$placeHoldersdoctors_report["Bulgarian"]["id"] = "";
	$fieldLabelsdoctors_report["Bulgarian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Bulgarian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Bulgarian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Bulgarian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Bulgarian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Bulgarian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Bulgarian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Bulgarian"]["Email"] = "";
	$placeHoldersdoctors_report["Bulgarian"]["Email"] = "";
	$fieldLabelsdoctors_report["Bulgarian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Bulgarian"]["Photo"] = "";
	$placeHoldersdoctors_report["Bulgarian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Bulgarian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Catalan")
{
	$fieldLabelsdoctors_report["Catalan"] = array();
	$fieldToolTipsdoctors_report["Catalan"] = array();
	$placeHoldersdoctors_report["Catalan"] = array();
	$pageTitlesdoctors_report["Catalan"] = array();
	$fieldLabelsdoctors_report["Catalan"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Catalan"]["id"] = "";
	$placeHoldersdoctors_report["Catalan"]["id"] = "";
	$fieldLabelsdoctors_report["Catalan"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Catalan"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Catalan"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Catalan"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Catalan"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Catalan"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Catalan"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Catalan"]["Email"] = "";
	$placeHoldersdoctors_report["Catalan"]["Email"] = "";
	$fieldLabelsdoctors_report["Catalan"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Catalan"]["Photo"] = "";
	$placeHoldersdoctors_report["Catalan"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Catalan"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese")
{
	$fieldLabelsdoctors_report["Chinese"] = array();
	$fieldToolTipsdoctors_report["Chinese"] = array();
	$placeHoldersdoctors_report["Chinese"] = array();
	$pageTitlesdoctors_report["Chinese"] = array();
	$fieldLabelsdoctors_report["Chinese"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Chinese"]["id"] = "";
	$placeHoldersdoctors_report["Chinese"]["id"] = "";
	$fieldLabelsdoctors_report["Chinese"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Chinese"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Chinese"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Chinese"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Chinese"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Chinese"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Chinese"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Chinese"]["Email"] = "";
	$placeHoldersdoctors_report["Chinese"]["Email"] = "";
	$fieldLabelsdoctors_report["Chinese"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Chinese"]["Photo"] = "";
	$placeHoldersdoctors_report["Chinese"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Chinese"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Hong Kong S.A.R.)")
{
	$fieldLabelsdoctors_report["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldToolTipsdoctors_report["Chinese (Hong Kong S.A.R.)"] = array();
	$placeHoldersdoctors_report["Chinese (Hong Kong S.A.R.)"] = array();
	$pageTitlesdoctors_report["Chinese (Hong Kong S.A.R.)"] = array();
	$fieldLabelsdoctors_report["Chinese (Hong Kong S.A.R.)"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$placeHoldersdoctors_report["Chinese (Hong Kong S.A.R.)"]["id"] = "";
	$fieldLabelsdoctors_report["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Chinese (Hong Kong S.A.R.)"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Chinese (Hong Kong S.A.R.)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Chinese (Hong Kong S.A.R.)"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Chinese (Hong Kong S.A.R.)"]["Email"] = "";
	$placeHoldersdoctors_report["Chinese (Hong Kong S.A.R.)"]["Email"] = "";
	$fieldLabelsdoctors_report["Chinese (Hong Kong S.A.R.)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	$placeHoldersdoctors_report["Chinese (Hong Kong S.A.R.)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Chinese (Hong Kong S.A.R.)"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Chinese (Taiwan)")
{
	$fieldLabelsdoctors_report["Chinese (Taiwan)"] = array();
	$fieldToolTipsdoctors_report["Chinese (Taiwan)"] = array();
	$placeHoldersdoctors_report["Chinese (Taiwan)"] = array();
	$pageTitlesdoctors_report["Chinese (Taiwan)"] = array();
	$fieldLabelsdoctors_report["Chinese (Taiwan)"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Chinese (Taiwan)"]["id"] = "";
	$placeHoldersdoctors_report["Chinese (Taiwan)"]["id"] = "";
	$fieldLabelsdoctors_report["Chinese (Taiwan)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Chinese (Taiwan)"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Chinese (Taiwan)"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Chinese (Taiwan)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Chinese (Taiwan)"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Chinese (Taiwan)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Chinese (Taiwan)"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Chinese (Taiwan)"]["Email"] = "";
	$placeHoldersdoctors_report["Chinese (Taiwan)"]["Email"] = "";
	$fieldLabelsdoctors_report["Chinese (Taiwan)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Chinese (Taiwan)"]["Photo"] = "";
	$placeHoldersdoctors_report["Chinese (Taiwan)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Chinese (Taiwan)"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Croatian")
{
	$fieldLabelsdoctors_report["Croatian"] = array();
	$fieldToolTipsdoctors_report["Croatian"] = array();
	$placeHoldersdoctors_report["Croatian"] = array();
	$pageTitlesdoctors_report["Croatian"] = array();
	$fieldLabelsdoctors_report["Croatian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Croatian"]["id"] = "";
	$placeHoldersdoctors_report["Croatian"]["id"] = "";
	$fieldLabelsdoctors_report["Croatian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Croatian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Croatian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Croatian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Croatian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Croatian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Croatian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Croatian"]["Email"] = "";
	$placeHoldersdoctors_report["Croatian"]["Email"] = "";
	$fieldLabelsdoctors_report["Croatian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Croatian"]["Photo"] = "";
	$placeHoldersdoctors_report["Croatian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Croatian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Czech")
{
	$fieldLabelsdoctors_report["Czech"] = array();
	$fieldToolTipsdoctors_report["Czech"] = array();
	$placeHoldersdoctors_report["Czech"] = array();
	$pageTitlesdoctors_report["Czech"] = array();
	$fieldLabelsdoctors_report["Czech"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Czech"]["id"] = "";
	$placeHoldersdoctors_report["Czech"]["id"] = "";
	$fieldLabelsdoctors_report["Czech"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Czech"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Czech"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Czech"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Czech"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Czech"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Czech"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Czech"]["Email"] = "";
	$placeHoldersdoctors_report["Czech"]["Email"] = "";
	$fieldLabelsdoctors_report["Czech"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Czech"]["Photo"] = "";
	$placeHoldersdoctors_report["Czech"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Czech"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Danish")
{
	$fieldLabelsdoctors_report["Danish"] = array();
	$fieldToolTipsdoctors_report["Danish"] = array();
	$placeHoldersdoctors_report["Danish"] = array();
	$pageTitlesdoctors_report["Danish"] = array();
	$fieldLabelsdoctors_report["Danish"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Danish"]["id"] = "";
	$placeHoldersdoctors_report["Danish"]["id"] = "";
	$fieldLabelsdoctors_report["Danish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Danish"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Danish"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Danish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Danish"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Danish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Danish"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Danish"]["Email"] = "";
	$placeHoldersdoctors_report["Danish"]["Email"] = "";
	$fieldLabelsdoctors_report["Danish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Danish"]["Photo"] = "";
	$placeHoldersdoctors_report["Danish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Danish"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Dutch")
{
	$fieldLabelsdoctors_report["Dutch"] = array();
	$fieldToolTipsdoctors_report["Dutch"] = array();
	$placeHoldersdoctors_report["Dutch"] = array();
	$pageTitlesdoctors_report["Dutch"] = array();
	$fieldLabelsdoctors_report["Dutch"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Dutch"]["id"] = "";
	$placeHoldersdoctors_report["Dutch"]["id"] = "";
	$fieldLabelsdoctors_report["Dutch"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Dutch"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Dutch"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Dutch"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Dutch"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Dutch"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Dutch"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Dutch"]["Email"] = "";
	$placeHoldersdoctors_report["Dutch"]["Email"] = "";
	$fieldLabelsdoctors_report["Dutch"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Dutch"]["Photo"] = "";
	$placeHoldersdoctors_report["Dutch"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Dutch"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Farsi")
{
	$fieldLabelsdoctors_report["Farsi"] = array();
	$fieldToolTipsdoctors_report["Farsi"] = array();
	$placeHoldersdoctors_report["Farsi"] = array();
	$pageTitlesdoctors_report["Farsi"] = array();
	$fieldLabelsdoctors_report["Farsi"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Farsi"]["id"] = "";
	$placeHoldersdoctors_report["Farsi"]["id"] = "";
	$fieldLabelsdoctors_report["Farsi"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Farsi"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Farsi"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Farsi"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Farsi"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Farsi"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Farsi"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Farsi"]["Email"] = "";
	$placeHoldersdoctors_report["Farsi"]["Email"] = "";
	$fieldLabelsdoctors_report["Farsi"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Farsi"]["Photo"] = "";
	$placeHoldersdoctors_report["Farsi"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Farsi"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="French")
{
	$fieldLabelsdoctors_report["French"] = array();
	$fieldToolTipsdoctors_report["French"] = array();
	$placeHoldersdoctors_report["French"] = array();
	$pageTitlesdoctors_report["French"] = array();
	$fieldLabelsdoctors_report["French"]["id"] = "Id";
	$fieldToolTipsdoctors_report["French"]["id"] = "";
	$placeHoldersdoctors_report["French"]["id"] = "";
	$fieldLabelsdoctors_report["French"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["French"]["DoctorName"] = "";
	$placeHoldersdoctors_report["French"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["French"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["French"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["French"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["French"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["French"]["Email"] = "";
	$placeHoldersdoctors_report["French"]["Email"] = "";
	$fieldLabelsdoctors_report["French"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["French"]["Photo"] = "";
	$placeHoldersdoctors_report["French"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["French"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Georgian")
{
	$fieldLabelsdoctors_report["Georgian"] = array();
	$fieldToolTipsdoctors_report["Georgian"] = array();
	$placeHoldersdoctors_report["Georgian"] = array();
	$pageTitlesdoctors_report["Georgian"] = array();
	$fieldLabelsdoctors_report["Georgian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Georgian"]["id"] = "";
	$placeHoldersdoctors_report["Georgian"]["id"] = "";
	$fieldLabelsdoctors_report["Georgian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Georgian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Georgian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Georgian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Georgian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Georgian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Georgian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Georgian"]["Email"] = "";
	$placeHoldersdoctors_report["Georgian"]["Email"] = "";
	$fieldLabelsdoctors_report["Georgian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Georgian"]["Photo"] = "";
	$placeHoldersdoctors_report["Georgian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Georgian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="German")
{
	$fieldLabelsdoctors_report["German"] = array();
	$fieldToolTipsdoctors_report["German"] = array();
	$placeHoldersdoctors_report["German"] = array();
	$pageTitlesdoctors_report["German"] = array();
	$fieldLabelsdoctors_report["German"]["id"] = "Id";
	$fieldToolTipsdoctors_report["German"]["id"] = "";
	$placeHoldersdoctors_report["German"]["id"] = "";
	$fieldLabelsdoctors_report["German"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["German"]["DoctorName"] = "";
	$placeHoldersdoctors_report["German"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["German"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["German"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["German"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["German"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["German"]["Email"] = "";
	$placeHoldersdoctors_report["German"]["Email"] = "";
	$fieldLabelsdoctors_report["German"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["German"]["Photo"] = "";
	$placeHoldersdoctors_report["German"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["German"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Greek")
{
	$fieldLabelsdoctors_report["Greek"] = array();
	$fieldToolTipsdoctors_report["Greek"] = array();
	$placeHoldersdoctors_report["Greek"] = array();
	$pageTitlesdoctors_report["Greek"] = array();
	$fieldLabelsdoctors_report["Greek"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Greek"]["id"] = "";
	$placeHoldersdoctors_report["Greek"]["id"] = "";
	$fieldLabelsdoctors_report["Greek"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Greek"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Greek"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Greek"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Greek"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Greek"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Greek"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Greek"]["Email"] = "";
	$placeHoldersdoctors_report["Greek"]["Email"] = "";
	$fieldLabelsdoctors_report["Greek"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Greek"]["Photo"] = "";
	$placeHoldersdoctors_report["Greek"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Greek"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hebrew")
{
	$fieldLabelsdoctors_report["Hebrew"] = array();
	$fieldToolTipsdoctors_report["Hebrew"] = array();
	$placeHoldersdoctors_report["Hebrew"] = array();
	$pageTitlesdoctors_report["Hebrew"] = array();
	$fieldLabelsdoctors_report["Hebrew"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Hebrew"]["id"] = "";
	$placeHoldersdoctors_report["Hebrew"]["id"] = "";
	$fieldLabelsdoctors_report["Hebrew"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Hebrew"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Hebrew"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Hebrew"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Hebrew"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Hebrew"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Hebrew"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Hebrew"]["Email"] = "";
	$placeHoldersdoctors_report["Hebrew"]["Email"] = "";
	$fieldLabelsdoctors_report["Hebrew"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Hebrew"]["Photo"] = "";
	$placeHoldersdoctors_report["Hebrew"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Hebrew"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Hungarian")
{
	$fieldLabelsdoctors_report["Hungarian"] = array();
	$fieldToolTipsdoctors_report["Hungarian"] = array();
	$placeHoldersdoctors_report["Hungarian"] = array();
	$pageTitlesdoctors_report["Hungarian"] = array();
	$fieldLabelsdoctors_report["Hungarian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Hungarian"]["id"] = "";
	$placeHoldersdoctors_report["Hungarian"]["id"] = "";
	$fieldLabelsdoctors_report["Hungarian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Hungarian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Hungarian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Hungarian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Hungarian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Hungarian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Hungarian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Hungarian"]["Email"] = "";
	$placeHoldersdoctors_report["Hungarian"]["Email"] = "";
	$fieldLabelsdoctors_report["Hungarian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Hungarian"]["Photo"] = "";
	$placeHoldersdoctors_report["Hungarian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Hungarian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsdoctors_report["Indonesian"] = array();
	$fieldToolTipsdoctors_report["Indonesian"] = array();
	$placeHoldersdoctors_report["Indonesian"] = array();
	$pageTitlesdoctors_report["Indonesian"] = array();
	$fieldLabelsdoctors_report["Indonesian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Indonesian"]["id"] = "";
	$placeHoldersdoctors_report["Indonesian"]["id"] = "";
	$fieldLabelsdoctors_report["Indonesian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Indonesian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Indonesian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Indonesian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Indonesian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Indonesian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Indonesian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Indonesian"]["Email"] = "";
	$placeHoldersdoctors_report["Indonesian"]["Email"] = "";
	$fieldLabelsdoctors_report["Indonesian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Indonesian"]["Photo"] = "";
	$placeHoldersdoctors_report["Indonesian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Indonesian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Italian")
{
	$fieldLabelsdoctors_report["Italian"] = array();
	$fieldToolTipsdoctors_report["Italian"] = array();
	$placeHoldersdoctors_report["Italian"] = array();
	$pageTitlesdoctors_report["Italian"] = array();
	$fieldLabelsdoctors_report["Italian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Italian"]["id"] = "";
	$placeHoldersdoctors_report["Italian"]["id"] = "";
	$fieldLabelsdoctors_report["Italian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Italian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Italian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Italian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Italian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Italian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Italian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Italian"]["Email"] = "";
	$placeHoldersdoctors_report["Italian"]["Email"] = "";
	$fieldLabelsdoctors_report["Italian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Italian"]["Photo"] = "";
	$placeHoldersdoctors_report["Italian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Italian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Japanese")
{
	$fieldLabelsdoctors_report["Japanese"] = array();
	$fieldToolTipsdoctors_report["Japanese"] = array();
	$placeHoldersdoctors_report["Japanese"] = array();
	$pageTitlesdoctors_report["Japanese"] = array();
	$fieldLabelsdoctors_report["Japanese"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Japanese"]["id"] = "";
	$placeHoldersdoctors_report["Japanese"]["id"] = "";
	$fieldLabelsdoctors_report["Japanese"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Japanese"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Japanese"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Japanese"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Japanese"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Japanese"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Japanese"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Japanese"]["Email"] = "";
	$placeHoldersdoctors_report["Japanese"]["Email"] = "";
	$fieldLabelsdoctors_report["Japanese"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Japanese"]["Photo"] = "";
	$placeHoldersdoctors_report["Japanese"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Japanese"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Malay")
{
	$fieldLabelsdoctors_report["Malay"] = array();
	$fieldToolTipsdoctors_report["Malay"] = array();
	$placeHoldersdoctors_report["Malay"] = array();
	$pageTitlesdoctors_report["Malay"] = array();
	$fieldLabelsdoctors_report["Malay"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Malay"]["id"] = "";
	$placeHoldersdoctors_report["Malay"]["id"] = "";
	$fieldLabelsdoctors_report["Malay"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Malay"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Malay"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Malay"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Malay"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Malay"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Malay"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Malay"]["Email"] = "";
	$placeHoldersdoctors_report["Malay"]["Email"] = "";
	$fieldLabelsdoctors_report["Malay"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Malay"]["Photo"] = "";
	$placeHoldersdoctors_report["Malay"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Malay"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Norwegian(Bokmal)")
{
	$fieldLabelsdoctors_report["Norwegian(Bokmal)"] = array();
	$fieldToolTipsdoctors_report["Norwegian(Bokmal)"] = array();
	$placeHoldersdoctors_report["Norwegian(Bokmal)"] = array();
	$pageTitlesdoctors_report["Norwegian(Bokmal)"] = array();
	$fieldLabelsdoctors_report["Norwegian(Bokmal)"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Norwegian(Bokmal)"]["id"] = "";
	$placeHoldersdoctors_report["Norwegian(Bokmal)"]["id"] = "";
	$fieldLabelsdoctors_report["Norwegian(Bokmal)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Norwegian(Bokmal)"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Norwegian(Bokmal)"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Norwegian(Bokmal)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Norwegian(Bokmal)"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Norwegian(Bokmal)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Norwegian(Bokmal)"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Norwegian(Bokmal)"]["Email"] = "";
	$placeHoldersdoctors_report["Norwegian(Bokmal)"]["Email"] = "";
	$fieldLabelsdoctors_report["Norwegian(Bokmal)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Norwegian(Bokmal)"]["Photo"] = "";
	$placeHoldersdoctors_report["Norwegian(Bokmal)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Norwegian(Bokmal)"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Polish")
{
	$fieldLabelsdoctors_report["Polish"] = array();
	$fieldToolTipsdoctors_report["Polish"] = array();
	$placeHoldersdoctors_report["Polish"] = array();
	$pageTitlesdoctors_report["Polish"] = array();
	$fieldLabelsdoctors_report["Polish"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Polish"]["id"] = "";
	$placeHoldersdoctors_report["Polish"]["id"] = "";
	$fieldLabelsdoctors_report["Polish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Polish"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Polish"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Polish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Polish"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Polish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Polish"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Polish"]["Email"] = "";
	$placeHoldersdoctors_report["Polish"]["Email"] = "";
	$fieldLabelsdoctors_report["Polish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Polish"]["Photo"] = "";
	$placeHoldersdoctors_report["Polish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Polish"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Brazil)")
{
	$fieldLabelsdoctors_report["Portuguese(Brazil)"] = array();
	$fieldToolTipsdoctors_report["Portuguese(Brazil)"] = array();
	$placeHoldersdoctors_report["Portuguese(Brazil)"] = array();
	$pageTitlesdoctors_report["Portuguese(Brazil)"] = array();
	$fieldLabelsdoctors_report["Portuguese(Brazil)"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Portuguese(Brazil)"]["id"] = "";
	$placeHoldersdoctors_report["Portuguese(Brazil)"]["id"] = "";
	$fieldLabelsdoctors_report["Portuguese(Brazil)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Portuguese(Brazil)"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Portuguese(Brazil)"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Portuguese(Brazil)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Portuguese(Brazil)"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Portuguese(Brazil)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Portuguese(Brazil)"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Portuguese(Brazil)"]["Email"] = "";
	$placeHoldersdoctors_report["Portuguese(Brazil)"]["Email"] = "";
	$fieldLabelsdoctors_report["Portuguese(Brazil)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Portuguese(Brazil)"]["Photo"] = "";
	$placeHoldersdoctors_report["Portuguese(Brazil)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Portuguese(Brazil)"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Portuguese(Standard)")
{
	$fieldLabelsdoctors_report["Portuguese(Standard)"] = array();
	$fieldToolTipsdoctors_report["Portuguese(Standard)"] = array();
	$placeHoldersdoctors_report["Portuguese(Standard)"] = array();
	$pageTitlesdoctors_report["Portuguese(Standard)"] = array();
	$fieldLabelsdoctors_report["Portuguese(Standard)"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Portuguese(Standard)"]["id"] = "";
	$placeHoldersdoctors_report["Portuguese(Standard)"]["id"] = "";
	$fieldLabelsdoctors_report["Portuguese(Standard)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Portuguese(Standard)"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Portuguese(Standard)"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Portuguese(Standard)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Portuguese(Standard)"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Portuguese(Standard)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Portuguese(Standard)"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Portuguese(Standard)"]["Email"] = "";
	$placeHoldersdoctors_report["Portuguese(Standard)"]["Email"] = "";
	$fieldLabelsdoctors_report["Portuguese(Standard)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Portuguese(Standard)"]["Photo"] = "";
	$placeHoldersdoctors_report["Portuguese(Standard)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Portuguese(Standard)"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Romanian")
{
	$fieldLabelsdoctors_report["Romanian"] = array();
	$fieldToolTipsdoctors_report["Romanian"] = array();
	$placeHoldersdoctors_report["Romanian"] = array();
	$pageTitlesdoctors_report["Romanian"] = array();
	$fieldLabelsdoctors_report["Romanian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Romanian"]["id"] = "";
	$placeHoldersdoctors_report["Romanian"]["id"] = "";
	$fieldLabelsdoctors_report["Romanian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Romanian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Romanian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Romanian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Romanian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Romanian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Romanian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Romanian"]["Email"] = "";
	$placeHoldersdoctors_report["Romanian"]["Email"] = "";
	$fieldLabelsdoctors_report["Romanian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Romanian"]["Photo"] = "";
	$placeHoldersdoctors_report["Romanian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Romanian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Russian")
{
	$fieldLabelsdoctors_report["Russian"] = array();
	$fieldToolTipsdoctors_report["Russian"] = array();
	$placeHoldersdoctors_report["Russian"] = array();
	$pageTitlesdoctors_report["Russian"] = array();
	$fieldLabelsdoctors_report["Russian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Russian"]["id"] = "";
	$placeHoldersdoctors_report["Russian"]["id"] = "";
	$fieldLabelsdoctors_report["Russian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Russian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Russian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Russian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Russian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Russian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Russian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Russian"]["Email"] = "";
	$placeHoldersdoctors_report["Russian"]["Email"] = "";
	$fieldLabelsdoctors_report["Russian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Russian"]["Photo"] = "";
	$placeHoldersdoctors_report["Russian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Russian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Serbian")
{
	$fieldLabelsdoctors_report["Serbian"] = array();
	$fieldToolTipsdoctors_report["Serbian"] = array();
	$placeHoldersdoctors_report["Serbian"] = array();
	$pageTitlesdoctors_report["Serbian"] = array();
	$fieldLabelsdoctors_report["Serbian"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Serbian"]["id"] = "";
	$placeHoldersdoctors_report["Serbian"]["id"] = "";
	$fieldLabelsdoctors_report["Serbian"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Serbian"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Serbian"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Serbian"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Serbian"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Serbian"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Serbian"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Serbian"]["Email"] = "";
	$placeHoldersdoctors_report["Serbian"]["Email"] = "";
	$fieldLabelsdoctors_report["Serbian"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Serbian"]["Photo"] = "";
	$placeHoldersdoctors_report["Serbian"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Serbian"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Slovak")
{
	$fieldLabelsdoctors_report["Slovak"] = array();
	$fieldToolTipsdoctors_report["Slovak"] = array();
	$placeHoldersdoctors_report["Slovak"] = array();
	$pageTitlesdoctors_report["Slovak"] = array();
	$fieldLabelsdoctors_report["Slovak"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Slovak"]["id"] = "";
	$placeHoldersdoctors_report["Slovak"]["id"] = "";
	$fieldLabelsdoctors_report["Slovak"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Slovak"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Slovak"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Slovak"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Slovak"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Slovak"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Slovak"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Slovak"]["Email"] = "";
	$placeHoldersdoctors_report["Slovak"]["Email"] = "";
	$fieldLabelsdoctors_report["Slovak"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Slovak"]["Photo"] = "";
	$placeHoldersdoctors_report["Slovak"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Slovak"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsdoctors_report["Spanish"] = array();
	$fieldToolTipsdoctors_report["Spanish"] = array();
	$placeHoldersdoctors_report["Spanish"] = array();
	$pageTitlesdoctors_report["Spanish"] = array();
	$fieldLabelsdoctors_report["Spanish"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Spanish"]["id"] = "";
	$placeHoldersdoctors_report["Spanish"]["id"] = "";
	$fieldLabelsdoctors_report["Spanish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Spanish"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Spanish"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Spanish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Spanish"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Spanish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Spanish"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Spanish"]["Email"] = "";
	$placeHoldersdoctors_report["Spanish"]["Email"] = "";
	$fieldLabelsdoctors_report["Spanish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Spanish"]["Photo"] = "";
	$placeHoldersdoctors_report["Spanish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Spanish"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Swedish")
{
	$fieldLabelsdoctors_report["Swedish"] = array();
	$fieldToolTipsdoctors_report["Swedish"] = array();
	$placeHoldersdoctors_report["Swedish"] = array();
	$pageTitlesdoctors_report["Swedish"] = array();
	$fieldLabelsdoctors_report["Swedish"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Swedish"]["id"] = "";
	$placeHoldersdoctors_report["Swedish"]["id"] = "";
	$fieldLabelsdoctors_report["Swedish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Swedish"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Swedish"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Swedish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Swedish"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Swedish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Swedish"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Swedish"]["Email"] = "";
	$placeHoldersdoctors_report["Swedish"]["Email"] = "";
	$fieldLabelsdoctors_report["Swedish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Swedish"]["Photo"] = "";
	$placeHoldersdoctors_report["Swedish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Swedish"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Tagalog(Philippines)")
{
	$fieldLabelsdoctors_report["Tagalog(Philippines)"] = array();
	$fieldToolTipsdoctors_report["Tagalog(Philippines)"] = array();
	$placeHoldersdoctors_report["Tagalog(Philippines)"] = array();
	$pageTitlesdoctors_report["Tagalog(Philippines)"] = array();
	$fieldLabelsdoctors_report["Tagalog(Philippines)"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Tagalog(Philippines)"]["id"] = "";
	$placeHoldersdoctors_report["Tagalog(Philippines)"]["id"] = "";
	$fieldLabelsdoctors_report["Tagalog(Philippines)"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Tagalog(Philippines)"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Tagalog(Philippines)"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Tagalog(Philippines)"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Tagalog(Philippines)"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Tagalog(Philippines)"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Tagalog(Philippines)"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Tagalog(Philippines)"]["Email"] = "";
	$placeHoldersdoctors_report["Tagalog(Philippines)"]["Email"] = "";
	$fieldLabelsdoctors_report["Tagalog(Philippines)"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Tagalog(Philippines)"]["Photo"] = "";
	$placeHoldersdoctors_report["Tagalog(Philippines)"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Tagalog(Philippines)"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Thai")
{
	$fieldLabelsdoctors_report["Thai"] = array();
	$fieldToolTipsdoctors_report["Thai"] = array();
	$placeHoldersdoctors_report["Thai"] = array();
	$pageTitlesdoctors_report["Thai"] = array();
	$fieldLabelsdoctors_report["Thai"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Thai"]["id"] = "";
	$placeHoldersdoctors_report["Thai"]["id"] = "";
	$fieldLabelsdoctors_report["Thai"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Thai"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Thai"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Thai"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Thai"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Thai"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Thai"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Thai"]["Email"] = "";
	$placeHoldersdoctors_report["Thai"]["Email"] = "";
	$fieldLabelsdoctors_report["Thai"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Thai"]["Photo"] = "";
	$placeHoldersdoctors_report["Thai"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Thai"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Turkish")
{
	$fieldLabelsdoctors_report["Turkish"] = array();
	$fieldToolTipsdoctors_report["Turkish"] = array();
	$placeHoldersdoctors_report["Turkish"] = array();
	$pageTitlesdoctors_report["Turkish"] = array();
	$fieldLabelsdoctors_report["Turkish"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Turkish"]["id"] = "";
	$placeHoldersdoctors_report["Turkish"]["id"] = "";
	$fieldLabelsdoctors_report["Turkish"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Turkish"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Turkish"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Turkish"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Turkish"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Turkish"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Turkish"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Turkish"]["Email"] = "";
	$placeHoldersdoctors_report["Turkish"]["Email"] = "";
	$fieldLabelsdoctors_report["Turkish"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Turkish"]["Photo"] = "";
	$placeHoldersdoctors_report["Turkish"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Turkish"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Urdu")
{
	$fieldLabelsdoctors_report["Urdu"] = array();
	$fieldToolTipsdoctors_report["Urdu"] = array();
	$placeHoldersdoctors_report["Urdu"] = array();
	$pageTitlesdoctors_report["Urdu"] = array();
	$fieldLabelsdoctors_report["Urdu"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Urdu"]["id"] = "";
	$placeHoldersdoctors_report["Urdu"]["id"] = "";
	$fieldLabelsdoctors_report["Urdu"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Urdu"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Urdu"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Urdu"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Urdu"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Urdu"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Urdu"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Urdu"]["Email"] = "";
	$placeHoldersdoctors_report["Urdu"]["Email"] = "";
	$fieldLabelsdoctors_report["Urdu"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Urdu"]["Photo"] = "";
	$placeHoldersdoctors_report["Urdu"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Urdu"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Welsh")
{
	$fieldLabelsdoctors_report["Welsh"] = array();
	$fieldToolTipsdoctors_report["Welsh"] = array();
	$placeHoldersdoctors_report["Welsh"] = array();
	$pageTitlesdoctors_report["Welsh"] = array();
	$fieldLabelsdoctors_report["Welsh"]["id"] = "Id";
	$fieldToolTipsdoctors_report["Welsh"]["id"] = "";
	$placeHoldersdoctors_report["Welsh"]["id"] = "";
	$fieldLabelsdoctors_report["Welsh"]["DoctorName"] = "Doctor Name";
	$fieldToolTipsdoctors_report["Welsh"]["DoctorName"] = "";
	$placeHoldersdoctors_report["Welsh"]["DoctorName"] = "";
	$fieldLabelsdoctors_report["Welsh"]["ContactNumber"] = "Contact Number";
	$fieldToolTipsdoctors_report["Welsh"]["ContactNumber"] = "";
	$placeHoldersdoctors_report["Welsh"]["ContactNumber"] = "";
	$fieldLabelsdoctors_report["Welsh"]["Email"] = "Email";
	$fieldToolTipsdoctors_report["Welsh"]["Email"] = "";
	$placeHoldersdoctors_report["Welsh"]["Email"] = "";
	$fieldLabelsdoctors_report["Welsh"]["Photo"] = "Photo";
	$fieldToolTipsdoctors_report["Welsh"]["Photo"] = "";
	$placeHoldersdoctors_report["Welsh"]["Photo"] = "";
	if (count($fieldToolTipsdoctors_report["Welsh"]))
		$tdatadoctors_report[".isUseToolTips"] = true;
}


	$tdatadoctors_report[".NCSearch"] = true;



$tdatadoctors_report[".shortTableName"] = "doctors_report";
$tdatadoctors_report[".nSecOptions"] = 0;

$tdatadoctors_report[".mainTableOwnerID"] = "";
$tdatadoctors_report[".entityType"] = 2;
$tdatadoctors_report[".connId"] = "testdb_at_localhost";


$tdatadoctors_report[".strOriginalTableName"] = "doctors";

	



$tdatadoctors_report[".showAddInPopup"] = false;

$tdatadoctors_report[".showEditInPopup"] = false;

$tdatadoctors_report[".showViewInPopup"] = false;

$tdatadoctors_report[".listAjax"] = false;
//	temporary
//$tdatadoctors_report[".listAjax"] = false;

	$tdatadoctors_report[".audit"] = false;

	$tdatadoctors_report[".locking"] = false;


$pages = $tdatadoctors_report[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatadoctors_report[".edit"] = true;
	$tdatadoctors_report[".afterEditAction"] = 1;
	$tdatadoctors_report[".closePopupAfterEdit"] = 1;
	$tdatadoctors_report[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatadoctors_report[".add"] = true;
$tdatadoctors_report[".afterAddAction"] = 1;
$tdatadoctors_report[".closePopupAfterAdd"] = 1;
$tdatadoctors_report[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatadoctors_report[".list"] = true;
}



$tdatadoctors_report[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatadoctors_report[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatadoctors_report[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatadoctors_report[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatadoctors_report[".printFriendly"] = true;
}



$tdatadoctors_report[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatadoctors_report[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatadoctors_report[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatadoctors_report[".isUseAjaxSuggest"] = true;





$tdatadoctors_report[".ajaxCodeSnippetAdded"] = false;

$tdatadoctors_report[".buttonsAdded"] = false;

$tdatadoctors_report[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadoctors_report[".isUseTimeForSearch"] = false;


$tdatadoctors_report[".badgeColor"] = "DAA520";


$tdatadoctors_report[".allSearchFields"] = array();
$tdatadoctors_report[".filterFields"] = array();
$tdatadoctors_report[".requiredSearchFields"] = array();

$tdatadoctors_report[".googleLikeFields"] = array();
$tdatadoctors_report[".googleLikeFields"][] = "id";
$tdatadoctors_report[".googleLikeFields"][] = "DoctorName";
$tdatadoctors_report[".googleLikeFields"][] = "ContactNumber";
$tdatadoctors_report[".googleLikeFields"][] = "Email";
$tdatadoctors_report[".googleLikeFields"][] = "Photo";



$tdatadoctors_report[".tableType"] = "report";

$tdatadoctors_report[".printerPageOrientation"] = 0;
$tdatadoctors_report[".nPrinterPageScale"] = 100;

$tdatadoctors_report[".nPrinterSplitRecords"] = 40;

$tdatadoctors_report[".geocodingEnabled"] = false;

//report settings

$tdatadoctors_report[".reportPrintGroupsPerPage"] = 3;
$tdatadoctors_report[".reportPrintRecordsPerPage"] = 40;

$tdatadoctors_report[".pageSizeGroups"] = 5;
$tdatadoctors_report[".pageSizeRecords"] = 20;


//end of report settings



$tdatadoctors_report[".isDisplayLoading"] = true;







$tstrOrderBy = "";
$tdatadoctors_report[".strOrderBy"] = $tstrOrderBy;

$tdatadoctors_report[".orderindexes"] = array();


$tdatadoctors_report[".sqlHead"] = "SELECT id,  	DoctorName,  	ContactNumber,  	Email,  	Photo";
$tdatadoctors_report[".sqlFrom"] = "FROM doctors";
$tdatadoctors_report[".sqlWhereExpr"] = "";
$tdatadoctors_report[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadoctors_report[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadoctors_report[".arrGroupsPerPage"] = $arrGPP;

$tdatadoctors_report[".highlightSearchResults"] = true;

$tableKeysdoctors_report = array();
$tableKeysdoctors_report[] = "id";
$tdatadoctors_report[".Keys"] = $tableKeysdoctors_report;


$tdatadoctors_report[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Report","id");
	$fdata["FieldType"] = 20;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_report["id"] = $fdata;
		$tdatadoctors_report[".searchableFields"][] = "id";
//	DoctorName
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "DoctorName";
	$fdata["GoodName"] = "DoctorName";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Report","DoctorName");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "DoctorName";

		$fdata["sourceSingle"] = "DoctorName";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "DoctorName";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_report["DoctorName"] = $fdata;
		$tdatadoctors_report[".searchableFields"][] = "DoctorName";
//	ContactNumber
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "ContactNumber";
	$fdata["GoodName"] = "ContactNumber";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Report","ContactNumber");
	$fdata["FieldType"] = 3;


	
	
			

		$fdata["strField"] = "ContactNumber";

		$fdata["sourceSingle"] = "ContactNumber";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ContactNumber";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_report["ContactNumber"] = $fdata;
		$tdatadoctors_report[".searchableFields"][] = "ContactNumber";
//	Email
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Email";
	$fdata["GoodName"] = "Email";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Report","Email");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Email";

		$fdata["sourceSingle"] = "Email";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Email";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=255";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_report["Email"] = $fdata;
		$tdatadoctors_report[".searchableFields"][] = "Email";
//	Photo
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Photo";
	$fdata["GoodName"] = "Photo";
	$fdata["ownerTable"] = "doctors";
	$fdata["Label"] = GetFieldLabel("doctors_Report","Photo");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Photo";

		$fdata["sourceSingle"] = "Photo";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Photo";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "File-based Image");

	
	
				$vdata["ImageWidth"] = 600;
	$vdata["ImageHeight"] = 400;

			$vdata["multipleImgMode"] = 1;
	$vdata["maxImages"] = 0;

			$vdata["showGallery"] = true;
	$vdata["galleryMode"] = 2;
	$vdata["captionMode"] = 2;
	$vdata["captionField"] = "";

	$vdata["imageBorder"] = 1;
	$vdata["imageFullWidth"] = 1;


	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
	
	
	
	
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatadoctors_report["Photo"] = $fdata;
		$tdatadoctors_report[".searchableFields"][] = "Photo";


$tables_data["doctors Report"]=&$tdatadoctors_report;
$field_labels["doctors_Report"] = &$fieldLabelsdoctors_report;
$fieldToolTips["doctors_Report"] = &$fieldToolTipsdoctors_report;
$placeHolders["doctors_Report"] = &$placeHoldersdoctors_report;
$page_titles["doctors_Report"] = &$pageTitlesdoctors_report;


changeTextControlsToDate( "doctors Report" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["doctors Report"] = array();
//	treatments
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="treatments";
		$detailsParam["dOriginalTable"] = "treatments";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "treatments";
	$detailsParam["dCaptionTable"] = GetTableCaption("treatments");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["doctors Report"][$dIndex] = $detailsParam;

	
		$detailsTablesData["doctors Report"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["doctors Report"][$dIndex]["masterKeys"][]="id";

				$detailsTablesData["doctors Report"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["doctors Report"][$dIndex]["detailKeys"][]="doctor_id";
//endif

// tables which are master tables for current table (detail)
$masterTablesData["doctors Report"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_doctors_report()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	DoctorName,  	ContactNumber,  	Email,  	Photo";
$proto0["m_strFrom"] = "FROM doctors";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Report"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "doctors Report";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "DoctorName",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Report"
));

$proto8["m_sql"] = "DoctorName";
$proto8["m_srcTableName"] = "doctors Report";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "ContactNumber",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Report"
));

$proto10["m_sql"] = "ContactNumber";
$proto10["m_srcTableName"] = "doctors Report";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Email",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Report"
));

$proto12["m_sql"] = "Email";
$proto12["m_srcTableName"] = "doctors Report";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Photo",
	"m_strTable" => "doctors",
	"m_srcTableName" => "doctors Report"
));

$proto14["m_sql"] = "Photo";
$proto14["m_srcTableName"] = "doctors Report";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "doctors";
$proto17["m_srcTableName"] = "doctors Report";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "id";
$proto17["m_columns"][] = "DoctorName";
$proto17["m_columns"][] = "ContactNumber";
$proto17["m_columns"][] = "Email";
$proto17["m_columns"][] = "Photo";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "doctors";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "doctors Report";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="doctors Report";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_doctors_report = createSqlQuery_doctors_report();


	
		;

					

$tdatadoctors_report[".sqlquery"] = $queryData_doctors_report;



$tdatadoctors_report[".hasEvents"] = false;

?>