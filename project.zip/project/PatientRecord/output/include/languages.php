<?php

$langfile="";
if(mlang_getcurrentlang() == "Afrikaans")
	$langfile="Afrikaans.php";
if(mlang_getcurrentlang() == "Arabic")
	$langfile="Arabic.php";
if(mlang_getcurrentlang() == "Bosnian")
	$langfile="Bosnian.php";
if(mlang_getcurrentlang() == "Bulgarian")
	$langfile="Bulgarian.php";
if(mlang_getcurrentlang() == "Catalan")
	$langfile="Catalan.php";
if(mlang_getcurrentlang() == "Chinese")
	$langfile="Chinese.php";
if(mlang_getcurrentlang() == "Chinese (Hong Kong S.A.R.)")
	$langfile="Hongkong.php";
if(mlang_getcurrentlang() == "Chinese (Taiwan)")
	$langfile="Taiwan.php";
if(mlang_getcurrentlang() == "Croatian")
	$langfile="Croatian.php";
if(mlang_getcurrentlang() == "Czech")
	$langfile="Czech.php";
if(mlang_getcurrentlang() == "Danish")
	$langfile="Danish.php";
if(mlang_getcurrentlang() == "Dutch")
	$langfile="Dutch.php";
if(mlang_getcurrentlang() == "English")
	$langfile="English.php";
if(mlang_getcurrentlang() == "Farsi")
	$langfile="Farsi.php";
if(mlang_getcurrentlang() == "French")
	$langfile="French.php";
if(mlang_getcurrentlang() == "Georgian")
	$langfile="Georgian.php";
if(mlang_getcurrentlang() == "German")
	$langfile="German.php";
if(mlang_getcurrentlang() == "Greek")
	$langfile="Greek.php";
if(mlang_getcurrentlang() == "Hebrew")
	$langfile="Hebrew.php";
if(mlang_getcurrentlang() == "Hungarian")
	$langfile="Hungarian.php";
if(mlang_getcurrentlang() == "Indonesian")
	$langfile="Indonesian.php";
if(mlang_getcurrentlang() == "Italian")
	$langfile="Italian.php";
if(mlang_getcurrentlang() == "Japanese")
	$langfile="Japanese.php";
if(mlang_getcurrentlang() == "Malay")
	$langfile="Malay.php";
if(mlang_getcurrentlang() == "Norwegian(Bokmal)")
	$langfile="Norwegian.php";
if(mlang_getcurrentlang() == "Polish")
	$langfile="Polish.php";
if(mlang_getcurrentlang() == "Portuguese(Brazil)")
	$langfile="Portuguese.php";
if(mlang_getcurrentlang() == "Portuguese(Standard)")
	$langfile="Portugal.php";
if(mlang_getcurrentlang() == "Romanian")
	$langfile="Romanian.php";
if(mlang_getcurrentlang() == "Russian")
	$langfile="Russian.php";
if(mlang_getcurrentlang() == "Serbian")
	$langfile="Srpski.php";
if(mlang_getcurrentlang() == "Slovak")
	$langfile="Slovak.php";
if(mlang_getcurrentlang() == "Spanish")
	$langfile="Spanish.php";
if(mlang_getcurrentlang() == "Swedish")
	$langfile="Swedish.php";
if(mlang_getcurrentlang() == "Tagalog(Philippines)")
	$langfile="Phillipines.php";
if(mlang_getcurrentlang() == "Thai")
	$langfile="Thai.php";
if(mlang_getcurrentlang() == "Turkish")
	$langfile="Turkish.php";
if(mlang_getcurrentlang() == "Urdu")
	$langfile="Urdu.php";
if(mlang_getcurrentlang() == "Welsh")
	$langfile="Welsh.php";

if($langfile)
	include(getabspath("include/lang/".$langfile));

function mlang_message($tag)
{
	global $mlang_messages,$mlang_defaultlang;
	return @$mlang_messages[mlang_getcurrentlang()][$tag];
}

?>